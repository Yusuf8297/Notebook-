import os, sys, random
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import numpy as np, torch
from gemm.grammar import Grammar
from gemm.models import FusionModel
from gemm.spec import BASELINES
from gemm.data import make_synthetic, make_splits
from gemm.fitness import evaluate
from gemm.stats import delong_test, holm

G = Grammar.from_file(os.path.join(os.path.dirname(__file__), "..", "grammar", "fusion.bnf"))
XI, XR, Y = torch.randn(32, 64), torch.randn(32, 48), torch.randint(0, 2, (32,))


def _check(spec):
    m = FusionModel(spec, 64, 48)
    t = m.training_loss(XI, XR, Y)
    assert torch.isfinite(t["total"])
    t["total"].backward()
    assert m(XI, None)["logit"].shape == (32,)
    assert m(XI, XR, torch.rand(32) > 0.5)["logit"].shape == (32,)


def test_baselines_build_and_train():
    for spec in BASELINES.values():
        _check(spec)


def test_random_specs_build_and_train():
    for s in range(40):
        r = random.Random(s)
        d = G.map([r.randint(0, 255) for _ in range(200)])
        if d.valid:
            _check(d.spec())


def test_missing_rna_uses_imputed_shared_latent():
    m = FusionModel(BASELINES["uhler_hand"], 64, 48).eval()
    z = m.encode(XI, None)
    assert torch.allclose(z["zs_r"], z["zs_i"]) and z["zp_r"].abs().sum() == 0


def test_fitness_on_synthetic():
    c = make_synthetic(200, seed=3)
    sp = next(make_splits(c, n_outer=3))
    f = evaluate(BASELINES["early_concat"], sp, time_budget_s=10)
    assert f.valid and 0 <= f.values["val_auc"] <= 1
    assert evaluate(None, sp).valid is False


def test_delong_and_holm():
    rng = np.random.RandomState(0)
    y = rng.randint(0, 2, 300)
    p1 = y + rng.randn(300) * 0.8
    p2 = rng.randn(300)
    a1, a2, p = delong_test(y, p1, p2)
    assert a1 > a2 and p < 0.01
    assert holm([0.01, 0.04, 0.03]) == [0.03, 0.06, 0.06]
