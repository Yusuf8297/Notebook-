import json, random, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from gemm.grammar import Grammar
from gemm.spec import validate, principle_flags

G = Grammar.from_file(os.path.join(os.path.dirname(__file__), "..", "grammar", "fusion.bnf"))


def test_random_genomes_map_to_valid_json():
    ok = 0
    for s in range(300):
        r = random.Random(s)
        d = G.map([r.randint(0, 255) for _ in range(200)])
        if d.valid:
            spec = json.loads(d.phenotype)
            validate(spec)
            principle_flags(spec)
            ok += 1
    assert ok > 280


def test_choices_are_recorded():
    d = G.map([7] * 200)
    assert d.valid and d.choices and d.choices[0][0] == "<model>"


def test_override_restricts_grammar():
    g2 = G.override({"<align>": "null"})
    for s in range(50):
        r = random.Random(s)
        d = g2.map([r.randint(0, 255) for _ in range(200)])
        if d.valid:
            assert json.loads(d.phenotype)["loss"]["align"] is None


def test_wrapping_exhaustion_is_invalid():
    d = G.map([1], max_wraps=0)
    assert not d.valid
