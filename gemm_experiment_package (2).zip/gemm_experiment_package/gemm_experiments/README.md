# GEMM — Grammatical Evolution of causally-principled Multimodal fusion for cancer detection

Experiment package for the study *Does evolution rediscover causal principles? Grammar-guided search
over partially shared latent spaces for histology–transcriptomics cancer detection*, built on the four
design principles from Caroline Uhler's CCAIM 2026 lecture *Causal principles for multi-modal data
integration and translation*.

The idea in one paragraph: hand-designed multimodal cancer models fix the fusion topology. Here a BNF
grammar spans a space that contains both the principled designs (contrastive alignment, partially shared
latents, image-conditioning with modality dropout, directed attention) and their violations. Grammatical
evolution with NSGA-II searches that space under four objectives (detection AUROC, held-out-institution
AUROC, batch-invariance of the shared latent, AUROC with RNA absent) over frozen foundation-model
embeddings. The paper then asks (i) whether evolved models beat the hand-designed ones, internally and
on an external cohort; (ii) whether omics knowledge gets distilled into an H&E-only-at-inference model;
(iii) whether the principled productions are enriched among Pareto-optimal models and whether removing
them from the grammar hurts; and (iv) whether the evolved shared/specific latent split matches model-free
estimates of shared information and separates biology (hypoxia vs proliferation) the way theory predicts.

## Layout

```
grammar/fusion.bnf            the search space (each Uhler principle is one production among alternatives)
configs/synthetic_smoke.yaml  10-minute end-to-end run on synthetic data
configs/tcga_full.yaml        full-scale config (copy per cancer type)
src/gemm/
  grammar.py     BNF parser + GE mapper (records every production choice)
  spec.py        phenotype schema, principle flags, hand-designed BASELINES in the same language
  models.py      spec -> PyTorch: partitioned latent, fusion ops (concat/gated/xattn/cond/single), heads
  losses.py      InfoNCE, adversarial (GRL) alignment, HSIC / orthogonality / MMD disentanglement
  data.py        Cohort .npz format, patient/site-aware nested splits, SyntheticWorld with causal latents
  train.py       time-boxed training, AUROC/AUPRC/ECE, site-probe (batch identifiability)
  fitness.py     the four NSGA-II objectives (+ parsimony tie-break)
  evolution.py   GE + NSGA-II, evaluation log (jsonl), pre-registered final-selection rule
  analysis.py    production enrichment, motifs, out-of-sample CCA rank & MI, hallmark probes, hypervolume
  stats.py       DeLong, Holm, Mann-Whitney + Cliff's delta, bootstrap CIs, enrichment test
  report.py      tables E1-E7 -> analysis/report.md
  embeddings/    real-data pipeline: wsi_embed.py (UNI/CONCH), rna_embed.py, build_cohort.py, build_hest.py
notebooks/main_experiment.ipynb   the main experiment as a notebook (executed; synthetic preset)
build_notebook.py                 regenerates that notebook
scripts/         thin CLIs: make_synthetic, run_baselines, run_evolution, run_ablations, run_final, run_analysis
tests/           pytest (grammar validity, every fusion op builds/trains, fitness, DeLong/Holm)
docs/readiness_assessment.md  verdict on the local run, the simulation-stage results, and the path to submission
manuscript/      manuscript.docx / .pdf generated from results/study by scripts/make_manuscript.py
scripts/make_synthetic_study.py, run_study.sh, reselect_winners.py, summarize_study.py   the multi-world simulation study
docs/            protocol.md (full experimental protocol), preregistration.md (OSF template), data_access.md
```

## Quick start

Unzip so the top-level folder is `gemm_experiments/` (the Python package itself is `src/gemm`; do not rename the repo folder to `gemm`, it would shadow the package as a namespace package).

```bash
pip install -r requirements.txt
python -m pytest -q tests
bash scripts/smoke_test.sh          # synthetic data, ~10-15 min on 2 CPU cores
# or open notebooks/main_experiment.ipynb and run all cells (same pipeline, with figures)
cat results/synthetic_smoke/analysis/report.md
```

The smoke config (12 individuals × 3 generations, 20 s per candidate) exists to validate the pipeline, not
to produce meaningful evolved models; with those settings the winners are selected on a 70-sample
validation fold and will look worse than the baselines on test. That is expected.

## Running the real study

1. Build cohorts (see `docs/data_access.md`): `data/tcga_<cancer>.npz`, `data/cptac_<cancer>.npz`,
   `data/hest_<organs>.npz`. Each is `(img, rna, y, patient, site, hallmark_*)`.
2. Copy `configs/tcga_full.yaml` per cancer, point `data.internal` at the TCGA cohort. Leave
   `data.external` pointing at the CPTAC file but **do not create that file until the pre-registration is
   filed** (`docs/preregistration.md`); the pipeline silently skips external evaluation when the file is absent.
3. Per cancer, in this order (each step is resumable; finished runs are skipped):

```bash
CFG=configs/tcga_brca.yaml
python scripts/run_baselines.py --config $CFG                 # E1-E3 baselines, all folds × seeds
python scripts/run_evolution.py --config $CFG --variant full   # 5 seeds × 5 folds
python scripts/run_evolution.py --config $CFG --variant random # random-search control (same eval budget)
python scripts/run_ablations.py --config $CFG                  # E4: no_align, fully_shared, no_moddrop, bi_only
python scripts/run_final.py --config $CFG                      # retrain winners with fresh seeds, evaluate
python scripts/run_analysis.py --config $CFG                   # E1-E7 tables -> results/<run>/analysis/
```

Runs are independent across `--seeds`/`--folds`, so they parallelise trivially over GPUs
(`--seeds 0 --folds 2` etc.). Every candidate evaluation is appended to
`results/<run>/evolution/<variant>/seed<s>/fold<k>/evaluations.jsonl` with its spec, derivation choices,
principle flags and fitness, so all analyses can be recomputed from the logs.

## Extending the grammar

Edit `grammar/fusion.bnf`. Any new fusion op needs a class in `models.py` (`build_op`) and, if it is a
principle you want to test, a flag in `spec.principle_flags` and `analysis.FLAG_NAMES`. Ablations are
grammar overrides in the config (`ablations:`), e.g. `{"<align>": "null"}` removes P1 from the search space.

## Swapping in PonyGE2 / GRAPE

`gemm.grammar.Grammar.map` is a plain GE mapper. If you prefer PonyGE2, point it at the same `.bnf`
(it is standard BNF) and use `gemm.fitness.evaluate(json.loads(phenotype), split)` as the fitness function;
keep logging `Derivation.choices` or you lose the rediscovery analysis.

## Citation of the source ideas

Uhler, C. *Causal principles for multi-modal data integration and translation*, CCAIM ML in Healthcare
Summer School, Sept 2026 (lecture). Sturma, Squires et al., NeurIPS 2023 (identifiability of shared and
modality-specific latents). Zhang et al., Nat Comp Sci 2026 (partially shared multimodal embedding).
Jaume et al., 2024 (HEST-1k). Chen et al., Nat Med 2024 (UNI). Lu et al., Nat Med 2024 (CONCH).
