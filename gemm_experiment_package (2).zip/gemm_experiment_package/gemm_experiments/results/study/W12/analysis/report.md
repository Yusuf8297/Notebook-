# Results report
Run: `results/study/W12`

## E1-E3: detection performance (AUROC, mean ± sd over folds × seeds)

| model | params | test | held-out site | external | test, RNA absent | external, RNA absent | ECE | site probe | DeLong vs best baseline (Holm p) |
|---|---|---|---|---|---|---|---|---|---|
| uhler_hand | 210,401 | 0.773 ± 0.022 | 0.807 ± 0.030 | 0.791 ± 0.007 | 0.677 ± 0.015 | 0.688 ± 0.014 | 0.120 | 0.683 | – |
| evolved_full-deploy_seed0 | 355,121 | 0.770 ± 0.019 | 0.807 ± 0.032 | 0.782 ± 0.009 | 0.638 ± 0.053 | 0.644 ± 0.061 | 0.106 | 0.794 | p=1.53e-17 |
| evolved_full_seed0 | 355,121 | 0.770 ± 0.019 | 0.807 ± 0.032 | 0.782 ± 0.009 | 0.638 ± 0.053 | 0.644 ± 0.061 | 0.106 | 0.794 | p=1.53e-17 |
| rna_only | 230,785 | 0.767 ± 0.037 | 0.802 ± 0.042 | 0.776 ± 0.008 | 0.485 ± 0.043 | 0.498 ± 0.015 | 0.092 | 0.833 | – |
| late_fusion | 263,938 | 0.766 ± 0.020 | 0.810 ± 0.035 | 0.789 ± 0.007 | 0.647 ± 0.015 | 0.677 ± 0.027 | 0.114 | 0.831 | – |
| evolved_full_seed2 | 213,082 | 0.766 ± 0.010 | 0.826 ± 0.021 | 0.790 ± 0.014 | 0.666 ± 0.021 | 0.703 ± 0.035 | 0.101 | 0.603 | p=1.43e-15 |
| evolved_full_seed1 | 212,849 | 0.765 ± 0.027 | 0.812 ± 0.032 | 0.786 ± 0.019 | 0.650 ± 0.012 | 0.683 ± 0.034 | 0.115 | 0.760 | p=7.83e-17 |
| xattn_bi | 511,361 | 0.763 ± 0.031 | 0.801 ± 0.037 | 0.773 ± 0.024 | 0.633 ± 0.009 | 0.655 ± 0.052 | 0.127 | 0.832 | – |
| evolved_full-deploy_seed1 | 196,693 | 0.763 ± 0.026 | 0.808 ± 0.036 | 0.785 ± 0.017 | 0.651 ± 0.010 | 0.695 ± 0.019 | 0.135 | 0.696 | p=1.1e-15 |
| evolved_full-deploy_seed2 | 125,105 | 0.759 ± 0.022 | 0.815 ± 0.024 | 0.755 ± 0.051 | 0.686 ± 0.007 | 0.688 ± 0.039 | 0.106 | 0.501 | p=7.44e-14 |
| early_concat | 247,169 | 0.756 ± 0.042 | 0.810 ± 0.033 | 0.782 ± 0.017 | 0.609 ± 0.041 | 0.652 ± 0.055 | 0.125 | 0.832 | – |
| evolved_bi_only-deploy_seed0 | 517,033 | 0.755 ± 0.004 | 0.835 ± 0.016 | 0.761 ± 0.013 | 0.675 ± 0.018 | 0.661 ± 0.019 | 0.102 | 0.815 | p=1 |
| evolved_random-deploy_seed0 | 248,769 | 0.747 ± 0.013 | 0.853 ± 0.012 | 0.736 ± 0.026 | 0.686 ± 0.010 | 0.672 ± 0.041 | 0.116 | 0.697 | p=1 |
| evolved_random_seed0 | 248,769 | 0.747 ± 0.013 | 0.853 ± 0.012 | 0.736 ± 0.026 | 0.686 ± 0.010 | 0.672 ± 0.041 | 0.116 | 0.697 | p=1 |
| evolved_random_seed1 | 320,729 | 0.746 ± 0.008 | 0.834 ± 0.024 | 0.765 ± 0.027 | 0.690 ± 0.004 | 0.670 ± 0.019 | 0.128 | 0.694 | p=1 |
| evolved_no_moddrop-deploy_seed0 | 933,265 | 0.745 ± 0.013 | 0.845 ± 0.018 | 0.755 ± 0.030 | 0.679 ± 0.008 | 0.684 ± 0.044 | 0.136 | 0.806 | p=1 |
| evolved_bi_only_seed1 | 208,425 | 0.745 ± 0.001 | 0.848 ± 0.014 | 0.782 ± 0.006 | 0.571 ± 0.041 | 0.634 ± 0.048 | 0.105 | 0.833 | p=1 |
| evolved_no_align-deploy_seed0 | 159,409 | 0.745 ± 0.011 | 0.836 ± 0.007 | 0.761 ± 0.031 | 0.654 ± 0.013 | 0.649 ± 0.045 | 0.095 | 0.411 | p=1 |
| evolved_bi_only_seed0 | 767,171 | 0.745 ± 0.012 | 0.845 ± 0.011 | 0.787 ± 0.009 | 0.539 ± 0.038 | 0.656 ± 0.017 | 0.131 | 0.833 | p=1 |
| evolved_no_align_seed0 | 208,321 | 0.742 ± 0.009 | 0.846 ± 0.011 | 0.774 ± 0.025 | 0.634 ± 0.033 | 0.661 ± 0.050 | 0.123 | 0.833 | p=1 |
| evolved_fully_shared-deploy_seed0 | 206,273 | 0.741 ± 0.015 | 0.837 ± 0.007 | 0.784 ± 0.009 | 0.668 ± 0.016 | 0.672 ± 0.010 | 0.149 | 0.683 | p=1 |
| evolved_fully_shared_seed0 | 206,273 | 0.741 ± 0.015 | 0.837 ± 0.007 | 0.784 ± 0.009 | 0.668 ± 0.016 | 0.672 ± 0.010 | 0.149 | 0.683 | p=1 |
| evolved_no_align_seed1 | 593,793 | 0.738 ± 0.016 | 0.842 ± 0.009 | 0.756 ± 0.043 | 0.631 ± 0.024 | 0.632 ± 0.044 | 0.157 | 0.833 | p=1 |
| evolved_no_moddrop_seed1 | 218,947 | 0.738 ± 0.016 | 0.845 ± 0.004 | 0.788 ± 0.009 | 0.591 ± 0.013 | 0.602 ± 0.076 | 0.128 | 0.833 | p=1 |
| evolved_no_moddrop_seed0 | 691,075 | 0.731 ± 0.007 | 0.826 ± 0.020 | 0.758 ± 0.021 | 0.538 ± 0.049 | 0.598 ± 0.021 | 0.100 | 0.833 | p=0.498 |
| evolved_fully_shared_seed1 | 560,257 | 0.730 ± 0.032 | 0.832 ± 0.018 | 0.754 ± 0.012 | 0.613 ± 0.052 | 0.617 ± 0.061 | 0.175 | 0.833 | p=0.133 |
| evolved_bi_only-deploy_seed1 | 300,033 | 0.729 ± 0.005 | 0.843 ± 0.019 | 0.739 ± 0.016 | 0.657 ± 0.002 | 0.670 ± 0.028 | 0.136 | 0.827 | p=0.84 |
| evolved_no_align-deploy_seed1 | 121,321 | 0.729 ± 0.019 | 0.816 ± 0.003 | 0.768 ± 0.019 | 0.647 ± 0.021 | 0.630 ± 0.062 | 0.153 | 0.810 | p=0.325 |
| evolved_fully_shared-deploy_seed1 | 461,441 | 0.726 ± 0.007 | 0.838 ± 0.007 | 0.756 ± 0.007 | 0.673 ± 0.034 | 0.635 ± 0.024 | 0.150 | 0.785 | p=0.248 |
| evolved_random-deploy_seed1 | 274,305 | 0.723 ± 0.009 | 0.842 ± 0.009 | 0.739 ± 0.019 | 0.671 ± 0.021 | 0.665 ± 0.016 | 0.144 | 0.819 | p=0.306 |
| evolved_no_moddrop-deploy_seed1 | 310,497 | 0.721 ± 0.050 | 0.812 ± 0.039 | 0.767 ± 0.021 | 0.655 ± 0.034 | 0.649 ± 0.038 | 0.069 | 0.761 | p=0.0358 |
| img_only | 230,785 | 0.650 ± 0.025 | 0.747 ± 0.037 | 0.678 ± 0.018 | 0.650 ± 0.025 | 0.678 ± 0.018 | 0.116 | 0.833 | – |

## H2/H4: effect of each principle across all evaluated individuals (population level)

### grammar variant `full` (n = 1584 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | 0.006 | 0.011 | 0.0394 | -0.07 | 0.688 | 0.667 | 3.35e-10 | -0.496 | -0.713 |
| P2_partial | 0.017 | 0.001 | 1.12e-07 | 0.16 | 0.684 | 0.680 | 0.935 | -0.535 | -0.577 |
| P2_disentangle | 0.012 | 0.005 | 0.0341 | 0.07 | 0.680 | 0.682 | 0.0225 | -0.474 | -0.600 |
| P3_moddrop | 0.003 | 0.012 | 0.00972 | -0.08 | 0.684 | 0.679 | 0.892 | -0.537 | -0.581 |
| P3_cond | 0.003 | 0.009 | 0.144 | -0.05 | 0.682 | 0.681 | 0.632 | -0.583 | -0.550 |
| P4_directed | 0.038 | 0.001 | 3.37e-18 | 0.33 | 0.696 | 0.678 | 5.37e-07 | -0.568 | -0.557 |

### grammar variant `random` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.044 | -0.046 | 0.823 | 0.01 | 0.653 | 0.654 | 0.449 | -0.672 | -0.773 |
| P2_partial | -0.045 | -0.045 | 0.729 | -0.02 | 0.654 | 0.652 | 0.723 | -0.678 | -0.727 |
| P2_disentangle | -0.046 | -0.044 | 0.045 | -0.11 | 0.653 | 0.653 | 0.481 | -0.679 | -0.717 |
| P3_moddrop | -0.044 | -0.045 | 0.833 | 0.01 | 0.658 | 0.648 | 0.172 | -0.719 | -0.689 |
| P3_cond | -0.044 | -0.045 | 0.488 | 0.04 | 0.655 | 0.653 | 0.867 | -0.726 | -0.697 |
| P4_directed | -0.042 | -0.045 | 0.337 | 0.06 | 0.656 | 0.652 | 0.996 | -0.694 | -0.708 |

### grammar variant `no_moddrop` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.048 | -0.052 | 0.191 | 0.07 | 0.669 | 0.613 | 1.01e-14 | -0.500 | -0.722 |
| P2_partial | -0.049 | -0.048 | 0.84 | 0.01 | 0.635 | 0.674 | 2.79e-09 | -0.555 | -0.562 |
| P2_disentangle | -0.051 | -0.047 | 0.117 | -0.08 | 0.613 | 0.675 | 1.58e-22 | -0.568 | -0.554 |
| P3_moddrop | – | -0.049 | nan | nan | – | 0.654 | nan | – | -0.559 |
| P3_cond | -0.052 | -0.045 | 0.000218 | -0.19 | 0.641 | 0.666 | 0.000228 | -0.575 | -0.543 |
| P4_directed | -0.043 | -0.050 | 0.0115 | 0.17 | 0.675 | 0.649 | 0.000376 | -0.634 | -0.542 |

### grammar variant `bi_only` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.048 | -0.050 | 0.911 | -0.01 | 0.676 | 0.625 | 6.15e-11 | -0.474 | -0.747 |
| P2_partial | -0.048 | -0.048 | 0.544 | 0.03 | 0.648 | 0.676 | 7.83e-05 | -0.528 | -0.548 |
| P2_disentangle | -0.050 | -0.047 | 0.269 | -0.06 | 0.663 | 0.664 | 0.293 | -0.452 | -0.568 |
| P3_moddrop | -0.048 | -0.049 | 0.467 | 0.04 | 0.672 | 0.657 | 0.00176 | -0.496 | -0.579 |
| P3_cond | -0.049 | -0.048 | 0.589 | -0.03 | 0.680 | 0.658 | 0.00329 | -0.637 | -0.503 |
| P4_directed | – | -0.048 | nan | nan | – | 0.664 | nan | – | -0.539 |

### grammar variant `fully_shared` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.053 | -0.050 | 0.718 | -0.02 | 0.694 | 0.665 | 2.83e-08 | -0.522 | -0.790 |
| P2_partial | – | -0.052 | nan | nan | – | 0.687 | nan | – | -0.580 |
| P2_disentangle | – | -0.052 | nan | nan | – | 0.687 | nan | – | -0.580 |
| P3_moddrop | -0.053 | -0.051 | 0.149 | -0.07 | 0.688 | 0.686 | 0.658 | -0.620 | -0.539 |
| P3_cond | -0.046 | -0.055 | 0.000134 | 0.20 | 0.696 | 0.683 | 0.0431 | -0.686 | -0.523 |
| P4_directed | -0.057 | -0.051 | 0.0511 | -0.14 | 0.694 | 0.686 | 0.248 | -0.643 | -0.569 |

### grammar variant `no_align` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | – | -0.047 | nan | nan | – | 0.663 | nan | – | -0.638 |
| P2_partial | -0.046 | -0.049 | 0.644 | 0.02 | 0.656 | 0.673 | 0.000201 | -0.542 | -0.793 |
| P2_disentangle | -0.047 | -0.048 | 0.728 | -0.02 | 0.656 | 0.670 | 0.00336 | -0.484 | -0.783 |
| P3_moddrop | -0.044 | -0.049 | 0.00233 | 0.16 | 0.672 | 0.657 | 6.66e-05 | -0.685 | -0.608 |
| P3_cond | -0.050 | -0.046 | 0.0558 | -0.10 | 0.644 | 0.676 | 4.67e-10 | -0.553 | -0.699 |
| P4_directed | -0.045 | -0.048 | 0.337 | 0.07 | 0.671 | 0.661 | 0.733 | -0.763 | -0.616 |

## E4: grammar ablations

| variant | runs | Pareto hypervolume (95% CI) | best val AUROC (95% CI) |
|---|---|---|---|
| bi_only | 2 | 0.0276 [0.0276, 0.0277] | 0.822 [0.821, 0.824] |
| full | 6 | 0.0268 [0.0260, 0.0276] | 0.843 [0.826, 0.859] |
| fully_shared | 2 | 0.0274 [0.0270, 0.0278] | 0.828 [0.827, 0.830] |
| no_align | 2 | 0.0199 [0.0175, 0.0222] | 0.822 [0.818, 0.826] |
| no_moddrop | 2 | 0.0278 [0.0272, 0.0284] | 0.827 [0.824, 0.830] |
| random | 2 | 0.0264 [0.0263, 0.0265] | 0.829 [0.826, 0.833] |

### H5: principle enrichment among Pareto-optimal individuals (full grammar) vs uniform-derivation prior

| principle | frequency | prior | fold | one-sided p |
|---|---|---|---|---|
| P1_align | 0.802 | 0.662 | 1.21 | 5e-05 |
| P2_partial | 0.349 | 0.471 | 0.74 | 1 |
| P2_disentangle | 0.262 | 0.368 | 0.71 | 1 |
| P3_moddrop | 0.444 | 0.517 | 0.86 | 0.999 |
| P3_cond | 0.294 | 0.272 | 1.08 | 0.168 |
| P4_directed | 0.239 | 0.194 | 1.23 | 0.0112 |

### E7: recurrent motifs among Pareto-optimal individuals

- (25×) latent 8s/0i/0r | single(rna)+single(rna) | align=infonce | moddrop=yes
- (21×) latent 128s/0i/0r | cond(img)+gated | align=none | moddrop=no
- (21×) latent 128s/0i/0r | xattn(bi) | align=infonce | moddrop=no
- (19×) latent 128s/0i/0r | xattn(rna2img) | align=infonce | moddrop=no
- (18×) latent 64s/0i/0r | xattn(img2rna) | align=infonce | moddrop=no
- (14×) latent 8s/0i/0r | single(rna)+cond(img) | align=infonce | moddrop=no
- (12×) latent 128s/32i/8r | single(rna)+cond(rna) | align=infonce | moddrop=yes
- (11×) latent 128s/0i/0r | cond(img)+gated | align=infonce | moddrop=no
- (11×) latent 8s/0i/0r | xattn(img2rna)+single(img) | align=infonce | moddrop=yes
- (10×) latent 32s/0i/0r | gated+gated | align=none | moddrop=no

## E5: partial sharing

- fold 0: CCA rank (permutation, α=0.05) = 7, MI over top canonical pairs = 0.16 nats; evolved latents: [{'shared': 32, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}, {'shared': 128, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}, {'shared': 8, 'img_spec': 128, 'rna_spec': 128, 'disentangle': {'type': 'orth', 'w': 0.1}}]
- fold 1: CCA rank (permutation, α=0.05) = 16, MI over top canonical pairs = 0.52 nats; evolved latents: [{'shared': 32, 'img_spec': 32, 'rna_spec': 32, 'disentangle': None}, {'shared': 64, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}, {'shared': 64, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}]
- Spearman(evolved shared dim, CCA rank) = 0.20 (p = 0.703, n = 6)

| hallmark | shared (img) | shared (rna) | img-specific | rna-specific |
|---|---|---|---|---|
| hypoxia | 0.51 | 0.43 | 0.54 | 0.41 |
| proliferation | -0.22 | 0.50 | -0.27 | 0.55 |
| stroma | 0.23 | -0.28 | 0.35 | -0.35 |
