# Results report
Run: `results/study/W4`

## E1-E3: detection performance (AUROC, mean ± sd over folds × seeds)

| model | params | test | held-out site | external | test, RNA absent | external, RNA absent | ECE | site probe | DeLong vs best baseline (Holm p) |
|---|---|---|---|---|---|---|---|---|---|
| evolved_full-deploy_seed2 | 262,377 | 0.848 ± 0.028 | 0.831 ± 0.019 | 0.783 ± 0.019 | 0.780 ± 0.020 | 0.709 ± 0.017 | 0.087 | 0.832 | p=2.85e-23 |
| uhler_hand | 210,401 | 0.846 ± 0.022 | 0.846 ± 0.008 | 0.803 ± 0.008 | 0.764 ± 0.013 | 0.723 ± 0.010 | 0.072 | 0.820 | – |
| evolved_full_seed2 | 263,241 | 0.843 ± 0.021 | 0.839 ± 0.012 | 0.794 ± 0.008 | 0.778 ± 0.017 | 0.715 ± 0.012 | 0.075 | 0.808 | p=2.8e-22 |
| rna_only | 230,785 | 0.842 ± 0.031 | 0.848 ± 0.008 | 0.796 ± 0.006 | 0.533 ± 0.050 | 0.503 ± 0.028 | 0.075 | 0.833 | – |
| early_concat | 247,169 | 0.842 ± 0.031 | 0.843 ± 0.012 | 0.794 ± 0.011 | 0.709 ± 0.027 | 0.688 ± 0.006 | 0.100 | 0.833 | – |
| evolved_full_seed1 | 242,501 | 0.840 ± 0.022 | 0.845 ± 0.018 | 0.777 ± 0.021 | 0.778 ± 0.022 | 0.705 ± 0.024 | 0.084 | 0.546 | p=1.56e-18 |
| xattn_bi | 511,361 | 0.837 ± 0.021 | 0.840 ± 0.014 | 0.800 ± 0.006 | 0.698 ± 0.036 | 0.692 ± 0.008 | 0.110 | 0.833 | – |
| late_fusion | 263,938 | 0.830 ± 0.022 | 0.848 ± 0.006 | 0.794 ± 0.005 | 0.688 ± 0.027 | 0.684 ± 0.014 | 0.092 | 0.833 | – |
| evolved_full-deploy_seed1 | 241,349 | 0.828 ± 0.016 | 0.824 ± 0.034 | 0.767 ± 0.024 | 0.771 ± 0.013 | 0.712 ± 0.023 | 0.092 | 0.587 | p=3.94e-15 |
| evolved_bi_only-deploy_seed1 | 342,561 | 0.827 ± 0.011 | 0.845 ± 0.006 | 0.799 ± 0.005 | 0.764 ± 0.013 | 0.726 ± 0.010 | 0.068 | 0.570 | p=1 |
| evolved_random-deploy_seed0 | 205,129 | 0.826 ± 0.004 | 0.853 ± 0.005 | 0.804 ± 0.003 | 0.775 ± 0.002 | 0.724 ± 0.011 | 0.087 | 0.487 | p=1 |
| evolved_no_moddrop_seed0 | 395,649 | 0.823 ± 0.006 | 0.855 ± 0.001 | 0.796 ± 0.006 | 0.753 ± 0.010 | 0.697 ± 0.012 | 0.077 | 0.805 | p=1 |
| evolved_random_seed1 | 542,915 | 0.823 ± 0.002 | 0.862 ± 0.009 | 0.798 ± 0.006 | 0.714 ± 0.011 | 0.676 ± 0.026 | 0.087 | 0.833 | p=1 |
| evolved_bi_only-deploy_seed0 | 230,529 | 0.823 ± 0.003 | 0.856 ± 0.004 | 0.799 ± 0.006 | 0.748 ± 0.005 | 0.706 ± 0.011 | 0.107 | 0.833 | p=1 |
| evolved_bi_only_seed0 | 230,529 | 0.823 ± 0.003 | 0.856 ± 0.004 | 0.799 ± 0.006 | 0.748 ± 0.005 | 0.706 ± 0.011 | 0.107 | 0.833 | p=1 |
| evolved_full-deploy_seed0 | 279,697 | 0.821 ± 0.007 | 0.806 ± 0.034 | 0.752 ± 0.031 | 0.773 ± 0.010 | 0.696 ± 0.020 | 0.087 | 0.677 | p=4.79e-12 |
| evolved_full_seed0 | 279,697 | 0.821 ± 0.007 | 0.806 ± 0.034 | 0.752 ± 0.031 | 0.773 ± 0.010 | 0.696 ± 0.020 | 0.087 | 0.677 | p=4.79e-12 |
| evolved_random_seed0 | 175,617 | 0.821 ± 0.009 | 0.866 ± 0.010 | 0.791 ± 0.011 | 0.765 ± 0.002 | 0.699 ± 0.020 | 0.086 | 0.462 | p=1 |
| evolved_fully_shared-deploy_seed0 | 263,681 | 0.821 ± 0.006 | 0.856 ± 0.005 | 0.795 ± 0.007 | 0.758 ± 0.013 | 0.713 ± 0.012 | 0.112 | 0.818 | p=1 |
| evolved_no_moddrop_seed1 | 278,793 | 0.819 ± 0.001 | 0.869 ± 0.005 | 0.795 ± 0.002 | 0.763 ± 0.005 | 0.721 ± 0.005 | 0.098 | 0.814 | p=1 |
| evolved_no_align_seed1 | 130,889 | 0.819 ± 0.002 | 0.859 ± 0.006 | 0.787 ± 0.011 | 0.742 ± 0.002 | 0.693 ± 0.016 | 0.123 | 0.709 | p=1 |
| evolved_random-deploy_seed1 | 320,729 | 0.817 ± 0.005 | 0.850 ± 0.011 | 0.781 ± 0.007 | 0.765 ± 0.009 | 0.706 ± 0.015 | 0.095 | 0.778 | p=1 |
| evolved_bi_only_seed1 | 669,313 | 0.816 ± 0.002 | 0.854 ± 0.007 | 0.789 ± 0.012 | 0.751 ± 0.005 | 0.718 ± 0.012 | 0.091 | 0.791 | p=0.339 |
| evolved_no_moddrop-deploy_seed0 | 214,561 | 0.815 ± 0.006 | 0.857 ± 0.007 | 0.797 ± 0.007 | 0.757 ± 0.007 | 0.694 ± 0.020 | 0.077 | 0.701 | p=1 |
| evolved_fully_shared-deploy_seed1 | 342,561 | 0.814 ± 0.004 | 0.826 ± 0.009 | 0.783 ± 0.009 | 0.763 ± 0.007 | 0.733 ± 0.009 | 0.066 | 0.545 | p=1 |
| evolved_no_align-deploy_seed0 | 395,393 | 0.812 ± 0.006 | 0.853 ± 0.012 | 0.788 ± 0.010 | 0.731 ± 0.006 | 0.698 ± 0.007 | 0.124 | 0.833 | p=0.339 |
| evolved_fully_shared_seed1 | 159,361 | 0.812 ± 0.002 | 0.847 ± 0.012 | 0.787 ± 0.003 | 0.705 ± 0.017 | 0.694 ± 0.011 | 0.119 | 0.833 | p=0.322 |
| evolved_no_align_seed0 | 310,401 | 0.812 ± 0.001 | 0.855 ± 0.003 | 0.799 ± 0.004 | 0.692 ± 0.011 | 0.656 ± 0.029 | 0.118 | 0.305 | p=0.266 |
| evolved_no_moddrop-deploy_seed1 | 262,497 | 0.812 ± 0.004 | 0.866 ± 0.006 | 0.792 ± 0.003 | 0.736 ± 0.006 | 0.721 ± 0.009 | 0.097 | 0.833 | p=0.0478 |
| evolved_no_align-deploy_seed1 | 280,353 | 0.809 ± 0.003 | 0.852 ± 0.004 | 0.788 ± 0.010 | 0.732 ± 0.010 | 0.707 ± 0.013 | 0.137 | 0.833 | p=0.102 |
| evolved_fully_shared_seed0 | 243,297 | 0.808 ± 0.003 | 0.860 ± 0.014 | 0.786 ± 0.005 | 0.594 ± 0.044 | 0.611 ± 0.021 | 0.099 | 0.833 | p=0.226 |
| img_only | 230,785 | 0.756 ± 0.019 | 0.733 ± 0.019 | 0.714 ± 0.015 | 0.756 ± 0.019 | 0.714 ± 0.015 | 0.078 | 0.833 | – |

## H2/H4: effect of each principle across all evaluated individuals (population level)

### grammar variant `full` (n = 1584 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | 0.000 | -0.013 | 6.06e-11 | 0.22 | 0.743 | 0.704 | 2.02e-37 | -0.614 | -0.676 |
| P2_partial | -0.011 | 0.002 | 1.18e-12 | -0.21 | 0.717 | 0.744 | 1.72e-31 | -0.590 | -0.651 |
| P2_disentangle | -0.010 | 0.000 | 5.53e-06 | -0.14 | 0.716 | 0.742 | 1.19e-28 | -0.555 | -0.661 |
| P3_moddrop | -0.004 | -0.002 | 0.298 | -0.03 | 0.741 | 0.729 | 0.0168 | -0.619 | -0.634 |
| P3_cond | -0.010 | -0.000 | 3.28e-07 | -0.17 | 0.727 | 0.736 | 0.0033 | -0.629 | -0.628 |
| P4_directed | -0.007 | -0.002 | 0.381 | -0.04 | 0.737 | 0.733 | 0.15 | -0.635 | -0.627 |

### grammar variant `random` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.003 | -0.002 | 0.957 | 0.00 | 0.698 | 0.689 | 0.0128 | -0.738 | -0.779 |
| P2_partial | -0.002 | -0.003 | 0.568 | 0.03 | 0.701 | 0.691 | 0.533 | -0.727 | -0.770 |
| P2_disentangle | -0.002 | -0.003 | 0.296 | 0.06 | 0.697 | 0.694 | 0.984 | -0.726 | -0.762 |
| P3_moddrop | -0.004 | -0.001 | 0.0791 | -0.09 | 0.705 | 0.684 | 0.0218 | -0.759 | -0.742 |
| P3_cond | -0.005 | -0.002 | 0.0178 | -0.13 | 0.683 | 0.699 | 0.0318 | -0.765 | -0.746 |
| P4_directed | -0.002 | -0.003 | 0.412 | 0.05 | 0.713 | 0.691 | 0.0799 | -0.744 | -0.753 |

### grammar variant `no_moddrop` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | 0.001 | -0.001 | 0.384 | 0.06 | 0.717 | 0.663 | 8.47e-12 | -0.617 | -0.766 |
| P2_partial | -0.000 | 0.001 | 0.957 | 0.00 | 0.701 | 0.718 | 0.00138 | -0.543 | -0.755 |
| P2_disentangle | -0.002 | 0.002 | 0.106 | -0.08 | 0.704 | 0.713 | 0.00224 | -0.496 | -0.755 |
| P3_moddrop | – | 0.000 | nan | nan | – | 0.709 | nan | – | -0.640 |
| P3_cond | 0.002 | -0.002 | 0.0072 | 0.14 | 0.695 | 0.727 | 1.28e-09 | -0.590 | -0.707 |
| P4_directed | 0.004 | -0.000 | 0.025 | 0.17 | 0.702 | 0.710 | 0.786 | -0.765 | -0.622 |

### grammar variant `bi_only` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | 0.007 | -0.006 | 1.17e-09 | 0.35 | 0.720 | 0.694 | 8.92e-12 | -0.590 | -0.725 |
| P2_partial | -0.001 | 0.005 | 0.0294 | -0.12 | 0.668 | 0.730 | 4.09e-18 | -0.634 | -0.620 |
| P2_disentangle | -0.000 | 0.004 | 0.387 | -0.05 | 0.673 | 0.724 | 1.45e-12 | -0.588 | -0.633 |
| P3_moddrop | 0.004 | 0.003 | 0.917 | 0.01 | 0.718 | 0.708 | 0.0293 | -0.618 | -0.631 |
| P3_cond | -0.000 | 0.004 | 0.108 | -0.11 | 0.671 | 0.722 | 1.65e-09 | -0.688 | -0.610 |
| P4_directed | – | 0.003 | nan | nan | – | 0.713 | nan | – | -0.624 |

### grammar variant `fully_shared` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | 0.002 | -0.004 | 0.00154 | 0.22 | 0.731 | 0.688 | 9.59e-09 | -0.622 | -0.779 |
| P2_partial | – | 0.001 | nan | nan | – | 0.724 | nan | – | -0.647 |
| P2_disentangle | – | 0.001 | nan | nan | – | 0.724 | nan | – | -0.647 |
| P3_moddrop | 0.001 | 0.001 | 0.541 | 0.03 | 0.740 | 0.709 | 2.66e-07 | -0.648 | -0.646 |
| P3_cond | -0.001 | 0.002 | 0.227 | -0.09 | 0.713 | 0.725 | 0.00948 | -0.764 | -0.628 |
| P4_directed | 0.001 | 0.001 | 0.163 | -0.11 | 0.734 | 0.722 | 0.301 | -0.685 | -0.643 |

### grammar variant `no_align` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | – | -0.004 | nan | nan | – | 0.690 | nan | – | -0.637 |
| P2_partial | -0.003 | -0.005 | 0.136 | 0.08 | 0.687 | 0.696 | 0.283 | -0.557 | -0.790 |
| P2_disentangle | -0.001 | -0.006 | 0.00016 | 0.19 | 0.668 | 0.709 | 3.93e-13 | -0.480 | -0.775 |
| P3_moddrop | -0.003 | -0.004 | 0.733 | 0.02 | 0.716 | 0.673 | 9.91e-13 | -0.735 | -0.574 |
| P3_cond | -0.003 | -0.004 | 0.938 | -0.00 | 0.661 | 0.703 | 1.96e-10 | -0.636 | -0.638 |
| P4_directed | -0.005 | -0.003 | 0.0626 | -0.11 | 0.727 | 0.678 | 8.76e-12 | -0.760 | -0.597 |

## E4: grammar ablations

| variant | runs | Pareto hypervolume (95% CI) | best val AUROC (95% CI) |
|---|---|---|---|
| bi_only | 2 | 0.0343 [0.0334, 0.0353] | 0.876 [0.876, 0.876] |
| full | 6 | 0.0351 [0.0340, 0.0362] | 0.864 [0.855, 0.874] |
| fully_shared | 2 | 0.0326 [0.0306, 0.0346] | 0.873 [0.873, 0.873] |
| no_align | 2 | 0.0345 [0.0330, 0.0361] | 0.876 [0.875, 0.877] |
| no_moddrop | 2 | 0.0345 [0.0321, 0.0369] | 0.878 [0.878, 0.878] |
| random | 2 | 0.0336 [0.0318, 0.0353] | 0.882 [0.882, 0.882] |

### H5: principle enrichment among Pareto-optimal individuals (full grammar) vs uniform-derivation prior

| principle | frequency | prior | fold | one-sided p |
|---|---|---|---|---|
| P1_align | 0.842 | 0.662 | 1.27 | 5e-05 |
| P2_partial | 0.312 | 0.471 | 0.66 | 1 |
| P2_disentangle | 0.286 | 0.368 | 0.78 | 1 |
| P3_moddrop | 0.344 | 0.517 | 0.67 | 1 |
| P3_cond | 0.307 | 0.272 | 1.13 | 0.0515 |
| P4_directed | 0.117 | 0.194 | 0.60 | 1 |

### E7: recurrent motifs among Pareto-optimal individuals

- (46×) latent 128s/0i/0r | cond(img)+gated | align=infonce | moddrop=no
- (43×) latent 8s/0i/0r | gated+xattn(bi) | align=infonce | moddrop=yes
- (26×) latent 16s/0i/0r | gated | align=infonce | moddrop=no
- (22×) latent 8s/0i/0r | single(rna)+single(img) | align=infonce | moddrop=yes
- (17×) latent 8s/0i/0r | single(img)+cond(img) | align=infonce | moddrop=no
- (14×) latent 128s/0i/0r | single(img) | align=infonce | moddrop=no
- (13×) latent 8s/128i/128r | xattn(rna2img)+gated | align=none | moddrop=no
- (12×) latent 8s/0i/0r | xattn(bi) | align=infonce | moddrop=no
- (11×) latent 32s/32i/0r | concat+cond(img) | align=infonce | moddrop=no
- (11×) latent 64s/0i/0r | concat+single(rna) | align=none | moddrop=yes

## E5: partial sharing

- fold 0: CCA rank (permutation, α=0.05) = 9, MI over top canonical pairs = 0.34 nats; evolved latents: [{'shared': 8, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}, {'shared': 128, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}, {'shared': 128, 'img_spec': 0, 'rna_spec': 64, 'disentangle': {'type': 'mmd', 'w': 3.0}}]
- fold 1: CCA rank (permutation, α=0.05) = 7, MI over top canonical pairs = 0.30 nats; evolved latents: [{'shared': 8, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}, {'shared': 64, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}, {'shared': 16, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}]
- Spearman(evolved shared dim, CCA rank) = 0.40 (p = 0.429, n = 6)

| hallmark | shared (img) | shared (rna) | img-specific | rna-specific |
|---|---|---|---|---|
| hypoxia | 0.86 | 0.87 | – | 0.61 |
| proliferation | -0.15 | 0.65 | – | 0.66 |
| stroma | 0.28 | -0.21 | – | -0.21 |
