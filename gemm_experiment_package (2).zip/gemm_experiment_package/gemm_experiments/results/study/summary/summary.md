# Simulation study summary

## Table 1. Detection AUROC by world and model group (mean ± sd over folds × retraining seeds)

| world (true shared dim) | model | test | external | test, RNA absent | external, RNA absent | site probe |
|---|---|---|---|---|---|---|
| W2 (2) | H&E only | 0.679 ± 0.041 | 0.710 ± 0.008 | 0.679 ± 0.041 | 0.710 ± 0.008 | 0.83 |
| W2 (2) | RNA only | 0.814 ± 0.062 | 0.824 ± 0.003 | 0.517 ± 0.055 | 0.485 ± 0.081 | 0.83 |
| W2 (2) | Early concat | 0.809 ± 0.057 | 0.828 ± 0.004 | 0.651 ± 0.057 | 0.678 ± 0.019 | 0.83 |
| W2 (2) | Late fusion | 0.814 ± 0.065 | 0.834 ± 0.004 | 0.638 ± 0.068 | 0.681 ± 0.007 | 0.83 |
| W2 (2) | Co-attention (bi) | 0.811 ± 0.068 | 0.829 ± 0.005 | 0.628 ± 0.059 | 0.684 ± 0.031 | 0.83 |
| W2 (2) | Hand-built principled | 0.814 ± 0.060 | 0.829 ± 0.003 | 0.724 ± 0.076 | 0.713 ± 0.022 | 0.83 |
| W2 (2) | Random search | 0.860 ± 0.010 | 0.812 ± 0.007 | 0.668 ± 0.146 | 0.624 ± 0.111 | 0.83 |
| W2 (2) | Random search (deployment rule) | 0.866 ± 0.010 | 0.825 ± 0.007 | 0.783 ± 0.015 | 0.718 ± 0.009 | 0.83 |
| W2 (2) | GE − P1 (no align) | 0.863 ± 0.016 | 0.813 ± 0.019 | 0.545 ± 0.041 | 0.529 ± 0.026 | 0.54 |
| W2 (2) | GE − P2 (fully shared) | 0.869 ± 0.007 | 0.821 ± 0.010 | 0.574 ± 0.054 | 0.616 ± 0.066 | 0.83 |
| W2 (2) | GE − P3 (no moddrop) | 0.872 ± 0.005 | 0.825 ± 0.006 | 0.653 ± 0.128 | 0.642 ± 0.082 | 0.83 |
| W2 (2) | GE − P4 (bi only) | 0.868 ± 0.006 | 0.821 ± 0.007 | 0.588 ± 0.048 | 0.551 ± 0.026 | 0.54 |
| W2 (2) | GE full grammar | 0.812 ± 0.058 | 0.822 ± 0.011 | 0.590 ± 0.070 | 0.617 ± 0.074 | 0.75 |
| W2 (2) | GE full grammar (deployment rule) | 0.814 ± 0.060 | 0.824 ± 0.007 | 0.671 ± 0.063 | 0.682 ± 0.047 | 0.64 |
| W4 (4) | H&E only | 0.756 ± 0.019 | 0.714 ± 0.015 | 0.756 ± 0.019 | 0.714 ± 0.015 | 0.83 |
| W4 (4) | RNA only | 0.842 ± 0.031 | 0.796 ± 0.006 | 0.533 ± 0.050 | 0.503 ± 0.028 | 0.83 |
| W4 (4) | Early concat | 0.842 ± 0.031 | 0.794 ± 0.011 | 0.709 ± 0.027 | 0.688 ± 0.006 | 0.83 |
| W4 (4) | Late fusion | 0.830 ± 0.022 | 0.794 ± 0.005 | 0.688 ± 0.027 | 0.684 ± 0.014 | 0.83 |
| W4 (4) | Co-attention (bi) | 0.837 ± 0.021 | 0.800 ± 0.006 | 0.698 ± 0.036 | 0.692 ± 0.008 | 0.83 |
| W4 (4) | Hand-built principled | 0.846 ± 0.022 | 0.803 ± 0.008 | 0.764 ± 0.013 | 0.723 ± 0.010 | 0.82 |
| W4 (4) | Random search | 0.822 ± 0.006 | 0.794 ± 0.010 | 0.739 ± 0.027 | 0.687 ± 0.026 | 0.65 |
| W4 (4) | Random search (deployment rule) | 0.822 ± 0.006 | 0.793 ± 0.013 | 0.770 ± 0.008 | 0.715 ± 0.016 | 0.63 |
| W4 (4) | GE − P1 (no align) | 0.815 ± 0.004 | 0.793 ± 0.010 | 0.717 ± 0.026 | 0.675 ± 0.030 | 0.51 |
| W4 (4) | GE − P2 (fully shared) | 0.810 ± 0.004 | 0.787 ± 0.004 | 0.649 ± 0.065 | 0.653 ± 0.045 | 0.83 |
| W4 (4) | GE − P3 (no moddrop) | 0.821 ± 0.005 | 0.796 ± 0.004 | 0.758 ± 0.009 | 0.709 ± 0.015 | 0.81 |
| W4 (4) | GE − P4 (bi only) | 0.819 ± 0.004 | 0.794 ± 0.011 | 0.750 ± 0.005 | 0.712 ± 0.013 | 0.81 |
| W4 (4) | GE full grammar | 0.835 ± 0.021 | 0.774 ± 0.028 | 0.776 ± 0.017 | 0.705 ± 0.021 | 0.68 |
| W4 (4) | GE full grammar (deployment rule) | 0.832 ± 0.022 | 0.767 ± 0.028 | 0.775 ± 0.015 | 0.706 ± 0.021 | 0.70 |
| W8 (8) | H&E only | 0.748 ± 0.020 | 0.705 ± 0.031 | 0.748 ± 0.020 | 0.705 ± 0.031 | 0.83 |
| W8 (8) | RNA only | 0.823 ± 0.005 | 0.847 ± 0.005 | 0.453 ± 0.065 | 0.490 ± 0.023 | 0.83 |
| W8 (8) | Early concat | 0.832 ± 0.010 | 0.849 ± 0.006 | 0.703 ± 0.041 | 0.676 ± 0.019 | 0.83 |
| W8 (8) | Late fusion | 0.828 ± 0.007 | 0.842 ± 0.007 | 0.714 ± 0.042 | 0.682 ± 0.030 | 0.83 |
| W8 (8) | Co-attention (bi) | 0.830 ± 0.009 | 0.836 ± 0.010 | 0.707 ± 0.032 | 0.661 ± 0.021 | 0.83 |
| W8 (8) | Hand-built principled | 0.826 ± 0.010 | 0.838 ± 0.010 | 0.744 ± 0.023 | 0.701 ± 0.020 | 0.76 |
| W8 (8) | Random search | 0.825 ± 0.012 | 0.831 ± 0.006 | 0.717 ± 0.022 | 0.699 ± 0.026 | 0.45 |
| W8 (8) | Random search (deployment rule) | 0.818 ± 0.031 | 0.812 ± 0.036 | 0.726 ± 0.024 | 0.692 ± 0.033 | 0.43 |
| W8 (8) | GE − P1 (no align) | 0.823 ± 0.013 | 0.839 ± 0.011 | 0.630 ± 0.040 | 0.644 ± 0.040 | 0.59 |
| W8 (8) | GE − P2 (fully shared) | 0.833 ± 0.005 | 0.840 ± 0.010 | 0.686 ± 0.053 | 0.671 ± 0.050 | 0.78 |
| W8 (8) | GE − P3 (no moddrop) | 0.826 ± 0.009 | 0.840 ± 0.005 | 0.726 ± 0.023 | 0.685 ± 0.034 | 0.49 |
| W8 (8) | GE − P4 (bi only) | 0.824 ± 0.010 | 0.832 ± 0.012 | 0.728 ± 0.015 | 0.683 ± 0.043 | 0.58 |
| W8 (8) | GE full grammar | 0.828 ± 0.006 | 0.843 ± 0.008 | 0.731 ± 0.021 | 0.686 ± 0.034 | 0.66 |
| W8 (8) | GE full grammar (deployment rule) | 0.820 ± 0.016 | 0.827 ± 0.034 | 0.739 ± 0.033 | 0.704 ± 0.027 | 0.45 |
| W12 (12) | H&E only | 0.650 ± 0.025 | 0.678 ± 0.018 | 0.650 ± 0.025 | 0.678 ± 0.018 | 0.83 |
| W12 (12) | RNA only | 0.767 ± 0.037 | 0.776 ± 0.008 | 0.485 ± 0.043 | 0.498 ± 0.015 | 0.83 |
| W12 (12) | Early concat | 0.756 ± 0.042 | 0.782 ± 0.017 | 0.609 ± 0.041 | 0.652 ± 0.055 | 0.83 |
| W12 (12) | Late fusion | 0.766 ± 0.020 | 0.789 ± 0.007 | 0.647 ± 0.015 | 0.677 ± 0.027 | 0.83 |
| W12 (12) | Co-attention (bi) | 0.763 ± 0.031 | 0.773 ± 0.024 | 0.633 ± 0.009 | 0.655 ± 0.052 | 0.83 |
| W12 (12) | Hand-built principled | 0.773 ± 0.022 | 0.791 ± 0.007 | 0.677 ± 0.015 | 0.688 ± 0.014 | 0.68 |
| W12 (12) | Random search | 0.747 ± 0.011 | 0.750 ± 0.031 | 0.688 ± 0.007 | 0.671 ± 0.032 | 0.70 |
| W12 (12) | Random search (deployment rule) | 0.735 ± 0.016 | 0.737 ± 0.023 | 0.678 ± 0.018 | 0.668 ± 0.031 | 0.76 |
| W12 (12) | GE − P1 (no align) | 0.740 ± 0.013 | 0.765 ± 0.036 | 0.632 ± 0.029 | 0.646 ± 0.049 | 0.83 |
| W12 (12) | GE − P2 (fully shared) | 0.735 ± 0.026 | 0.769 ± 0.018 | 0.641 ± 0.048 | 0.644 ± 0.052 | 0.76 |
| W12 (12) | GE − P3 (no moddrop) | 0.734 ± 0.012 | 0.773 ± 0.022 | 0.564 ± 0.045 | 0.600 ± 0.056 | 0.83 |
| W12 (12) | GE − P4 (bi only) | 0.745 ± 0.009 | 0.784 ± 0.008 | 0.555 ± 0.043 | 0.645 ± 0.038 | 0.83 |
| W12 (12) | GE full grammar | 0.767 ± 0.020 | 0.786 ± 0.015 | 0.651 ± 0.035 | 0.677 ± 0.051 | 0.72 |
| W12 (12) | GE full grammar (deployment rule) | 0.764 ± 0.023 | 0.774 ± 0.034 | 0.658 ± 0.037 | 0.676 ± 0.049 | 0.66 |

## Paired comparisons (evolved full grammar vs reference), pooled over worlds × folds × seeds

| comparison | n pairs | mean Δ AUROC (95% CI) | Wilcoxon p | wins |
|---|---|---|---|---|
| GE full (detection rule) vs best baseline, test | 72 | -0.006 [-0.009, -0.003] | 0.00255 | 23/72 |
| GE full (detection rule) vs best baseline, external | 72 | -0.012 [-0.017, -0.007] | 3.98e-06 | 17/72 |
| GE full vs random search (same budget, same seed), test | 24 | +0.004 [-0.001, +0.009] | 0.0839 | 16/24 |
| GE full (deployment rule, RNA absent) vs H&E-only, test | 72 | +0.003 [-0.007, +0.012] | 0.302 | 41/72 |
| GE full (deployment rule, RNA absent) vs H&E-only, external | 72 | -0.010 [-0.020, +0.000] | 0.187 | 32/72 |
| GE full (deployment rule, RNA absent) vs hand-built principled (RNA absent), test | 72 | -0.016 [-0.028, -0.005] | 0.0834 | 33/72 |

Best baseline per world: {'W2': 'uhler_hand', 'W4': 'uhler_hand', 'W8': 'early_concat', 'W12': 'uhler_hand'}

## Population-level effect of each principle (all 6336 valid individuals of full-grammar runs, pooled)

| principle | n with / without | shift drop with | without | MWU p | Cliff δ | RNA-absent AUROC with | without | MWU p | invariance with | without | MWU p |
|---|---|---|---|---|---|---|---|---|---|---|---|
| P1_align | 4716 / 1620 | -0.009 | -0.009 | 0.35 | +0.02 | 0.688 | 0.651 | 9.9e-51 | -0.561 | -0.698 | 9.1e-90 |
| P2_partial | 2902 / 3434 | -0.011 | -0.008 | 0.00032 | -0.05 | 0.661 | 0.694 | 2e-74 | -0.565 | -0.623 | 2.1e-41 |
| P2_disentangle | 2415 / 3921 | -0.012 | -0.007 | 4.8e-05 | -0.06 | 0.657 | 0.692 | 1.2e-76 | -0.529 | -0.638 | 6.1e-105 |
| P3_moddrop | 2860 / 3476 | -0.011 | -0.008 | 0.0015 | -0.05 | 0.682 | 0.676 | 0.17 | -0.574 | -0.615 | 9.8e-07 |
| P3_cond | 1782 / 4554 | -0.012 | -0.008 | 0.0017 | -0.05 | 0.671 | 0.681 | 2.1e-10 | -0.588 | -0.600 | 0.0024 |
| P4_directed | 868 / 5468 | 0.002 | -0.011 | 1.4e-11 | +0.14 | 0.686 | 0.677 | 0.18 | -0.614 | -0.593 | 0.041 |

## H3: evolved shared dimension vs true shared dimension

- Spearman(true k_shared, winner shared dim) = 0.13 (p = 0.539, n = 24)
- Spearman(true k_shared, Pareto-front mean shared dim) = 0.02 (p = 0.94)
- Spearman(out-of-sample CCA rank, winner shared dim) = 0.17 (p = 0.419)
- CCA rank per world (model-free estimate of shared dim): W2: 1, W4: 11, W8: 5, W12: 8

## H5: principle enrichment among Pareto-optimal individuals of full-grammar runs (n = 829, pooled over worlds/seeds/folds)

| principle | frequency | prior | fold | one-sided p |
|---|---|---|---|---|
| P1_align | 0.813 | 0.662 | 1.23 | 5e-05 |
| P2_partial | 0.510 | 0.471 | 1.08 | 0.012 |
| P2_disentangle | 0.472 | 0.368 | 1.28 | 5e-05 |
| P3_moddrop | 0.411 | 0.517 | 0.80 | 1 |
| P3_cond | 0.398 | 0.272 | 1.46 | 5e-05 |
| P4_directed | 0.129 | 0.194 | 0.66 | 1 |

## E4: Pareto hypervolume by grammar variant (fold 0; paired with the full grammar on the same world & seed)

| variant | n runs | hypervolume mean (95% CI) | Δ vs full (paired) | Wilcoxon p | best val AUROC |
|---|---|---|---|---|---|
| GE full grammar | 12 | 0.0258 [0.0212, 0.0300] | – | – | 0.841 |
| Random search | 8 | 0.0250 [0.0192, 0.0300] | -0.0007 (n=8) | 0.195 | 0.845 |
| GE − P1 (no align) | 8 | 0.0228 [0.0174, 0.0286] | -0.0028 (n=8) | 0.195 | 0.840 |
| GE − P2 (fully shared) | 8 | 0.0252 [0.0192, 0.0302] | -0.0005 (n=8) | 0.195 | 0.839 |
| GE − P3 (no moddrop) | 8 | 0.0261 [0.0203, 0.0312] | +0.0004 (n=8) | 0.547 | 0.842 |
| GE − P4 (bi only) | 8 | 0.0259 [0.0203, 0.0309] | +0.0002 (n=8) | 0.844 | 0.842 |

## E7: recurrent motifs (Pareto-optimal, full grammar)

- (43×) latent 128s/0i/0r | cond(img)+gated | align=infonce | moddrop=no
- (29×) latent 32s/32i/0r | concat+cond(img) | align=infonce | moddrop=no
- (26×) latent 8s/0i/0r | single(rna)+single(img) | align=infonce | moddrop=yes
- (21×) latent 8s/0i/0r | single(rna)+single(rna) | align=infonce | moddrop=yes
- (21×) latent 128s/0i/0r | cond(img)+gated | align=none | moddrop=no
- (17×) latent 128s/8i/16r | gated+concat | align=infonce | moddrop=no
- (17×) latent 8s/0i/0r | single(img)+cond(img) | align=infonce | moddrop=no
- (16×) latent 16s/128i/8r | single(rna)+cond(rna) | align=infonce | moddrop=yes

## E5: hallmark probe R² by latent block (evolved full-grammar winners, test cohorts, pooled)

|               |   shared_img |   shared_rna |   img_specific |   rna_specific |
|:--------------|-------------:|-------------:|---------------:|---------------:|
| hypoxia       |         0.66 |         0.67 |           0.51 |           0.46 |
| proliferation |        -0.21 |         0.62 |          -0.19 |           0.51 |
| stroma        |         0.35 |        -0.25 |           0.39 |          -0.25 |
