# Results report
Run: `results/study/W2`

## E1-E3: detection performance (AUROC, mean ± sd over folds × seeds)

| model | params | test | held-out site | external | test, RNA absent | external, RNA absent | ECE | site probe | DeLong vs best baseline (Holm p) |
|---|---|---|---|---|---|---|---|---|---|
| evolved_bi_only-deploy_seed0 | 338,785 | 0.881 ± 0.003 | 0.814 ± 0.005 | 0.835 ± 0.002 | 0.804 ± 0.006 | 0.725 ± 0.010 | 0.078 | 0.833 | p=1 |
| evolved_no_moddrop-deploy_seed0 | 416,169 | 0.880 ± 0.009 | 0.809 ± 0.005 | 0.827 ± 0.009 | 0.795 ± 0.010 | 0.719 ± 0.012 | 0.080 | 0.833 | p=1 |
| evolved_bi_only-deploy_seed1 | 176,385 | 0.876 ± 0.004 | 0.812 ± 0.002 | 0.825 ± 0.004 | 0.693 ± 0.043 | 0.614 ± 0.058 | 0.161 | 0.487 | p=0.562 |
| evolved_random-deploy_seed0 | 424,033 | 0.875 ± 0.001 | 0.825 ± 0.004 | 0.827 ± 0.006 | 0.775 ± 0.018 | 0.712 ± 0.007 | 0.062 | 0.833 | p=1 |
| evolved_no_moddrop-deploy_seed1 | 140,049 | 0.874 ± 0.008 | 0.810 ± 0.005 | 0.820 ± 0.005 | 0.782 ± 0.006 | 0.721 ± 0.011 | 0.060 | 0.600 | p=1 |
| evolved_fully_shared-deploy_seed1 | 872,673 | 0.874 ± 0.008 | 0.811 ± 0.002 | 0.823 ± 0.004 | 0.788 ± 0.004 | 0.724 ± 0.018 | 0.093 | 0.833 | p=1 |
| evolved_no_align_seed0 | 107,873 | 0.874 ± 0.002 | 0.814 ± 0.007 | 0.824 ± 0.004 | 0.528 ± 0.014 | 0.521 ± 0.015 | 0.132 | 0.666 | p=1 |
| evolved_no_moddrop_seed1 | 383,553 | 0.872 ± 0.005 | 0.804 ± 0.009 | 0.827 ± 0.007 | 0.778 ± 0.022 | 0.714 ± 0.012 | 0.075 | 0.833 | p=1 |
| evolved_no_align-deploy_seed1 | 185,697 | 0.871 ± 0.004 | 0.808 ± 0.017 | 0.809 ± 0.009 | 0.705 ± 0.036 | 0.614 ± 0.033 | 0.178 | 0.416 | p=1 |
| evolved_fully_shared-deploy_seed0 | 176,675 | 0.871 ± 0.004 | 0.815 ± 0.004 | 0.823 ± 0.001 | 0.527 ± 0.022 | 0.571 ± 0.056 | 0.141 | 0.833 | p=1 |
| evolved_fully_shared_seed0 | 176,675 | 0.871 ± 0.004 | 0.815 ± 0.004 | 0.823 ± 0.001 | 0.527 ± 0.022 | 0.571 ± 0.056 | 0.141 | 0.833 | p=1 |
| evolved_no_moddrop_seed0 | 176,675 | 0.871 ± 0.004 | 0.815 ± 0.004 | 0.823 ± 0.001 | 0.527 ± 0.022 | 0.571 ± 0.056 | 0.141 | 0.833 | p=1 |
| evolved_bi_only_seed1 | 192,387 | 0.869 ± 0.006 | 0.820 ± 0.006 | 0.824 ± 0.007 | 0.555 ± 0.043 | 0.533 ± 0.022 | 0.095 | 0.735 | p=1 |
| evolved_random_seed1 | 237,379 | 0.868 ± 0.008 | 0.814 ± 0.006 | 0.807 ± 0.006 | 0.523 ± 0.028 | 0.523 ± 0.063 | 0.227 | 0.833 | p=1 |
| evolved_bi_only_seed0 | 189,809 | 0.868 ± 0.005 | 0.816 ± 0.004 | 0.817 ± 0.004 | 0.621 ± 0.025 | 0.569 ± 0.016 | 0.083 | 0.339 | p=1 |
| evolved_fully_shared_seed1 | 148,451 | 0.867 ± 0.008 | 0.814 ± 0.007 | 0.819 ± 0.014 | 0.621 ± 0.029 | 0.661 ± 0.039 | 0.095 | 0.831 | p=1 |
| evolved_no_align-deploy_seed0 | 333,737 | 0.862 ± 0.007 | 0.824 ± 0.003 | 0.820 ± 0.008 | 0.634 ± 0.014 | 0.614 ± 0.025 | 0.138 | 0.784 | p=0.0265 |
| evolved_random-deploy_seed1 | 320,729 | 0.857 ± 0.007 | 0.809 ± 0.009 | 0.822 ± 0.007 | 0.791 ± 0.004 | 0.724 ± 0.007 | 0.062 | 0.829 | p=0.496 |
| evolved_no_align_seed1 | 181,569 | 0.853 ± 0.018 | 0.816 ± 0.007 | 0.802 ± 0.021 | 0.561 ± 0.051 | 0.536 ± 0.032 | 0.116 | 0.422 | p=0.00934 |
| evolved_random_seed0 | 308,929 | 0.852 ± 0.000 | 0.802 ± 0.006 | 0.817 ± 0.003 | 0.812 ± 0.002 | 0.725 ± 0.010 | 0.072 | 0.833 | p=0.0463 |
| evolved_full-deploy_seed1 | 186,013 | 0.816 ± 0.060 | 0.850 ± 0.035 | 0.826 ± 0.005 | 0.669 ± 0.014 | 0.655 ± 0.054 | 0.107 | 0.441 | p=2.04e-15 |
| evolved_full_seed1 | 509,329 | 0.816 ± 0.062 | 0.848 ± 0.032 | 0.824 ± 0.012 | 0.536 ± 0.041 | 0.551 ± 0.025 | 0.088 | 0.819 | p=1.34e-20 |
| uhler_hand | 210,401 | 0.814 ± 0.060 | 0.845 ± 0.036 | 0.829 ± 0.003 | 0.724 ± 0.076 | 0.713 ± 0.022 | 0.115 | 0.833 | – |
| rna_only | 230,785 | 0.814 ± 0.062 | 0.855 ± 0.039 | 0.824 ± 0.003 | 0.517 ± 0.055 | 0.485 ± 0.081 | 0.151 | 0.833 | – |
| late_fusion | 263,938 | 0.814 ± 0.065 | 0.849 ± 0.027 | 0.834 ± 0.004 | 0.638 ± 0.068 | 0.681 ± 0.007 | 0.098 | 0.833 | – |
| evolved_full-deploy_seed2 | 384,961 | 0.813 ± 0.064 | 0.848 ± 0.032 | 0.825 ± 0.007 | 0.704 ± 0.087 | 0.721 ± 0.018 | 0.091 | 0.833 | p=7.18e-19 |
| xattn_bi | 511,361 | 0.811 ± 0.068 | 0.846 ± 0.038 | 0.829 ± 0.005 | 0.628 ± 0.059 | 0.684 ± 0.031 | 0.131 | 0.833 | – |
| evolved_full-deploy_seed0 | 217,270 | 0.811 ± 0.057 | 0.853 ± 0.042 | 0.821 ± 0.009 | 0.641 ± 0.046 | 0.671 ± 0.033 | 0.103 | 0.647 | p=5.12e-16 |
| evolved_full_seed0 | 217,270 | 0.811 ± 0.057 | 0.853 ± 0.042 | 0.821 ± 0.009 | 0.641 ± 0.046 | 0.671 ± 0.033 | 0.103 | 0.647 | p=5.12e-16 |
| evolved_full_seed2 | 303,755 | 0.810 ± 0.055 | 0.854 ± 0.035 | 0.822 ± 0.011 | 0.594 ± 0.073 | 0.631 ± 0.085 | 0.084 | 0.797 | p=1.11e-18 |
| early_concat | 247,169 | 0.809 ± 0.057 | 0.848 ± 0.031 | 0.828 ± 0.004 | 0.651 ± 0.057 | 0.678 ± 0.019 | 0.098 | 0.833 | – |
| img_only | 230,785 | 0.679 ± 0.041 | 0.708 ± 0.027 | 0.710 ± 0.008 | 0.679 ± 0.041 | 0.710 ± 0.008 | 0.097 | 0.833 | – |

## H2/H4: effect of each principle across all evaluated individuals (population level)

### grammar variant `full` (n = 1584 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.034 | -0.039 | 0.0117 | 0.08 | 0.615 | 0.570 | 3.67e-26 | -0.626 | -0.690 |
| P2_partial | -0.033 | -0.039 | 0.00113 | 0.10 | 0.594 | 0.614 | 9.61e-09 | -0.606 | -0.703 |
| P2_disentangle | -0.033 | -0.038 | 0.00576 | 0.08 | 0.592 | 0.614 | 2e-09 | -0.583 | -0.716 |
| P3_moddrop | -0.034 | -0.036 | 0.608 | 0.02 | 0.607 | 0.598 | 0.0296 | -0.648 | -0.640 |
| P3_cond | -0.029 | -0.037 | 0.000187 | 0.12 | 0.589 | 0.607 | 3.03e-06 | -0.622 | -0.652 |
| P4_directed | -0.029 | -0.036 | 0.0602 | 0.08 | 0.607 | 0.601 | 0.501 | -0.652 | -0.642 |

### grammar variant `random` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.010 | -0.010 | 0.314 | 0.05 | 0.579 | 0.578 | 0.355 | -0.761 | -0.775 |
| P2_partial | -0.011 | -0.009 | 0.978 | 0.00 | 0.579 | 0.579 | 0.986 | -0.742 | -0.785 |
| P2_disentangle | -0.013 | -0.009 | 0.239 | -0.06 | 0.580 | 0.578 | 0.964 | -0.733 | -0.780 |
| P3_moddrop | -0.012 | -0.009 | 0.149 | -0.07 | 0.581 | 0.576 | 0.466 | -0.768 | -0.764 |
| P3_cond | -0.006 | -0.012 | 0.125 | 0.09 | 0.574 | 0.581 | 0.33 | -0.769 | -0.765 |
| P4_directed | -0.005 | -0.012 | 0.0838 | 0.11 | 0.583 | 0.578 | 0.405 | -0.769 | -0.765 |

### grammar variant `no_moddrop` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.004 | -0.002 | 0.805 | -0.01 | 0.586 | 0.556 | 4.37e-07 | -0.626 | -0.663 |
| P2_partial | -0.006 | -0.002 | 0.0101 | -0.13 | 0.580 | 0.579 | 0.972 | -0.561 | -0.718 |
| P2_disentangle | -0.005 | -0.003 | 0.103 | -0.08 | 0.573 | 0.584 | 0.0129 | -0.504 | -0.727 |
| P3_moddrop | – | -0.004 | nan | nan | – | 0.579 | nan | – | -0.634 |
| P3_cond | -0.005 | -0.003 | 0.281 | -0.05 | 0.588 | 0.572 | 0.000924 | -0.602 | -0.661 |
| P4_directed | -0.006 | -0.004 | 0.646 | -0.05 | 0.573 | 0.580 | 0.316 | -0.688 | -0.631 |

### grammar variant `bi_only` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.011 | -0.004 | 0.0212 | -0.13 | 0.597 | 0.564 | 1.31e-13 | -0.654 | -0.734 |
| P2_partial | -0.006 | -0.012 | 0.0145 | 0.12 | 0.578 | 0.596 | 4.07e-05 | -0.625 | -0.712 |
| P2_disentangle | -0.005 | -0.012 | 0.00814 | 0.14 | 0.580 | 0.593 | 0.00927 | -0.601 | -0.716 |
| P3_moddrop | -0.007 | -0.011 | 0.0719 | 0.09 | 0.580 | 0.593 | 0.00449 | -0.708 | -0.656 |
| P3_cond | -0.003 | -0.012 | 0.00539 | 0.16 | 0.585 | 0.590 | 0.7 | -0.706 | -0.663 |
| P4_directed | – | -0.009 | nan | nan | – | 0.589 | nan | – | -0.675 |

### grammar variant `fully_shared` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.014 | -0.003 | 3.33e-05 | -0.24 | 0.595 | 0.553 | 2.58e-19 | -0.642 | -0.796 |
| P2_partial | – | -0.011 | nan | nan | – | 0.584 | nan | – | -0.683 |
| P2_disentangle | – | -0.011 | nan | nan | – | 0.584 | nan | – | -0.683 |
| P3_moddrop | -0.012 | -0.011 | 0.749 | 0.02 | 0.581 | 0.587 | 0.451 | -0.666 | -0.699 |
| P3_cond | -0.008 | -0.012 | 0.832 | -0.01 | 0.605 | 0.580 | 2.15e-05 | -0.796 | -0.658 |
| P4_directed | -0.004 | -0.012 | 0.106 | 0.13 | 0.587 | 0.584 | 0.679 | -0.745 | -0.675 |

### grammar variant `no_align` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | – | -0.005 | nan | nan | – | 0.569 | nan | – | -0.650 |
| P2_partial | -0.006 | -0.004 | 0.181 | -0.07 | 0.571 | 0.565 | 0.11 | -0.558 | -0.772 |
| P2_disentangle | -0.006 | -0.004 | 0.21 | -0.06 | 0.571 | 0.566 | 0.33 | -0.514 | -0.774 |
| P3_moddrop | -0.004 | -0.006 | 0.751 | 0.02 | 0.574 | 0.564 | 0.03 | -0.630 | -0.670 |
| P3_cond | -0.004 | -0.005 | 0.561 | 0.03 | 0.566 | 0.570 | 0.194 | -0.582 | -0.700 |
| P4_directed | -0.009 | -0.004 | 0.00506 | -0.23 | 0.570 | 0.568 | 0.884 | -0.759 | -0.637 |

## E4: grammar ablations

| variant | runs | Pareto hypervolume (95% CI) | best val AUROC (95% CI) |
|---|---|---|---|
| bi_only | 2 | 0.0136 [0.0132, 0.0139] | 0.849 [0.848, 0.850] |
| full | 6 | 0.0194 [0.0143, 0.0244] | 0.840 [0.835, 0.844] |
| fully_shared | 2 | 0.0125 [0.0114, 0.0135] | 0.844 [0.841, 0.847] |
| no_align | 2 | 0.0132 [0.0130, 0.0134] | 0.843 [0.842, 0.844] |
| no_moddrop | 2 | 0.0139 [0.0123, 0.0156] | 0.848 [0.847, 0.849] |
| random | 2 | 0.0126 [0.0120, 0.0132] | 0.846 [0.843, 0.849] |

### H5: principle enrichment among Pareto-optimal individuals (full grammar) vs uniform-derivation prior

| principle | frequency | prior | fold | one-sided p |
|---|---|---|---|---|
| P1_align | 0.776 | 0.662 | 1.17 | 5e-05 |
| P2_partial | 0.696 | 0.471 | 1.48 | 5e-05 |
| P2_disentangle | 0.647 | 0.368 | 1.76 | 5e-05 |
| P3_moddrop | 0.397 | 0.517 | 0.77 | 1 |
| P3_cond | 0.347 | 0.272 | 1.27 | 0.0002 |
| P4_directed | 0.093 | 0.194 | 0.48 | 1 |

### E7: recurrent motifs among Pareto-optimal individuals

- (31×) latent 8s/8i/0r | single(rna) | align=none | moddrop=no
- (30×) latent 8s/0i/0r | gated | align=infonce | moddrop=yes
- (18×) latent 32s/32i/0r | concat+cond(img) | align=infonce | moddrop=no
- (17×) latent 128s/8i/16r | gated+concat | align=infonce | moddrop=no
- (16×) latent 16s/128i/8r | single(rna)+cond(rna) | align=infonce | moddrop=yes
- (16×) latent 8s/128i/128r | gated+xattn(img2rna) | align=disc | moddrop=yes
- (15×) latent 32s/32i/32r | concat+cond(img) | align=infonce | moddrop=no
- (14×) latent 32s/128i/8r | single(rna)+cond(rna) | align=infonce | moddrop=no
- (13×) latent 256s/0i/0r | cond(img)+gated | align=infonce | moddrop=no
- (11×) latent 8s/0i/0r | single(rna) | align=infonce | moddrop=yes

## E5: partial sharing

- fold 0: CCA rank (permutation, α=0.05) = 1, MI over top canonical pairs = 0.31 nats; evolved latents: [{'shared': 32, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}, {'shared': 16, 'img_spec': 128, 'rna_spec': 8, 'disentangle': {'type': 'orth', 'w': 0.3}}, {'shared': 8, 'img_spec': 8, 'rna_spec': 0, 'disentangle': {'type': 'hsic', 'w': 0.3}}]
- fold 1: CCA rank (permutation, α=0.05) = 4, MI over top canonical pairs = 0.24 nats; evolved latents: [{'shared': 256, 'img_spec': 32, 'rna_spec': 0, 'disentangle': {'type': 'orth', 'w': 3.0}}, {'shared': 8, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}, {'shared': 64, 'img_spec': 128, 'rna_spec': 64, 'disentangle': {'type': 'orth', 'w': 0.1}}]
- Spearman(evolved shared dim, CCA rank) = 0.40 (p = 0.437, n = 6)

| hallmark | shared (img) | shared (rna) | img-specific | rna-specific |
|---|---|---|---|---|
| hypoxia | 0.58 | 0.75 | 0.56 | 0.50 |
| proliferation | -0.17 | 0.76 | -0.20 | 0.46 |
| stroma | 0.50 | -0.23 | 0.50 | -0.21 |
