# Results report
Run: `results/study/W8`

## E1-E3: detection performance (AUROC, mean ± sd over folds × seeds)

| model | params | test | held-out site | external | test, RNA absent | external, RNA absent | ECE | site probe | DeLong vs best baseline (Holm p) |
|---|---|---|---|---|---|---|---|---|---|
| evolved_random-deploy_seed0 | 205,129 | 0.839 ± 0.010 | 0.858 ± 0.009 | 0.836 ± 0.004 | 0.747 ± 0.007 | 0.711 ± 0.012 | 0.081 | 0.304 | p=0.0445 |
| evolved_fully_shared-deploy_seed0 | 195,905 | 0.835 ± 0.003 | 0.835 ± 0.003 | 0.843 ± 0.007 | 0.735 ± 0.008 | 0.709 ± 0.025 | 0.115 | 0.730 | p=0.0422 |
| evolved_fully_shared_seed0 | 195,905 | 0.835 ± 0.003 | 0.835 ± 0.003 | 0.843 ± 0.007 | 0.735 ± 0.008 | 0.709 ± 0.025 | 0.115 | 0.730 | p=0.0422 |
| early_concat | 247,169 | 0.832 ± 0.010 | 0.824 ± 0.008 | 0.849 ± 0.006 | 0.703 ± 0.041 | 0.676 ± 0.019 | 0.092 | 0.833 | – |
| evolved_fully_shared_seed1 | 725,761 | 0.831 ± 0.006 | 0.835 ± 0.007 | 0.837 ± 0.011 | 0.637 ± 0.029 | 0.633 ± 0.039 | 0.123 | 0.833 | p=0.0543 |
| evolved_full_seed0 | 218,749 | 0.831 ± 0.003 | 0.847 ± 0.009 | 0.843 ± 0.007 | 0.738 ± 0.015 | 0.688 ± 0.037 | 0.084 | 0.624 | p=2.54e-29 |
| xattn_bi | 511,361 | 0.830 ± 0.009 | 0.826 ± 0.011 | 0.836 ± 0.010 | 0.707 ± 0.032 | 0.661 ± 0.021 | 0.095 | 0.833 | – |
| evolved_bi_only-deploy_seed1 | 209,985 | 0.829 ± 0.000 | 0.837 ± 0.010 | 0.843 ± 0.006 | 0.737 ± 0.014 | 0.702 ± 0.028 | 0.123 | 0.330 | p=0.755 |
| evolved_bi_only_seed1 | 209,985 | 0.829 ± 0.000 | 0.837 ± 0.010 | 0.843 ± 0.006 | 0.737 ± 0.014 | 0.702 ± 0.028 | 0.123 | 0.330 | p=0.755 |
| evolved_no_align_seed0 | 186,337 | 0.829 ± 0.010 | 0.834 ± 0.009 | 0.844 ± 0.002 | 0.607 ± 0.043 | 0.614 ± 0.035 | 0.122 | 0.356 | p=1 |
| evolved_full-deploy_seed2 | 321,738 | 0.828 ± 0.007 | 0.836 ± 0.014 | 0.845 ± 0.008 | 0.742 ± 0.010 | 0.713 ± 0.013 | 0.093 | 0.541 | p=2.06e-26 |
| late_fusion | 263,938 | 0.828 ± 0.007 | 0.831 ± 0.008 | 0.842 ± 0.007 | 0.714 ± 0.042 | 0.682 ± 0.030 | 0.110 | 0.833 | – |
| evolved_no_moddrop_seed0 | 366,881 | 0.828 ± 0.005 | 0.839 ± 0.011 | 0.835 ± 0.004 | 0.708 ± 0.004 | 0.659 ± 0.025 | 0.072 | 0.592 | p=0.755 |
| evolved_full_seed2 | 321,738 | 0.827 ± 0.005 | 0.833 ± 0.011 | 0.850 ± 0.005 | 0.734 ± 0.013 | 0.708 ± 0.011 | 0.102 | 0.556 | p=1.86e-26 |
| evolved_full_seed1 | 281,601 | 0.826 ± 0.008 | 0.835 ± 0.015 | 0.835 ± 0.003 | 0.722 ± 0.028 | 0.661 ± 0.031 | 0.115 | 0.800 | p=4.07e-25 |
| evolved_random_seed0 | 251,201 | 0.826 ± 0.006 | 0.837 ± 0.007 | 0.837 ± 0.004 | 0.722 ± 0.020 | 0.699 ± 0.026 | 0.124 | 0.109 | p=1 |
| uhler_hand | 210,401 | 0.826 ± 0.010 | 0.831 ± 0.018 | 0.838 ± 0.010 | 0.744 ± 0.023 | 0.701 ± 0.020 | 0.115 | 0.762 | – |
| evolved_no_moddrop_seed1 | 130,361 | 0.824 ± 0.012 | 0.848 ± 0.009 | 0.844 ± 0.001 | 0.744 ± 0.021 | 0.712 ± 0.018 | 0.093 | 0.383 | p=1 |
| evolved_random_seed1 | 187,729 | 0.824 ± 0.015 | 0.842 ± 0.007 | 0.825 ± 0.001 | 0.713 ± 0.023 | 0.700 ± 0.026 | 0.092 | 0.785 | p=1 |
| evolved_full-deploy_seed1 | 673,537 | 0.823 ± 0.015 | 0.826 ± 0.013 | 0.816 ± 0.020 | 0.764 ± 0.017 | 0.710 ± 0.017 | 0.090 | 0.508 | p=3.22e-25 |
| evolved_no_align-deploy_seed1 | 270,129 | 0.823 ± 0.007 | 0.831 ± 0.007 | 0.847 ± 0.004 | 0.710 ± 0.014 | 0.706 ± 0.008 | 0.140 | 0.833 | p=1 |
| rna_only | 230,785 | 0.823 ± 0.005 | 0.826 ± 0.007 | 0.847 ± 0.005 | 0.453 ± 0.065 | 0.490 ± 0.023 | 0.095 | 0.833 | – |
| evolved_no_align-deploy_seed0 | 259,873 | 0.821 ± 0.014 | 0.813 ± 0.012 | 0.808 ± 0.014 | 0.721 ± 0.021 | 0.629 ± 0.018 | 0.093 | 0.461 | p=1 |
| evolved_bi_only-deploy_seed0 | 670,865 | 0.819 ± 0.013 | 0.850 ± 0.005 | 0.822 ± 0.004 | 0.720 ± 0.011 | 0.663 ± 0.046 | 0.099 | 0.828 | p=1 |
| evolved_bi_only_seed0 | 670,865 | 0.819 ± 0.013 | 0.850 ± 0.005 | 0.822 ± 0.004 | 0.720 ± 0.011 | 0.663 ± 0.046 | 0.099 | 0.828 | p=1 |
| evolved_no_align_seed1 | 125,705 | 0.817 ± 0.012 | 0.824 ± 0.007 | 0.834 ± 0.014 | 0.653 ± 0.016 | 0.675 ± 0.011 | 0.164 | 0.826 | p=1 |
| evolved_no_moddrop-deploy_seed0 | 103,849 | 0.810 ± 0.012 | 0.851 ± 0.001 | 0.817 ± 0.005 | 0.750 ± 0.010 | 0.718 ± 0.007 | 0.079 | 0.189 | p=1 |
| evolved_full-deploy_seed0 | 186,541 | 0.809 ± 0.017 | 0.823 ± 0.023 | 0.820 ± 0.050 | 0.711 ± 0.038 | 0.688 ± 0.036 | 0.090 | 0.311 | p=1.67e-21 |
| evolved_random-deploy_seed1 | 231,169 | 0.798 ± 0.032 | 0.845 ± 0.005 | 0.787 ± 0.037 | 0.704 ± 0.014 | 0.674 ± 0.037 | 0.081 | 0.552 | p=0.00277 |
| evolved_fully_shared-deploy_seed1 | 342,561 | 0.796 ± 0.022 | 0.829 ± 0.025 | 0.797 ± 0.025 | 0.722 ± 0.028 | 0.686 ± 0.025 | 0.133 | 0.126 | p=0.508 |
| evolved_no_moddrop-deploy_seed1 | 140,193 | 0.779 ± 0.021 | 0.818 ± 0.019 | 0.772 ± 0.047 | 0.721 ± 0.021 | 0.686 ± 0.032 | 0.154 | 0.183 | p=0.0445 |
| img_only | 230,785 | 0.748 ± 0.020 | 0.755 ± 0.019 | 0.705 ± 0.031 | 0.748 ± 0.020 | 0.705 ± 0.031 | 0.120 | 0.833 | – |

## H2/H4: effect of each principle across all evaluated individuals (population level)

### grammar variant `full` (n = 1584 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.010 | 0.006 | 5.77e-09 | -0.21 | 0.701 | 0.680 | 3.69e-10 | -0.511 | -0.711 |
| P2_partial | -0.008 | -0.005 | 0.389 | -0.03 | 0.683 | 0.707 | 4.58e-32 | -0.515 | -0.583 |
| P2_disentangle | -0.005 | -0.007 | 0.432 | 0.02 | 0.682 | 0.705 | 1.55e-26 | -0.471 | -0.597 |
| P3_moddrop | -0.009 | -0.004 | 0.0139 | -0.07 | 0.698 | 0.696 | 0.88 | -0.507 | -0.597 |
| P3_cond | -0.013 | -0.003 | 7.88e-05 | -0.12 | 0.685 | 0.702 | 2.01e-16 | -0.526 | -0.566 |
| P4_directed | -0.013 | -0.005 | 0.04 | -0.09 | 0.695 | 0.697 | 0.00474 | -0.623 | -0.545 |

### grammar variant `random` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.047 | -0.041 | 0.00431 | -0.15 | 0.663 | 0.665 | 0.118 | -0.702 | -0.776 |
| P2_partial | -0.043 | -0.047 | 0.0713 | 0.09 | 0.666 | 0.662 | 0.878 | -0.694 | -0.750 |
| P2_disentangle | -0.043 | -0.046 | 0.38 | 0.05 | 0.666 | 0.662 | 0.801 | -0.699 | -0.738 |
| P3_moddrop | -0.044 | -0.046 | 0.291 | 0.05 | 0.669 | 0.658 | 0.103 | -0.740 | -0.710 |
| P3_cond | -0.044 | -0.045 | 0.522 | 0.04 | 0.656 | 0.666 | 0.0242 | -0.740 | -0.721 |
| P4_directed | -0.042 | -0.046 | 0.0565 | 0.12 | 0.674 | 0.661 | 0.163 | -0.706 | -0.730 |

### grammar variant `no_moddrop` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.048 | -0.040 | 5.97e-05 | -0.24 | 0.691 | 0.650 | 2.91e-17 | -0.505 | -0.751 |
| P2_partial | -0.040 | -0.050 | 8.21e-07 | 0.25 | 0.666 | 0.691 | 9.71e-12 | -0.536 | -0.579 |
| P2_disentangle | -0.039 | -0.049 | 6.53e-07 | 0.26 | 0.666 | 0.690 | 5.07e-11 | -0.516 | -0.587 |
| P3_moddrop | – | -0.046 | nan | nan | – | 0.681 | nan | – | -0.561 |
| P3_cond | -0.046 | -0.045 | 0.581 | -0.03 | 0.677 | 0.684 | 0.0546 | -0.535 | -0.580 |
| P4_directed | -0.039 | -0.047 | 0.00737 | 0.19 | 0.692 | 0.679 | 0.00196 | -0.663 | -0.544 |

### grammar variant `bi_only` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.048 | -0.036 | 1.67e-06 | -0.30 | 0.692 | 0.678 | 1.07e-08 | -0.494 | -0.759 |
| P2_partial | -0.040 | -0.049 | 0.000228 | 0.19 | 0.668 | 0.703 | 1.89e-18 | -0.593 | -0.518 |
| P2_disentangle | -0.040 | -0.048 | 0.0015 | 0.17 | 0.665 | 0.700 | 1.43e-16 | -0.609 | -0.519 |
| P3_moddrop | -0.045 | -0.046 | 0.425 | 0.04 | 0.682 | 0.696 | 0.258 | -0.574 | -0.516 |
| P3_cond | -0.047 | -0.045 | 0.0448 | -0.10 | 0.675 | 0.698 | 0.000276 | -0.645 | -0.483 |
| P4_directed | – | -0.045 | nan | nan | – | 0.689 | nan | – | -0.548 |

### grammar variant `fully_shared` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | -0.054 | -0.038 | 1.72e-09 | -0.40 | 0.709 | 0.647 | 4.33e-26 | -0.507 | -0.794 |
| P2_partial | – | -0.051 | nan | nan | – | 0.698 | nan | – | -0.557 |
| P2_disentangle | – | -0.051 | nan | nan | – | 0.698 | nan | – | -0.557 |
| P3_moddrop | -0.052 | -0.051 | 0.486 | 0.04 | 0.703 | 0.694 | 0.278 | -0.557 | -0.556 |
| P3_cond | -0.055 | -0.050 | 0.134 | -0.08 | 0.695 | 0.700 | 0.00134 | -0.725 | -0.490 |
| P4_directed | -0.045 | -0.053 | 0.00114 | 0.19 | 0.692 | 0.700 | 0.363 | -0.633 | -0.534 |

### grammar variant `no_align` (n = 528 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | – | -0.042 | nan | nan | – | 0.676 | nan | – | -0.638 |
| P2_partial | -0.041 | -0.043 | 0.4 | 0.04 | 0.676 | 0.675 | 0.535 | -0.546 | -0.792 |
| P2_disentangle | -0.040 | -0.043 | 0.256 | 0.06 | 0.676 | 0.675 | 0.441 | -0.517 | -0.789 |
| P3_moddrop | -0.041 | -0.042 | 0.665 | 0.02 | 0.691 | 0.663 | 2.78e-10 | -0.704 | -0.581 |
| P3_cond | -0.041 | -0.042 | 0.844 | 0.01 | 0.662 | 0.683 | 5.68e-06 | -0.624 | -0.645 |
| P4_directed | -0.047 | -0.040 | 0.00237 | -0.18 | 0.672 | 0.677 | 0.158 | -0.679 | -0.625 |

## E4: grammar ablations

| variant | runs | Pareto hypervolume (95% CI) | best val AUROC (95% CI) |
|---|---|---|---|
| bi_only | 2 | 0.0278 [0.0274, 0.0281] | 0.819 [0.817, 0.821] |
| full | 6 | 0.0315 [0.0294, 0.0336] | 0.852 [0.828, 0.874] |
| fully_shared | 2 | 0.0280 [0.0270, 0.0291] | 0.812 [0.811, 0.813] |
| no_align | 2 | 0.0236 [0.0222, 0.0250] | 0.819 [0.818, 0.819] |
| no_moddrop | 2 | 0.0279 [0.0272, 0.0287] | 0.817 [0.814, 0.819] |
| random | 2 | 0.0272 [0.0258, 0.0285] | 0.821 [0.820, 0.823] |

### H5: principle enrichment among Pareto-optimal individuals (full grammar) vs uniform-derivation prior

| principle | frequency | prior | fold | one-sided p |
|---|---|---|---|---|
| P1_align | 0.900 | 0.662 | 1.36 | 5e-05 |
| P2_partial | 0.362 | 0.471 | 0.77 | 1 |
| P2_disentangle | 0.319 | 0.368 | 0.87 | 0.986 |
| P3_moddrop | 0.490 | 0.517 | 0.95 | 0.882 |
| P3_cond | 0.260 | 0.272 | 0.95 | 0.736 |
| P4_directed | 0.132 | 0.194 | 0.68 | 1 |

### E7: recurrent motifs among Pareto-optimal individuals

- (28×) latent 16s/0i/0r | gated | align=infonce | moddrop=no
- (24×) latent 8s/0i/0r | single(rna)+single(rna) | align=infonce | moddrop=yes
- (22×) latent 8s/0i/0r | single(rna)+single(img) | align=infonce | moddrop=yes
- (20×) latent 256s/0i/0r | xattn(img2rna) | align=infonce | moddrop=no
- (13×) latent 8s/8i/16r | gated+concat | align=infonce | moddrop=yes
- (12×) latent 128s/0i/0r | cond(img)+gated | align=infonce | moddrop=no
- (11×) latent 64s/0i/0r | cond(img) | align=infonce | moddrop=yes
- (10×) latent 8s/8i/64r | concat | align=none | moddrop=no
- (10×) latent 8s/0i/0r | single(rna)+cond(img) | align=infonce | moddrop=no
- (9×) latent 64s/0i/0r | single(img)+single(img) | align=infonce | moddrop=no

## E5: partial sharing

- fold 0: CCA rank (permutation, α=0.05) = 5, MI over top canonical pairs = 0.09 nats; evolved latents: [{'shared': 32, 'img_spec': 32, 'rna_spec': 32, 'disentangle': {'type': 'orth', 'w': 3.0}}, {'shared': 64, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}, {'shared': 16, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}]
- fold 1: CCA rank (permutation, α=0.05) = 8, MI over top canonical pairs = 0.32 nats; evolved latents: [{'shared': 64, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}, {'shared': 8, 'img_spec': 8, 'rna_spec': 64, 'disentangle': {'type': 'orth', 'w': 3.0}}, {'shared': 256, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}]
- Spearman(evolved shared dim, CCA rank) = 0.20 (p = 0.707, n = 6)

| hallmark | shared (img) | shared (rna) | img-specific | rna-specific |
|---|---|---|---|---|
| hypoxia | 0.69 | 0.63 | 0.37 | 0.40 |
| proliferation | -0.30 | 0.59 | -0.08 | 0.43 |
| stroma | 0.40 | -0.27 | 0.20 | -0.20 |
