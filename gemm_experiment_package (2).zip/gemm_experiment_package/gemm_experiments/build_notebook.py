"""Generates notebooks/main_experiment.ipynb (kept as a script so the notebook is reproducible)."""
import nbformat as nbf

nb = nbf.v4.new_notebook()
cells = []
md = lambda s: cells.append(nbf.v4.new_markdown_cell(s))
code = lambda s: cells.append(nbf.v4.new_code_cell(s))

md("""# Main experiment — Grammatical evolution of causally-principled multimodal fusion for cancer detection

This notebook runs the complete study end to end using the `gemm` package (`../src/gemm`):

1. **Setup & data** — synthetic cohorts with a known causal latent structure (default) *or* real TCGA / CPTAC / HEST cohorts.
2. **The search space** — the BNF grammar in which each of Uhler's principles (P1 contrastive alignment, P2 partially shared latents, P3 conditioning on the ubiquitous modality + modality dropout, P4 directed attention) is one production among alternatives.
3. **E1–E3 baselines** — six hand-designed fusion models written in the same language.
4. **Evolution** — NSGA-II grammatical evolution under four objectives (validation AUROC, held-out-site AUROC, batch-invariance of the shared latent, AUROC with RNA absent).
5. **E4 grammar ablations** — remove one principle at a time from the search space.
6. **Final evaluation** — retrain winners with fresh seeds; test / held-out-site / external / RNA-absent.
7. **Analysis** — E1–E3 tables with DeLong tests, H2/H4 population-level tests, H5 principle enrichment, E5 shared-information estimates and hallmark probes, E7 motifs.

> The default `PRESET = "smoke"` runs in ~10–15 min on a laptop CPU and exists to validate the pipeline; evolved models under that budget are **not** meaningful. Switch to `"full"` (and point `INTERNAL`/`EXTERNAL` at real cohorts) for the study.
""")

code("""import os, sys, json, time, glob, warnings
warnings.filterwarnings("ignore")

# --- locate the repo root (the folder containing src/gemm/__init__.py), wherever Jupyter was launched from
def _find_root():
    cands = [os.getcwd(), os.path.dirname(os.getcwd())] + [os.path.join(os.getcwd(), d) for d in os.listdir(os.getcwd()) if os.path.isdir(d)]
    for c in cands:
        if os.path.isfile(os.path.join(c, "src", "gemm", "__init__.py")):
            return os.path.abspath(c)
    raise FileNotFoundError("Could not find src/gemm/__init__.py — set ROOT to the package folder manually")
ROOT = _find_root()
os.chdir(ROOT)
for m in [m for m in sys.modules if m == "gemm" or m.startswith("gemm.")]:   # drop any stale/namespace 'gemm'
    del sys.modules[m]
sys.path.insert(0, os.path.join(ROOT, "src"))
print("repo root:", ROOT)

import numpy as np, pandas as pd, torch, yaml
import matplotlib.pyplot as plt
torch.set_num_threads(max(1, os.cpu_count() // 2))

from gemm.grammar import Grammar, production_labels
from gemm.spec import BASELINES, principle_flags
from gemm.models import FusionModel
from gemm.data import Cohort, make_splits, make_synthetic, make_synthetic_external
from gemm.fitness import evaluate, OBJECTIVES
from gemm.evolution import GE, GEConfig, pareto_front, select_final
from gemm.pipeline import load_config, get_split, get_external, full_evaluation, run_baselines, run_evolution, run_final
from gemm.analysis import uniform_prior_flags, FLAG_NAMES, cca_rank, mi_shared_estimate, load_evaluations, pareto_records
from gemm.report import write_report, table_e1_e3, table_e2_h2, table_e4, table_e5
print("torch", torch.__version__, "| device:", "cuda" if torch.cuda.is_available() else "cpu")""")

md("""## 1. Configuration

`PRESET="smoke"` uses tiny evolutionary budgets on synthetic data. `PRESET="full"` uses the pre-registered budgets
(`configs/tcga_full.yaml`). Both write to `results/<out>/` and every step is resumable.""")

code("""PRESET = "smoke"          # "smoke" | "full"
INTERNAL = None           # e.g. "data/tcga_brca.npz" ; None -> synthetic
EXTERNAL = None           # e.g. "data/cptac_brca.npz" ; None -> synthetic external (or absent for real runs before pre-registration)

cfg = load_config("configs/synthetic_smoke.yaml" if PRESET == "smoke" else "configs/tcga_full.yaml")
if INTERNAL is None:
    os.makedirs("data", exist_ok=True)
    make_synthetic(600, seed=0).save("data/synthetic_internal.npz")
    make_synthetic_external(300, seed=1).save("data/synthetic_external.npz")
    cfg["data"]["internal"], cfg["data"]["external"] = "data/synthetic_internal.npz", "data/synthetic_external.npz"
else:
    cfg["data"]["internal"], cfg["data"]["external"] = INTERNAL, EXTERNAL
cfg["device"] = "cuda" if torch.cuda.is_available() else "cpu"
cfg["out"] = f"results/notebook_{PRESET}"
os.makedirs(cfg["out"], exist_ok=True)
print(yaml.safe_dump(cfg, sort_keys=False))""")

md("""### Data and splits

Cohort format: `img` (frozen image-encoder embedding), `rna` (frozen RNA embedding), `y` (tumour/normal), `patient`, `site`
(tissue-source site — the batch variable), and optional `hallmark_*` gene-set scores for the latent probes.
Splits are patient-grouped; inside each training fold the smallest site is held out entirely (shift objective) and a
patient-grouped 20 % validation set is carved from the rest. Standardisation uses training statistics only.""")

code("""cohort = Cohort.load(cfg["data"]["internal"])
print(f"n={len(cohort)}  img dim={cohort.img.shape[1]}  rna dim={cohort.rna.shape[1]}  positives={cohort.y.mean():.2f}")
print("sites:", dict(zip(*np.unique(cohort.site, return_counts=True))))
print("hallmarks:", list(cohort.hallmarks))
FOLD = cfg["folds"][0]
split = get_split(cfg, FOLD)
external = get_external(cfg, split)
print({k: len(getattr(split, k)) for k in ("train", "val", "heldout_site", "test")}, "| external:", None if external is None else len(external))""")

md("""## 2. The search space

Every principle is a production choice, so its selection by evolution is a measurable event. The phenotype is a JSON spec;
`FusionModel` interprets it. Below: the grammar, the prior probability of each principle under uniform random derivations
(the null for H5), and one random phenotype.""")

code("""grammar = Grammar.from_file(cfg["grammar"])
print(open(cfg["grammar"]).read())""")

code("""prior = uniform_prior_flags(grammar, n=3000)
pd.Series(prior, name="prior P(flag) under uniform derivation").to_frame().T""")

code("""import random
d = grammar.map([random.Random(3).randint(0, 255) for _ in range(200)])
spec = d.spec()
print(json.dumps(spec, indent=1))
print("principle flags:", principle_flags(spec))
m = FusionModel(spec, cohort.img.shape[1], cohort.rna.shape[1])
print("parameters:", m.n_params(), "| first 6 production choices:", d.choices[:6])""")

md("""## 3. E1–E3: hand-designed baselines

`img_only`, `rna_only`, `early_concat`, `late_fusion`, `xattn_bi` (MCAT-style co-attention) and `uhler_hand`
(P1 InfoNCE + P2 64/64/32 with HSIC + P3 image-FiLM + modality dropout). Same encoders, head defaults and training recipe as
the evolved models, so the comparison isolates fusion design. Each is trained on the fold and evaluated on test,
held-out site, external cohort, and with RNA absent at inference.""")

code("""t0 = time.time()
run_baselines(cfg, FOLD, cfg["final_seeds"])
print(f"{time.time()-t0:.0f}s")""")

md("""## 4. Evolution (full grammar)

Population × generations from the config. Objectives (all maximised): `val_auc`, `shift_auc`, `invariance`
(−site-probe accuracy above chance on the image-side shared latent), `missing_auc` (RNA absent at inference; the RNA shared
latent is imputed from the image shared latent and the RNA-specific latent zeroed — the P3 mechanism, which only works if P1 holds).
Every evaluated individual is logged with its spec, production choices and fitness.""")

code("""t0 = time.time()
for seed in cfg["ge"]["seeds"]:
    run_evolution(cfg, FOLD, seed, "full")
print(f"{time.time()-t0:.0f}s")""")

code("""# Convergence: best value of each objective per generation, one line per seed
fig, axes = plt.subplots(1, len(OBJECTIVES), figsize=(4 * len(OBJECTIVES), 3))
for seed in cfg["ge"]["seeds"]:
    p = os.path.join(cfg["out"], "evolution", "full", f"seed{seed}", f"fold{FOLD}", "generations.jsonl")
    gens = [json.loads(l) for l in open(p)]
    for ax, obj in zip(axes, OBJECTIVES):
        ax.plot([g["gen"] for g in gens], [g["best"][obj] for g in gens], marker="o", ms=3, label=f"seed {seed}")
        ax.set_title(obj); ax.set_xlabel("generation")
axes[0].legend(); plt.tight_layout(); plt.show()""")

code("""# Pareto front of one run projected on (val_auc, missing_auc), coloured by whether P1 alignment is present
recs = load_evaluations(os.path.join(cfg["out"], "evolution", "full", f"seed{cfg['ge']['seeds'][0]}", f"fold{FOLD}", "evaluations.jsonl"))
valid = [r for r in recs if r["valid"]]
front = pareto_records(recs, cfg["ge"]["objectives"])
fig, ax = plt.subplots(figsize=(5, 4))
for flag, col in ((True, "tab:blue"), (False, "tab:gray")):
    pts = [(r["fitness"]["val_auc"], r["fitness"]["missing_auc"]) for r in valid if r["flags"]["P1_align"] == flag]
    if pts: ax.scatter(*zip(*pts), s=10, c=col, alpha=.4, label=f"P1_align={flag}")
ax.scatter([r["fitness"]["val_auc"] for r in front], [r["fitness"]["missing_auc"] for r in front], s=40, facecolors="none", edgecolors="red", label="Pareto")
ax.set_xlabel("val AUROC"); ax.set_ylabel("val AUROC, RNA absent"); ax.legend(); plt.show()
print(f"{len(valid)} valid evaluations, {len(recs)-len(valid)} invalid/diverged, Pareto front size {len(front)}")""")

md("""## 5. E4: grammar ablations

Re-run evolution with restricted grammars: `no_align` (P1 removed), `fully_shared` (P2 removed), `no_moddrop` (P3 loss removed),
`bi_only` (P4 removed). If a principle matters, removing it should shrink the Pareto hypervolume.""")

code("""t0 = time.time()
for variant in cfg["ablations"]:
    for seed in cfg["ge"]["seeds"]:
        run_evolution(cfg, FOLD, seed, variant)
print(f"{time.time()-t0:.0f}s")""")

md("""## 6. Final evaluation of evolved winners

Pre-registered selection rule: among Pareto-optimal individuals within 0.005 AUROC of the best `val_auc`, take the best
`shift_auc`. Winners are retrained with fresh seeds and evaluated exactly like the baselines.""")

code("""t0 = time.time()
run_final(cfg, FOLD, cfg["final_seeds"])
print(f"{time.time()-t0:.0f}s")""")

md("""## 7. Analysis

### E1–E3 table (AUROC mean ± sd; DeLong vs strongest baseline, Holm-corrected)""")

code("""e1 = table_e1_e3(cfg)
rows = []
for name, r in e1.items():
    row = {"model": name, "params": r["n_params"], "ECE": r["ece_test"], "site probe": r["site_probe_test"]}
    for t in ("test", "heldout_site", "external", "test_noRNA", "external_noRNA"):
        row[t] = f"{r[t]['mean']:.3f} ± {r[t]['sd']:.3f}" if t in r else "–"
    dl = [v for k, v in r.items() if k.startswith("delong_vs_")]
    row["DeLong p (Holm)"] = f"{dl[0].get('p_holm', dl[0]['p']):.3g}" if dl else "–"
    rows.append(row)
df_e1 = pd.DataFrame(rows).sort_values("test", ascending=False).reset_index(drop=True)
df_e1""")

code("""# Missing-modality deployment (H4): AUROC on test with RNA absent, evolved models vs img_only
fig, ax = plt.subplots(figsize=(7, 3.2))
sub = df_e1[["model", "test_noRNA"]].copy()
sub["v"] = sub["test_noRNA"].str.split(" ±").str[0].astype(float)
sub = sub.sort_values("v")
ax.barh(sub["model"], sub["v"], color=["tab:red" if m == "img_only" else ("tab:blue" if m.startswith("evolved") else "tab:gray") for m in sub["model"]])
ax.set_xlabel("test AUROC with RNA absent at inference"); ax.set_xlim(0.4, 1); plt.tight_layout(); plt.show()""")

md("""### H2 / H4 at population level

Across *all* evaluated individuals of each grammar variant: does having the principle reduce the validation→held-out-site drop,
raise RNA-absent AUROC, or improve invariance? (Mann–Whitney, Cliff's δ.)""")

code("""e2 = table_e2_h2(cfg)
rows = []
for variant, v in e2.items():
    for flag, r in v["by_flag"].items():
        rows.append({"variant": variant, "principle": flag, "n": v["n_individuals"],
                     "shift drop with": r["shift_drop_with"], "without": r["shift_drop_without"], "p": r["shift_drop_test"]["p"], "Cliff δ": r["shift_drop_test"]["cliffs_delta"],
                     "missing AUROC with": r["missing_auc_with"], "missing without": r["missing_auc_without"], "p (missing)": r["missing_auc_test"]["p"],
                     "invariance with": r["invariance_with"], "invariance without": r["invariance_without"]})
pd.DataFrame(rows).query("variant == 'full'").round(3)""")

md("""### E4: ablation hypervolumes and H5 principle enrichment""")

code("""e4 = table_e4(cfg)
df_hv = pd.DataFrame({v: {"runs": r["n_runs"], "hypervolume": r["hypervolume"][0], "HV lo": r["hypervolume"][1], "HV hi": r["hypervolume"][2],
                          "best val AUROC": r["best_val_auc"][0]} for v, r in e4["variants"].items()}).T
display(df_hv.round(4))
if e4["enrichment"]:
    enr = pd.DataFrame(e4["enrichment"]["pareto"]).T[["frequency", "prior", "fold", "p_one_sided"]]
    display(enr.round(3))
    fig, ax = plt.subplots(figsize=(6, 3))
    x = np.arange(len(enr)); ax.bar(x - .2, enr["prior"], .4, label="uniform prior", color="tab:gray"); ax.bar(x + .2, enr["frequency"], .4, label="Pareto-optimal", color="tab:blue")
    ax.set_xticks(x); ax.set_xticklabels(enr.index, rotation=30, ha="right"); ax.set_ylabel("P(principle selected)"); ax.legend(); plt.tight_layout(); plt.show()
    print("Recurrent motifs among Pareto-optimal individuals:")
    for motif, c in e4.get("motifs", []): print(f"  ({c}x) {motif}")""")

md("""### E5: partial sharing

Model-free, out-of-sample estimates of shared information between the frozen embeddings (CCA rank with permutation threshold;
kNN mutual information over canonical pairs) versus the shared dimension the winners chose; and ridge probes of the hallmark
scores from each latent block. In the synthetic world the truth is 6 shared / 6 image-specific / 4 RNA-specific latents,
`hypoxia` lives in the shared block and `proliferation` in the RNA-specific block.""")

code("""e5 = table_e5(cfg)
for fold, r in e5["folds"].items():
    print(f"fold {fold}: CCA rank = {r['cca_rank']}  MI = {r['mi_nats']:.2f} nats  top canonical corrs = {np.round(r['cca_top_corrs'][:6], 2)}")
    for lat in r["evolved_latents"]: print("   evolved latent:", lat)
if e5["hallmark_probes_r2"]:
    hp = pd.DataFrame(e5["hallmark_probes_r2"]).T
    display(hp.round(2))
    fig, ax = plt.subplots(figsize=(5, 2.5))
    im = ax.imshow(hp.values, cmap="Blues", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(range(hp.shape[1])); ax.set_xticklabels(hp.columns, rotation=30, ha="right"); ax.set_yticks(range(hp.shape[0])); ax.set_yticklabels(hp.index)
    plt.colorbar(im, label="probe R²"); ax.set_title("which latent block carries which programme"); plt.tight_layout(); plt.show()""")

md("""### Full report

`write_report` regenerates every table above into `results/<out>/analysis/report.md` and JSON files.""")

code("""report = write_report(cfg)
print(report[:1500] + "\\n...")
print("written to", os.path.join(cfg["out"], "analysis"))""")

md("""## Next steps for the real study

1. Build cohorts with `src/gemm/embeddings/` (see `docs/data_access.md`), set `INTERNAL` and `PRESET="full"`.
2. File `docs/preregistration.md` on OSF **before** creating the CPTAC file; the pipeline skips external evaluation while it is absent.
3. Run all folds and seeds (the CLI scripts parallelise over `--seeds/--folds`), then re-run section 7 here or `scripts/run_analysis.py`.
""")

nb["cells"] = cells
nb["metadata"] = {"kernelspec": {"name": "python3", "display_name": "Python 3", "language": "python"},
                  "language_info": {"name": "python"}}
import os
os.makedirs("notebooks", exist_ok=True)
nbf.write(nb, "notebooks/main_experiment.ipynb")
print("wrote notebooks/main_experiment.ipynb")
