"""E4: run every restricted-grammar variant listed under `ablations:` in the config."""
import _common  # noqa
import argparse
from gemm.pipeline import load_config, run_evolution

ap = argparse.ArgumentParser()
ap.add_argument("--config", required=True)
ap.add_argument("--folds", type=int, nargs="*")
ap.add_argument("--seeds", type=int, nargs="*")
a = ap.parse_args()
cfg = load_config(a.config)
for variant in cfg["ablations"]:
    for fold in a.folds or cfg["folds"]:
        for seed in a.seeds or cfg["ge"]["seeds"]:
            run_evolution(cfg, fold, seed, variant)
