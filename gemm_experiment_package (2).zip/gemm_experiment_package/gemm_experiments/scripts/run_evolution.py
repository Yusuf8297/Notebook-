"""Run grammatical evolution (full grammar or an ablated variant) for one or more seeds/folds."""
import _common  # noqa
import argparse
from gemm.pipeline import load_config, run_evolution, run_random_search

ap = argparse.ArgumentParser()
ap.add_argument("--config", required=True)
ap.add_argument("--variant", default="full", help="'full', an ablation name from the config, or 'random'")
ap.add_argument("--folds", type=int, nargs="*")
ap.add_argument("--seeds", type=int, nargs="*")
a = ap.parse_args()
cfg = load_config(a.config)
for fold in a.folds or cfg["folds"]:
    for seed in a.seeds or cfg["ge"]["seeds"]:
        if a.variant == "random":
            run_random_search(cfg, fold, seed, cfg["ge"]["pop_size"] * (cfg["ge"]["generations"] + 1))
        else:
            run_evolution(cfg, fold, seed, a.variant)
