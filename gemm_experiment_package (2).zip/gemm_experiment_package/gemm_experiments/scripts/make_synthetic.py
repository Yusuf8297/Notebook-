"""Generate synthetic internal ('TCGA-like') and external ('CPTAC-like') cohorts with a
known causal latent structure. Used for smoke tests and for the H3/H5 sanity checks."""
import _common  # noqa
import argparse, os
from gemm.data import make_synthetic, make_synthetic_external

ap = argparse.ArgumentParser()
ap.add_argument("--out", default="data")
ap.add_argument("--n", type=int, default=600)
ap.add_argument("--n_external", type=int, default=300)
ap.add_argument("--seed", type=int, default=0)
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
make_synthetic(a.n, seed=a.seed).save(os.path.join(a.out, "synthetic_internal.npz"))
make_synthetic_external(a.n_external, seed=a.seed + 1).save(os.path.join(a.out, "synthetic_external.npz"))
print("wrote", os.listdir(a.out))
