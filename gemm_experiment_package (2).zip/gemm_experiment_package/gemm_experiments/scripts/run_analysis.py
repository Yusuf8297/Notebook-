"""Aggregate everything into analysis/report.md and JSON tables (E1-E7)."""
import _common  # noqa
import argparse
from gemm.pipeline import load_config
from gemm.report import write_report

ap = argparse.ArgumentParser()
ap.add_argument("--config", required=True)
a = ap.parse_args()
print(write_report(load_config(a.config)))
