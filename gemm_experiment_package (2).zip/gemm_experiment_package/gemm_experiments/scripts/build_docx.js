// Generic manuscript renderer: reads a JSON spec ({title, authors, blocks:[...]}) and writes a .docx.
// Block types: h1/h2/h3 {text}, p {text | runs:[{text,italic,bold,super}]}, table {header:[...], rows:[[...]], widths:[dxa...], caption},
//              figure {path, width_in, caption}, pagebreak, bullets {items:[...]}
const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType, ImageRun, PageBreak,
        AlignmentType, BorderStyle, ShadingType, LevelFormat } = require("docx");

const spec = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const out = process.argv[3];
const FONT = "Calibri";

function runs(b) {
  if (b.runs) return b.runs.map(r => new TextRun({ text: r.text, italics: !!r.italic, bold: !!r.bold, superScript: !!r.super, font: FONT, size: 22 }));
  return [new TextRun({ text: b.text, font: FONT, size: 22 })];
}
const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: "999999" };
const borders = { top: cellBorder, bottom: cellBorder, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } };

function table(b) {
  const n = b.header.length;
  const widths = b.widths || Array(n).fill(Math.floor(9360 / n));
  const mk = (cells, head) => new TableRow({
    tableHeader: head,
    children: cells.map((c, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA }, borders,
      shading: head ? { type: ShadingType.CLEAR, fill: "EEEEEE", color: "auto" } : undefined,
      children: [new Paragraph({ children: [new TextRun({ text: String(c), bold: head, font: FONT, size: 18 })] })],
    })),
  });
  const children = [];
  if (b.caption) children.push(new Paragraph({ spacing: { before: 200, after: 80 }, children: [new TextRun({ text: b.caption, bold: true, font: FONT, size: 20 })] }));
  children.push(new Table({ columnWidths: widths, width: { size: widths.reduce((a, c) => a + c, 0), type: WidthType.DXA },
                            rows: [mk(b.header, true), ...b.rows.map(r => mk(r, false))] }));
  children.push(new Paragraph({ spacing: { after: 120 }, children: [] }));
  return children;
}

function figure(b) {
  const data = fs.readFileSync(b.path);
  const type = b.path.endsWith(".png") ? "png" : "jpg";
  const sizeOf = require("child_process").execSync(`python3 -c "from PIL import Image; im=Image.open('${b.path}'); print(im.size[0], im.size[1])"`).toString().trim().split(" ").map(Number);
  const w = Math.round((b.width_in || 6.5) * 96), h = Math.round(w * sizeOf[1] / sizeOf[0]);
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 200 }, children: [new ImageRun({ type, data, transformation: { width: w, height: h } })] }),
    new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: b.caption, font: FONT, size: 20 })] }),
  ];
}

const body = [];
body.push(new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun({ text: spec.title, font: FONT, size: 36, bold: true })] }));
if (spec.authors) body.push(new Paragraph({ spacing: { after: 240 }, children: [new TextRun({ text: spec.authors, font: FONT, size: 22, italics: true })] }));
for (const b of spec.blocks) {
  if (b.type === "h1") body.push(new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 280, after: 120 }, children: [new TextRun({ text: b.text, font: FONT, size: 28, bold: true })] }));
  else if (b.type === "h2") body.push(new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 200, after: 80 }, children: [new TextRun({ text: b.text, font: FONT, size: 24, bold: true })] }));
  else if (b.type === "h3") body.push(new Paragraph({ heading: HeadingLevel.HEADING_3, spacing: { before: 160, after: 60 }, children: [new TextRun({ text: b.text, font: FONT, size: 22, bold: true, italics: true })] }));
  else if (b.type === "p") body.push(new Paragraph({ spacing: { after: 140, line: 300 }, alignment: AlignmentType.JUSTIFIED, children: runs(b) }));
  else if (b.type === "bullets") b.items.forEach(t => body.push(new Paragraph({ numbering: { reference: "bul", level: 0 }, spacing: { after: 60 }, children: [new TextRun({ text: t, font: FONT, size: 22 })] })));
  else if (b.type === "table") body.push(...table(b));
  else if (b.type === "figure") body.push(...figure(b));
  else if (b.type === "pagebreak") body.push(new Paragraph({ children: [new PageBreak()] }));
}
const doc = new Document({
  numbering: { config: [{ reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] }] },
  styles: { default: { document: { run: { font: FONT, size: 22 } } } },
  sections: [{ properties: { page: { margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } }, children: body }],
});
Packer.toBuffer(doc).then(buf => { fs.writeFileSync(out, buf); console.log("wrote", out); });
