"""Robust winner selection from finished evolution logs (no re-running evolution).

For every run: rebuild the Pareto front from evaluations.jsonl, shortlist the top-K candidates by
each rule's primary objective, re-train each shortlisted spec with `--extra_seeds` additional seeds,
average the objectives over seeds, and apply the rules to the averaged values.

Rules (both fixed in docs/preregistration.md):
  detection  (winner.json):        among candidates within `tol` of the best mean val_auc, max mean shift_auc
  deployment (winner_deploy.json): among candidates within `tol_deploy` of the best mean val_auc, max mean missing_auc
The original single-seed choice is kept as winner_v1.json for transparency.
"""
import _common  # noqa
import argparse, glob, json, os, shutil

import numpy as np

from gemm.analysis import load_evaluations, pareto_records
from gemm.fitness import evaluate
from gemm.pipeline import get_split, load_config
from gemm.spec import principle_flags, to_json

ap = argparse.ArgumentParser()
ap.add_argument("--config", required=True)
ap.add_argument("--variants", nargs="*")
ap.add_argument("--top_k", type=int, default=6)
ap.add_argument("--extra_seeds", type=int, default=2)
ap.add_argument("--tol", type=float, default=0.005)
ap.add_argument("--tol_deploy", type=float, default=0.02)
a = ap.parse_args()
cfg = load_config(a.config)
objectives = cfg["ge"]["objectives"]
splits = {}

for run in sorted(glob.glob(os.path.join(cfg["out"], "evolution", "*", "seed*", "fold*"))):
    variant = run.split(os.sep)[-3]
    if a.variants and variant not in a.variants:
        continue
    fold = int(run.split("fold")[-1])
    if os.path.exists(os.path.join(run, "winner_deploy.json")):
        print("[skip]", run); continue
    recs = load_evaluations(os.path.join(run, "evaluations.jsonl"))
    front = pareto_records(recs, objectives)
    if not front:
        continue
    if fold not in splits:
        splits[fold] = get_split(cfg, fold)
    split = splits[fold]
    # shortlist: union of top-K by val_auc and top-K by missing_auc (dedup by spec)
    short = {}
    for key in ("val_auc", "missing_auc"):
        for r in sorted(front, key=lambda r: -r["fitness"][key])[: a.top_k]:
            short[to_json(r["spec"])] = r
    # re-evaluate with extra seeds and average
    scored = []
    for sj, r in short.items():
        vals = [r["fitness"]]
        for s in range(1, a.extra_seeds + 1):
            f = evaluate(r["spec"], split, seed=1000 + s, device=cfg["device"], time_budget_s=cfg["ge"]["time_budget_s"])
            if f.valid:
                vals.append(f.values)
        mean = {k: float(np.mean([v[k] for v in vals])) for k in objectives}
        scored.append({"spec": r["spec"], "fitness_single": r["fitness"], "fitness_mean": mean, "n_seeds": len(vals),
                       "flags": principle_flags(r["spec"])})
    best_val = max(s["fitness_mean"]["val_auc"] for s in scored)
    det = max([s for s in scored if s["fitness_mean"]["val_auc"] >= best_val - a.tol], key=lambda s: s["fitness_mean"]["shift_auc"])
    dep = max([s for s in scored if s["fitness_mean"]["val_auc"] >= best_val - a.tol_deploy], key=lambda s: s["fitness_mean"]["missing_auc"])
    old = os.path.join(run, "winner.json")
    if os.path.exists(old) and not os.path.exists(os.path.join(run, "winner_v1.json")):
        shutil.move(old, os.path.join(run, "winner_v1.json"))
    front_out = [{"spec": r["spec"], "fitness": r["fitness"], "flags": r["flags"]} for r in front]
    for name, w in (("winner.json", det), ("winner_deploy.json", dep)):
        json.dump({"spec": w["spec"], "fitness": w["fitness_mean"], "fitness_single": w["fitness_single"], "n_seeds": w["n_seeds"],
                   "flags": w["flags"], "rule": name.replace(".json", ""), "shortlist": scored, "front": front_out},
                  open(os.path.join(run, name), "w"), indent=1)
    print(f"[{variant} fold{fold} {run.split(os.sep)[-2]}] shortlist {len(scored)} | detection: val {det['fitness_mean']['val_auc']:.3f} "
          f"missing {det['fitness_mean']['missing_auc']:.3f} | deploy: val {dep['fitness_mean']['val_auc']:.3f} missing {dep['fitness_mean']['missing_auc']:.3f}")
