#!/usr/bin/env bash
# End-to-end pipeline on synthetic data. ~10-15 min on 2 CPU cores.
set -e
cd "$(dirname "$0")/.."
CFG=configs/synthetic_smoke.yaml
python scripts/make_synthetic.py --out data
python scripts/run_baselines.py --config $CFG
python scripts/run_evolution.py --config $CFG --variant full
python scripts/run_ablations.py --config $CFG
python scripts/run_final.py --config $CFG
python scripts/run_analysis.py --config $CFG
