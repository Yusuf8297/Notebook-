"""Build the manuscript (docx) from the simulation-study summary. Numbers are read from
results/study/summary/*.json|csv so the text never drifts from the results.

    python scripts/summarize_study.py
    python scripts/make_manuscript.py --out manuscript/manuscript.docx
"""
import _common  # noqa
import argparse, json, os, subprocess

import numpy as np
import pandas as pd
import yaml

ap = argparse.ArgumentParser()
ap.add_argument("--summary", default="results/study/summary")
ap.add_argument("--out", default="manuscript/manuscript.docx")
a = ap.parse_args()
os.makedirs(os.path.dirname(a.out), exist_ok=True)
S = json.load(open(os.path.join(a.summary, "summary.json")))
T1 = pd.read_csv(os.path.join(a.summary, "table1_performance.csv"))
H3 = pd.read_csv(os.path.join(a.summary, "table_h3_shared_dim.csv"))
E5 = pd.read_csv(os.path.join(a.summary, "table_e5_probes.csv"), index_col=0)
cfg = yaml.safe_load(open("configs/synthetic_study/W8.yaml"))
worlds = sorted(T1.world.unique(), key=lambda w: int(w[1:]))
LAB = {"img_only": "H&E-only", "rna_only": "RNA-only", "early_concat": "early concatenation", "late_fusion": "late fusion",
       "xattn_bi": "bidirectional co-attention", "uhler_hand": "hand-built principled model", "evolved_random": "random search",
       "evolved_full": "GE (full grammar)", "evolved_no_align": "GE − P1", "evolved_fully_shared": "GE − P2",
       "evolved_no_moddrop": "GE − P3", "evolved_bi_only": "GE − P4", "evolved_full-deploy": "GE (full grammar, deployment rule)", "evolved_random-deploy": "random search (deployment rule)"}

def g(world, group, col):
    r = T1[(T1.world == world) & (T1.group == group)]
    return float(r[col].iloc[0]) if len(r) else float("nan")

def pooled(group, col):
    v = [g(w, group, col) for w in worlds]
    return np.nanmean(v)

p = S["paired"]; enr = S["enrichment"]; hv = S["hv"]; h2 = S["h2"]; h3 = S["h3"] or {}
fmt_p = lambda x: "p < 0.001" if x < 0.001 else f"p = {x:.3f}"
n_pool = sum(v["n_with"] + v["n_without"] for v in h2.values()) // max(len(h2), 1)

blocks = []
H = lambda lvl, t: blocks.append({"type": f"h{lvl}", "text": t})
P = lambda t: blocks.append({"type": "p", "text": t})

# ------------------------------------------------------------------ Abstract
H(1, "Abstract")
P(f"Multimodal models that fuse histology with transcriptomics for cancer detection are designed by hand, and the choices they fix — whether "
  f"modalities are aligned, whether the latent space separates shared from modality-specific information, and whether the model still works "
  f"when the expensive modality is missing — are the choices that causal representation-learning theory says matter. We ask whether an "
  f"architecture search that knows nothing of that theory rediscovers it. Four causal integration principles are encoded as alternative "
  f"productions of a context-free grammar spanning fusion topology, latent partitioning, loss composition and training recipe; the grammar is "
  f"searched with multi-objective grammatical evolution (NSGA-II) under detection, institution-shift, batch-invariance and missing-modality "
  f"objectives over frozen embeddings. In a controlled simulation with a known causal latent structure across four worlds that differ in their "
  f"true shared dimensionality ({p['test']['n']} paired winner evaluations; {n_pool} evaluated candidates), contrastive alignment was selected among "
  f"Pareto-optimal solutions {enr['P1_align']['fold']:.2f}× more often than under random derivation ({fmt_p(enr['P1_align']['p_one_sided'])}), and "
  f"partially shared latents with an explicit independence penalty {enr['P2_disentangle']['fold']:.2f}× more often ({fmt_p(enr['P2_disentangle']['p_one_sided'])}). "
  f"At the population level, candidates carrying an alignment term had markedly lower batch identifiability of their shared latent and a higher AUROC "
  f"with the transcriptomic input absent ({h2['P1_align']['means'][2]:.3f} vs {h2['P1_align']['means'][3]:.3f}, {fmt_p(h2['P1_align']['missing']['p'])}); "
  f"linear probes on evolved latents placed a shared gene programme in the shared block and an RNA-specific programme outside it, the "
  f"empirical signature of partial sharing. Evolved winners did not, however, exceed a hand-built model that implements the same principles "
  f"(test ΔAUROC {p['test']['mean']:+.3f}, 95% CI [{p['test']['lo']:+.3f}, {p['test']['hi']:+.3f}]), nor did the evolved shared dimension track the "
  f"true one (Spearman ρ = {h3.get('true_vs_winner', {}).get('rho', float('nan')):.2f}). Evolution therefore rediscovers the principles as "
  f"population-level preferences, while a well-specified principled design remains a strong baseline at modest search budgets. The framework, "
  f"grammar and a pre-registered protocol for the TCGA/CPTAC/HEST-1k stage are released.")

# ------------------------------------------------------------------ Introduction
H(1, "1. Introduction")
P("Cancer detection from tissue increasingly draws on more than one measurement of the same specimen: a haematoxylin-and-eosin (H&E) slide, "
  "bulk or spatial transcriptomics, and clinical covariates. Multimodal fusion models for pathology–omics data — PORPOISE, MCAT, SurvPath and "
  "the foundation-model fusion heads that followed them — choose a fusion topology by hand, usually early concatenation or a single "
  "bidirectional cross-attention block, and train it with a task loss alone. Whether that topology is the right one is rarely tested, because "
  "testing it would mean enumerating alternatives.")
P("Causal representation learning offers a principled account of what a multimodal representation should look like. Uhler and colleagues "
  "distil it into four design principles: (P1) causal features are invariant to the modality in which they are measured, so modalities should "
  "be aligned in a shared latent space with a contrastive or discriminative loss; (P2) some information is modality-specific and cannot be "
  "generated from the other modality, so the latent space should be partially overlapping, with shared and modality-specific parts whose "
  "dimensions are identifiable under stated conditions (Sturma et al., 2023); (P3) the widely available modality — imaging — should supply "
  "context for the expensive one, which also means a model should degrade gracefully when the expensive modality is absent; and (P4) "
  "attention is directed and can be read as a causal regulatory direction. These principles have each been demonstrated in dedicated "
  "models, but they have not been tested against their alternatives inside a single search space.")
P("Grammatical evolution (GE) is the natural tool for that test. A context-free grammar defines a space of programmes; an evolutionary "
  "search over integer genomes, mapped through the grammar, explores it under an arbitrary fitness. Because every design decision is a "
  "production of the grammar, the frequency with which a decision is selected is a measurable quantity with a computable null. If the "
  "grammar contains both the principled and the unprincipled options and evolution is driven only by task-relevant objectives, then the "
  "enrichment of the principled options among the Pareto-optimal solutions is empirical evidence for the principles that is independent "
  "of the theory that motivated them — and the ablation of a production from the grammar measures its value directly.")
P("We make three contributions. First, a grammar and interpreter for multimodal fusion over frozen foundation-model embeddings in which "
  "latent partitioning, alignment losses, disentanglement penalties, fusion operators, attention direction, modality dropout and the training "
  "recipe are all evolvable, together with a four-objective fitness that operationalises P1–P3 as measurable quantities (detection AUROC, "
  "held-out-institution AUROC, linear batch-identifiability of the shared latent, and AUROC with the omics input absent at inference). "
  "Second, a controlled simulation study with a known causal latent structure, in which the true shared dimensionality is varied across "
  "worlds, that tests five pre-specified hypotheses about performance, transfer, missing-modality deployment, rediscovery of principles, "
  "and the recovery of the shared dimension. Third, a pre-registered protocol and open pipeline for the same experiment on public "
  "histology–transcriptomics cohorts (TCGA with CPTAC as an external cohort, and HEST-1k at spot level), which is the study's next stage.")

# ------------------------------------------------------------------ Methods
H(1, "2. Methods")
H(2, "2.1 Problem setting")
P("Each sample i has a frozen image embedding x_i^img ∈ R^{D_img}, a frozen RNA embedding x_i^rna ∈ R^{D_rna}, a binary label y_i "
  "(tumour vs normal), a patient identifier used for grouping, and a site identifier (tissue-source institution) used as the batch variable. "
  "Frozen encoders make thousands of candidate evaluations affordable and isolate the object of study, which is fusion design rather "
  "than representation learning.")
H(2, "2.2 Search space")
P("A candidate is a JSON specification produced by a BNF grammar (Supplementary Grammar S1) and interpreted into a PyTorch module. Each "
  "modality passes through a one-hidden-layer encoder to a latent split into a shared block of dimension s ∈ {8,…,256} and a "
  "modality-specific block of dimension in {0, 8,…,128}. The top-level latent production is a binary choice between a fully shared latent "
  "(both specific blocks zero, no disentanglement term) and a partially shared one (P2), so that the P2 decision has a prior of 0.5 under "
  "uniform derivation. Fusion operators act on the projected latent vectors or their tokens: concatenation, a learned gate, FiLM conditioning "
  "of one modality on the other (P3), cross-attention with a chosen direction — image-queries-RNA, RNA-queries-image, or bidirectional (P4) — "
  "and a unimodal pass-through; up to two operators can be stacked. The loss is the task binary cross-entropy plus optional terms: a symmetric "
  "InfoNCE or an adversarial (gradient-reversal) modality classifier on the shared latents (P1); an HSIC, orthogonality or MMD independence "
  "penalty between shared and specific blocks (P2); reconstruction of either input from its latent; and a modality-dropout term that "
  "re-evaluates the task loss with the RNA input removed for a random subset of the batch (P3). Learning rate, weight decay, epochs and batch "
  "size are also evolved. Baselines in the same language are H&E-only, RNA-only, early concatenation, late fusion (two unimodal heads with "
  "averaged logits), bidirectional co-attention in the style of MCAT, and a hand-built model that follows P1–P3 with fixed hyperparameters.")
P("When the RNA input is absent at inference, its shared latent is replaced by the image's shared latent and its specific latent is set to "
  "zero. This is the P3 mechanism: imputation through the shared space is valid only to the extent that the two shared latents are aligned "
  "(P1) and the specific block was correctly separated (P2), so the missing-modality objective couples the three principles.")
H(2, "2.3 Objectives and search")
P("Four objectives, all maximised: validation AUROC; AUROC on tissue-source sites held out entirely from training (institution shift); "
  "batch invariance, defined as minus the balanced accuracy above chance of a cross-validated linear probe predicting site from the "
  "image-side shared latent; and AUROC on the validation fold with RNA absent. Parameter count breaks ties. Genomes have 200 codons; "
  f"populations of {cfg['ge']['pop_size']} evolve for {cfg['ge']['generations']} generations with one-point crossover (p = {cfg['ge']['p_crossover']}, cut inside the used "
  f"region), per-codon mutation ({cfg['ge']['p_mutation']}), binary tournament on non-domination rank and crowding distance, and (μ+λ) NSGA-II survival; "
  "duplicate phenotypes are cached, invalid derivations and diverged trainings receive penalty fitness, and each candidate is trained with early "
  "stopping on validation AUROC under a wall-clock cap. The final model of a run is chosen by a rule fixed in advance: among Pareto-optimal "
  "individuals within 0.005 of the best validation AUROC, the one with the best held-out-site AUROC. A random-search control draws the same "
  "number of uniform derivations with no selection. Every evaluated individual is logged with its specification, its sequence of production "
  "choices and its fitness, so all analyses are recomputable from the logs.")
H(2, "2.4 Simulation design")
P("To test the hypotheses against a known ground truth we constructed four synthetic worlds that share one causal structure and differ "
  "only in the number of shared latent variables (k_shared ∈ {2, 4, 8, 12}; six image-specific and four RNA-specific latents). Shared latents "
  "drive both modalities through fixed non-linear mixing functions; the tumour label depends on shared latents and on an RNA-specific latent, "
  "so part of the signal is invisible to the image, mirroring the observation that some protein-level phenotypes cannot be predicted from "
  "chromatin images. Sites add an additive batch offset to the image embedding only. Three gene-programme scores are functions of known "
  "blocks: hypoxia of the shared block, proliferation of the RNA-specific block, stroma of the image-specific block. Each world has an internal "
  f"cohort ({cfg['data'].get('n', 1200)} patients, six sites) and an external cohort (400 patients, three new sites, stronger batch effect) generated from the same "
  "mixing functions. Internal cohorts are split by patient into five outer folds; within a training fold the smallest site is held out and a "
  "patient-grouped 20% validation subset is carved from the rest; standardisation uses training statistics only, also for the external cohort.")
H(2, "2.5 Experiments and hypotheses")
P("H1 (performance): evolved models match or exceed the strongest hand-designed baseline on the outer test fold. H2 (transfer): individuals "
  "with an alignment term show a smaller validation-to-held-out-site drop and evolved winners transfer to the external cohort. H3 (partial "
  "sharing): the evolved shared dimension increases with the true shared dimension and with a model-free out-of-sample canonical-correlation "
  "estimate. H4 (missing modality): evolved models deployed without RNA outperform models trained on histology alone. H5 (rediscovery): "
  "P1–P3 productions are enriched among Pareto-optimal individuals relative to the uniform-derivation prior, and removing each from the "
  "grammar reduces the Pareto hypervolume. Winners were retrained with three fresh seeds on two outer folds of every world; ablated grammars "
  "and the random-search control ran on fold 0 with two seeds. Paired differences are tested with Wilcoxon signed-rank tests over "
  "(world, fold, seed) triplets and reported with bootstrap 95% confidence intervals; population-level effects with Mann–Whitney U and Cliff's δ "
  "over all evaluated individuals; enrichment with one-sided binomial tests against the simulated prior; and the hallmark probes are "
  "five-fold cross-validated ridge R² from each latent block on the held-out test cohort.")

# ------------------------------------------------------------------ Results
H(1, "3. Results")
H(2, "3.1 Evolved winners versus hand-designed baselines (H1, H2)")
best = {w: max([g_ for g_ in T1[T1.world == w].group if not g_.startswith("evolved_")], key=lambda g_: g(w, g_, "test_mean")) for w in worlds}
P(f"Table 1 and Figure 1 summarise detection AUROC across the four worlds. The strongest hand-designed baseline was "
  f"{', '.join(f'the {LAB[best[w]]} in {w}' for w in worlds)}. Pooled over {p['test']['n']} paired (world, fold, retraining-seed) runs, the "
  f"full-grammar winner selected by the detection rule changed test AUROC by {p['test']['mean']:+.3f} relative to the strongest baseline "
  f"(95% CI [{p['test']['lo']:+.3f}, {p['test']['hi']:+.3f}]; Wilcoxon {fmt_p(p['test']['p'])}; {p['test']['wins']}/{p['test']['n']} wins) and external-cohort "
  f"AUROC by {p['external']['mean']:+.3f} ([{p['external']['lo']:+.3f}, {p['external']['hi']:+.3f}]; {fmt_p(p['external']['p'])}). H1 is therefore not supported "
  f"at this budget: evolved winners are statistically indistinguishable from, or marginally below, a hand-built model that implements P1–P3 with "
  f"sensible fixed hyperparameters. Against the random-search control with the same evaluation budget and seed, evolution changed test AUROC by "
  f"{p['vs_random']['mean']:+.3f} ([{p['vs_random']['lo']:+.3f}, {p['vs_random']['hi']:+.3f}]; {fmt_p(p['vs_random']['p'])}; {p['vs_random']['wins']}/{p['vs_random']['n']} wins), "
  f"a small advantage for selection over sampling that does not reach significance with 24 pairs.")
r = h2["P1_align"]; m = r["means"]
P(f"The population-level picture is different. Across {n_pool} valid candidates from the full-grammar runs, individuals carrying an alignment term "
  f"had a batch-invariance score of {m[4]:.3f} versus {m[5]:.3f} without it (Mann–Whitney {fmt_p(r['inv']['p'])}) — the linear probe recovered the "
  f"tissue-source site from the shared latent far less often — and an RNA-absent AUROC of {m[2]:.3f} versus {m[3]:.3f} ({fmt_p(r['missing']['p'])}, "
  f"Cliff's δ = {r['missing']['cliffs_delta']:+.2f}). The validation-to-held-out-site drop was small in every world ({m[0]:.3f} with, {m[1]:.3f} without, "
  f"{fmt_p(r['shift']['p'])}), because the simulated batch effect perturbs the image embedding only and the RNA pathway carries most of the label "
  f"signal; the shift component of H2 is therefore untested here and is deferred to the real-data stage, where institution effects are known to be large.")
H(2, "3.2 Deployment without the transcriptomic modality (H4)")
P(f"For the RNA-absent scenario we used the deployment selection rule (Methods). Deployed without RNA, these winners reached a mean test AUROC of "
  f"{pooled('evolved_full-deploy','test_noRNA_mean'):.3f} against {pooled('img_only','test_noRNA_mean'):.3f} for models trained on histology alone "
  f"(paired Δ = {p['noRNA']['mean']:+.3f}, 95% CI [{p['noRNA']['lo']:+.3f}, {p['noRNA']['hi']:+.3f}], {fmt_p(p['noRNA']['p'])}; external cohort "
  f"Δ = {p['noRNA_ext']['mean']:+.3f}, {fmt_p(p['noRNA_ext']['p'])}) and {p['noRNA_vs_hand']['mean']:+.3f} relative to the hand-built principled model "
  f"deployed the same way ({fmt_p(p['noRNA_vs_hand']['p'])}). H4 is not supported for winners. The population-level analysis nevertheless shows the "
  f"mechanism working: alignment raised RNA-absent AUROC by {m[2]-m[3]:.3f} on average across all candidates, and partially shared latents lowered it "
  f"({h2['P2_partial']['means'][2]:.3f} vs {h2['P2_partial']['means'][3]:.3f}, {fmt_p(h2['P2_partial']['missing']['p'])}), which is what the theory predicts: "
  f"information placed in an RNA-specific block cannot be imputed from the image, so partial sharing trades missing-modality robustness for a "
  f"cleaner shared space. Note that in these worlds an RNA-specific latent contributes directly to the label, which bounds every image-only "
  f"deployment, including the distilled one, well below the bimodal model.")
H(2, "3.3 Does evolution rediscover the principles? (H5)")
lines = []
for k in ["P1_align", "P2_partial", "P2_disentangle", "P3_moddrop", "P3_cond", "P4_directed"]:
    if k in enr:
        e = enr[k]; lines.append(f"{k}: {e['frequency']:.2f} vs prior {e['prior']:.2f} ({e['fold']:.2f}×, {fmt_p(e['p_one_sided'])})")
P("Figure 3a compares the frequency of each principle among the Pareto-optimal individuals of the full-grammar runs with its probability under "
  "uniform random derivation (one-sided binomial): " + "; ".join(lines) + ". Contrastive or adversarial alignment (P1), an explicit independence "
  "penalty between shared and specific blocks (P2) and image-conditioned FiLM fusion (P3, conditioning) were selected significantly more often than "
  "chance; the modality-dropout loss (P3, robustness) and directed attention (P4) were selected less often than chance. The latter two are the "
  "productions that trade validation AUROC — the first objective and the one that dominates selection in practice — for the third and fourth "
  "objectives, and their depletion is consistent with the population-level finding that modality dropout raised RNA-absent AUROC only marginally "
  f"({h2['P3_moddrop']['means'][2]:.3f} vs {h2['P3_moddrop']['means'][3]:.3f}, {fmt_p(h2['P3_moddrop']['missing']['p'])}) once alignment is present.")
hv_lines = [f"{LAB['evolved_'+v]}: Δ = {r['delta']:+.4f} ({fmt_p(r['p']) if r['p']==r['p'] else 'n too small'}, n = {r['n']})" for v, r in hv.items() if v != "random"]
P("Ablating productions from the grammar (Figure 3b) did not measurably change the Pareto hypervolume with eight paired runs per variant — "
  + "; ".join(hv_lines) + f"; random search Δ = {hv.get('random', {}).get('delta', float('nan')):+.4f}. The point estimate for removing "
  "alignment is the largest reduction, but the hypervolume of a four-objective front estimated from 264 evaluations is too variable for this "
  "test to be informative at the present budget; we report it for completeness and treat the enrichment analysis as the primary H5 evidence.")
H(2, "3.4 Recovery of the shared dimension and what the latent blocks encode (H3)")
if h3:
    P(f"Across {len(H3)} full-grammar winners, the evolved shared-latent dimension was unrelated to the true shared dimension of the generating "
      f"process (Spearman ρ = {h3['true_vs_winner']['rho']:.2f}, {fmt_p(h3['true_vs_winner']['p'])}; Pareto-front mean ρ = "
      f"{h3['true_vs_front']['rho']:.2f}, {fmt_p(h3['true_vs_front']['p'])}) and to the out-of-sample canonical-correlation rank of the frozen "
      f"embeddings (ρ = {h3['cca_vs_winner']['rho']:.2f}, {fmt_p(h3['cca_vs_winner']['p'])}; Figure 2). The CCA ranks themselves were noisy estimates of "
      f"the truth (" + ", ".join(f"{w}: {int(H3[H3.world==w].cca_rank.iloc[0])} vs {int(H3[H3.world==w].true_shared.iloc[0])}" for w in worlds if (H3.world==w).any())
      + "). H3 is not supported. Two features of the design explain this: the grammar offers the shared dimension in powers of two from 8 to 256, all of "
      "which exceed the true dimension in every world, and parsimony enters the fitness only as a tie-break, so nothing pushes the shared block towards "
      "minimality once the objectives are satisfied. A follow-up should either add a capacity objective or estimate the effective shared dimension of "
      "the trained latent (for example by its stable rank) rather than reading the nominal width.")
if len(E5):
    r2 = lambda h, b: E5.loc[h, b] if (h in E5.index and b in E5.columns and E5.loc[h, b] == E5.loc[h, b]) else float("nan")
    P(f"The probes tell a clearer story (Figure 4). Linear probes on the winners' latent blocks placed the hypoxia programme, a function of the shared "
      f"latents by construction, in the shared block (R² = {r2('hypoxia','shared_img'):.2f} from the image-side shared latent, {r2('hypoxia','shared_rna'):.2f} "
      f"from the RNA side), whereas the proliferation programme, a function of the RNA-specific latents, was readable from the RNA-side shared block "
      f"({r2('proliferation','shared_rna'):.2f}) and the RNA-specific block ({r2('proliferation','rna_specific'):.2f}) but not from the image-side shared "
      f"latent (R² = {r2('proliferation','shared_img'):.2f}), and the stroma programme, a function of the image-specific latents, from the image side "
      f"({r2('stroma','shared_img'):.2f}, {r2('stroma','img_specific'):.2f}) but not the RNA side ({r2('stroma','shared_rna'):.2f}). Information that one "
      f"modality cannot observe stays out of that modality's shared representation; this is the operational content of P2 and it emerges without "
      f"being specified.")

# ------------------------------------------------------------------ Discussion
H(1, "4. Discussion")
P("The central question was whether a search procedure that knows nothing about causal representation theory converges on its recommendations "
  "when the search space contains both the principled options and their alternatives and the objectives are the ones a deployment cares about. "
  "The answer is graded and, we think, more useful than a uniform yes. As population-level preferences, the principles are rediscovered: alignment "
  "and an explicit shared/specific independence penalty are enriched among Pareto-optimal solutions, alignment makes the shared latent far less "
  "identifiable by institution and makes the model far more usable when the omics modality is absent, and the latent partition that evolution "
  "chooses keeps modality-private biology out of the shared space. As a route to a better single model, evolution at this budget did not beat a "
  "hand-built model that already follows the principles, and the nominal shared dimension it chose carried no information about the true one.")
P("Three lessons follow for the real-data stage. First, the objectives shape the rediscovery: modality dropout and directed attention were "
  "depleted, not because they hurt the objectives they serve but because they cost validation AUROC, which dominates selection. A lexicographic or "
  "constrained formulation (a floor on RNA-absent AUROC) would test P3 more fairly than an unweighted Pareto front. Second, winner selection must be "
  "seed-robust; re-training shortlisted candidates before choosing, as done here, is cheap and should be pre-registered. Third, the value of the "
  "search is likely to appear where hand design is hardest — real institution effects, non-linear batch structure, and spot-level spatial data — "
  "rather than in a simulation where the principled baseline is, by construction, close to optimal.")
P("Limitations. The results are from a simulation with a known causal structure; that is what makes the probe analysis possible, but generalisation "
  "to histology–transcriptomics data is the object of the pre-registered second stage (TCGA BRCA, LUAD, COAD, KIRC, OV with CPTAC as external "
  "cohorts and HEST-1k at spot level), whose grammar hash, budgets and both selection rules are fixed in the accompanying repository. Evolutionary "
  "budgets here are modest (population 24, ten generations, 264 evaluations per run); the full-scale configuration uses population 100 and forty "
  "generations, and the small, non-significant advantage over random search may grow or vanish with budget. The batch effect is additive and "
  "affects one modality; real institution effects are neither. Frozen embeddings cap absolute performance and are shared by all models.")
P("Conclusion. Grammar-guided evolution is a workable instrument for testing multimodal design principles empirically: it recovers alignment and "
  "partial sharing as population-level preferences, shows through probes that the evolved partition has the semantics the theory assigns to it, "
  "and identifies which principles the chosen objectives fail to reward. Whether it also produces better cancer detectors than principled hand "
  "design is, on the present evidence, an open question that the real-data stage is designed to settle.")

# ------------------------------------------------------------------ Tables & figures
H(1, "Tables and Figures")
hdr = ["World (true k)", "Model", "Test", "External", "Test, RNA absent", "External, RNA absent", "Site probe"]
rows = []
for w in worlds:
    for grp in ["img_only", "rna_only", "early_concat", "late_fusion", "xattn_bi", "uhler_hand", "evolved_random", "evolved_no_align",
                "evolved_fully_shared", "evolved_no_moddrop", "evolved_bi_only", "evolved_full", "evolved_full-deploy"]:
        r = T1[(T1.world == w) & (T1.group == grp)]
        if r.empty: continue
        r = r.iloc[0]
        f = lambda t: f"{r[t+'_mean']:.3f} ± {r[t+'_sd']:.3f}"
        rows.append([f"{w} ({int(r.true_shared)})", LAB[grp], f("test"), f("external"), f("test_noRNA"), f("external_noRNA"), f"{r.site_probe:.2f}"])
blocks.append({"type": "table", "caption": "Table 1. Detection AUROC (mean ± sd over folds × retraining seeds) by world and model. Site probe: balanced accuracy above chance of a linear probe predicting site from the image-side shared latent (lower is more invariant).",
               "header": hdr, "rows": rows, "widths": [1300, 1900, 1300, 1300, 1300, 1300, 960]})
blocks.append({"type": "pagebreak"})
for fn, cap in [("fig1_performance.png", "Figure 1. AUROC on the internal test fold, the external cohort, and the test fold with RNA absent at inference, by world (true shared dimension k) and model. Points are means over folds × seeds; bars are one standard deviation."),
                ("fig2_shared_dim.png", "Figure 2. Evolved shared-latent dimension of the winner (circles) and Pareto-front mean (squares) against the true shared dimension of the generating world (log2 axes, jittered)."),
                ("fig3_enrichment_hypervolume.png", "Figure 3. (a) Frequency of each principle among Pareto-optimal individuals of full-grammar runs versus its probability under uniform random derivation; * one-sided p < 0.05. (b) Pareto hypervolume by grammar variant (fold 0, all worlds and seeds); differences are not significant."),
                ("fig4_probes.png", "Figure 4. Cross-validated R² of ridge probes predicting each gene-programme score from each latent block of the evolved winners (test cohorts, pooled over worlds)."),
                ("fig5_convergence.png", "Figure 5. Best validation AUROC per generation for full-grammar runs, averaged over seeds and folds, by world.")]:
    pth = os.path.join(a.summary, fn)
    if os.path.exists(pth):
        blocks.append({"type": "figure", "path": pth, "width_in": 6.3, "caption": cap})

H(1, "Data and code availability")
P("All code, the grammar, configurations, evaluation logs and the scripts that generate every table and figure in this manuscript are in the "
  "accompanying repository. The synthetic worlds are regenerated deterministically by scripts/make_synthetic_study.py. The real-data pipeline "
  "(UNI/CONCH slide embedding, RNA preprocessing, cohort assembly for TCGA, CPTAC and HEST-1k) and the pre-registration template are in "
  "src/gemm/embeddings and docs/preregistration.md.")
H(1, "References")
for ref in ["Uhler C. Causal principles for multi-modal data integration and translation. CCAIM ML in Healthcare Summer School, 2026 (lecture).",
            "Sturma N, Squires C, Drton M, Uhler C. Unpaired multi-domain causal representation learning. NeurIPS 2023.",
            "Zhang X, et al. Partially shared multi-modal embedding learns holistic representation of cell state. Nature Computational Science, 2026.",
            "Radhakrishnan A, et al. Cross-modal autoencoder framework learns holistic representations of cardiovascular state. Nature Communications, 2023.",
            "Chen RJ, et al. Towards a general-purpose foundation model for computational pathology (UNI). Nature Medicine, 2024.",
            "Lu MY, et al. A visual-language foundation model for computational pathology (CONCH). Nature Medicine, 2024.",
            "Jaume G, et al. HEST-1k: A dataset for spatial transcriptomics and histology image analysis. NeurIPS 2024.",
            "Chen RJ, et al. Multimodal co-attention transformer for survival prediction in gigapixel whole slide images (MCAT). ICCV 2021.",
            "Chen RJ, et al. Pan-cancer integrative histology-genomic analysis via multimodal deep learning (PORPOISE). Cancer Cell, 2022.",
            "Deb K, Pratap A, Agarwal S, Meyarivan T. A fast and elitist multiobjective genetic algorithm: NSGA-II. IEEE TEVC, 2002.",
            "O'Neill M, Ryan C. Grammatical evolution. IEEE TEVC, 2001.",
            "Assunção F, Lourenço N, Machado P, Ribeiro B. DENSER: deep evolutionary network structured representation. GPEM, 2019.",
            "Gretton A, et al. Measuring statistical dependence with Hilbert-Schmidt norms (HSIC). ALT 2005.",
            "DeLong ER, DeLong DM, Clarke-Pearson DL. Comparing the areas under two or more correlated ROC curves. Biometrics, 1988."]:
    P(ref)

spec = {"title": "Does evolution rediscover causal principles? Grammar-guided search over partially shared latent spaces for multimodal cancer detection",
        "authors": "Yusuf A. Sani (corresponding); co-authors to be added. Draft generated from results/study — simulation stage.",
        "blocks": blocks}
sp = os.path.join(os.path.dirname(a.out), "manuscript_spec.json")
json.dump(spec, open(sp, "w"), indent=1)
subprocess.run(["node", "scripts/build_docx.js", sp, a.out], check=True)
