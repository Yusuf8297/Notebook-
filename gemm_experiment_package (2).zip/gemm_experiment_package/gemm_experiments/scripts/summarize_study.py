"""Cross-world summary of the simulation study: manuscript tables (CSV + Markdown) and figures (PDF + PNG).

Reads results/study/<world>/ produced by scripts/run_study.sh and writes results/study/summary/.
"""
import _common  # noqa
import argparse, glob, json, os
from collections import defaultdict

import numpy as np
import pandas as pd
import yaml
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from gemm.analysis import FLAG_NAMES, flag_enrichment, hypervolume, load_evaluations, pareto_records, uniform_prior_flags, motifs, cca_rank
from gemm.grammar import Grammar
from gemm.stats import delong_test, holm, mann_whitney, bootstrap_ci
from gemm.pipeline import get_split

# reference categorical palette (validated, CVD-safe order)
PAL = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#52514e",
                     "axes.labelcolor": "#0b0b0b", "xtick.color": "#52514e", "ytick.color": "#52514e", "grid.color": "#e6e6e3",
                     "axes.grid": True, "axes.axisbelow": True, "grid.linewidth": 0.6, "legend.frameon": False, "figure.dpi": 150})

GROUPS = ["img_only", "rna_only", "early_concat", "late_fusion", "xattn_bi", "uhler_hand",
          "evolved_random", "evolved_random-deploy", "evolved_no_align", "evolved_fully_shared", "evolved_no_moddrop", "evolved_bi_only",
          "evolved_full", "evolved_full-deploy"]
LABELS = {"img_only": "H&E only", "rna_only": "RNA only", "early_concat": "Early concat", "late_fusion": "Late fusion",
          "xattn_bi": "Co-attention (bi)", "uhler_hand": "Hand-built principled", "evolved_random": "Random search",
          "evolved_no_align": "GE − P1 (no align)", "evolved_fully_shared": "GE − P2 (fully shared)",
          "evolved_no_moddrop": "GE − P3 (no moddrop)", "evolved_bi_only": "GE − P4 (bi only)", "evolved_full": "GE full grammar",
          "evolved_full-deploy": "GE full grammar (deployment rule)", "evolved_random-deploy": "Random search (deployment rule)"}


def group_of(name):
    if not name.startswith("evolved_"):
        return name
    return "_".join(name.split("_")[:-1])  # strip _seedN (the evolution seed)


def load_final(world_dir):
    recs = []
    for p in glob.glob(os.path.join(world_dir, "baselines", "fold*", "*.json")) + glob.glob(os.path.join(world_dir, "final", "fold*", "*.json")):
        r = json.load(open(p))
        r["fold"] = int(p.split("fold")[-1].split(os.sep)[0])
        r["group"] = group_of(r["name"])
        recs.append(r)
    return recs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="results/study")
    ap.add_argument("--cfg_dir", default="configs/synthetic_study")
    a = ap.parse_args()
    out = os.path.join(a.root, "summary"); os.makedirs(out, exist_ok=True)
    worlds = sorted([w for w in os.listdir(a.root) if w.startswith("W") and os.path.isdir(os.path.join(a.root, w))
                     and glob.glob(os.path.join(a.root, w, "final", "fold*", "evolved_full_*.json"))], key=lambda w: int(w[1:]))
    print("worlds with completed final evaluation:", worlds)
    cfgs = {w: yaml.safe_load(open(os.path.join(a.cfg_dir, f"{w}.yaml"))) for w in worlds}
    md = ["# Simulation study summary", ""]

    # ---------------------------------------------------------------- Table 1: performance per world and group
    rows, paired = [], defaultdict(list)
    per_world_best_baseline = {}
    for w in worlds:
        recs = load_final(os.path.join(a.root, w))
        by = defaultdict(list)
        for r in recs:
            by[r["group"]].append(r)
        bl = [g for g in by if not g.startswith("evolved_")]
        best_b = max(bl, key=lambda g: np.mean([r["metrics"]["test"]["auroc"] for r in by[g]]))
        per_world_best_baseline[w] = best_b
        for g, rs in by.items():
            row = {"world": w, "true_shared": cfgs[w]["true_k"]["shared"], "group": g, "n_models": len(rs)}
            for t in ("test", "heldout_site", "external", "test_noRNA", "external_noRNA"):
                v = [r["metrics"][t]["auroc"] for r in rs if t in r["metrics"]]
                row[f"{t}_mean"], row[f"{t}_sd"] = (np.mean(v), np.std(v)) if v else (np.nan, np.nan)
            row["ece"] = np.mean([r["metrics"]["test"]["ece"] for r in rs])
            row["site_probe"] = np.mean([r["metrics"]["test"]["site_probe"] for r in rs])
            row["shift_drop_ext"] = row["test_mean"] - row["external_mean"]
            rows.append(row)
        # paired (fold, retrain-seed) differences: evolved_full vs best baseline; evolved_full noRNA vs img_only
        for r in by.get("evolved_full", []):
            mates = [b for b in by[best_b] if b["fold"] == r["fold"] and b["seed"] == r["seed"]]
            if mates:
                paired["test"].append((w, r["metrics"]["test"]["auroc"], mates[0]["metrics"]["test"]["auroc"]))
                paired["external"].append((w, r["metrics"]["external"]["auroc"], mates[0]["metrics"]["external"]["auroc"]))
            rs = [x for x in by.get("evolved_random", []) if x["fold"] == r["fold"] and x["seed"] == r["seed"] and x["name"].endswith(r["name"][-6:])]
            if rs:
                paired["vs_random"].append((w, r["metrics"]["test"]["auroc"], rs[0]["metrics"]["test"]["auroc"]))
        for r in by.get("evolved_full-deploy", []):
            im = [b for b in by["img_only"] if b["fold"] == r["fold"] and b["seed"] == r["seed"]]
            hb = [b for b in by["uhler_hand"] if b["fold"] == r["fold"] and b["seed"] == r["seed"]]
            if im:
                paired["noRNA"].append((w, r["metrics"]["test_noRNA"]["auroc"], im[0]["metrics"]["test_noRNA"]["auroc"]))
                paired["noRNA_ext"].append((w, r["metrics"]["external_noRNA"]["auroc"], im[0]["metrics"]["external_noRNA"]["auroc"]))
            if hb:
                paired["noRNA_vs_hand"].append((w, r["metrics"]["test_noRNA"]["auroc"], hb[0]["metrics"]["test_noRNA"]["auroc"]))
    t1 = pd.DataFrame(rows)
    t1.to_csv(os.path.join(out, "table1_performance.csv"), index=False)
    md += ["## Table 1. Detection AUROC by world and model group (mean ± sd over folds × retraining seeds)", "",
           "| world (true shared dim) | model | test | external | test, RNA absent | external, RNA absent | site probe |", "|---|---|---|---|---|---|---|"]
    for w in worlds:
        for g in GROUPS:
            r = t1[(t1.world == w) & (t1.group == g)]
            if r.empty: continue
            r = r.iloc[0]
            f = lambda t: f"{r[t+'_mean']:.3f} ± {r[t+'_sd']:.3f}"
            md.append(f"| {w} ({r.true_shared}) | {LABELS[g]} | {f('test')} | {f('external')} | {f('test_noRNA')} | {f('external_noRNA')} | {r.site_probe:.2f} |")

    # ---------------------------------------------------------------- H1 / H4: paired tests across worlds
    md += ["", "## Paired comparisons (evolved full grammar vs reference), pooled over worlds × folds × seeds", "",
           "| comparison | n pairs | mean Δ AUROC (95% CI) | Wilcoxon p | wins |", "|---|---|---|---|---|"]
    h = {}
    for key, label in [("test", "GE full (detection rule) vs best baseline, test"), ("external", "GE full (detection rule) vs best baseline, external"),
                       ("vs_random", "GE full vs random search (same budget, same seed), test"),
                       ("noRNA", "GE full (deployment rule, RNA absent) vs H&E-only, test"), ("noRNA_ext", "GE full (deployment rule, RNA absent) vs H&E-only, external"),
                       ("noRNA_vs_hand", "GE full (deployment rule, RNA absent) vs hand-built principled (RNA absent), test")]:
        d = np.array([x[1] - x[2] for x in paired[key]])
        if len(d) < 3: continue
        m, lo, hi = bootstrap_ci(d)
        p = stats.wilcoxon(d).pvalue if np.any(d != 0) else 1.0
        h[key] = {"n": len(d), "mean": m, "lo": lo, "hi": hi, "p": p, "wins": int((d > 0).sum())}
        md.append(f"| {label} | {len(d)} | {m:+.3f} [{lo:+.3f}, {hi:+.3f}] | {p:.3g} | {int((d>0).sum())}/{len(d)} |")
    md.append(f"\nBest baseline per world: {per_world_best_baseline}")

    # ---------------------------------------------------------------- H2: population-level effect of P1 pooled over worlds
    pooled = []
    for w in worlds:
        for p in glob.glob(os.path.join(a.root, w, "evolution", "full", "seed*", "fold*", "evaluations.jsonl")):
            pooled += [dict(r, world=w) for r in load_evaluations(p) if r["valid"]]
    md += ["", f"## Population-level effect of each principle (all {len(pooled)} valid individuals of full-grammar runs, pooled)", "",
           "| principle | n with / without | shift drop with | without | MWU p | Cliff δ | RNA-absent AUROC with | without | MWU p | invariance with | without | MWU p |", "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    h2 = {}
    for flag in FLAG_NAMES:
        A = [r for r in pooled if r["flags"][flag]]; B = [r for r in pooled if not r["flags"][flag]]
        if len(A) < 3 or len(B) < 3: continue
        sd = lambda rs: [r["fitness"]["val_auc"] - r["fitness"]["shift_auc"] for r in rs]
        ma = lambda rs: [r["fitness"]["missing_auc"] for r in rs]
        inv = lambda rs: [r["fitness"]["invariance"] for r in rs]
        t_s, t_m, t_i = mann_whitney(sd(A), sd(B)), mann_whitney(ma(A), ma(B)), mann_whitney(inv(A), inv(B))
        h2[flag] = {"n_with": len(A), "n_without": len(B), "shift": t_s, "missing": t_m, "inv": t_i,
                    "means": [np.mean(sd(A)), np.mean(sd(B)), np.mean(ma(A)), np.mean(ma(B)), np.mean(inv(A)), np.mean(inv(B))]}
        m = h2[flag]["means"]
        md.append(f"| {flag} | {len(A)} / {len(B)} | {m[0]:.3f} | {m[1]:.3f} | {t_s['p']:.2g} | {t_s['cliffs_delta']:+.2f} | {m[2]:.3f} | {m[3]:.3f} | {t_m['p']:.2g} | {m[4]:.3f} | {m[5]:.3f} | {t_i['p']:.2g} |")

    # ---------------------------------------------------------------- H3: evolved shared dimension vs truth and vs CCA rank
    pts = []
    for w in worlds:
        cr = {}
        for p in glob.glob(os.path.join(a.root, w, "evolution", "full", "seed*", "fold*", "winner.json")):
            fold = int(p.split("fold")[-1].split(os.sep)[0])
            wj = json.load(open(p))
            if fold not in cr:
                sp = get_split(cfgs[w], fold)
                cr[fold] = cca_rank(sp.train.img, sp.train.rna, n_perm=cfgs[w]["analysis"]["cca_perms"])["rank"]
            lat = wj["spec"]["latent"]
            pts.append({"world": w, "true_shared": cfgs[w]["true_k"]["shared"], "fold": fold, "cca_rank": cr[fold],
                        "evolved_shared": lat["shared"], "evolved_img_spec": lat["img_spec"], "evolved_rna_spec": lat["rna_spec"],
                        "front_mean_shared": np.mean([f["spec"]["latent"]["shared"] for f in wj["front"]]),
                        "front_frac_partial": np.mean([f["flags"]["P2_partial"] for f in wj["front"]])})
    h3 = pd.DataFrame(pts); h3.to_csv(os.path.join(out, "table_h3_shared_dim.csv"), index=False)
    md += ["", "## H3: evolved shared dimension vs true shared dimension", ""]
    if len(h3) >= 4 and h3.true_shared.nunique() > 1:
        s1 = stats.spearmanr(h3.true_shared, h3.evolved_shared); s2 = stats.spearmanr(h3.true_shared, h3.front_mean_shared)
        s3 = stats.spearmanr(h3.cca_rank, h3.evolved_shared)
        md += [f"- Spearman(true k_shared, winner shared dim) = {s1.correlation:.2f} (p = {s1.pvalue:.3g}, n = {len(h3)})",
               f"- Spearman(true k_shared, Pareto-front mean shared dim) = {s2.correlation:.2f} (p = {s2.pvalue:.3g})",
               f"- Spearman(out-of-sample CCA rank, winner shared dim) = {s3.correlation:.2f} (p = {s3.pvalue:.3g})",
               f"- CCA rank per world (model-free estimate of shared dim): " + ", ".join(f"{w}: {h3[h3.world==w].cca_rank.iloc[0]}" for w in worlds if (h3.world==w).any())]
        h3_stats = {"true_vs_winner": s1, "true_vs_front": s2, "cca_vs_winner": s3}
    else:
        h3_stats = None

    # ---------------------------------------------------------------- H5: enrichment + hypervolume, pooled
    g = Grammar.from_file(cfgs[worlds[0]]["grammar"]); prior = uniform_prior_flags(g, n=5000)
    objectives = cfgs[worlds[0]]["ge"]["objectives"] if "objectives" in cfgs[worlds[0]]["ge"] else ["val_auc", "shift_auc", "invariance", "missing_auc"]
    ref = np.array([0.5 if o.endswith("auc") else -1.0 for o in objectives])
    fronts = []
    hv = defaultdict(list)
    for w in worlds:
        for variant in ["full", "random", "no_align", "fully_shared", "no_moddrop", "bi_only"]:
            for p in glob.glob(os.path.join(a.root, w, "evolution", variant, "seed*", "fold0", "evaluations.jsonl")):
                recs = load_evaluations(p)
                fr = pareto_records(recs, objectives)
                F = np.array([[r["fitness"][k] for k in objectives] for r in fr])
                seed = p.split("seed")[-1].split(os.sep)[0]
                hv[variant].append({"world": w, "seed": seed, "hv": hypervolume(F, ref, n_samples=100000),
                                    "best_val": max(r["fitness"]["val_auc"] for r in recs if r["valid"])})
                if variant == "full":
                    fronts += fr
    enr = flag_enrichment(fronts, prior) if fronts else {}
    md += ["", f"## H5: principle enrichment among Pareto-optimal individuals of full-grammar runs (n = {len(fronts)}, pooled over worlds/seeds/folds)", "",
           "| principle | frequency | prior | fold | one-sided p |", "|---|---|---|---|---|"]
    for k, r in enr.items():
        md.append(f"| {k} | {r['frequency']:.3f} | {r['prior']:.3f} | {r['fold']:.2f} | {r['p_one_sided']:.3g} |")
    md += ["", "## E4: Pareto hypervolume by grammar variant (fold 0; paired with the full grammar on the same world & seed)", "",
           "| variant | n runs | hypervolume mean (95% CI) | Δ vs full (paired) | Wilcoxon p | best val AUROC |", "|---|---|---|---|---|---|"]
    hvdf = {v: pd.DataFrame(rs) for v, rs in hv.items() if rs}
    hv_stats = {}
    for v, df in hvdf.items():
        m, lo, hi = bootstrap_ci(df.hv)
        if v != "full" and "full" in hvdf:
            mg = df.merge(hvdf["full"], on=["world", "seed"], suffixes=("", "_full"))
            d = mg.hv - mg.hv_full
            p = stats.wilcoxon(d).pvalue if len(d) >= 3 and np.any(d != 0) else np.nan
            hv_stats[v] = {"delta": d.mean(), "p": p, "n": len(d)}
            md.append(f"| {LABELS.get('evolved_'+v, v)} | {len(df)} | {m:.4f} [{lo:.4f}, {hi:.4f}] | {d.mean():+.4f} (n={len(d)}) | {p:.3g} | {df.best_val.mean():.3f} |")
        else:
            md.append(f"| {LABELS.get('evolved_'+v, v)} | {len(df)} | {m:.4f} [{lo:.4f}, {hi:.4f}] | – | – | {df.best_val.mean():.3f} |")
    md += ["", "## E7: recurrent motifs (Pareto-optimal, full grammar)", ""] + [f"- ({c}×) {m}" for m, c in motifs(fronts, 8)]

    # ---------------------------------------------------------------- E5: hallmark probes pooled
    probes = defaultdict(lambda: defaultdict(list))
    for w in worlds:
        for p in glob.glob(os.path.join(a.root, w, "final", "fold*", "evolved_full_*.json")):
            hp = json.load(open(p))["metrics"].get("test", {}).get("hallmark_probes")
            if hp:
                for hname, blocks in hp.items():
                    for b, v in blocks.items():
                        if v == v: probes[hname][b].append(v)
    hpdf = pd.DataFrame({hn: {b: np.mean(v) for b, v in bl.items()} for hn, bl in probes.items()}).T
    hpdf.to_csv(os.path.join(out, "table_e5_probes.csv"))
    md += ["", "## E5: hallmark probe R² by latent block (evolved full-grammar winners, test cohorts, pooled)", "", hpdf.round(2).to_markdown()]

    with open(os.path.join(out, "summary.md"), "w") as f:
        f.write("\n".join(md) + "\n")
    json.dump({"paired": h, "h2": {k: {kk: (vv if not isinstance(vv, dict) else vv) for kk, vv in v.items()} for k, v in h2.items()},
               "enrichment": enr, "hv": hv_stats,
               "h3": {k: {"rho": float(v.correlation), "p": float(v.pvalue)} for k, v in h3_stats.items()} if h3_stats else None},
              open(os.path.join(out, "summary.json"), "w"), indent=1, default=str)

    # ---------------------------------------------------------------- Figures
    figs(out, t1, worlds, h3, enr, prior, hvdf, hpdf, pooled, a.root)
    print("\n".join(md))


def figs(out, t1, worlds, h3, enr, prior, hvdf, hpdf, pooled, root):
    show = ["img_only", "early_concat", "xattn_bi", "uhler_hand", "evolved_random", "evolved_full", "evolved_full-deploy"]
    cols = dict(zip(show, PAL[:len(show)]))
    # Fig 1: test / external / RNA-absent AUROC per world, dot + sd
    fig, axes = plt.subplots(1, 3, figsize=(10, 3.2), sharey=True)
    for ax, t, title in zip(axes, ["test", "external", "test_noRNA"], ["Internal test", "External cohort", "Test, RNA absent at inference"]):
        for j, g in enumerate(show):
            sub = t1[t1.group == g].set_index("world").reindex(worlds)
            x = np.arange(len(worlds)) + (j - len(show) / 2) * 0.1
            ax.errorbar(x, sub[f"{t}_mean"], yerr=sub[f"{t}_sd"], fmt="o", ms=4, lw=1.2, color=cols[g], label=LABELS[g], capsize=0)
        ax.set_xticks(range(len(worlds))); ax.set_xticklabels([f"{w}\n(k={t1[t1.world==w].true_shared.iloc[0]})" for w in worlds])
        ax.set_title(title, fontsize=9); ax.set_ylim(0.45, 1.0)
    axes[0].set_ylabel("AUROC")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=4, fontsize=7, bbox_to_anchor=(0.5, -0.02))
    fig.tight_layout(rect=(0, 0.1, 1, 1)); fig.savefig(os.path.join(out, "fig1_performance.pdf"), bbox_inches="tight"); fig.savefig(os.path.join(out, "fig1_performance.png"), bbox_inches="tight"); plt.close(fig)
    # Fig 2: H3
    if len(h3):
        fig, ax = plt.subplots(figsize=(4, 3.2))
        jit = np.random.RandomState(0).uniform(-0.3, 0.3, len(h3))
        ax.scatter(h3.true_shared + jit, h3.evolved_shared, s=22, color=PAL[0], alpha=0.8, label="winner")
        ax.scatter(h3.true_shared + jit, h3.front_mean_shared, s=22, color=PAL[1], alpha=0.8, marker="s", label="Pareto-front mean")
        ax.set_xscale("log", base=2); ax.set_yscale("log", base=2); ax.set_xlabel("true shared dimension"); ax.set_ylabel("evolved shared latent dimension")
        ax.legend(fontsize=7); fig.tight_layout(); fig.savefig(os.path.join(out, "fig2_shared_dim.pdf")); fig.savefig(os.path.join(out, "fig2_shared_dim.png")); plt.close(fig)
    # Fig 3: enrichment + hypervolume
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.2))
    if enr:
        names = list(enr); x = np.arange(len(names))
        axes[0].bar(x - 0.2, [prior[k] for k in names], 0.4, color="#c3c2b7", label="uniform-derivation prior")
        axes[0].bar(x + 0.2, [enr[k]["frequency"] for k in names], 0.4, color=PAL[0], label="Pareto-optimal")
        for i, k in enumerate(names):
            if enr[k]["p_one_sided"] < 0.05: axes[0].text(i + 0.2, enr[k]["frequency"] + 0.02, "*", ha="center")
        axes[0].set_xticks(x); axes[0].set_xticklabels(names, rotation=30, ha="right"); axes[0].set_ylabel("P(principle selected)"); axes[0].legend(fontsize=7)
    order = [v for v in ["full", "random", "no_align", "fully_shared", "no_moddrop", "bi_only"] if v in hvdf]
    axes[1].boxplot([hvdf[v].hv for v in order], tick_labels=[LABELS.get("evolved_" + v, v).replace("GE ", "") for v in order], widths=0.5,
                    medianprops=dict(color=PAL[0]), boxprops=dict(color="#52514e"), whiskerprops=dict(color="#52514e"), capprops=dict(color="#52514e"))
    axes[1].set_ylabel("Pareto hypervolume"); axes[1].tick_params(axis="x", rotation=30)
    fig.tight_layout(); fig.savefig(os.path.join(out, "fig3_enrichment_hypervolume.pdf")); fig.savefig(os.path.join(out, "fig3_enrichment_hypervolume.png")); plt.close(fig)
    # Fig 4: probe heatmap
    if len(hpdf):
        fig, ax = plt.subplots(figsize=(4.5, 2.4))
        im = ax.imshow(hpdf.values.clip(0, 1), cmap="Blues", vmin=0, vmax=1, aspect="auto")
        ax.set_xticks(range(hpdf.shape[1])); ax.set_xticklabels(hpdf.columns, rotation=30, ha="right"); ax.set_yticks(range(hpdf.shape[0])); ax.set_yticklabels(hpdf.index)
        for i in range(hpdf.shape[0]):
            for j in range(hpdf.shape[1]):
                v = hpdf.values[i, j]; ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=7, color="white" if v > 0.5 else "#0b0b0b")
        ax.grid(False); plt.colorbar(im, label="probe R²"); fig.tight_layout(); fig.savefig(os.path.join(out, "fig4_probes.pdf")); fig.savefig(os.path.join(out, "fig4_probes.png")); plt.close(fig)
    # Fig 5: convergence (full grammar, mean over runs per world)
    fig, ax = plt.subplots(figsize=(4.5, 3))
    for i, w in enumerate(worlds):
        curves = []
        for p in glob.glob(os.path.join(root, w, "evolution", "full", "seed*", "fold*", "generations.jsonl")):
            gens = [json.loads(l) for l in open(p)]
            curves.append([g["best"]["val_auc"] for g in gens])
        if curves:
            L = min(map(len, curves)); m = np.mean([c[:L] for c in curves], 0)
            ax.plot(range(1, L + 1), m, color=PAL[i % len(PAL)], lw=2, label=w)
    ax.set_xlabel("generation"); ax.set_ylabel("best validation AUROC (mean over runs)"); ax.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(os.path.join(out, "fig5_convergence.pdf")); fig.savefig(os.path.join(out, "fig5_convergence.png")); plt.close(fig)


if __name__ == "__main__":
    main()
