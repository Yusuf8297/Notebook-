#!/usr/bin/env bash
# Re-select winners robustly and redo the final evaluation for the given worlds.
set -e
cd "$(dirname "$0")/.."
for W in "$@"; do
  CFG=configs/synthetic_study/$W.yaml
  python scripts/reselect_winners.py --config $CFG
  rm -f results/study/$W/final/fold*/evolved_*.json
  python scripts/run_final.py --config $CFG --folds 0 1
  python scripts/run_analysis.py --config $CFG > /dev/null
  echo "== $W refinal done"
done
