"""Multi-world simulation study: four synthetic worlds that differ only in the TRUE number of
shared latent dimensions (2, 4, 8, 12), each with an internal (6 sites) and an external
(3 new sites, stronger batch effect) cohort. Varying the true shared dimension is what makes
H3 (evolved shared dimension tracks shared information) testable in silico."""
import _common  # noqa
import argparse, os, yaml
from gemm.data import make_synthetic, make_synthetic_external

WORLDS = {"W2": 2, "W4": 4, "W8": 8, "W12": 12}
ap = argparse.ArgumentParser()
ap.add_argument("--n", type=int, default=1200)
ap.add_argument("--n_external", type=int, default=400)
ap.add_argument("--out", default="data/study")
ap.add_argument("--cfg_dir", default="configs/synthetic_study")
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True); os.makedirs(a.cfg_dir, exist_ok=True)
base = yaml.safe_load(open("configs/synthetic_smoke.yaml"))
for i, (name, ks) in enumerate(WORLDS.items()):
    kw = dict(k_shared=ks, k_img=6, k_rna=4, world_seed=100 + i)
    make_synthetic(a.n, n_sites=6, seed=i, **kw).save(f"{a.out}/{name}_internal.npz")
    make_synthetic_external(a.n_external, n_sites=3, seed=50 + i, **kw).save(f"{a.out}/{name}_external.npz")
    cfg = dict(base)
    cfg["data"] = {"internal": f"{a.out}/{name}_internal.npz", "external": f"{a.out}/{name}_external.npz",
                   "n_outer_folds": 5, "split_seed": 0}
    cfg["folds"] = [0, 1]
    cfg["ge"] = {"pop_size": 24, "generations": 10, "seeds": [0, 1, 2], "time_budget_s": 60,
                 "genome_len": 200, "p_mutation": 0.02, "p_crossover": 0.8}
    cfg["final_seeds"] = [0, 1, 2]
    cfg["analysis"] = {"cca_perms": 100}
    cfg["out"] = f"results/study/{name}"
    cfg["true_k"] = {"shared": ks, "img": 6, "rna": 4}
    yaml.safe_dump(cfg, open(f"{a.cfg_dir}/{name}.yaml", "w"), sort_keys=False)
    print(name, "true shared dim", ks)
