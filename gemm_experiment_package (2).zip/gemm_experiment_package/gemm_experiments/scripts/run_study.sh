#!/usr/bin/env bash
# Full simulation study. Usage: bash scripts/run_study.sh W2 W4   (worlds to run in this process)
set -e
cd "$(dirname "$0")/.."
for W in "$@"; do
  CFG=configs/synthetic_study/$W.yaml
  python scripts/run_baselines.py --config $CFG --folds 0 1
  python scripts/run_evolution.py --config $CFG --variant full --folds 0 1
  python scripts/run_evolution.py --config $CFG --variant random --folds 0 --seeds 0 1
  python scripts/run_ablations.py --config $CFG --folds 0 --seeds 0 1
  python scripts/reselect_winners.py --config $CFG
  python scripts/run_final.py --config $CFG --folds 0 1
  python scripts/run_analysis.py --config $CFG > /dev/null
  echo "== $W done"
done
