"""E1-E3 for the hand-designed baselines (all expressed as fixed specs in the grammar's language)."""
import _common  # noqa
import argparse
from gemm.pipeline import load_config, run_baselines

ap = argparse.ArgumentParser()
ap.add_argument("--config", required=True)
ap.add_argument("--folds", type=int, nargs="*")
ap.add_argument("--seeds", type=int, nargs="*")
ap.add_argument("--names", nargs="*")
a = ap.parse_args()
cfg = load_config(a.config)
for fold in a.folds or cfg["folds"]:
    run_baselines(cfg, fold, a.seeds or cfg["final_seeds"], a.names)
