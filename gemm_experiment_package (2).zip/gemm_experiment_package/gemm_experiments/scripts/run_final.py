"""Retrain evolved winners with fresh seeds and evaluate on test / held-out site / external / RNA-absent."""
import _common  # noqa
import argparse
from gemm.pipeline import load_config, run_final

ap = argparse.ArgumentParser()
ap.add_argument("--config", required=True)
ap.add_argument("--folds", type=int, nargs="*")
ap.add_argument("--seeds", type=int, nargs="*")
ap.add_argument("--variants", nargs="*")
a = ap.parse_args()
cfg = load_config(a.config)
for fold in a.folds or cfg["folds"]:
    run_final(cfg, fold, a.seeds or cfg["final_seeds"], a.variants)
