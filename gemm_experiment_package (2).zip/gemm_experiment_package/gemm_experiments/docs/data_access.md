# Data access and cohort construction

All data are public. Nothing in this package downloads data automatically; the steps below produce the
`.npz` cohorts consumed by `gemm.data.Cohort`.

## TCGA (internal cohorts)

1. GDC portal (https://portal.gdc.cancer.gov): for each project (TCGA-BRCA, -LUAD, -COAD, -KIRC, -OV)
   download (a) diagnostic slides (`*.svs`, "Slide Image", experimental strategy "Diagnostic Slide"),
   (b) STAR gene counts (`*.rna_seq.augmented_star_gene_counts.tsv`), (c) the sample sheet and the
   biospecimen/clinical supplements. Use `gdc-client` with the manifest.
2. Labels: sample-type code in the barcode (`TCGA-XX-XXXX-01A` tumour, `-11A` solid tissue normal).
   Normal-adjacent counts per project are roughly BRCA 113, LUAD 59, COAD 41, KIRC 72, OV 0 — for OV use
   the GTEx-vs-TCGA comparison only as exploratory, and use histologic grade / subtype as the primary label.
3. `site` = tissue-source-site code (barcode characters 6–7). This is the batch variable held out for `shift_auc`.
4. Embeddings: `python -m gemm.embeddings.wsi_embed --slides ... --model uni --out emb/brca_uni`
   then `python -m gemm.embeddings.rna_embed --counts brca_counts.tsv --fit --out emb/brca_rna.npz`
   then `python -m gemm.embeddings.build_cohort --manifest brca_manifest.csv --wsi emb/brca_uni --rna emb/brca_rna.npz --out data/tcga_brca.npz`.

UNI/CONCH weights: request access on Hugging Face (MahmoodLab/UNI, MahmoodLab/CONCH), set `HF_TOKEN`.

## CPTAC (external cohorts)

Slides via TCIA (CPTAC-BRCA, CPTAC-LUAD, CPTAC-COAD, CPTAC-CCRCC collections); RNA-seq via the GDC
(CPTAC-3 project) or the PDC. Build with the same scripts but `rna_embed.py --load emb/brca_rna.npz`
so the HVG list and PCA are the TCGA ones. Do not build until the pre-registration is filed.

## HEST-1k (spatial, E6)

`pip install hest`; data on Hugging Face (MahmoodLab/hest, gated). `python -m gemm.embeddings.build_hest
--organs Ovary Breast Colon --out data/hest.npz`. Tumour spot labels: use the pathologist annotations
where shipped; otherwise the marker-score fallback in `build_hest._marker_label` (document which samples
used which). `patient` = HEST sample id; `site` = originating study.

## Hallmark scores (E5)

`rna_embed.HALLMARKS` contains abbreviated gene lists. Replace with the full MSigDB Hallmark GMT
(`h.all.v2023.2.Hs.symbols.gmt`) for the paper; the score is the mean z-scored log-CPM of member genes.

## Synthetic data

`scripts/make_synthetic.py` builds cohorts from `data.SyntheticWorld`: shared latents drive both
modalities, RNA-specific latents drive part of the label (so the image cannot see all of the signal),
sites add an image-only batch offset, and hallmark scores are functions of known latent blocks. It exists
to validate the pipeline and the E5 probes, not to make scientific claims.
