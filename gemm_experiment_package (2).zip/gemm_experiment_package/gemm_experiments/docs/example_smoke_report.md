# Results report
Run: `results/synthetic_smoke`

## E1-E3: detection performance (AUROC, mean ± sd over folds × seeds)

| model | params | test | held-out site | external | test, RNA absent | external, RNA absent | ECE | site probe | DeLong vs best baseline (Holm p) |
|---|---|---|---|---|---|---|---|---|---|
| early_concat | 247,169 | 0.885 ± 0.003 | 0.790 ± 0.000 | 0.789 ± 0.009 | 0.667 ± 0.009 | 0.709 ± 0.004 | 0.082 | 0.750 | – |
| late_fusion | 263,938 | 0.872 ± 0.011 | 0.784 ± 0.004 | 0.794 ± 0.005 | 0.675 ± 0.019 | 0.714 ± 0.013 | 0.086 | 0.750 | – |
| evolved_no_moddrop_seed1 | 264,227 | 0.872 ± 0.016 | 0.771 ± 0.005 | 0.789 ± 0.001 | 0.595 ± 0.022 | 0.631 ± 0.014 | 0.093 | 0.750 | p=0.371 |
| rna_only | 230,785 | 0.869 ± 0.019 | 0.785 ± 0.006 | 0.793 ± 0.008 | 0.469 ± 0.030 | 0.504 ± 0.039 | 0.085 | 0.750 | – |
| xattn_bi | 511,361 | 0.868 ± 0.003 | 0.805 ± 0.004 | 0.802 ± 0.003 | 0.651 ± 0.026 | 0.704 ± 0.009 | 0.114 | 0.750 | – |
| evolved_bi_only_seed1 | 461,441 | 0.867 ± 0.023 | 0.797 ± 0.002 | 0.786 ± 0.013 | 0.700 ± 0.026 | 0.644 ± 0.034 | 0.105 | 0.703 | p=0.371 |
| evolved_fully_shared_seed1 | 221,185 | 0.865 ± 0.004 | 0.786 ± 0.009 | 0.793 ± 0.003 | 0.637 ± 0.010 | 0.678 ± 0.011 | 0.105 | 0.750 | p=0.133 |
| evolved_bi_only_seed0 | 352,425 | 0.864 ± 0.014 | 0.769 ± 0.021 | 0.783 ± 0.008 | 0.653 ± 0.034 | 0.614 ± 0.001 | 0.096 | 0.750 | p=0.371 |
| evolved_no_moddrop_seed0 | 352,425 | 0.864 ± 0.014 | 0.769 ± 0.021 | 0.783 ± 0.008 | 0.653 ± 0.034 | 0.614 ± 0.001 | 0.096 | 0.750 | p=0.371 |
| uhler_hand | 210,401 | 0.860 ± 0.006 | 0.793 ± 0.006 | 0.778 ± 0.000 | 0.680 ± 0.001 | 0.676 ± 0.001 | 0.088 | 0.740 | – |
| evolved_full_seed0 | 174,289 | 0.854 ± 0.003 | 0.784 ± 0.005 | 0.792 ± 0.003 | 0.682 ± 0.018 | 0.696 ± 0.000 | 0.064 | 0.433 | p=0.0216 |
| evolved_no_align_seed0 | 437,601 | 0.849 ± 0.019 | 0.795 ± 0.009 | 0.789 ± 0.007 | 0.633 ± 0.012 | 0.650 ± 0.093 | 0.124 | 0.750 | p=0.0468 |
| evolved_no_align_seed1 | 156,737 | 0.849 ± 0.010 | 0.769 ± 0.013 | 0.788 ± 0.009 | 0.672 ± 0.017 | 0.584 ± 0.105 | 0.106 | 0.750 | p=0.0559 |
| evolved_fully_shared_seed0 | 436,675 | 0.835 ± 0.012 | 0.767 ± 0.019 | 0.770 ± 0.011 | 0.673 ± 0.009 | 0.679 ± 0.010 | 0.097 | 0.750 | p=0.00339 |
| evolved_full_seed1 | 403,779 | 0.817 ± 0.067 | 0.735 ± 0.060 | 0.691 ± 0.104 | 0.544 ± 0.036 | 0.562 ± 0.103 | 0.068 | 0.750 | p=0.00339 |
| img_only | 230,785 | 0.695 ± 0.002 | 0.714 ± 0.010 | 0.681 ± 0.001 | 0.695 ± 0.002 | 0.681 ± 0.001 | 0.128 | 0.750 | – |

## H2/H4: effect of each principle across all evaluated individuals (population level)

### grammar variant `full` (n = 96 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | 0.085 | 0.084 | 0.58 | 0.08 | 0.715 | 0.725 | 0.76 | -0.608 | -0.643 |
| P2_partial | 0.092 | 0.080 | 0.234 | 0.15 | 0.712 | 0.721 | 0.577 | -0.604 | -0.624 |
| P2_disentangle | 0.096 | 0.079 | 0.0861 | 0.22 | 0.729 | 0.712 | 0.397 | -0.592 | -0.628 |
| P3_moddrop | 0.082 | 0.089 | 0.69 | -0.05 | 0.711 | 0.728 | 0.588 | -0.615 | -0.619 |
| P3_cond | 0.086 | 0.083 | 0.706 | -0.05 | 0.729 | 0.705 | 0.132 | -0.618 | -0.615 |
| P4_directed | 0.055 | 0.087 | 0.0173 | -0.51 | 0.646 | 0.724 | 0.00801 | -0.667 | -0.612 |

### grammar variant `no_moddrop` (n = 96 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | 0.089 | 0.081 | 0.0158 | 0.33 | 0.696 | 0.699 | 0.3 | -0.556 | -0.559 |
| P2_partial | 0.099 | 0.068 | 0.0343 | 0.26 | 0.695 | 0.700 | 0.891 | -0.548 | -0.572 |
| P2_disentangle | 0.095 | 0.084 | 0.936 | -0.01 | 0.691 | 0.699 | 0.292 | -0.543 | -0.563 |
| P3_moddrop | – | 0.087 | nan | nan | – | 0.697 | nan | – | -0.557 |
| P3_cond | 0.087 | 0.088 | 0.736 | -0.04 | 0.701 | 0.694 | 0.931 | -0.618 | -0.520 |
| P4_directed | 0.079 | 0.090 | 0.186 | -0.19 | 0.647 | 0.710 | 0.0461 | -0.658 | -0.530 |

### grammar variant `bi_only` (n = 96 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | 0.084 | 0.069 | 0.0444 | 0.32 | 0.711 | 0.729 | 0.742 | -0.567 | -0.643 |
| P2_partial | 0.094 | 0.076 | 0.0876 | 0.22 | 0.711 | 0.716 | 0.751 | -0.618 | -0.561 |
| P2_disentangle | 0.100 | 0.077 | 0.135 | 0.22 | 0.723 | 0.712 | 0.882 | -0.597 | -0.575 |
| P3_moddrop | 0.081 | 0.083 | 0.794 | -0.03 | 0.713 | 0.715 | 0.806 | -0.559 | -0.614 |
| P3_cond | 0.083 | 0.081 | 0.579 | -0.07 | 0.713 | 0.715 | 0.625 | -0.614 | -0.554 |
| P4_directed | – | 0.082 | nan | nan | – | 0.714 | nan | – | -0.579 |

### grammar variant `fully_shared` (n = 96 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | 0.080 | 0.090 | 0.704 | -0.06 | 0.739 | 0.684 | 0.00029 | -0.589 | -0.667 |
| P2_partial | – | 0.082 | nan | nan | – | 0.729 | nan | – | -0.604 |
| P2_disentangle | – | 0.082 | nan | nan | – | 0.729 | nan | – | -0.604 |
| P3_moddrop | 0.077 | 0.088 | 0.251 | -0.14 | 0.724 | 0.736 | 0.687 | -0.608 | -0.598 |
| P3_cond | 0.076 | 0.084 | 0.0545 | -0.25 | 0.706 | 0.739 | 0.185 | -0.628 | -0.594 |
| P4_directed | 0.079 | 0.082 | 0.669 | -0.09 | 0.676 | 0.734 | 0.0732 | -0.660 | -0.598 |

### grammar variant `no_align` (n = 96 individuals)

| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |
|---|---|---|---|---|---|---|---|---|---|
| P1_align | – | 0.081 | nan | nan | – | 0.709 | nan | – | -0.623 |
| P2_partial | 0.077 | 0.083 | 0.0799 | -0.22 | 0.745 | 0.690 | 0.000134 | -0.572 | -0.649 |
| P2_disentangle | 0.075 | 0.084 | 0.0177 | -0.32 | 0.775 | 0.686 | 6.18e-07 | -0.544 | -0.650 |
| P3_moddrop | 0.079 | 0.082 | 0.931 | -0.01 | 0.711 | 0.709 | 0.786 | -0.660 | -0.609 |
| P3_cond | 0.085 | 0.079 | 0.0457 | 0.24 | 0.684 | 0.729 | 0.00066 | -0.662 | -0.592 |
| P4_directed | 0.073 | 0.083 | 0.342 | -0.16 | 0.723 | 0.707 | 0.655 | -0.656 | -0.617 |

## E4: grammar ablations

| variant | runs | Pareto hypervolume (95% CI) | best val AUROC (95% CI) |
|---|---|---|---|
| bi_only | 2 | 0.0273 [0.0265, 0.0281] | 0.904 [0.892, 0.917] |
| full | 2 | 0.0262 [0.0228, 0.0296] | 0.896 [0.895, 0.896] |
| fully_shared | 2 | 0.0237 [0.0225, 0.0249] | 0.893 [0.892, 0.894] |
| no_align | 2 | 0.0228 [0.0183, 0.0272] | 0.892 [0.892, 0.893] |
| no_moddrop | 2 | 0.0312 [0.0303, 0.0320] | 0.900 [0.884, 0.917] |

### H5: principle enrichment among Pareto-optimal individuals (full grammar) vs uniform-derivation prior

| principle | frequency | prior | fold | one-sided p |
|---|---|---|---|---|
| P1_align | 0.811 | 0.662 | 1.22 | 0.0404 |
| P2_partial | 0.297 | 0.471 | 0.63 | 0.989 |
| P2_disentangle | 0.297 | 0.368 | 0.81 | 0.849 |
| P3_moddrop | 0.676 | 0.517 | 1.31 | 0.0415 |
| P3_cond | 0.432 | 0.272 | 1.59 | 0.0255 |
| P4_directed | 0.000 | 0.194 | 0.00 | 1 |

### E7: recurrent motifs among Pareto-optimal individuals

- (5×) latent 128s/0i/0r | gated | align=disc | moddrop=yes
- (4×) latent 32s/0i/0r | gated+gated | align=none | moddrop=no
- (4×) latent 8s/0i/0r | single(rna)+single(rna) | align=infonce | moddrop=yes
- (4×) latent 256s/128i/16r | cond(img) | align=disc | moddrop=yes
- (3×) latent 128s/0i/0r | cond(img) | align=infonce | moddrop=yes
- (3×) latent 128s/0i/0r | gated+xattn(bi) | align=infonce | moddrop=yes
- (2×) latent 64s/0i/0r | cond(img) | align=infonce | moddrop=no
- (2×) latent 128s/32i/8r | single(rna)+cond(rna) | align=infonce | moddrop=no
- (2×) latent 32s/0i/16r | cond(rna)+gated | align=infonce | moddrop=yes
- (1×) latent 128s/0i/0r | cond(img) | align=infonce | moddrop=no

## E5: partial sharing

- fold 0: CCA rank (permutation, α=0.05) = 9, MI over top canonical pairs = 0.52 nats; evolved latents: [{'shared': 128, 'img_spec': 0, 'rna_spec': 0, 'disentangle': None}, {'shared': 32, 'img_spec': 0, 'rna_spec': 16, 'disentangle': {'type': 'mmd', 'w': 0.01}}]

| hallmark | shared (img) | shared (rna) | img-specific | rna-specific |
|---|---|---|---|---|
| hypoxia | 0.73 | 0.74 | – | 0.51 |
| proliferation | -0.40 | 0.67 | – | 0.56 |
| stroma | 0.36 | -0.41 | – | -0.22 |
