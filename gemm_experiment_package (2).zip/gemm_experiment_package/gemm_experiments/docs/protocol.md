# Experimental protocol

This is the operational counterpart of the proposal. Every number here is a default in the configs.

## 0. Definitions

- **Candidate**: a JSON spec produced by the grammar (`grammar/fusion.bnf`), interpreted by `models.FusionModel`.
- **Objectives** (`fitness.py`, all maximised): `val_auc` (inner validation AUROC), `shift_auc` (AUROC on
  held-out tissue-source sites inside the training fold), `invariance` (minus the balanced accuracy above
  chance of a linear probe predicting site from the image-side shared latent on the validation fold),
  `missing_auc` (validation AUROC with RNA absent at inference; the RNA shared latent is imputed from the
  image shared latent and the RNA-specific latent zeroed). `parsimony` (−log10 params) is a tie-break only.
- **Principle flags** (`spec.principle_flags`): P1_align (InfoNCE or adversarial alignment present),
  P2_partial (any modality-specific latent), P2_disentangle (HSIC/orth/MMD term present), P3_moddrop
  (modality-dropout loss), P3_cond (FiLM conditioning op), P4_directed (uni-directional cross-attention).
  Under uniform random derivations their priors are ≈ 0.67 / 0.48 / 0.37 / 0.51 / 0.27 / 0.20 — the null for H5.

## 1. Data splits (`data.make_splits`)

Outer: patient-grouped 5-fold. Inside each training fold: the smallest tissue-source site(s) are held out
entirely (`heldout_site`); from the remaining sites a patient-grouped 20 % validation subset is carved
(`val`). Standardisation uses training statistics only, including for the external cohort. The external
cohort (CPTAC) is never touched by evolution or model selection.

## 2. Evolution (`evolution.py`)

Population 100, 40 generations, genome 200 codons, one-point crossover (p = 0.8, cut inside the used
region), per-codon mutation 0.02, binary tournament on (rank, crowding), (μ+λ) NSGA-II survival, duplicate
phenotypes cached. 5 seeds × 5 folds per cancer. Candidate training is early-stopped on `val_auc`
(patience 5) and time-boxed (300 s on GPU). Invalid derivations or diverged trainings get penalty fitness.
**Final selection rule (pre-registered):** among Pareto-optimal individuals within 0.005 of the best
`val_auc`, choose the best `shift_auc`; ties broken by parsimony.

Random-search control: 100 × 41 uniformly random derivations, same evaluation, same selection rule.

## 3. Experiments

| ID | Question | Procedure | Primary readout | Test |
|---|---|---|---|---|
| E1 | H1 performance | Winners retrained with 5 fresh seeds on each outer fold; baselines identically | test AUROC, AUPRC, ECE | DeLong vs strongest baseline, paired on (fold, seed) predictions, Holm over evolved models |
| E2 | H2 shift | Same models on held-out site and on CPTAC without fine-tuning | AUROC drop val→external | Mann-Whitney over *all evaluated individuals* with vs without P1 (population level, Cliff's δ) |
| E3 | H4 missing modality | Same models with RNA zeroed at inference | test/external AUROC (RNA absent) vs img_only baseline | DeLong; MWU with vs without P3_moddrop |
| E4 | H5 ablation | Re-run evolution with `no_align`, `fully_shared`, `no_moddrop`, `bi_only` grammars | Pareto hypervolume, best-of-run val AUROC (bootstrap CI over runs) | enrichment of flags among Pareto individuals vs uniform prior (binomial/permutation) |
| E5 | H3 partial sharing | Out-of-sample CCA rank (permutation α = 0.05) and kNN-MI of frozen embeddings vs evolved shared dim; ridge probes of hallmark scores from each latent block | Spearman over (cancer × fold); probe R² table | prediction: hypoxia readable from shared, proliferation/immune partly RNA-specific |
| E6 | spatial replication | E1, E4, E5 at spot level on HEST-1k (ovary, breast, colon) | as above + latent maps on tissue coordinates | as above |
| E7 | motifs | Cluster Pareto-optimal derivations across seeds/cancers | motif table | descriptive |

## 4. Baselines (`spec.BASELINES`)

img_only, rna_only, early_concat, late_fusion (two heads, averaged logits), xattn_bi (MCAT-style
bidirectional co-attention), uhler_hand (P1 InfoNCE + P2 64/64/32 with HSIC + P3 image-FiLM + moddrop 0.3).
All share the same encoders, head defaults and training recipe so that the comparison isolates fusion.

## 5. Compute budget

Per cancer: (1 + 4 ablations + 1 random) × 5 seeds × 5 folds × 4,100 evaluations ≈ 615k candidate
trainings at 1–5 min each. That is too much; the pre-registered budget is **full grammar on all 5 folds,
ablations and random control on fold 0 only**, giving ≈ 5 × 5 × 4,100 + 5 × 5 × 4,100 ≈ 205k trainings,
≈ 3,400–17,000 GPU-hours worst case. Reduce with `time_budget_s: 120` and cached embeddings (a candidate
head over 1,024 + 256-d inputs trains in well under a minute on 4,000 patients); realistic total ≈ 1,500 GPU-h.

## 6. Reporting

`report.md` tables are the paper's Tables 1–4; Pareto fronts, hypervolume distributions, enrichment
bars and latent-probe heatmaps are Figures 2–5. Report all Pareto fronts, not only winners. Report the
number of invalid derivations and diverged trainings per run.
