# Readiness assessment and path to submission

## 1. What you ran locally

`results/notebook_smoke/`: synthetic data (600 patients, one world), population 12 × 3 generations (≈ 40 evaluations per
run), 2 evolution seeds, 1 fold, 2 retraining seeds. It executed cleanly and produced every table the pipeline can produce.
**It is not a study.** The budget is two orders of magnitude below the pre-registered one, there is one world, one fold and
no random-search control, and winners were chosen from a single training seed on a ~150-sample validation set. Nothing in it
can be cited in a manuscript except as a pipeline test.

## 2. What was done here (simulation stage)

A powered simulation study was run in this environment (`configs/synthetic_study/`, `scripts/run_study.sh`):

- **4 worlds** with the same causal structure and true shared dimension k ∈ {2, 4, 8, 12}; 1,200 patients × 6 sites internal,
  400 patients × 3 new sites external, per world.
- **Full grammar**: population 24 × 10 generations, 3 seeds × 2 folds per world (24 runs, 6,336 evaluated candidates).
- **Random-search control** with the same evaluation budget, and **4 ablated grammars** (−P1, −P2, −P3, −P4), 2 seeds each on fold 0.
- **Robust winner selection** (new, `scripts/reselect_winners.py`): shortlisted Pareto candidates re-trained with 2 extra seeds, two
  pre-specified rules (detection; deployment for the RNA-absent scenario). Winners retrained with 3 fresh seeds.
- Cross-world summary, five figures and a manuscript generated from the results (`scripts/summarize_study.py`, `scripts/make_manuscript.py`).

## 3. What the results say (results/study/summary/summary.md)

| Hypothesis | Outcome | Evidence |
|---|---|---|
| H1 evolved winners ≥ best baseline | **Not supported** | Δ test AUROC −0.006 [−0.009, −0.003], p = 0.003 vs the hand-built principled model; vs random search +0.004, p = 0.08 |
| H2 alignment → invariance / transfer | **Supported for invariance; shift untested** | site-probe accuracy −0.56 vs −0.70 with vs without alignment (p ≈ 1e-90); held-out-site drop is ≈ 0 in every world by construction |
| H3 evolved shared dim tracks truth | **Not supported** | Spearman ρ = 0.13 (p = 0.54), n = 24 |
| H4 RNA-absent winners > H&E-only | **Not supported for winners; mechanism supported at population level** | winners Δ +0.003 (p = 0.30); across 6,336 candidates alignment raises RNA-absent AUROC 0.651 → 0.688 (p ≈ 1e-51) |
| H5 principles enriched on Pareto front | **Supported for P1, P2, P3-conditioning; P3-dropout and P4 depleted** | P1 1.23× (p < 1e-4), P2-disentangle 1.28× (p < 1e-4), P3-cond 1.46× (p < 1e-4); hypervolume ablations n.s. (n = 8) |
| E5 probes | **Supported** | hypoxia (shared by construction) R² 0.66/0.67 from both shared blocks; proliferation (RNA-specific) 0.62 RNA-side, −0.21 image-side |

The honest headline is: *evolution rediscovers alignment and partial sharing as population-level preferences and the evolved
partition has the semantics the theory assigns to it, but at this budget evolved winners do not beat a well-specified
principled hand design, and the nominal shared dimension is uninformative.*

## 4. Is it ready for manuscript draft and submission?

**Manuscript draft: yes** — `manuscript/manuscript.docx` (and `.pdf`) is a complete, number-faithful draft of the simulation stage
(abstract, introduction, methods, results with all statistics, discussion, Table 1, Figures 1–5, references), regenerated from the
results by script so it cannot drift from them.

**Submission: not yet.** Two things are missing, and one of them cannot be done from here.

1. **Real cohorts.** A high-impact venue (Nat. Mach. Intell., Nat. Comput. Sci., Nat. Commun., Cell Rep. Med.) will not accept a
   simulation-only study of a cancer-detection method. The pre-registered stage (TCGA BRCA/LUAD/COAD/KIRC/OV → CPTAC, HEST-1k) needs
   slides, gated foundation-model weights and GPUs; the pipeline for it is in `src/gemm/embeddings/` and `docs/data_access.md`.
   Before running it, file `docs/preregistration.md` (now including both selection rules and the shortlist re-training).
2. **Budget.** The simulation used population 24 × 10 generations. The pre-registered budget is 100 × 40. The H1 result may
   change with budget; the population-level results are unlikely to.

**Where the simulation stage can go now:** as it stands it is a credible methods/simulation paper for an evolutionary-computation
venue (GECCO, IEEE TEVC) or a thesis chapter — the negative results on H1/H3 are reported as such, with the mechanistic
positive results (enrichment, invariance, probes) carrying the contribution.

## 5. Changes made to the package in this pass

- `src/gemm/data.py`: worlds can have any true shared dimension (`world_seed`, `k_shared` wrap-safe).
- `scripts/make_synthetic_study.py`, `configs/synthetic_study/*.yaml`, `scripts/run_study.sh`, `scripts/refinal.sh`: the study.
- `scripts/reselect_winners.py` + `pipeline.run_final`: seed-robust selection; detection and deployment winners (`winner.json`, `winner_deploy.json`; single-seed choice kept as `winner_v1.json`).
- `scripts/summarize_study.py`: cross-world tables, paired tests, pooled population tests, enrichment, hypervolume, H3, probes, Figures 1–5.
- `scripts/make_manuscript.py` + `scripts/build_docx.js`: manuscript generated from the summary.
- `docs/preregistration.md`: selection rules updated.

## 6. Submission checklist

- [ ] Decide venue for the simulation stage (GECCO/TEVC) vs. wait for the real-data stage (Nature-family / Cell Rep. Med.).
- [ ] Add co-authors, affiliations, funding, competing interests.
- [ ] File pre-registration (OSF) with the grammar hash: `sha256sum grammar/fusion.bnf`.
- [ ] Optional but recommended before any submission: rerun the study at population 48 × 20 generations (≈ 4× compute) to test whether
      the GE-vs-random and GE-vs-hand-built gaps move with budget; `configs/synthetic_study/*.yaml` → `pop_size`, `generations`.
- [ ] Consider the two follow-ups the discussion names: a floor on RNA-absent AUROC (constrained selection) and an effective-rank
      estimate of the shared latent for H3.
- [ ] Supplementary: `grammar/fusion.bnf` (S1), `results/study/summary/summary.md` (S2), per-world `analysis/report.md` (S3).
- [ ] Data/code availability: push the repository (results logs are 55 MB; keep `evaluations.jsonl`, they are the analysis's raw data).
