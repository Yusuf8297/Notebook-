# Evolving Causally-Principled Multimodal Fusion for Cancer Detection with Grammatical Evolution

**Working title for the paper:** *Does evolution rediscover causal principles? Grammar-guided search over partially shared latent spaces for histology–transcriptomics cancer detection*

**Source presentation selected:** Prof. Caroline Uhler (Broad Institute / MIT), *Causal principles for multi-modal data integration and translation*, CCAIM ML in Healthcare Summer School 2026.

---

## 1. Why this presentation, and why it matters for the thesis

Of the eight files supplied, only the Uhler deck is about multimodal integration of biomedical data. The others cover LLM reasoning (Ruiz; two identical copies), causal ML for treatment-effect estimation in tabular EHR data (Feuerriegel), LLM clinical-reasoning benchmarks (VivaBench), active test selection and clinical scoring systems (Ruhrberg Estévez), and entrepreneurship (Hsieh & Rochon). Feuerriegel's deck is a useful secondary reference on invariance and distribution shift, but it does not touch imaging or omics fusion.

The Uhler deck is directly relevant for three reasons. First, it works with exactly the modality pairing the thesis needs: tissue H&E images paired with (spatial) transcriptomics, demonstrated on ovarian cancer, where contrastive integration removed patient/batch effects and surfaced a hypoxia-enriched, metastasis-associated tumour niche. Second, it states four design principles that are, in effect, *architectural and loss-function constraints* — precisely the kind of thing a grammar can encode and grammatical evolution (GE) can search over. Third, it attaches identifiability theorems (Sturma, Squires et al., NeurIPS 2023) to those principles, which lets us compare what evolution discovers against what theory predicts.

The four principles from the deck, restated as search-space decisions:

| Uhler principle | What it says | What GE could decide |
|---|---|---|
| P1: Contrastive/discriminative alignment | Causal features should be invariant to the modality they are measured in; align modalities in a shared latent space with a contrastive loss | Whether to include a contrastive term, which pairs to contrast, temperature, weight relative to the task loss |
| P2: Partially overlapping latent spaces | Some information is modality-specific and cannot be generated from the other modality; disentangle shared from specific latents (dimensions are identifiable under conditions) | The *dimension split* between shared and modality-specific latents, and whether to enforce independence between them |
| P3: Condition on a widely available modality | Use the cheap, ubiquitous modality (imaging) to supply context for the expensive one | Which modality is the conditioning "backbone", how cross-modal conditioning is wired, and how the model degrades when the expensive modality is absent |
| P4: Directed attention infers causal effects | Attention is asymmetric and can be read as a directed regulatory graph | Whether cross-modal attention is uni- or bi-directional, and which direction |

The central bet of the proposed work: **instead of hand-designing a fusion model that obeys these principles, we give GE a grammar that *can* express them (and can also express architectures that violate them), and we ask whether evolution, driven only by detection performance plus robustness objectives, rediscovers them — and whether the evolved models beat the hand-designed ones.** If yes, this is both a methods result (a new way to build multimodal cancer detectors) and a scientific result (empirical support for the causal principles from an independent search procedure). If no, the discrepancies are themselves informative.

---

## 2. Gap in the literature

Existing multimodal cancer models (e.g., PORPOISE, MCAT, TransMIL-style multiple-instance fusion, SurvPath, and the pathology–omics foundation-model line of work) fix the fusion topology by hand and almost universally use either early concatenation or a single bidirectional cross-attention block. None of them (a) disentangles shared from modality-specific latents in the P2 sense, (b) is trained with a loss that is explicitly optimised for degradation-free deployment when the omics modality is missing, or (c) has its architecture chosen by search. On the evolutionary side, GE has been applied to neural architecture search (DSGE, GE-NAS, Assunção et al.) and to symbolic feature construction, but never to *loss composition and latent-space partitioning* in a multimodal biomedical setting, and never with a causal-invariance objective. That intersection is empty and is where a high-impact paper lives.

---

## 3. Hypotheses

**H1 (performance).** GE-evolved fusion heads over frozen foundation-model embeddings match or exceed hand-designed fusion baselines for tumour-vs-normal detection and for subtype detection, on held-out patients.

**H2 (invariance / generalisation).** Evolved models that include a contrastive alignment term (P1) show smaller performance drops under cohort shift (TCGA → CPTAC, different scanners and institutions) and lower batch-identifiability in the latent space than evolved models without it.

**H3 (partial sharing).** When the grammar allows a free split between shared and modality-specific latent dimensions, evolution selects a non-degenerate split (neither fully shared nor fully separate), and the selected shared dimension correlates with an independent, model-free estimate of shared information (e.g., CCA rank or mutual-information estimate) — a direct empirical check of P2 and the Sturma et al. identifiability claim.

**H4 (missing-modality deployment).** Models evolved with a modality-dropout fitness term (P3) deployed on H&E alone outperform models trained on H&E alone, i.e., the transcriptomic signal is *distilled* into the image pathway through the shared latent. This is the clinically important claim: omics-informed detection from a slide alone.

**H5 (rediscovery).** Across independent evolutionary runs, the grammar productions corresponding to P1–P3 are selected significantly more often than chance and than their alternatives, and ablating them from the grammar reduces best-of-run fitness.

---

## 4. Data

Everything below is public, which matters for reproducibility and reviewer confidence.

**Primary (bulk, patient-level).** TCGA diagnostic WSIs + matched RNA-seq + clinical labels, five cancers chosen to cover different tissue morphologies and to include normal-adjacent tissue for a true detection task: BRCA, LUAD, COAD, KIRC, OV (OV to connect to Uhler's setting). Approximately 4,500 patients in total. Detection labels: tumour vs normal-adjacent slide; secondary labels: molecular subtype (PAM50 for BRCA, CMS for COAD), grade.

**External validation.** CPTAC (BRCA, LUAD, COAD, ccRCC) — different institutions, scanners, and sequencing pipelines. This is the cohort-shift test for H2. No CPTAC data is used during evolution or training.

**Spatial (spot-level), closest to the Uhler slides.** HEST-1k (Jaume et al., 2024): ~1,200 spatial-transcriptomics samples with paired, registered H&E, covering multiple cancer types including ovarian. Task: spot-level tumour/non-tumour classification using pathologist or expression-derived labels. This setting lets the P2 analysis be done at the resolution where the hypoxia-niche finding in the deck was made.

**Preprocessing.** Frozen foundation encoders produce fixed embeddings once, so evolution never re-trains a backbone. For H&E: UNI or CONCH patch embeddings (aggregated to slide level via attention-MIL for TCGA/CPTAC; per-spot for HEST). For transcriptomics: log-CPM of the 5,000 most variable genes projected through a frozen scGPT/Geneformer-style encoder for HEST, or a simple 512-d autoencoder for bulk TCGA. All embeddings cached to disk.

---

## 5. The grammar (the novel methodological core)

GE evolves an integer genome that is mapped through a BNF grammar into a *specification* (in JSON or Python) that instantiates a fusion model, a loss, and a training recipe. The grammar is deliberately designed so that every Uhler principle is one production among alternatives, so its selection is a measurable event.

```
<model>        ::= <latent> <fusion> <head> <loss> <train>

<latent>       ::= shared_dim=<dim> img_spec_dim=<dim_or_zero> rna_spec_dim=<dim_or_zero>
                   <disentangle>
<dim>          ::= 8 | 16 | 32 | 64 | 128 | 256
<dim_or_zero>  ::= 0 | 8 | 16 | 32 | 64 | 128
<disentangle>  ::= none | hsic(<w>) | orth(<w>) | mmd(<w>)

<fusion>       ::= concat
                 | gated(<act>)
                 | xattn(dir=<dir>, heads=<heads>, layers=<L>)
                 | cond(backbone=<mod>, film)          # P3: condition on one modality
                 | seq(<fusion>, <fusion>)
<dir>          ::= img2rna | rna2img | bi                # P4: directed attention
<mod>          ::= img | rna

<head>         ::= mlp(<L>, <width>, <act>, dropout=<p>)
<loss>         ::= task(<task_loss>) <align> <recon> <dropout_term>
<align>        ::= none
                 | infonce(temp=<t>, w=<w>)              # P1: contrastive alignment
                 | disc(w=<w>)                           # discriminative alignment
<recon>        ::= none | recon(img, w=<w>) | recon(rna, w=<w>) | recon(both, w=<w>)
<dropout_term> ::= none | moddrop(p=<p>, w=<w>)          # train for missing modality
<train>        ::= lr=<lr> wd=<wd> epochs=<E> batch=<B>
```

Key design points. The `<latent>` non-terminal makes the shared/specific split explicit and allows `0` for either specific block, so a fully shared latent (P2 violated) is expressible. `<align>` can be `none`, so P1 is not forced. `cond(backbone=img, film)` and `moddrop` together express P3. `<dir>` expresses P4. The grammar also admits nonsense (e.g., reconstruction of a modality with zero-dimensional specific latent) and the fitness function simply penalises it; that is standard for GE and is part of the rediscovery test.

Genome length 200 codons, wrapping enabled, with a depth limit of 12 to keep models trainable in minutes. Use PonyGE2 or GRAPE as the GE engine; both support multi-objective (NSGA-II) selection.

---

## 6. Fitness

Multi-objective, evaluated on a fixed inner validation fold with all embeddings cached, so a candidate trains in roughly 2–5 minutes on one GPU:

1. **Detection AUROC** on the inner validation fold (maximise).
2. **Shift robustness:** AUROC on a *held-out institution* within TCGA (tissue source site held out), used as a proxy for external shift without touching CPTAC (maximise).
3. **Batch invariance:** negative of the accuracy of a linear probe predicting tissue-source-site from the shared latent (maximise, i.e., minimise batch identifiability). This is the operational form of "causal features should be invariant to the modality/batch in which they are measured".
4. **Missing-modality AUROC:** AUROC when the RNA input is zeroed at test time (maximise).
5. **Parsimony:** negative parameter count (weak objective, lexicographic tiebreak).

NSGA-II over objectives 1–4; final model selection from the Pareto front by a pre-registered rule (best objective 2 among candidates within 0.005 AUROC of the best objective 1). Population 100, 40 generations, 5 independent runs per cancer type with different seeds — roughly 20,000 candidate trainings per cancer, ~1,000 GPU-hours total across five cancers, feasible on a single 4-GPU node over a few weeks.

---

## 7. Experimental design

**E1 — Head-to-head performance (H1).** Patient-level nested 5-fold CV on TCGA per cancer type. Baselines: H&E-only attention-MIL; RNA-only MLP; early concatenation; late fusion (averaged logits); a bidirectional cross-attention model matching MCAT; a hand-built "Uhler model" implementing P1+P2+P3 with sensible fixed hyperparameters; and a random-search control that draws 100 random grammar derivations (no evolution). Metrics: AUROC, AUPRC, expected calibration error, with DeLong tests and Holm correction across the six comparisons.

**E2 — Cohort shift (H2).** Train on TCGA, evaluate on CPTAC with no fine-tuning. Report absolute AUROC and the TCGA→CPTAC drop. Stratify evolved models by whether their derivation includes `infonce`/`disc` and compare the drop distribution between the two groups (Mann–Whitney across the Pareto front populations of all runs, not just the winner, which gives hundreds of models per group).

**E3 — Missing modality (H4).** Deploy every model with RNA absent. Compare evolved-with-`moddrop` models against H&E-only baselines and against the same evolved architectures retrained without `moddrop`. The interesting outcome is an H&E-only-at-inference model that is better than any H&E-only-trained model.

**E4 — Grammar ablation (H5).** Re-run evolution with restricted grammars: (a) `<align> ::= none` only; (b) `<dim_or_zero> ::= 0` only, forcing fully shared latents; (c) `<dropout_term> ::= none` only; (d) `<dir> ::= bi` only. Compare best-of-run fitness and Pareto hypervolume against the full grammar. Also compute production-selection frequencies over all final-generation individuals in the full-grammar runs and test enrichment against the uniform-derivation prior with a permutation test.

**E5 — Partial-sharing analysis (H3).** For the evolved winners, record the chosen shared and specific dimensions. Independently estimate shared information between the frozen H&E and RNA embeddings with linear CCA rank (after permutation-based significance) and with a MINE-style mutual-information estimate. Test whether the evolved shared dimension tracks these estimates across cancer types (Spearman across five cancers plus HEST tissue types gives ~15 points; weak but informative, and honest about it). Then probe the latents: train linear probes for hallmark gene-set scores (hypoxia, proliferation, EMT, immune infiltration) on the shared block versus the RNA-specific block. The deck's own example (γH2AX foci not predictable from DAPI) predicts that some programmes will be RNA-specific and invisible to the image; hypoxia, which the deck found in H&E-aligned space, should be shared. This is the analysis most likely to yield a biologically interesting figure.

**E6 — Spatial replication on HEST-1k.** Repeat E1, E4, and E5 at spot level on ovarian, breast, and colorectal HEST samples. Visualise the shared latent's clusters on tissue coordinates as in the deck, and check whether niches that are patient-specific in raw ST space become patient-mixed in the evolved shared latent.

**E7 — Interpretability of what evolution found.** Parse the derivation trees of all Pareto-optimal models across runs and cancers; cluster them by production usage; report the recurrent motifs in plain language (e.g., "image-conditioned FiLM plus InfoNCE with a 32-d shared / 64-d image-specific / 16-d RNA-specific latent recurs in 4 of 5 cancers"). This is the figure that turns a NAS paper into a scientific one.

**Pre-registration.** Register H1–H5, the Pareto selection rule, and the CPTAC lock-out on OSF before running E2, and state it in the paper.

---

## 8. What would make this a high-impact paper

The novelty is not "GE for NAS" and it is not "another multimodal cancer classifier". It is the combination: a search procedure that is agnostic to causal theory, given a space that contains both principled and unprincipled designs, and asked whether it converges on the principled ones — with a clinically important payoff (omics-informed detection from H&E alone, which is what hospitals can actually deploy) and an external cohort to prove it. The E4/E5/E7 analyses are what reviewers at *Nature Machine Intelligence*, *Nature Computational Science*, or *Nature Communications* will care about; E1–E3 are what makes it credible to *Cell Reports Medicine* or *Lancet Digital Health*. A methods-only cut (grammar, fitness, ablations) would suit *IEEE TEVC* or GECCO as an early conference paper to stake the claim.

Venues, in order of fit: Nature Machine Intelligence; Nature Computational Science (where the P2 paper in the deck appeared); Nature Communications; Cell Reports Medicine; IEEE TPAMI; IEEE TEVC.

---

## 9. Risks and mitigations

*Evolution just picks the biggest model.* The parsimony objective and the fixed compute budget per candidate (time-boxed training) prevent this; report parameter counts.

*Frozen embeddings cap performance.* Acceptable — the paper is about fusion, and frozen backbones make 20,000 candidate evaluations possible. Include one experiment fine-tuning the winner end-to-end to show headroom.

*Bulk RNA-seq is a weak partner for a slide.* That is why HEST-1k is included; and the bulk setting is the one that matches available clinical data.

*The rediscovery result is negative.* Still publishable if framed correctly: "evolution prefers X over the theoretically motivated Y under objectives Z" is a finding about the objectives, and E4 will show whether the principled productions help *when forced*.

*Multiple comparisons.* Pre-registration plus Holm correction; report all Pareto fronts, not just winners.

---

## 10. Suggested timeline for a PhD chapter

Months 1–2: embedding pipeline for TCGA and HEST, baselines, grammar v1, PonyGE2 integration, fitness harness with caching. Months 3–4: full evolution on BRCA only, iterate the grammar, freeze it, pre-register. Months 5–7: all five cancers plus HEST, E1–E4. Months 8–9: E5–E7 analyses, CPTAC unlock, figures. Months 10–11: writing and submission; a GECCO/TEVC methods paper can be split off at month 6.

---

## 11. Immediate next steps

Download TCGA-BRCA diagnostic slides and RNA-seq via GDC; compute UNI embeddings; reproduce a concatenation baseline. Write the grammar above as a PonyGE2 `.bnf` file and confirm that every production maps to a runnable PyTorch model via a small interpreter. Run a 10-individual, 2-generation smoke test to measure per-candidate wall time, then size the population and generation count to the available GPU budget.
