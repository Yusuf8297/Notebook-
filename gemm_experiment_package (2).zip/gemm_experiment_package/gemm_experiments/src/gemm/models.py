"""Interpreter: JSON model spec -> PyTorch module.

Inputs are frozen foundation-model embeddings (image: UNI/CONCH slide- or
spot-level; RNA: encoder output or PCA of log-CPM). The module owns encoders,
the partitioned latent (shared + modality-specific), the fusion op(s), the
classification head, and the auxiliary modules the losses need (decoders,
modality discriminator)."""
from __future__ import annotations

from typing import Dict, List, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from . import losses as L
from .spec import Spec, validate

ACTS = {"relu": nn.ReLU, "gelu": nn.GELU, "silu": nn.SiLU, "tanh": nn.Tanh}


def mlp(d_in: int, d_out: int, width: int, layers: int, act: str, dropout: float = 0.0) -> nn.Sequential:
    mods: List[nn.Module] = []
    d = d_in
    for _ in range(layers):
        mods += [nn.Linear(d, width), ACTS[act](), nn.Dropout(dropout)]
        d = width
    mods.append(nn.Linear(d, d_out))
    return nn.Sequential(*mods)


class Encoder(nn.Module):
    def __init__(self, d_in: int, shared: int, spec: int, width: int = 256):
        super().__init__()
        self.shared, self.spec = shared, spec
        self.net = mlp(d_in, shared + spec, width, 1, "gelu")

    def forward(self, x: Tensor):
        z = self.net(x)
        return z[:, : self.shared], z[:, self.shared :]


# ------------------------------------------------------------------ fusion ops
class FusionOp(nn.Module):
    out_dim: int


class Single(FusionOp):
    def __init__(self, d: int, mod: str):
        super().__init__()
        self.mod, self.out_dim = mod, d

    def forward(self, v_img, v_rna, tok_img, tok_rna):
        return v_img if self.mod == "img" else v_rna


class Concat(FusionOp):
    def __init__(self, d: int):
        super().__init__()
        self.out_dim = 2 * d

    def forward(self, v_img, v_rna, tok_img, tok_rna):
        return torch.cat([v_img, v_rna], -1)


class Gated(FusionOp):
    def __init__(self, d: int, act: str):
        super().__init__()
        self.gate = nn.Linear(2 * d, d)
        self.act = ACTS[act]()
        self.out_dim = d

    def forward(self, v_img, v_rna, tok_img, tok_rna):
        g = torch.sigmoid(self.gate(torch.cat([v_img, v_rna], -1)))
        return self.act(g * v_img + (1 - g) * v_rna)


class Cond(FusionOp):
    """P3: FiLM-condition the backbone modality on the other one."""

    def __init__(self, d: int, backbone: str):
        super().__init__()
        self.backbone = backbone
        self.film = nn.Linear(d, 2 * d)
        self.out_dim = d

    def forward(self, v_img, v_rna, tok_img, tok_rna):
        vb, vc = (v_img, v_rna) if self.backbone == "img" else (v_rna, v_img)
        gamma, beta = self.film(vc).chunk(2, -1)
        return F.gelu((1 + gamma) * vb + beta)


class XAttn(FusionOp):
    """P4: cross-attention with a chosen direction. dir='img2rna' means image
    tokens query RNA tokens (information flows RNA -> image pathway)."""

    def __init__(self, d: int, direction: str, heads: int, layers: int):
        super().__init__()
        self.direction = direction
        heads = min(heads, d)
        while d % heads:
            heads //= 2
        mk = lambda: nn.ModuleList([nn.MultiheadAttention(d, heads, batch_first=True) for _ in range(layers)])
        self.i2r = mk() if direction in ("img2rna", "bi") else None
        self.r2i = mk() if direction in ("rna2img", "bi") else None
        self.out_dim = d * (2 if direction == "bi" else 1)

    @staticmethod
    def _run(layers, q, kv):
        for att in layers:
            q = q + att(q, kv, kv, need_weights=False)[0]
        return q.mean(1)

    def forward(self, v_img, v_rna, tok_img, tok_rna):
        outs = []
        if self.i2r is not None:
            outs.append(self._run(self.i2r, tok_img, tok_rna))
        if self.r2i is not None:
            outs.append(self._run(self.r2i, tok_rna, tok_img))
        return torch.cat(outs, -1)


def build_op(op: dict, d: int) -> FusionOp:
    t = op["type"]
    if t == "single":
        return Single(d, op["mod"])
    if t == "concat":
        return Concat(d)
    if t == "gated":
        return Gated(d, op["act"])
    if t == "cond":
        return Cond(d, op["backbone"])
    if t == "xattn":
        return XAttn(d, op["dir"], op["heads"], op["layers"])
    raise ValueError(t)


# ---------------------------------------------------------------------- model
class FusionModel(nn.Module):
    def __init__(self, spec: Spec, d_img: int, d_rna: int):
        super().__init__()
        validate(spec)
        self.spec = spec
        lat = spec["latent"]
        self.s, self.pi, self.pr = lat["shared"], lat["img_spec"], lat["rna_spec"]
        self.enc_img = Encoder(d_img, self.s, self.pi)
        self.enc_rna = Encoder(d_rna, self.s, self.pr)
        d = self.s  # common fusion width
        self.proj_img = nn.Linear(self.s + self.pi, d)
        self.proj_rna = nn.Linear(self.s + self.pr, d)
        # token projections for attention: [shared, spec] -> tokens of width d
        self.tok_img_spec = nn.Linear(self.pi, d) if self.pi else None
        self.tok_rna_spec = nn.Linear(self.pr, d) if self.pr else None
        fus = spec["fusion"]
        h = spec["head"]
        self.late = fus["type"] == "late"  # baseline-only: two unimodal heads, logits averaged
        if self.late:
            self.ops = nn.ModuleList([Single(d, "img"), Single(d, "rna")])
            self.head_img = mlp(d, 1, h["width"], h["layers"], h["act"], h["dropout"])
            self.head_rna = mlp(d, 1, h["width"], h["layers"], h["act"], h["dropout"])
        else:
            ops = fus["ops"] if fus["type"] == "stack" else [fus]
            self.ops = nn.ModuleList([build_op(o, d) for o in ops])
            self.head = mlp(sum(o.out_dim for o in self.ops), 1, h["width"], h["layers"], h["act"], h["dropout"])
        # auxiliary modules
        loss = spec["loss"]
        self.disc = mlp(self.s, 2, 64, 1, "relu") if (loss.get("align") or {}).get("type") == "disc" else None
        rec = loss.get("recon")
        self.dec_img = mlp(self.s + self.pi, d_img, 256, 1, "gelu") if rec and rec["target"] in ("img", "both") else None
        self.dec_rna = mlp(self.s + self.pr, d_rna, 256, 1, "gelu") if rec and rec["target"] in ("rna", "both") else None

    # ------------------------------------------------------------------
    def encode(self, x_img: Tensor, x_rna: Optional[Tensor], rna_present: Optional[Tensor] = None) -> Dict[str, Tensor]:
        zs_i, zp_i = self.enc_img(x_img)
        if x_rna is None:
            zs_r = zs_i
            zp_r = zs_i.new_zeros(zs_i.shape[0], self.pr)
        else:
            zs_r, zp_r = self.enc_rna(x_rna)
            if rna_present is not None:
                # P3 mechanism: when RNA is missing, its shared latent is imputed from the
                # image's shared latent (valid only if the latents are aligned) and its
                # modality-specific latent is zeroed (cannot be generated, by P2).
                m = rna_present.float().unsqueeze(1)
                zs_r = m * zs_r + (1 - m) * zs_i
                zp_r = m * zp_r
        return {"zs_i": zs_i, "zp_i": zp_i, "zs_r": zs_r, "zp_r": zp_r}

    def fuse(self, z: Dict[str, Tensor]) -> Tensor:
        v_img = self.proj_img(torch.cat([z["zs_i"], z["zp_i"]], -1))
        v_rna = self.proj_rna(torch.cat([z["zs_r"], z["zp_r"]], -1))
        tok_img = [z["zs_i"]] + ([self.tok_img_spec(z["zp_i"])] if self.tok_img_spec else [])
        tok_rna = [z["zs_r"]] + ([self.tok_rna_spec(z["zp_r"])] if self.tok_rna_spec else [])
        tok_img, tok_rna = torch.stack(tok_img, 1), torch.stack(tok_rna, 1)
        return torch.cat([op(v_img, v_rna, tok_img, tok_rna) for op in self.ops], -1)

    def forward(self, x_img: Tensor, x_rna: Optional[Tensor], rna_present: Optional[Tensor] = None) -> Dict[str, Tensor]:
        z = self.encode(x_img, x_rna, rna_present)
        if self.late:
            v_img = self.proj_img(torch.cat([z["zs_i"], z["zp_i"]], -1))
            v_rna = self.proj_rna(torch.cat([z["zs_r"], z["zp_r"]], -1))
            logit = 0.5 * (self.head_img(v_img) + self.head_rna(v_rna)).squeeze(-1)
        else:
            logit = self.head(self.fuse(z)).squeeze(-1)
        return {"logit": logit, **z}

    # ------------------------------------------------------------------
    def training_loss(self, x_img: Tensor, x_rna: Tensor, y: Tensor) -> Dict[str, Tensor]:
        spec = self.spec["loss"]
        out = self.forward(x_img, x_rna)
        terms = {"task": F.binary_cross_entropy_with_logits(out["logit"], y.float())}
        al = spec.get("align")
        if al is not None:
            if al["type"] == "infonce":
                terms["align"] = al["w"] * L.info_nce(out["zs_i"], out["zs_r"], al["temp"])
            else:
                terms["align"] = al["w"] * L.discriminative_alignment(out["zs_i"], out["zs_r"], self.disc)
        dis = self.spec["latent"].get("disentangle")
        if dis is not None:
            fn = L.DISENTANGLE[dis["type"]]
            t = 0.0
            if self.pi:
                t = t + fn(out["zs_i"], out["zp_i"])
            if self.pr:
                t = t + fn(out["zs_r"], out["zp_r"])
            if isinstance(t, Tensor):
                terms["disentangle"] = dis["w"] * t
        rec = spec.get("recon")
        if rec is not None:
            r = 0.0
            if self.dec_img is not None:
                r = r + F.mse_loss(self.dec_img(torch.cat([out["zs_i"], out["zp_i"]], -1)), x_img)
            if self.dec_rna is not None:
                r = r + F.mse_loss(self.dec_rna(torch.cat([out["zs_r"], out["zp_r"]], -1)), x_rna)
            terms["recon"] = rec["w"] * r
        md = spec.get("moddrop")
        if md is not None:
            present = torch.rand(x_img.shape[0], device=x_img.device) > md["p"]
            out_d = self.forward(x_img, x_rna, rna_present=present)
            terms["moddrop"] = md["w"] * F.binary_cross_entropy_with_logits(out_d["logit"], y.float())
        terms["total"] = sum(terms.values())
        return terms

    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)
