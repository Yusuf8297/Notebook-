"""Loss terms selectable by the grammar."""
from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import Tensor


def info_nce(a: Tensor, b: Tensor, temp: float) -> Tensor:
    """Symmetric InfoNCE between paired shared latents (P1: contrastive alignment)."""
    a = F.normalize(a, dim=-1)
    b = F.normalize(b, dim=-1)
    logits = a @ b.t() / temp
    target = torch.arange(a.shape[0], device=a.device)
    return 0.5 * (F.cross_entropy(logits, target) + F.cross_entropy(logits.t(), target))


class GradReverse(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, lam):
        ctx.lam = lam
        return x.view_as(x)

    @staticmethod
    def backward(ctx, g):
        return -ctx.lam * g, None


def grad_reverse(x: Tensor, lam: float = 1.0) -> Tensor:
    return GradReverse.apply(x, lam)


def discriminative_alignment(shared_img: Tensor, shared_rna: Tensor, clf: torch.nn.Module) -> Tensor:
    """Adversarial modality classifier on shared latents through a gradient-reversal layer
    (P1, discriminative variant): encoders are pushed to make modality unidentifiable."""
    z = torch.cat([shared_img, shared_rna], 0)
    y = torch.cat([torch.zeros(shared_img.shape[0]), torch.ones(shared_rna.shape[0])]).long().to(z.device)
    return F.cross_entropy(clf(grad_reverse(z)), y)


def _center(k: Tensor) -> Tensor:
    n = k.shape[0]
    h = torch.eye(n, device=k.device) - 1.0 / n
    return h @ k @ h


def _rbf(x: Tensor) -> Tensor:
    d = torch.cdist(x, x) ** 2
    med = d[d > 0].median() if (d > 0).any() else torch.tensor(1.0, device=x.device)
    return torch.exp(-d / (med + 1e-8))


def hsic(x: Tensor, y: Tensor) -> Tensor:
    """Biased HSIC estimator with RBF kernels (P2: independence of shared and specific latents)."""
    n = x.shape[0]
    kx, ky = _center(_rbf(x)), _center(_rbf(y))
    return (kx * ky).sum() / (n - 1) ** 2


def orth(x: Tensor, y: Tensor) -> Tensor:
    x = x - x.mean(0, keepdim=True)
    y = y - y.mean(0, keepdim=True)
    return ((x.t() @ y) ** 2).sum() / (x.shape[0] ** 2)


def mmd_independence(x: Tensor, y: Tensor) -> Tensor:
    """MMD between the joint (x,y) and the product of marginals (x, shuffled y)."""
    perm = torch.randperm(y.shape[0], device=y.device)
    joint = torch.cat([x, y], 1)
    prod = torch.cat([x, y[perm]], 1)
    z = torch.cat([joint, prod], 0)
    k = _rbf(z)
    n = x.shape[0]
    kjj, kpp, kjp = k[:n, :n], k[n:, n:], k[:n, n:]
    return kjj.mean() + kpp.mean() - 2 * kjp.mean()


DISENTANGLE = {"hsic": hsic, "orth": orth, "mmd": mmd_independence}
