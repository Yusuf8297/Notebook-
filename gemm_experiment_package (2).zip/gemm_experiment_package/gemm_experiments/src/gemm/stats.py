"""Statistical tests used in the paper: DeLong's test for correlated AUROCs,
Holm correction, Mann-Whitney U, permutation enrichment, bootstrap CIs."""
from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

import numpy as np
from scipy import stats


# ------------------------------------------------------------------ DeLong
def _compute_midrank(x: np.ndarray) -> np.ndarray:
    J = np.argsort(x)
    Z = x[J]
    N = len(x)
    T = np.zeros(N)
    i = 0
    while i < N:
        j = i
        while j < N and Z[j] == Z[i]:
            j += 1
        T[i:j] = 0.5 * (i + j - 1) + 1
        i = j
    T2 = np.empty(N)
    T2[J] = T
    return T2


def _fast_delong(preds_sorted: np.ndarray, m: int) -> Tuple[np.ndarray, np.ndarray]:
    """preds_sorted: (k, n) with first m columns positives. Returns aucs, covariance."""
    n = preds_sorted.shape[1] - m
    k = preds_sorted.shape[0]
    tx, ty, tz = np.empty([k, m]), np.empty([k, n]), np.empty([k, m + n])
    for r in range(k):
        tx[r] = _compute_midrank(preds_sorted[r, :m])
        ty[r] = _compute_midrank(preds_sorted[r, m:])
        tz[r] = _compute_midrank(preds_sorted[r])
    aucs = tz[:, :m].sum(1) / m / n - (m + 1.0) / 2.0 / n
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    sx, sy = np.cov(v01), np.cov(v10)
    return aucs, sx / m + sy / n


def delong_test(y: np.ndarray, p1: np.ndarray, p2: np.ndarray) -> Tuple[float, float, float]:
    """Two-sided DeLong test that AUROC(p1) == AUROC(p2) on the same samples.
    Returns (auc1, auc2, p_value)."""
    order = np.argsort(-y)
    y_s = y[order]
    m = int(y_s.sum())
    preds = np.vstack([p1[order], p2[order]])
    aucs, cov = _fast_delong(preds, m)
    diff = aucs[0] - aucs[1]
    var = cov[0, 0] + cov[1, 1] - 2 * cov[0, 1]
    if var <= 0:
        return float(aucs[0]), float(aucs[1]), 1.0
    z = diff / np.sqrt(var)
    return float(aucs[0]), float(aucs[1]), float(2 * stats.norm.sf(abs(z)))


def delong_ci(y: np.ndarray, p: np.ndarray, alpha: float = 0.05) -> Tuple[float, float, float]:
    order = np.argsort(-y)
    m = int(y[order].sum())
    aucs, cov = _fast_delong(np.vstack([p[order], p[order]]), m)
    se = np.sqrt(max(cov[0, 0], 0))
    z = stats.norm.ppf(1 - alpha / 2)
    return float(aucs[0]), float(aucs[0] - z * se), float(aucs[0] + z * se)


# ------------------------------------------------------------------ corrections
def holm(pvals: Sequence[float]) -> List[float]:
    p = np.asarray(pvals, dtype=float)
    n = len(p)
    order = np.argsort(p)
    adj = np.empty(n)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, (n - rank) * p[i])
        adj[i] = min(1.0, running)
    return adj.tolist()


def mann_whitney(a: Sequence[float], b: Sequence[float]) -> Dict[str, float]:
    a, b = np.asarray(a, float), np.asarray(b, float)
    if len(a) < 2 or len(b) < 2:
        return {"U": float("nan"), "p": float("nan"), "cliffs_delta": float("nan"), "n_a": len(a), "n_b": len(b)}
    u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
    delta = 2 * u / (len(a) * len(b)) - 1  # Cliff's delta effect size
    return {"U": float(u), "p": float(p), "cliffs_delta": float(delta), "n_a": len(a), "n_b": len(b)}


def bootstrap_ci(values: Sequence[float], n_boot: int = 2000, alpha: float = 0.05, seed: int = 0) -> Tuple[float, float, float]:
    v = np.asarray(values, float)
    rng = np.random.RandomState(seed)
    boots = [rng.choice(v, len(v), replace=True).mean() for _ in range(n_boot)]
    return float(v.mean()), float(np.percentile(boots, 100 * alpha / 2)), float(np.percentile(boots, 100 * (1 - alpha / 2)))


def enrichment_permutation(observed_count: int, n_trials: int, p_null: float, n_perm: int = 20000, seed: int = 0) -> Dict[str, float]:
    """Is a production selected more often than its prior under uniform codons?
    One-sided permutation/binomial test, plus fold enrichment."""
    rng = np.random.RandomState(seed)
    sims = rng.binomial(n_trials, p_null, n_perm)
    p = float((sims >= observed_count).mean() + 1.0 / n_perm)
    return {"observed": observed_count, "expected": n_trials * p_null,
            "fold": observed_count / max(n_trials * p_null, 1e-9), "p_one_sided": min(1.0, p)}
