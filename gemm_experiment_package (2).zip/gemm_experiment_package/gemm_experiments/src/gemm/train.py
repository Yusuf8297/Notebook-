"""Time-boxed training of one candidate on cached embeddings, plus evaluation helpers."""
from __future__ import annotations

import copy
import time
from typing import Dict, Optional

import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import cross_val_score

from .data import Cohort
from .models import FusionModel
from .spec import Spec


def set_seed(seed: int) -> None:
    torch.manual_seed(seed)
    np.random.seed(seed)


def train_candidate(spec: Spec, train: Cohort, val: Cohort, seed: int = 0, device: str = "cpu",
                    time_budget_s: float = 120.0, patience: int = 5, verbose: bool = False) -> Dict:
    """Train with early stopping on validation AUROC and a wall-clock cap.
    Returns dict(model, best_val_auc, epochs_run, wall_s, diverged)."""
    set_seed(seed)
    model = FusionModel(spec, train.img.shape[1], train.rna.shape[1]).to(device)
    tr = spec["train"]
    opt = torch.optim.AdamW(model.parameters(), lr=tr["lr"], weight_decay=tr["wd"])
    xi, xr, y = train.tensors(device)
    n = len(train)
    best, best_state, bad, t0, ep = -1.0, None, 0, time.time(), 0
    diverged = False
    for ep in range(tr["epochs"]):
        model.train()
        perm = torch.randperm(n, device=device)
        for s in range(0, n, tr["batch"]):
            idx = perm[s : s + tr["batch"]]
            if len(idx) < 4:
                continue
            terms = model.training_loss(xi[idx], xr[idx], y[idx])
            loss = terms["total"]
            if not torch.isfinite(loss):
                diverged = True
                break
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
        if diverged:
            break
        auc = auroc(model, val, device)
        if verbose:
            print(f"ep {ep} loss {loss.item():.3f} val_auc {auc:.3f}")
        if auc > best + 1e-4:
            best, bad, best_state = auc, 0, copy.deepcopy(model.state_dict())
        else:
            bad += 1
        if bad >= patience or time.time() - t0 > time_budget_s:
            break
    if best_state is not None:
        model.load_state_dict(best_state)
    model.eval()
    return {"model": model, "best_val_auc": best, "epochs_run": ep + 1, "wall_s": time.time() - t0, "diverged": diverged}


@torch.no_grad()
def predict(model: FusionModel, c: Cohort, device: str = "cpu", rna_missing: bool = False) -> np.ndarray:
    if len(c) == 0:
        return np.zeros(0)
    model.eval()
    xi, xr, _ = c.tensors(device)
    out = model(xi, None if rna_missing else xr)
    return torch.sigmoid(out["logit"]).cpu().numpy()


@torch.no_grad()
def latents(model: FusionModel, c: Cohort, device: str = "cpu") -> Dict[str, np.ndarray]:
    model.eval()
    xi, xr, _ = c.tensors(device)
    z = model.encode(xi, xr)
    return {k: v.cpu().numpy() for k, v in z.items()}


def auroc(model: FusionModel, c: Cohort, device: str = "cpu", rna_missing: bool = False) -> float:
    if len(c) == 0 or len(np.unique(c.y)) < 2:
        return float("nan")
    return float(roc_auc_score(c.y, predict(model, c, device, rna_missing)))


def auprc(model: FusionModel, c: Cohort, device: str = "cpu", rna_missing: bool = False) -> float:
    if len(c) == 0 or len(np.unique(c.y)) < 2:
        return float("nan")
    return float(average_precision_score(c.y, predict(model, c, device, rna_missing)))


def ece(p: np.ndarray, y: np.ndarray, bins: int = 10) -> float:
    edges = np.linspace(0, 1, bins + 1)
    e = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (p >= lo) & (p < hi) if hi < 1 else (p >= lo) & (p <= hi)
        if m.any():
            e += m.mean() * abs(p[m].mean() - y[m].mean())
    return float(e)


def batch_probe_accuracy(z: np.ndarray, site: np.ndarray, seed: int = 0) -> float:
    """Balanced accuracy of a linear probe predicting site from a latent, minus chance.
    0 = site not linearly identifiable (the invariance we want); >0 = batch leaks."""
    sites = np.unique(site)
    if len(sites) < 2 or len(z) < 20:
        return 0.0
    clf = LogisticRegression(max_iter=500, class_weight="balanced")
    try:
        acc = cross_val_score(clf, z, site, cv=min(3, np.min(np.unique(site, return_counts=True)[1])),
                              scoring="balanced_accuracy").mean()
    except ValueError:
        return 0.0
    return float(max(0.0, acc - 1.0 / len(sites)))
