"""Grammatical evolution with NSGA-II selection.

Genome: fixed-length list of integer codons. Variation: one-point crossover
and per-codon integer mutation. Selection: binary tournament on
(non-domination rank, crowding distance). Survival: (mu + lambda) NSGA-II.
Every evaluated individual is logged with its spec, derivation choices and
fitness so that all analyses can be re-run from the log alone.
"""
from __future__ import annotations

import json
import os
import random
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence

import numpy as np

from .fitness import OBJECTIVES, Fitness, penalty_fitness
from .grammar import Derivation, Grammar
from .spec import principle_flags, to_json


@dataclass
class Individual:
    genome: List[int]
    derivation: Optional[Derivation] = None
    fitness: Optional[Fitness] = None
    rank: int = 10**9
    crowding: float = 0.0
    gen: int = 0
    uid: str = ""

    @property
    def spec(self):
        return self.derivation.spec() if self.derivation and self.derivation.valid else None


# ------------------------------------------------------------------ NSGA-II
def dominates(a: np.ndarray, b: np.ndarray) -> bool:
    return bool(np.all(a >= b) and np.any(a > b))


def fast_non_dominated_sort(F: np.ndarray) -> List[List[int]]:
    n = len(F)
    S = [[] for _ in range(n)]
    cnt = np.zeros(n, dtype=int)
    fronts: List[List[int]] = [[]]
    for p in range(n):
        for q in range(n):
            if p == q:
                continue
            if dominates(F[p], F[q]):
                S[p].append(q)
            elif dominates(F[q], F[p]):
                cnt[p] += 1
        if cnt[p] == 0:
            fronts[0].append(p)
    i = 0
    while fronts[i]:
        nxt = []
        for p in fronts[i]:
            for q in S[p]:
                cnt[q] -= 1
                if cnt[q] == 0:
                    nxt.append(q)
        i += 1
        fronts.append(nxt)
    return [f for f in fronts if f]


def crowding_distance(F: np.ndarray) -> np.ndarray:
    n, m = F.shape
    d = np.zeros(n)
    if n <= 2:
        d[:] = np.inf
        return d
    for j in range(m):
        order = np.argsort(F[:, j])
        d[order[0]] = d[order[-1]] = np.inf
        rng = F[order[-1], j] - F[order[0], j]
        if rng <= 0:
            continue
        for k in range(1, n - 1):
            d[order[k]] += (F[order[k + 1], j] - F[order[k - 1], j]) / rng
    return d


def assign_ranks(pop: List[Individual], objectives: Sequence[str]) -> None:
    F = np.array([ind.fitness.vector(list(objectives)) for ind in pop])
    for r, front in enumerate(fast_non_dominated_sort(F)):
        cd = crowding_distance(F[front])
        for k, i in enumerate(front):
            pop[i].rank, pop[i].crowding = r, float(cd[k])


def nsga2_survival(pop: List[Individual], mu: int, objectives: Sequence[str]) -> List[Individual]:
    assign_ranks(pop, objectives)
    pop = sorted(pop, key=lambda i: (i.rank, -i.crowding))
    return pop[:mu]


def pareto_front(pop: List[Individual], objectives: Sequence[str] = OBJECTIVES) -> List[Individual]:
    valid = [i for i in pop if i.fitness and i.fitness.valid]
    if not valid:
        return []
    assign_ranks(valid, objectives)
    return [i for i in valid if i.rank == 0]


# ------------------------------------------------------------------ GE loop
@dataclass
class GEConfig:
    pop_size: int = 100
    generations: int = 40
    genome_len: int = 200
    codon_max: int = 255
    p_crossover: float = 0.8
    p_mutation: float = 0.02   # per codon
    max_wraps: int = 3
    max_depth: int = 20
    seed: int = 0
    objectives: List[str] = field(default_factory=lambda: list(OBJECTIVES))
    elitism: bool = True


class GE:
    def __init__(self, grammar: Grammar, evaluate: Callable[[Optional[dict], int], Fitness], cfg: GEConfig,
                 log_dir: Optional[str] = None, dedupe: bool = True):
        self.g, self.evaluate, self.cfg = grammar, evaluate, cfg
        self.rng = random.Random(cfg.seed)
        self.log_dir = log_dir
        self.cache: Dict[str, Fitness] = {}
        self.dedupe = dedupe
        self.history: List[dict] = []
        self.n_evals = 0
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)

    # -------------------------------------------------------- individuals
    def random_ind(self, gen: int = 0) -> Individual:
        return Individual([self.rng.randint(0, self.cfg.codon_max) for _ in range(self.cfg.genome_len)], gen=gen)

    def derive(self, ind: Individual) -> None:
        ind.derivation = self.g.map(ind.genome, self.cfg.max_wraps, self.cfg.max_depth)

    def eval_ind(self, ind: Individual, gen: int) -> None:
        self.derive(ind)
        spec = ind.spec
        key = to_json(spec) if spec else "__invalid__"
        if spec is None:
            ind.fitness = penalty_fitness()
        elif self.dedupe and key in self.cache:
            ind.fitness = self.cache[key]
        else:
            ind.fitness = self.evaluate(spec, self.n_evals)
            self.n_evals += 1
            self.cache[key] = ind.fitness
        ind.gen = gen
        ind.uid = f"g{gen}_{len(self.history)}"
        self._log(ind)

    def _log(self, ind: Individual) -> None:
        spec = ind.spec
        rec = {
            "uid": ind.uid, "gen": ind.gen, "valid": ind.fitness.valid, "fitness": ind.fitness.values,
            "wall_s": ind.fitness.wall_s, "spec": spec,
            "choices": ind.derivation.choices if ind.derivation else [],
            "flags": principle_flags(spec) if spec else None,
            "extra": {k: v for k, v in ind.fitness.extra.items() if k != "model"},
        }
        self.history.append(rec)
        if self.log_dir:
            with open(os.path.join(self.log_dir, "evaluations.jsonl"), "a") as f:
                f.write(json.dumps(rec) + "\n")

    # -------------------------------------------------------- variation
    def tournament(self, pop: List[Individual]) -> Individual:
        a, b = self.rng.sample(pop, 2)
        if a.rank != b.rank:
            return a if a.rank < b.rank else b
        return a if a.crowding >= b.crowding else b

    def crossover(self, a: Individual, b: Individual) -> Individual:
        if self.rng.random() > self.cfg.p_crossover:
            return Individual(list(a.genome))
        # cut within the *used* region so crossover is meaningful (standard GE practice)
        used = max(2, min(a.derivation.used_codons if a.derivation else len(a.genome), len(a.genome)))
        cut = self.rng.randint(1, used - 1)
        return Individual(a.genome[:cut] + b.genome[cut:])

    def mutate(self, ind: Individual) -> Individual:
        g = [c if self.rng.random() > self.cfg.p_mutation else self.rng.randint(0, self.cfg.codon_max) for c in ind.genome]
        return Individual(g)

    # -------------------------------------------------------- main loop
    def run(self, progress: Optional[Callable[[int, List[Individual]], None]] = None) -> List[Individual]:
        cfg = self.cfg
        pop = [self.random_ind() for _ in range(cfg.pop_size)]
        for ind in pop:
            self.eval_ind(ind, 0)
        assign_ranks(pop, cfg.objectives)
        if progress:
            progress(0, pop)
        for gen in range(1, cfg.generations + 1):
            t0 = time.time()
            children = []
            while len(children) < cfg.pop_size:
                c = self.mutate(self.crossover(self.tournament(pop), self.tournament(pop)))
                children.append(c)
            for c in children:
                self.eval_ind(c, gen)
            pop = nsga2_survival(pop + children if cfg.elitism else children, cfg.pop_size, cfg.objectives)
            self._log_gen(gen, pop, time.time() - t0)
            if progress:
                progress(gen, pop)
        return pop

    def _log_gen(self, gen: int, pop: List[Individual], wall: float) -> None:
        if not self.log_dir:
            return
        front = [i for i in pop if i.rank == 0 and i.fitness.valid]
        rec = {"gen": gen, "wall_s": wall, "n_evals": self.n_evals,
               "front_size": len(front),
               "best": {k: max(i.fitness.values[k] for i in pop if i.fitness.valid) for k in self.cfg.objectives}
               if any(i.fitness.valid for i in pop) else None}
        with open(os.path.join(self.log_dir, "generations.jsonl"), "a") as f:
            f.write(json.dumps(rec) + "\n")


def select_final(front: List[Individual], primary: str = "val_auc", secondary: str = "shift_auc",
                 tol: float = 0.005) -> Individual:
    """Pre-registered selection rule: among Pareto-optimal models within `tol` AUROC of the
    best primary objective, pick the one with the best secondary objective."""
    best = max(i.fitness.values[primary] for i in front)
    cands = [i for i in front if i.fitness.values[primary] >= best - tol]
    return max(cands, key=lambda i: (i.fitness.values[secondary], i.fitness.values.get("parsimony", 0)))
