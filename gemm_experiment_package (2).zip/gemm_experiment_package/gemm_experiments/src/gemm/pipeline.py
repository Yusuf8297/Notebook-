"""High-level experiment steps shared by the CLI scripts. Results layout:

results/<run>/
  baselines/fold<k>/<name>_seed<s>.json        E1/E2/E3 metrics + predictions
  evolution/<variant>/seed<s>/fold<k>/          evaluations.jsonl, generations.jsonl, winner.json
  final/fold<k>/<model>_seed<s>.json            retrained winners evaluated like baselines
  analysis/                                     tables and figures (run_analysis.py)
"""
from __future__ import annotations

import json
import os
from typing import Dict, List, Optional

import numpy as np
import torch
import yaml

from .analysis import hallmark_probes
from .data import Cohort, Split, make_splits, standardize
from .evolution import GE, GEConfig, pareto_front, select_final
from .fitness import OBJECTIVES, evaluate
from .grammar import Grammar
from .spec import BASELINES, Spec, principle_flags
from .train import auprc, auroc, batch_probe_accuracy, ece, latents, predict, train_candidate


def load_config(path: str) -> dict:
    with open(path) as f:
        cfg = yaml.safe_load(f)
    cfg.setdefault("device", "cpu")
    cfg.setdefault("folds", [0])
    cfg["ge"].setdefault("objectives", list(OBJECTIVES))
    return cfg


def get_split(cfg: dict, fold: int) -> Split:
    c = Cohort.load(cfg["data"]["internal"], "internal")
    for k, sp in enumerate(make_splits(c, cfg["data"].get("n_outer_folds", 5), seed=cfg["data"].get("split_seed", 0))):
        if k == fold:
            return sp
    raise IndexError(fold)


def get_external(cfg: dict, split: Split) -> Optional[Cohort]:
    p = cfg["data"].get("external")
    if not p or not os.path.exists(p):
        return None
    ext = Cohort.load(p, "external")
    # standardise with the *training* statistics of this fold (no peeking at external stats)
    raw_train = Cohort.load(cfg["data"]["internal"], "internal")
    # reconstruct un-standardised train mean/std by matching patients
    idx = np.isin(raw_train.patient, split.train.patient)
    return standardize(raw_train.subset(np.where(idx)[0]), ext)[1]


# ------------------------------------------------------------------ E1-E3 evaluation
def full_evaluation(spec: Spec, split: Split, external: Optional[Cohort], seed: int, device: str,
                    time_budget_s: float, name: str) -> Dict:
    res = train_candidate(spec, split.train, split.val, seed=seed, device=device, time_budget_s=time_budget_s)
    m = res["model"]
    out: Dict = {"name": name, "seed": seed, "spec": spec, "flags": principle_flags(spec), "n_params": m.n_params(),
                 "val_auc": res["best_val_auc"], "metrics": {}, "predictions": {}}
    cohorts = {"test": split.test, "heldout_site": split.heldout_site}
    if external is not None:
        cohorts["external"] = external
    for cname, c in cohorts.items():
        if len(c) == 0:
            continue
        for missing in (False, True):
            tag = f"{cname}{'_noRNA' if missing else ''}"
            p = predict(m, c, device, rna_missing=missing)
            out["predictions"][tag] = {"p": p.round(5).tolist(), "y": c.y.tolist()}
            out["metrics"][tag] = {"auroc": auroc(m, c, device, missing), "auprc": auprc(m, c, device, missing),
                                   "ece": ece(p, c.y)}
        z = latents(m, c, device)
        out["metrics"][cname]["site_probe"] = batch_probe_accuracy(z["zs_i"], c.site, seed)
        if c.hallmarks:
            out["metrics"][cname]["hallmark_probes"] = hallmark_probes(z, c.hallmarks, seed)
    return out


def run_baselines(cfg: dict, fold: int, seeds: List[int], names: Optional[List[str]] = None) -> None:
    split = get_split(cfg, fold)
    ext = get_external(cfg, split)
    outdir = os.path.join(cfg["out"], "baselines", f"fold{fold}")
    os.makedirs(outdir, exist_ok=True)
    for name in names or list(BASELINES):
        for s in seeds:
            r = full_evaluation(BASELINES[name], split, ext, s, cfg["device"], cfg["ge"]["time_budget_s"], name)
            with open(os.path.join(outdir, f"{name}_seed{s}.json"), "w") as f:
                json.dump(r, f)
            print(f"[baseline] fold{fold} {name} seed{s} test AUROC {r['metrics']['test']['auroc']:.3f}"
                  f" noRNA {r['metrics']['test_noRNA']['auroc']:.3f}"
                  + (f" ext {r['metrics']['external']['auroc']:.3f}" if 'external' in r['metrics'] else ""))


def run_random_search(cfg: dict, fold: int, seed: int, n: int) -> None:
    """Control for E1: random grammar derivations, no selection pressure."""
    split = get_split(cfg, fold)
    g = Grammar.from_file(cfg["grammar"])
    outdir = os.path.join(cfg["out"], "evolution", "random", f"seed{seed}", f"fold{fold}")
    gecfg = GEConfig(pop_size=n, generations=0, seed=seed, objectives=cfg["ge"]["objectives"],
                     genome_len=cfg["ge"].get("genome_len", 200))
    ge = GE(g, lambda spec, i: evaluate(spec, split, seed=i, device=cfg["device"], time_budget_s=cfg["ge"]["time_budget_s"]),
            gecfg, log_dir=outdir)
    pop = ge.run()
    _save_winner(pop, outdir, cfg["ge"]["objectives"])


def run_evolution(cfg: dict, fold: int, seed: int, variant: str = "full") -> None:
    split = get_split(cfg, fold)
    g = Grammar.from_file(cfg["grammar"])
    if variant != "full":
        g = g.override(cfg["ablations"][variant])
    outdir = os.path.join(cfg["out"], "evolution", variant, f"seed{seed}", f"fold{fold}")
    if os.path.exists(os.path.join(outdir, "winner.json")):
        print(f"[skip] {outdir} already done")
        return
    for fn in ("evaluations.jsonl", "generations.jsonl"):
        p = os.path.join(outdir, fn)
        if os.path.exists(p):
            os.remove(p)
    gecfg = GEConfig(pop_size=cfg["ge"]["pop_size"], generations=cfg["ge"]["generations"], seed=seed,
                     objectives=cfg["ge"]["objectives"], genome_len=cfg["ge"].get("genome_len", 200),
                     p_mutation=cfg["ge"].get("p_mutation", 0.02), p_crossover=cfg["ge"].get("p_crossover", 0.8))
    ge = GE(g, lambda spec, i: evaluate(spec, split, seed=i, device=cfg["device"], time_budget_s=cfg["ge"]["time_budget_s"]),
            gecfg, log_dir=outdir)

    def progress(gen, pop):
        valid = [i for i in pop if i.fitness.valid]
        best = max(i.fitness.values["val_auc"] for i in valid) if valid else float("nan")
        print(f"[{variant} seed{seed} fold{fold}] gen {gen}/{gecfg.generations} evals {ge.n_evals} best val_auc {best:.3f}")

    pop = ge.run(progress=progress)
    _save_winner(pop, outdir, cfg["ge"]["objectives"])


def _save_winner(pop, outdir: str, objectives: List[str]) -> None:
    front = pareto_front(pop, objectives)
    if not front:
        print("no valid individuals")
        return
    w = select_final(front)
    with open(os.path.join(outdir, "winner.json"), "w") as f:
        json.dump({"spec": w.spec, "fitness": w.fitness.values, "flags": principle_flags(w.spec),
                   "front": [{"spec": i.spec, "fitness": i.fitness.values, "flags": principle_flags(i.spec)} for i in front]}, f, indent=1)
    print(f"winner: {json.dumps(w.fitness.values)}\n{json.dumps(w.spec)}")


def run_final(cfg: dict, fold: int, seeds: List[int], variants: Optional[List[str]] = None) -> None:
    """Retrain each variant's winner (for this fold) with several seeds and evaluate like the baselines."""
    split = get_split(cfg, fold)
    ext = get_external(cfg, split)
    evo = os.path.join(cfg["out"], "evolution")
    outdir = os.path.join(cfg["out"], "final", f"fold{fold}")
    os.makedirs(outdir, exist_ok=True)
    for variant in variants or sorted(os.listdir(evo)):
        vdir = os.path.join(evo, variant)
        for sd in sorted(os.listdir(vdir)):
            for wfile, suffix in (("winner.json", ""), ("winner_deploy.json", "-deploy")):
                wp = os.path.join(vdir, sd, f"fold{fold}", wfile)
                if not os.path.exists(wp):
                    continue
                spec = json.load(open(wp))["spec"]
                name = f"evolved_{variant}{suffix}_{sd}"   # group = evolved_<variant>[-deploy]
                for s in seeds:
                    fp = os.path.join(outdir, f"{name}_seed{s}.json")
                    if os.path.exists(fp):
                        continue
                    r = full_evaluation(spec, split, ext, s, cfg["device"], cfg["ge"]["time_budget_s"], name)
                    with open(fp, "w") as f:
                        json.dump(r, f)
                    print(f"[final] fold{fold} {name} seed{s} test AUROC {r['metrics']['test']['auroc']:.3f}"
                          f" noRNA {r['metrics']['test_noRNA']['auroc']:.3f}"
                          + (f" ext {r['metrics']['external']['auroc']:.3f}" if 'external' in r['metrics'] else ""))
