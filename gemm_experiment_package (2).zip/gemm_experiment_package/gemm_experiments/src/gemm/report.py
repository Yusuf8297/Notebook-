"""Aggregate results into the tables of the paper (E1-E7) and write analysis/report.md."""
from __future__ import annotations

import glob
import json
import os
from collections import defaultdict
from typing import Dict, List

import numpy as np

from .analysis import (cca_rank, final_generation, flag_enrichment, hypervolume, load_evaluations,
                       mi_shared_estimate, motifs, pareto_records, production_frequencies, spearman,
                       uniform_prior_flags, FLAG_NAMES)
from .grammar import Grammar
from .pipeline import get_split
from .stats import delong_test, holm, mann_whitney, bootstrap_ci


def _load_dir(pattern: str) -> List[dict]:
    return [json.load(open(p)) for p in sorted(glob.glob(pattern))]


def _fmt(m, s):
    return f"{m:.3f} ± {s:.3f}"


def table_e1_e3(cfg: dict) -> Dict:
    """Per-model test / held-out-site / external / no-RNA AUROC across folds and seeds, with DeLong vs the
    strongest hand-designed baseline (paired on identical fold+seed predictions)."""
    recs = _load_dir(os.path.join(cfg["out"], "baselines", "fold*", "*.json")) + \
           _load_dir(os.path.join(cfg["out"], "final", "fold*", "*.json"))
    by = defaultdict(list)
    for r in recs:
        by[r["name"]].append(r)
    tags = ["test", "heldout_site", "external", "test_noRNA", "external_noRNA"]
    rows = {}
    for name, rs in by.items():
        row = {"n_runs": len(rs), "n_params": int(np.mean([r["n_params"] for r in rs]))}
        for t in tags:
            vals = [r["metrics"][t]["auroc"] for r in rs if t in r["metrics"] and not np.isnan(r["metrics"][t]["auroc"])]
            if vals:
                row[t] = {"mean": float(np.mean(vals)), "sd": float(np.std(vals)), "n": len(vals)}
        v = [r["metrics"]["test"]["ece"] for r in rs if "test" in r["metrics"]]
        row["ece_test"] = float(np.mean(v)) if v else float("nan")
        v = [r["metrics"]["test"]["site_probe"] for r in rs if "test" in r["metrics"]]
        row["site_probe_test"] = float(np.mean(v)) if v else float("nan")
        rows[name] = row
    # DeLong: each evolved model vs best baseline, paired by (fold, seed) on the concatenated test predictions
    baselines = [n for n in rows if not n.startswith("evolved_")]
    if baselines and any(n.startswith("evolved_") for n in rows):
        best_b = max(baselines, key=lambda n: rows[n].get("test", {"mean": -1})["mean"])
        pvals, names = [], []
        for name in rows:
            if not name.startswith("evolved_"):
                continue
            y, p1, p2 = [], [], []
            for r in by[name]:
                mate = [b for b in by[best_b] if b["seed"] == r["seed"] and len(b["predictions"]["test"]["y"]) == len(r["predictions"]["test"]["y"])]
                if not mate:
                    continue
                y += r["predictions"]["test"]["y"]; p1 += r["predictions"]["test"]["p"]; p2 += mate[0]["predictions"]["test"]["p"]
            if len(set(y)) == 2:
                a1, a2, p = delong_test(np.array(y), np.array(p1), np.array(p2))
                rows[name]["delong_vs_" + best_b] = {"auc": a1, "auc_ref": a2, "p": p}
                pvals.append(p); names.append(name)
        for n, pa in zip(names, holm(pvals)):
            rows[n]["delong_vs_" + best_b]["p_holm"] = pa
    return rows


def table_e2_h2(cfg: dict) -> Dict:
    """H2: among ALL evaluated individuals of the full-grammar runs, does having an alignment term
    reduce the val->held-out-site drop? Mann-Whitney over individuals (population-level)."""
    out = {}
    for variant_dir in glob.glob(os.path.join(cfg["out"], "evolution", "*")):
        variant = os.path.basename(variant_dir)
        recs = []
        for p in glob.glob(os.path.join(variant_dir, "seed*", "fold*", "evaluations.jsonl")):
            recs += [r for r in load_evaluations(p) if r["valid"]]
        if not recs:
            continue
        res = {}
        for flag in FLAG_NAMES:
            with_f = [r["fitness"]["val_auc"] - r["fitness"]["shift_auc"] for r in recs if r["flags"][flag]]
            without = [r["fitness"]["val_auc"] - r["fitness"]["shift_auc"] for r in recs if not r["flags"][flag]]
            miss_w = [r["fitness"]["missing_auc"] for r in recs if r["flags"][flag]]
            miss_wo = [r["fitness"]["missing_auc"] for r in recs if not r["flags"][flag]]
            inv_w = [r["fitness"]["invariance"] for r in recs if r["flags"][flag]]
            inv_wo = [r["fitness"]["invariance"] for r in recs if not r["flags"][flag]]
            res[flag] = {"shift_drop_with": float(np.mean(with_f)) if with_f else None,
                         "shift_drop_without": float(np.mean(without)) if without else None,
                         "shift_drop_test": mann_whitney(with_f, without),
                         "missing_auc_with": float(np.mean(miss_w)) if miss_w else None,
                         "missing_auc_without": float(np.mean(miss_wo)) if miss_wo else None,
                         "missing_auc_test": mann_whitney(miss_w, miss_wo),
                         "invariance_with": float(np.mean(inv_w)) if inv_w else None,
                         "invariance_without": float(np.mean(inv_wo)) if inv_wo else None,
                         "invariance_test": mann_whitney(inv_w, inv_wo)}
        out[variant] = {"n_individuals": len(recs), "by_flag": res}
    return out


def table_e4(cfg: dict) -> Dict:
    """Grammar ablations: hypervolume and best-of-run per variant; principle enrichment in full runs."""
    g = Grammar.from_file(cfg["grammar"])
    objectives = cfg["ge"]["objectives"]
    ref = np.array([0.5 if o.endswith("auc") else -1.0 for o in objectives])
    out = {"variants": {}, "enrichment": {}, "productions": {}}
    prior = uniform_prior_flags(g, n=5000)
    for variant_dir in sorted(glob.glob(os.path.join(cfg["out"], "evolution", "*"))):
        variant = os.path.basename(variant_dir)
        hvs, bests, fronts = [], [], []
        for p in glob.glob(os.path.join(variant_dir, "seed*", "fold*", "evaluations.jsonl")):
            recs = load_evaluations(p)
            front = pareto_records(recs, objectives)
            fronts += front
            F = np.array([[r["fitness"][k] for k in objectives] for r in front])
            hvs.append(hypervolume(F, ref, n_samples=50000))
            bests.append(max(r["fitness"]["val_auc"] for r in recs if r["valid"]))
        if hvs:
            out["variants"][variant] = {"hypervolume": bootstrap_ci(hvs), "best_val_auc": bootstrap_ci(bests), "n_runs": len(hvs)}
        if variant == "full" and fronts:
            out["enrichment"]["pareto"] = flag_enrichment(fronts, prior)
            fin = []
            for p in glob.glob(os.path.join(variant_dir, "seed*", "fold*", "evaluations.jsonl")):
                fin += final_generation(load_evaluations(p))
            out["enrichment"]["final_generation"] = flag_enrichment(fin, prior)
            out["productions"] = production_frequencies(fronts, g)
            out["motifs"] = motifs(fronts)
    out["prior"] = prior
    return out


def table_e5(cfg: dict) -> Dict:
    """Model-free shared-information estimates vs evolved shared dimensions, plus hallmark probes."""
    out = {"folds": {}}
    dims, ranks = [], []
    for fold in cfg["folds"]:
        split = get_split(cfg, fold)
        X, Y = split.train.img, split.train.rna
        cr = cca_rank(X, Y, n_perm=cfg.get("analysis", {}).get("cca_perms", 50))
        mi = mi_shared_estimate(X, Y)
        winners = []
        for p in glob.glob(os.path.join(cfg["out"], "evolution", "full", "seed*", f"fold{fold}", "winner.json")):
            w = json.load(open(p))
            winners.append(w["spec"]["latent"])
            dims.append(w["spec"]["latent"]["shared"]); ranks.append(cr["rank"])
        out["folds"][fold] = {"cca_rank": cr["rank"], "cca_top_corrs": cr["canonical_corrs"][:8], "mi_nats": mi,
                              "evolved_latents": winners}
    if len(set(ranks)) > 1:
        out["spearman_shared_dim_vs_cca_rank"] = spearman(dims, ranks)
    # hallmark probes from final evaluations of the full-grammar winners
    probes = defaultdict(lambda: defaultdict(list))
    for r in _load_dir(os.path.join(cfg["out"], "final", "fold*", "evolved_full_*.json")):
        hp = r["metrics"].get("test", {}).get("hallmark_probes")
        if hp:
            for h, blocks in hp.items():
                for b, v in blocks.items():
                    if not np.isnan(v):
                        probes[h][b].append(v)
    out["hallmark_probes_r2"] = {h: {b: float(np.mean(v)) for b, v in blocks.items()} for h, blocks in probes.items()}
    return out


# ------------------------------------------------------------------ report
def write_report(cfg: dict) -> str:
    outdir = os.path.join(cfg["out"], "analysis")
    os.makedirs(outdir, exist_ok=True)
    e1 = table_e1_e3(cfg)
    e2 = table_e2_h2(cfg)
    e4 = table_e4(cfg)
    e5 = table_e5(cfg)
    for name, obj in [("e1_e3", e1), ("e2_h2", e2), ("e4", e4), ("e5", e5)]:
        with open(os.path.join(outdir, f"{name}.json"), "w") as f:
            json.dump(obj, f, indent=1, default=str)
    md = ["# Results report", f"Run: `{cfg['out']}`", ""]
    md += ["## E1-E3: detection performance (AUROC, mean ± sd over folds × seeds)", "",
           "| model | params | test | held-out site | external | test, RNA absent | external, RNA absent | ECE | site probe | DeLong vs best baseline (Holm p) |",
           "|---|---|---|---|---|---|---|---|---|---|"]
    for name, r in sorted(e1.items(), key=lambda kv: -kv[1].get("test", {"mean": 0})["mean"]):
        cell = lambda t: _fmt(r[t]["mean"], r[t]["sd"]) if t in r else "–"
        dl = [v for k, v in r.items() if k.startswith("delong_vs_")]
        dls = f"p={dl[0].get('p_holm', dl[0]['p']):.3g}" if dl else "–"
        md.append(f"| {name} | {r['n_params']:,} | {cell('test')} | {cell('heldout_site')} | {cell('external')} | "
                  f"{cell('test_noRNA')} | {cell('external_noRNA')} | {r['ece_test']:.3f} | {r['site_probe_test']:.3f} | {dls} |")
    md += ["", "## H2/H4: effect of each principle across all evaluated individuals (population level)", ""]
    for variant, v in e2.items():
        md += [f"### grammar variant `{variant}` (n = {v['n_individuals']} individuals)", "",
               "| principle | shift drop with | without | MWU p | Cliff's δ | missing-RNA AUROC with | without | MWU p | invariance with | without |",
               "|---|---|---|---|---|---|---|---|---|---|"]
        for flag, r in v["by_flag"].items():
            f = lambda x: "–" if x is None else f"{x:.3f}"
            md.append(f"| {flag} | {f(r['shift_drop_with'])} | {f(r['shift_drop_without'])} | {r['shift_drop_test']['p']:.3g} | "
                      f"{r['shift_drop_test']['cliffs_delta']:.2f} | {f(r['missing_auc_with'])} | {f(r['missing_auc_without'])} | "
                      f"{r['missing_auc_test']['p']:.3g} | {f(r['invariance_with'])} | {f(r['invariance_without'])} |")
        md.append("")
    md += ["## E4: grammar ablations", "", "| variant | runs | Pareto hypervolume (95% CI) | best val AUROC (95% CI) |", "|---|---|---|---|"]
    for variant, r in e4["variants"].items():
        hv, bv = r["hypervolume"], r["best_val_auc"]
        md.append(f"| {variant} | {r['n_runs']} | {hv[0]:.4f} [{hv[1]:.4f}, {hv[2]:.4f}] | {bv[0]:.3f} [{bv[1]:.3f}, {bv[2]:.3f}] |")
    if e4["enrichment"]:
        md += ["", "### H5: principle enrichment among Pareto-optimal individuals (full grammar) vs uniform-derivation prior", "",
               "| principle | frequency | prior | fold | one-sided p |", "|---|---|---|---|---|"]
        for flag, r in e4["enrichment"]["pareto"].items():
            md.append(f"| {flag} | {r['frequency']:.3f} | {r['prior']:.3f} | {r['fold']:.2f} | {r['p_one_sided']:.3g} |")
        md += ["", "### E7: recurrent motifs among Pareto-optimal individuals", ""]
        for motif, c in e4.get("motifs", []):
            md.append(f"- ({c}×) {motif}")
    md += ["", "## E5: partial sharing", ""]
    for fold, r in e5["folds"].items():
        md.append(f"- fold {fold}: CCA rank (permutation, α=0.05) = {r['cca_rank']}, MI over top canonical pairs = {r['mi_nats']:.2f} nats; "
                  f"evolved latents: {r['evolved_latents']}")
    if "spearman_shared_dim_vs_cca_rank" in e5:
        s = e5["spearman_shared_dim_vs_cca_rank"]
        md.append(f"- Spearman(evolved shared dim, CCA rank) = {s['rho']:.2f} (p = {s['p']:.3g}, n = {s['n']})")
    if e5["hallmark_probes_r2"]:
        md += ["", "| hallmark | shared (img) | shared (rna) | img-specific | rna-specific |", "|---|---|---|---|---|"]
        for h, b in e5["hallmark_probes_r2"].items():
            g = lambda k: f"{b[k]:.2f}" if k in b else "–"
            md.append(f"| {h} | {g('shared_img')} | {g('shared_rna')} | {g('img_specific')} | {g('rna_specific')} |")
    text = "\n".join(md) + "\n"
    with open(os.path.join(outdir, "report.md"), "w") as f:
        f.write(text)
    return text
