"""RNA embeddings for bulk (TCGA/CPTAC) and spot-level (HEST) transcriptomics.

Bulk: log2(CPM+1) -> top-K highly variable genes (variance computed on the
INTERNAL cohort only and frozen) -> PCA to D dims fitted on the internal cohort
and applied unchanged to the external cohort. This is deliberately simple and
frozen: the paper is about fusion, not the RNA encoder. Hallmark gene-set scores
(MSigDB H) are computed here as mean z-scored expression of member genes, for
the E5 latent probes.

Spot-level (HEST): the same, or the frozen scGPT/Geneformer encoders if you want
a learned representation (see notes in docs/data_access.md).

Usage:
  python -m gemm.embeddings.rna_embed --counts tcga_brca_counts.tsv --fit --out emb/brca_rna.npz --dim 256
  python -m gemm.embeddings.rna_embed --counts cptac_brca_counts.tsv --load emb/brca_rna.npz --out emb/cptac_brca_rna.npz
Counts file: genes x samples TSV (raw counts), gene symbols in the first column.
"""
from __future__ import annotations

import argparse
import json

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

# A minimal set of MSigDB Hallmark gene sets (abbreviated; replace with full h.all.v2023 GMT)
HALLMARKS = {
    "hypoxia": ["VEGFA", "SLC2A1", "PGK1", "LDHA", "CA9", "ADM", "BNIP3", "P4HA1", "NDRG1", "ANKRD37", "EGLN3", "PDK1"],
    "proliferation": ["MKI67", "TOP2A", "CCNB1", "CDK1", "BUB1", "PCNA", "MCM2", "AURKA", "CENPF", "TYMS", "RRM2", "BIRC5"],
    "emt": ["VIM", "FN1", "SNAI2", "TWIST1", "ZEB1", "CDH2", "COL1A1", "COL3A1", "SPARC", "TGFBI", "MMP2", "POSTN"],
    "immune": ["PTPRC", "CD3E", "CD8A", "GZMB", "PRF1", "IFNG", "CXCL9", "CXCL10", "CD274", "LAG3", "IDO1", "STAT1"],
}


def logcpm(counts: pd.DataFrame) -> pd.DataFrame:
    lib = counts.sum(0)
    return np.log2(counts / lib * 1e6 + 1)


def hallmark_scores(logx: pd.DataFrame) -> dict:
    z = (logx.sub(logx.mean(1), axis=0)).div(logx.std(1) + 1e-6, axis=0)
    return {name: z.reindex([g for g in genes if g in z.index]).mean(0).values.astype(np.float32)
            for name, genes in HALLMARKS.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--counts", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--fit", action="store_true", help="fit HVG selection + PCA on this cohort (internal only)")
    ap.add_argument("--load", help="reuse the HVG list and PCA of a previously --fit cohort (external)")
    ap.add_argument("--hvg", type=int, default=5000)
    ap.add_argument("--dim", type=int, default=256)
    a = ap.parse_args()

    counts = pd.read_csv(a.counts, sep="\t", index_col=0)
    logx = logcpm(counts)
    if a.fit:
        hvg = logx.var(1).sort_values(ascending=False).index[: a.hvg].tolist()
        X = logx.loc[hvg].T.values
        mu, sd = X.mean(0), X.std(0) + 1e-6
        pca = PCA(n_components=a.dim, random_state=0).fit((X - mu) / sd)
        params = {"hvg": hvg, "mu": mu.tolist(), "sd": sd.tolist(), "components": pca.components_.tolist(),
                  "mean": pca.mean_.tolist()}
    else:
        params = json.load(open(a.load.replace(".npz", ".params.json")))
        hvg = params["hvg"]
        X = logx.reindex(hvg).fillna(0).T.values
        mu, sd = np.array(params["mu"]), np.array(params["sd"])
    Z = ((X - mu) / sd - np.array(params["mean"])) @ np.array(params["components"]).T
    hall = hallmark_scores(logx)
    np.savez_compressed(a.out, rna=Z.astype(np.float32), sample=np.array(counts.columns, dtype=str),
                        **{f"hallmark_{k}": v for k, v in hall.items()})
    if a.fit:
        json.dump(params, open(a.out.replace(".npz", ".params.json"), "w"))
    print("wrote", a.out, Z.shape)


if __name__ == "__main__":
    main()
