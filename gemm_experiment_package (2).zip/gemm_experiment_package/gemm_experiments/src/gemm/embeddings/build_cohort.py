"""Assemble a cohort .npz (the format gemm.data.Cohort expects) from slide embeddings,
RNA embeddings and a clinical/manifest table.

Manifest CSV columns (TCGA example, built from the GDC sample sheet + biospecimen):
  slide_id, sample_barcode, patient (TCGA-XX-XXXX), site (TSS code, chars 6-7 of the barcode),
  y (1 tumour / 0 normal; from sample type code 01/11), rna_sample (column name in the counts file)

Usage:
  python -m gemm.embeddings.build_cohort --manifest brca_manifest.csv --wsi emb/brca_uni \
      --rna emb/brca_rna.npz --out data/tcga_brca.npz

For HEST-1k (spot level) use build_hest.py instead.
"""
from __future__ import annotations

import argparse
import os

import numpy as np
import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--wsi", required=True, help="directory of <slide_id>.npy slide embeddings")
    ap.add_argument("--rna", required=True, help=".npz from rna_embed.py")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    man = pd.read_csv(a.manifest)
    rna = np.load(a.rna, allow_pickle=True)
    rna_idx = {s: i for i, s in enumerate(rna["sample"].astype(str))}
    img, rz, y, pat, site, hall = [], [], [], [], [], {k[len("hallmark_"):]: [] for k in rna.files if k.startswith("hallmark_")}
    missing = 0
    for _, r in man.iterrows():
        p = os.path.join(a.wsi, f"{r.slide_id}.npy")
        if not os.path.exists(p) or r.rna_sample not in rna_idx:
            missing += 1
            continue
        img.append(np.load(p))
        j = rna_idx[r.rna_sample]
        rz.append(rna["rna"][j])
        for k in hall:
            hall[k].append(rna[f"hallmark_{k}"][j])
        y.append(int(r.y)); pat.append(str(r.patient)); site.append(str(r.site))
    np.savez_compressed(a.out, img=np.stack(img).astype(np.float32), rna=np.stack(rz).astype(np.float32),
                        y=np.array(y), patient=np.array(pat), site=np.array(site),
                        **{f"hallmark_{k}": np.array(v, dtype=np.float32) for k, v in hall.items()})
    print(f"wrote {a.out}: n={len(y)} pos={np.mean(y):.2f} patients={len(set(pat))} sites={len(set(site))} skipped={missing}")


if __name__ == "__main__":
    main()
