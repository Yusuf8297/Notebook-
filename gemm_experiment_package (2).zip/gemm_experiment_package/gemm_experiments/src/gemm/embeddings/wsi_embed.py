"""Slide-level image embeddings from a frozen pathology foundation model.

NOT RUN in the development sandbox (needs slides + GPU + Hugging Face access).
Pipeline per slide:
  1. tissue mask (Otsu on a low-res thumbnail)  -> tile grid at 20x, 256 px
  2. frozen encoder (UNI or CONCH via timm / HF hub) -> tile embeddings (T, D)
  3. slide embedding = attention-free mean + max pooling (2D)  [default]
     or an attention-MIL pooler trained once on the tumour/normal task (see mil_pool.py)
Writes one .npy per slide under --out; build_tcga_cohort.py assembles the cohort .npz.

Usage:
  python -m gemm.embeddings.wsi_embed --slides /data/tcga/brca/*.svs --out emb/brca_uni \
      --model uni --hf_token $HF_TOKEN --batch 256
"""
from __future__ import annotations

import argparse
import glob
import os

import numpy as np


def load_encoder(name: str, hf_token: str | None):
    import timm
    import torch

    if name == "uni":
        # MahmoodLab/UNI (ViT-L/16, DINOv2), 1024-d. Requires accepting the licence on HF.
        model = timm.create_model("hf-hub:MahmoodLab/uni", pretrained=True, init_values=1e-5,
                                 dynamic_img_size=True)
        dim = 1024
    elif name == "conch":
        from conch.open_clip_custom import create_model_from_pretrained  # pip install git+https://github.com/mahmoodlab/CONCH
        model, _ = create_model_from_pretrained("conch_ViT-B-16", "hf_hub:MahmoodLab/conch", hf_auth_token=hf_token)
        model = model.visual
        dim = 512
    else:
        raise ValueError(name)
    return model.eval(), dim


def tile_iter(slide_path: str, tile: int = 256, level_mpp: float = 0.5):
    """Yield RGB tiles covering tissue at ~0.5 mpp (20x)."""
    import openslide
    from PIL import Image
    from skimage.filters import threshold_otsu

    s = openslide.OpenSlide(slide_path)
    mpp = float(s.properties.get(openslide.PROPERTY_NAME_MPP_X, 0.25))
    ds = level_mpp / mpp
    W, H = s.dimensions
    thumb = np.asarray(s.get_thumbnail((W // 64, H // 64)).convert("L"))
    thr = threshold_otsu(thumb)
    mask = thumb < thr
    step = int(tile * ds)
    for y in range(0, H - step, step):
        for x in range(0, W - step, step):
            my, mx = y // 64, x // 64
            if mask[my : my + max(1, step // 64), mx : mx + max(1, step // 64)].mean() < 0.5:
                continue
            reg = s.read_region((x, y), 0, (step, step)).convert("RGB").resize((tile, tile), Image.BILINEAR)
            yield np.asarray(reg)


def embed_slide(model, slide_path: str, batch: int, device: str) -> np.ndarray:
    import torch

    mean = torch.tensor([0.485, 0.456, 0.406], device=device).view(1, 3, 1, 1)
    std = torch.tensor([0.229, 0.224, 0.225], device=device).view(1, 3, 1, 1)
    feats, buf = [], []

    def flush():
        if not buf:
            return
        x = torch.from_numpy(np.stack(buf)).permute(0, 3, 1, 2).float().div(255).to(device)
        with torch.no_grad():
            feats.append(model((x - mean) / std).cpu().numpy())
        buf.clear()

    for t in tile_iter(slide_path):
        buf.append(t)
        if len(buf) == batch:
            flush()
    flush()
    return np.concatenate(feats) if feats else np.zeros((0, 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--slides", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--model", default="uni", choices=["uni", "conch"])
    ap.add_argument("--hf_token", default=os.environ.get("HF_TOKEN"))
    ap.add_argument("--batch", type=int, default=256)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--keep_tiles", action="store_true", help="also save tile-level embeddings for MIL pooling")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    model, _ = load_encoder(a.model, a.hf_token)
    model = model.to(a.device)
    paths = [p for pat in a.slides for p in glob.glob(pat)]
    for p in paths:
        sid = os.path.splitext(os.path.basename(p))[0]
        dst = os.path.join(a.out, sid + ".npy")
        if os.path.exists(dst):
            continue
        tiles = embed_slide(model, p, a.batch, a.device)
        if a.keep_tiles:
            np.save(os.path.join(a.out, sid + ".tiles.npy"), tiles.astype(np.float16))
        slide_vec = np.concatenate([tiles.mean(0), tiles.max(0)])  # (2D,)
        np.save(dst, slide_vec.astype(np.float32))
        print(sid, tiles.shape)


if __name__ == "__main__":
    main()
