"""Spot-level cohort from HEST-1k (Jaume et al., 2024): paired, registered H&E + spatial transcriptomics.

NOT RUN in the development sandbox. Requires: pip install hest ; HF access to MahmoodLab/hest.
For each selected sample:
  - spot patches (224 px around each Visium spot) -> frozen UNI/CONCH -> img (N_spots, D)
  - spot counts -> log1p-CPM -> HVG (fitted on the training samples) -> PCA -> rna (N_spots, D_rna)
  - y: tumour spot label. HEST ships pathologist annotations for a subset; otherwise derive from
    a tumour-marker score (e.g. EPCAM/KRT8/KRT18 for carcinoma) thresholded per sample and
    report which was used.
  - patient = HEST sample id (grouping unit), site = the originating study/dataset id (batch).
Usage:
  python -m gemm.embeddings.build_hest --organs Ovary Breast Colon --out data/hest_ov_br_co.npz
"""
from __future__ import annotations

import argparse

import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--organs", nargs="+", default=["Ovary"])
    ap.add_argument("--out", required=True)
    ap.add_argument("--model", default="uni")
    ap.add_argument("--hvg", type=int, default=2000)
    ap.add_argument("--dim", type=int, default=128)
    ap.add_argument("--device", default="cuda")
    a = ap.parse_args()

    import pandas as pd
    import torch
    from hest import iter_hest  # type: ignore
    from sklearn.decomposition import PCA

    from .rna_embed import HALLMARKS
    from .wsi_embed import load_encoder

    enc, _ = load_encoder(a.model, None)
    enc = enc.to(a.device)
    mean = torch.tensor([0.485, 0.456, 0.406], device=a.device).view(1, 3, 1, 1)
    std = torch.tensor([0.229, 0.224, 0.225], device=a.device).view(1, 3, 1, 1)

    imgs, counts_list, meta = [], [], []
    for st in iter_hest("hest_data", id_list=None):  # filter by organ via st.meta
        if st.meta.get("organ") not in a.organs:
            continue
        patches = st.get_patches(patch_size=224)  # (N, 224, 224, 3) around spots
        with torch.no_grad():
            feats = []
            for s in range(0, len(patches), 256):
                x = torch.from_numpy(patches[s : s + 256]).permute(0, 3, 1, 2).float().div(255).to(a.device)
                feats.append(enc((x - mean) / std).cpu().numpy())
        imgs.append(np.concatenate(feats))
        adata = st.adata
        counts_list.append(pd.DataFrame(adata.X.toarray().T, index=adata.var_names, columns=adata.obs_names))
        tumour = adata.obs["tumor"].values.astype(int) if "tumor" in adata.obs else _marker_label(adata)
        meta.append(pd.DataFrame({"y": tumour, "patient": st.meta["id"], "site": st.meta.get("dataset_title", "na")}))
    counts = pd.concat(counts_list, axis=1).fillna(0)
    logx = np.log1p(counts / counts.sum(0) * 1e4)
    hvg = logx.var(1).sort_values(ascending=False).index[: a.hvg]
    X = logx.loc[hvg].T.values
    X = (X - X.mean(0)) / (X.std(0) + 1e-6)
    Z = PCA(n_components=a.dim, random_state=0).fit_transform(X)
    z = logx.sub(logx.mean(1), axis=0).div(logx.std(1) + 1e-6, axis=0)
    hall = {k: z.reindex([g for g in v if g in z.index]).mean(0).values for k, v in HALLMARKS.items()}
    m = pd.concat(meta, ignore_index=True)
    np.savez_compressed(a.out, img=np.concatenate(imgs).astype(np.float32), rna=Z.astype(np.float32),
                        y=m.y.values, patient=m.patient.values.astype(str), site=m.site.values.astype(str),
                        **{f"hallmark_{k}": v.astype(np.float32) for k, v in hall.items()})
    print("wrote", a.out, len(m))


def _marker_label(adata, genes=("EPCAM", "KRT8", "KRT18")):
    import numpy as np
    g = [x for x in genes if x in adata.var_names]
    s = np.asarray(adata[:, g].X.sum(1)).ravel()
    return (s > np.percentile(s, 60)).astype(int)


if __name__ == "__main__":
    main()
