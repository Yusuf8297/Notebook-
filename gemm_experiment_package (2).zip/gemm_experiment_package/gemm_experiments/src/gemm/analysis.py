"""Analyses for E4 (grammar ablation / production enrichment), E5 (partial-sharing
and latent probes), E7 (motifs), plus Pareto hypervolume."""
from __future__ import annotations

import json
from collections import Counter
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from scipy import stats
from sklearn.cross_decomposition import CCA
from sklearn.feature_selection import mutual_info_regression
from sklearn.linear_model import Ridge
from sklearn.model_selection import cross_val_score

from .grammar import Grammar, production_labels
from .stats import enrichment_permutation

FLAG_NAMES = ["P1_align", "P2_partial", "P2_disentangle", "P3_moddrop", "P3_cond", "P4_directed"]


# ------------------------------------------------------------------ logs
def load_evaluations(path: str) -> List[dict]:
    with open(path) as f:
        return [json.loads(ln) for ln in f if ln.strip()]


def final_generation(records: List[dict]) -> List[dict]:
    g = max(r["gen"] for r in records)
    return [r for r in records if r["gen"] == g and r["valid"]]


def pareto_records(records: List[dict], objectives: Sequence[str]) -> List[dict]:
    """Pareto-optimal records among ALL valid evaluations (population-level analysis)."""
    valid = [r for r in records if r["valid"]]
    F = np.array([[r["fitness"][k] for k in objectives] for r in valid])
    keep = []
    for i in range(len(F)):
        dominated = np.any(np.all(F >= F[i], axis=1) & np.any(F > F[i], axis=1))
        if not dominated:
            keep.append(valid[i])
    return keep


# ------------------------------------------------------------------ E4/E7: rediscovery
def uniform_prior_flags(grammar: Grammar, n: int = 20000, seed: int = 0, genome_len: int = 200) -> Dict[str, float]:
    """Probability of each principle flag under uniform random codons (the null)."""
    from .spec import principle_flags
    rng = np.random.RandomState(seed)
    cnt, tot = Counter(), 0
    for _ in range(n):
        d = grammar.map(rng.randint(0, 256, genome_len).tolist())
        if not d.valid:
            continue
        tot += 1
        for k, v in principle_flags(d.spec()).items():
            cnt[k] += int(v)
    return {k: cnt[k] / max(tot, 1) for k in FLAG_NAMES}


def flag_enrichment(records: List[dict], prior: Dict[str, float]) -> Dict[str, Dict[str, float]]:
    """Enrichment of each principle among (e.g.) final-generation or Pareto individuals vs the null."""
    out = {}
    n = len(records)
    for k in FLAG_NAMES:
        obs = sum(int(r["flags"][k]) for r in records if r.get("flags"))
        out[k] = {"frequency": obs / max(n, 1), "prior": prior[k], **enrichment_permutation(obs, n, prior[k])}
    return out


def production_frequencies(records: List[dict], grammar: Grammar) -> Dict[str, Dict[str, float]]:
    labels = production_labels(grammar)
    cnt, nt_tot = Counter(), Counter()
    for r in records:
        for nt, k in r["choices"]:
            cnt[f"{nt}#{k}"] += 1
            nt_tot[nt] += 1
    out = {}
    for key, c in cnt.items():
        nt = key.split("#")[0]
        out[key] = {"label": labels[key], "count": c, "share": c / nt_tot[nt],
                    "uniform_share": 1.0 / grammar.n_choices(nt)}
    return dict(sorted(out.items()))


def motifs(records: List[dict], top: int = 10) -> List[Tuple[str, int]]:
    """Most frequent (latent-split, fusion-type, alignment, moddrop) motifs across records."""
    c = Counter()
    for r in records:
        s = r["spec"]
        if not s:
            continue
        fus = s["fusion"]
        ops = fus["ops"] if fus["type"] == "stack" else ([] if fus["type"] == "late" else [fus])
        ftype = "late" if fus["type"] == "late" else "+".join(o["type"] + (f"({o['dir']})" if o["type"] == "xattn" else f"({o.get('backbone', o.get('mod'))})" if o["type"] in ("cond", "single") else "") for o in ops)
        al = s["loss"]["align"]
        key = (f"latent {s['latent']['shared']}s/{s['latent']['img_spec']}i/{s['latent']['rna_spec']}r | "
               f"{ftype} | align={al['type'] if al else 'none'} | moddrop={'yes' if s['loss']['moddrop'] else 'no'}")
        c[key] += 1
    return c.most_common(top)


# ------------------------------------------------------------------ E5: shared information
def cca_rank(X: np.ndarray, Y: np.ndarray, max_k: int = 32, n_perm: int = 100, alpha: float = 0.05,
             seed: int = 0) -> Dict[str, object]:
    """Number of significantly correlated canonical pairs (model-free estimate of shared dimension)."""
    rng = np.random.RandomState(seed)
    (Xa, Ya), (Xb, Yb) = _halves(X, Y, rng)  # fit on one half, score on the other (out-of-sample)
    k = min(max_k, X.shape[1], Y.shape[1], len(Xa) // 4)
    cca = CCA(n_components=k, max_iter=500).fit(Xa, Ya)
    U, V = cca.transform(Xb, Yb)
    obs = np.array([abs(np.corrcoef(U[:, i], V[:, i])[0, 1]) for i in range(k)])
    # permutation null: out-of-sample correlation of the first pair under shuffled pairing
    null = []
    for _ in range(n_perm):
        perm = rng.permutation(len(Xa))
        c2 = CCA(n_components=1, max_iter=200).fit(Xa, Ya[perm])
        u, v = c2.transform(Xb, Yb[rng.permutation(len(Xb))])
        null.append(abs(np.corrcoef(u[:, 0], v[:, 0])[0, 1]))
    thr = float(np.percentile(null, 100 * (1 - alpha)))
    rank = int((obs > thr).sum())
    return {"rank": rank, "canonical_corrs": obs.tolist(), "null_threshold": thr}


def mi_shared_estimate(X: np.ndarray, Y: np.ndarray, k: int = 16, seed: int = 0) -> float:
    """kNN mutual information summed over the top-k canonical pairs (nats)."""
    rng = np.random.RandomState(seed)
    (Xa, Ya), (Xb, Yb) = _halves(X, Y, rng)
    k = min(k, X.shape[1], Y.shape[1], len(Xa) // 4)
    cca = CCA(n_components=k, max_iter=500).fit(Xa, Ya)
    U, V = cca.transform(Xb, Yb)
    return float(sum(mutual_info_regression(U[:, [i]], V[:, i], random_state=seed)[0] for i in range(k)))


def _halves(X, Y, rng):
    idx = rng.permutation(len(X))
    a, b = idx[: len(X) // 2], idx[len(X) // 2 :]
    return (X[a], Y[a]), (X[b], Y[b])


def hallmark_probes(z: Dict[str, np.ndarray], hallmarks: Dict[str, np.ndarray], seed: int = 0) -> Dict[str, Dict[str, float]]:
    """Cross-validated R^2 of a ridge probe predicting each hallmark score from each latent block.
    Prediction: shared programmes (e.g. hypoxia) are readable from the shared block;
    RNA-specific programmes (e.g. proliferation in the synthetic world) only from the RNA-specific block."""
    blocks = {"shared_img": z["zs_i"], "shared_rna": z["zs_r"], "img_specific": z["zp_i"], "rna_specific": z["zp_r"]}
    out = {}
    for h, target in hallmarks.items():
        out[h] = {}
        for b, Z in blocks.items():
            if Z.shape[1] == 0:
                out[h][b] = float("nan")
                continue
            r2 = cross_val_score(Ridge(alpha=1.0), Z, target, cv=5, scoring="r2").mean()
            out[h][b] = float(max(r2, -1.0))
    return out


# ------------------------------------------------------------------ hypervolume
def hypervolume(F: np.ndarray, ref: np.ndarray, n_samples: int = 200000, seed: int = 0) -> float:
    """Monte-Carlo hypervolume of a maximisation front F (n, m) w.r.t. reference point ref."""
    if len(F) == 0:
        return 0.0
    rng = np.random.RandomState(seed)
    hi = F.max(0)
    box = np.prod(hi - ref)
    if box <= 0:
        return 0.0
    pts = ref + rng.rand(n_samples, F.shape[1]) * (hi - ref)
    dominated = np.zeros(n_samples, bool)
    for f in F:
        dominated |= np.all(pts <= f, axis=1)
    return float(box * dominated.mean())


def spearman(x: Sequence[float], y: Sequence[float]) -> Dict[str, float]:
    r, p = stats.spearmanr(x, y)
    return {"rho": float(r), "p": float(p), "n": len(x)}
