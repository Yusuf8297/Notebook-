"""Multi-objective fitness of a candidate spec on one Split.

Objectives (all maximised):
  f1  val_auc        detection AUROC on the inner validation fold
  f2  shift_auc      AUROC on the held-out tissue-source site(s)   (proxy for cohort shift)
  f3  invariance     -(site-probe accuracy above chance) on the shared latent  (P1 operationalised)
  f4  missing_auc    AUROC on validation with RNA absent at test time             (P3 operationalised)
  f5  parsimony      -log10(n_params)  (weak; used as a lexicographic tie-break, not in NSGA-II)
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np

from .data import Split
from .spec import Spec
from .train import auroc, batch_probe_accuracy, latents, train_candidate

OBJECTIVES = ["val_auc", "shift_auc", "invariance", "missing_auc"]
PENALTY = {"val_auc": 0.0, "shift_auc": 0.0, "invariance": -1.0, "missing_auc": 0.0, "parsimony": -9.0}


@dataclass
class Fitness:
    values: Dict[str, float]
    valid: bool = True
    wall_s: float = 0.0
    extra: Dict[str, float] = field(default_factory=dict)

    def vector(self, objectives: Optional[List[str]] = None) -> np.ndarray:
        return np.array([self.values[k] for k in (objectives or OBJECTIVES)], dtype=float)


def penalty_fitness() -> Fitness:
    return Fitness(dict(PENALTY), valid=False)


def evaluate(spec: Optional[Spec], split: Split, seed: int = 0, device: str = "cpu",
             time_budget_s: float = 120.0, return_model: bool = False) -> Fitness:
    if spec is None:
        return penalty_fitness()
    try:
        res = train_candidate(spec, split.train, split.val, seed=seed, device=device, time_budget_s=time_budget_s)
    except (RuntimeError, ValueError, AssertionError) as e:  # unbuildable/untrainable candidates
        f = penalty_fitness()
        f.extra["error"] = str(e)[:200]
        return f
    if res["diverged"] or res["best_val_auc"] < 0:
        return penalty_fitness()
    m = res["model"]
    v = {}
    v["val_auc"] = res["best_val_auc"]
    sa = auroc(m, split.heldout_site, device)
    v["shift_auc"] = v["val_auc"] if math.isnan(sa) else sa  # no held-out site available -> neutral
    z = latents(m, split.val, device)
    v["invariance"] = -batch_probe_accuracy(z["zs_i"], split.val.site, seed)
    v["missing_auc"] = auroc(m, split.val, device, rna_missing=True)
    v["parsimony"] = -math.log10(max(m.n_params(), 1))
    f = Fitness(v, True, res["wall_s"], {"epochs": res["epochs_run"], "n_params": m.n_params()})
    if return_model:
        f.extra["model"] = m
    return f
