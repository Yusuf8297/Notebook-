"""Model specification schema (the phenotype produced by the grammar) plus
hand-written specs for the baselines, expressed in the same language so that
baselines and evolved models are built, trained and evaluated identically."""
from __future__ import annotations

import copy
import json
from typing import Any, Dict

Spec = Dict[str, Any]

_DEFAULT_TRAIN = {"lr": 0.001, "wd": 0.0001, "epochs": 20, "batch": 128}
_DEFAULT_HEAD = {"layers": 2, "width": 128, "act": "gelu", "dropout": 0.2}


def validate(spec: Spec) -> None:
    lat = spec["latent"]
    assert lat["shared"] > 0, "shared latent must be > 0"
    fus = spec["fusion"]
    if fus["type"] == "late":
        return
    ops = fus["ops"] if fus["type"] == "stack" else [fus]
    for op in ops:
        assert op["type"] in {"concat", "gated", "xattn", "cond", "single"}, op
    rec = spec["loss"].get("recon")
    if rec is not None:
        # reconstruction of a modality with zero specific latent is allowed (decodes from shared only)
        assert rec["target"] in {"img", "rna", "both"}


def uses_rna(spec: Spec) -> bool:
    """Does any fusion op read the RNA pathway?"""
    return any(not (op["type"] == "single" and op["mod"] == "img") for op in _ops(spec))


def uses_img(spec: Spec) -> bool:
    return any(not (op["type"] == "single" and op["mod"] == "rna") for op in _ops(spec))


def has_alignment(spec: Spec) -> bool:
    return spec["loss"].get("align") is not None


def has_partial_sharing(spec: Spec) -> bool:
    lat = spec["latent"]
    return lat["img_spec"] > 0 or lat["rna_spec"] > 0


def has_moddrop(spec: Spec) -> bool:
    return spec["loss"].get("moddrop") is not None


def has_directed_attention(spec: Spec) -> bool:
    return any(op["type"] == "xattn" and op["dir"] != "bi" for op in _ops(spec))


def principle_flags(spec: Spec) -> Dict[str, bool]:
    return {
        "P1_align": has_alignment(spec),
        "P2_partial": has_partial_sharing(spec),
        "P2_disentangle": spec["latent"].get("disentangle") is not None,
        "P3_moddrop": has_moddrop(spec),
        "P3_cond": any(op["type"] == "cond" for op in _ops(spec)),
        "P4_directed": has_directed_attention(spec),
    }


def _ops(spec: Spec):
    fus = spec["fusion"]
    if fus["type"] == "late":
        return [{"type": "single", "mod": "img"}, {"type": "single", "mod": "rna"}]
    return fus["ops"] if fus["type"] == "stack" else [fus]


def to_json(spec: Spec) -> str:
    return json.dumps(spec, sort_keys=True)


# ------------------------------------------------------------------- baselines
def _base(latent, fusion, loss=None, head=None, train=None) -> Spec:
    return {
        "latent": latent,
        "fusion": fusion,
        "head": copy.deepcopy(head or _DEFAULT_HEAD),
        "loss": loss or {"align": None, "recon": None, "moddrop": None},
        "train": copy.deepcopy(train or _DEFAULT_TRAIN),
    }


BASELINES: Dict[str, Spec] = {
    # Unimodal
    "img_only": _base({"shared": 128, "img_spec": 0, "rna_spec": 0, "disentangle": None},
                      {"type": "single", "mod": "img"}),
    "rna_only": _base({"shared": 128, "img_spec": 0, "rna_spec": 0, "disentangle": None},
                      {"type": "single", "mod": "rna"}),
    # Early fusion (concatenate projected embeddings)
    "early_concat": _base({"shared": 128, "img_spec": 0, "rna_spec": 0, "disentangle": None},
                          {"type": "concat"}),
    # Late fusion: two unimodal heads, logits averaged ("late" is baseline-only, not in the grammar)
    "late_fusion": _base({"shared": 128, "img_spec": 0, "rna_spec": 0, "disentangle": None},
                         {"type": "late"}),
    # MCAT-style bidirectional co-attention, no alignment, fully shared latent
    "xattn_bi": _base({"shared": 128, "img_spec": 0, "rna_spec": 0, "disentangle": None},
                      {"type": "xattn", "dir": "bi", "heads": 4, "layers": 2}),
    # Hand-built "Uhler model": P1 InfoNCE + P2 partial sharing with HSIC + P3 image-conditioned FiLM + moddrop
    "uhler_hand": _base({"shared": 64, "img_spec": 64, "rna_spec": 32, "disentangle": {"type": "hsic", "w": 0.3}},
                        {"type": "cond", "backbone": "img"},
                        loss={"align": {"type": "infonce", "temp": 0.1, "w": 1.0},
                              "recon": None,
                              "moddrop": {"p": 0.3, "w": 1.0}}),
}
