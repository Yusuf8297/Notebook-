"""Cached-embedding datasets, patient/site-aware splits, and a synthetic
generator with a known causal latent structure for testing hypotheses H3/H5.

On-disk format (one .npz per cohort):
    img      float32 (N, D_img)   frozen image-encoder embedding (slide- or spot-level)
    rna      float32 (N, D_rna)   frozen RNA embedding
    y        int     (N,)         1 = tumour, 0 = normal (or subtype label)
    patient  str     (N,)         patient id  (grouping for CV)
    site     str     (N,)         tissue-source site / institution (batch variable)
    hallmark_<name> float32 (N,)  optional: gene-set scores used by the latent probes (E5)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterator, List, Optional, Tuple

import numpy as np
import torch
from sklearn.model_selection import GroupKFold


@dataclass
class Cohort:
    img: np.ndarray
    rna: np.ndarray
    y: np.ndarray
    patient: np.ndarray
    site: np.ndarray
    hallmarks: Dict[str, np.ndarray]
    name: str = "cohort"

    @classmethod
    def load(cls, path: str, name: Optional[str] = None) -> "Cohort":
        z = np.load(path, allow_pickle=True)
        hall = {k[len("hallmark_"):]: z[k] for k in z.files if k.startswith("hallmark_")}
        return cls(z["img"].astype(np.float32), z["rna"].astype(np.float32), z["y"].astype(int),
                   z["patient"].astype(str), z["site"].astype(str), hall, name or path)

    def save(self, path: str) -> None:
        np.savez_compressed(path, img=self.img, rna=self.rna, y=self.y, patient=self.patient, site=self.site,
                            **{f"hallmark_{k}": v for k, v in self.hallmarks.items()})

    def __len__(self) -> int:
        return len(self.y)

    def subset(self, idx: np.ndarray, name: Optional[str] = None) -> "Cohort":
        return Cohort(self.img[idx], self.rna[idx], self.y[idx], self.patient[idx], self.site[idx],
                      {k: v[idx] for k, v in self.hallmarks.items()}, name or self.name)

    def tensors(self, device="cpu") -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        return (torch.from_numpy(self.img).to(device), torch.from_numpy(self.rna).to(device),
                torch.from_numpy(self.y).to(device))


@dataclass
class Split:
    train: Cohort
    val: Cohort        # inner validation (objective 1)
    heldout_site: Cohort  # held-out institution(s) (objective 2)
    test: Cohort       # outer test fold


def standardize(train: Cohort, *others: Cohort) -> List[Cohort]:
    """Z-score using training statistics only."""
    mi, si = train.img.mean(0), train.img.std(0) + 1e-6
    mr, sr = train.rna.mean(0), train.rna.std(0) + 1e-6
    out = []
    for c in (train,) + others:
        out.append(Cohort((c.img - mi) / si, (c.rna - mr) / sr, c.y, c.patient, c.site, c.hallmarks, c.name))
    return out


def make_splits(c: Cohort, n_outer: int = 5, val_frac: float = 0.2, seed: int = 0,
                n_heldout_sites: int = 1) -> Iterator[Split]:
    """Patient-grouped outer K-fold. Inside each training fold: one or more
    sites are held out entirely (shift objective) and a patient-grouped
    validation subset is carved from the remaining sites."""
    rng = np.random.RandomState(seed)
    gkf = GroupKFold(n_splits=n_outer)
    for tr_idx, te_idx in gkf.split(c.img, c.y, groups=c.patient):
        trainpool = c.subset(tr_idx)
        sites, counts = np.unique(trainpool.site, return_counts=True)
        order = np.argsort(counts)  # hold out the smallest sites so most data stays for training
        held = set(sites[order[:n_heldout_sites]]) if len(sites) > 1 else set()
        held_mask = np.isin(trainpool.site, list(held))
        rest = trainpool.subset(np.where(~held_mask)[0])
        heldout = trainpool.subset(np.where(held_mask)[0], "heldout_site") if held else rest.subset(np.arange(0), "heldout_site")
        pats = np.unique(rest.patient)
        rng.shuffle(pats)
        val_p = set(pats[: max(1, int(len(pats) * val_frac))])
        vmask = np.isin(rest.patient, list(val_p))
        tr, va = rest.subset(np.where(~vmask)[0], "train"), rest.subset(np.where(vmask)[0], "val")
        tr, va, ho, te = standardize(tr, va, heldout, c.subset(te_idx, "test"))
        yield Split(tr, va, ho, te)


# ------------------------------------------------------------------- synthetic
class SyntheticWorld:
    """Fixed causal structure and mixing functions; cohorts are samples from it.

    z_s (shared) -> both modalities; z_i -> image only; z_r -> RNA only.
    Tumour label depends on z_s and on z_r, so part of the signal is RNA-specific
    and invisible to the image (cf. the gH2AX/DAPI example in the Uhler deck).
    Sites add an additive batch effect to the image embedding only.
    Hallmark scores: 'hypoxia' is a function of z_s (shared), 'proliferation' of
    z_r (RNA-specific), 'stroma' of z_i (image-specific)."""

    def __init__(self, d_img: int = 256, d_rna: int = 128, k_shared: int = 6, k_img: int = 6,
                 k_rna: int = 4, seed: int = 0):
        rng = np.random.RandomState(seed)
        self.k = (k_shared, k_img, k_rna)
        self.d_img, self.d_rna = d_img, d_rna
        self.Wi1 = rng.randn(k_shared + k_img, 64) / np.sqrt(k_shared + k_img)
        self.Wi2 = rng.randn(64, d_img) / 8
        self.Wr1 = rng.randn(k_shared + k_rna, 64) / np.sqrt(k_shared + k_rna)
        self.Wr2 = rng.randn(64, d_rna) / 8

    def sample(self, n: int = 600, n_sites: int = 4, site_strength: float = 1.0, noise: float = 0.5,
               seed: int = 0, site_prefix: str = "S", name: str = "synthetic") -> Cohort:
        rng = np.random.RandomState(seed)
        ks, ki, kr = self.k
        zs, zi, zr = rng.randn(n, ks), rng.randn(n, ki), rng.randn(n, kr)
        site = rng.randint(0, n_sites, n)
        # label depends on shared latents and on an RNA-specific latent (indices wrap for small k_shared)
        logit = 1.5 * zs[:, 0] + 1.0 * np.tanh(zs[:, 1 % ks] * zs[:, 2 % ks]) + 1.2 * zr[:, 0] - 0.5
        y = (rng.rand(n) < 1 / (1 + np.exp(-logit))).astype(int)
        site_vec = rng.randn(n_sites, self.d_img) * site_strength
        img = np.tanh(np.concatenate([zs, zi], 1) @ self.Wi1) @ self.Wi2 + site_vec[site] + noise * rng.randn(n, self.d_img)
        rna = np.tanh(np.concatenate([zs, zr], 1) @ self.Wr1) @ self.Wr2 + noise * rng.randn(n, self.d_rna)
        hall = {
            "hypoxia": zs[:, 0] + 0.5 * zs[:, 3 % ks] + 0.1 * rng.randn(n),
            "proliferation": zr[:, 0] + 0.5 * zr[:, 1] + 0.1 * rng.randn(n),
            "stroma": zi[:, 0] + 0.1 * rng.randn(n),
        }
        return Cohort(img.astype(np.float32), rna.astype(np.float32), y,
                      np.array([f"{site_prefix}P{i:05d}" for i in range(n)]),
                      np.array([f"{site_prefix}{s}" for s in site]), hall, name)


def make_synthetic(n_patients: int = 600, n_sites: int = 4, seed: int = 0, world_seed: int = 0, **world_kw) -> Cohort:
    """Convenience: an internal ('TCGA-like') cohort from a world."""
    return SyntheticWorld(seed=world_seed, **world_kw).sample(n_patients, n_sites, seed=seed)


def make_synthetic_external(n_patients: int = 300, n_sites: int = 3, seed: int = 1, world_seed: int = 0, **world_kw) -> Cohort:
    """A 'CPTAC-like' external cohort: same causal structure and mixing functions,
    different sites with a stronger batch effect. Biology transfers; batch does not."""
    return SyntheticWorld(seed=world_seed, **world_kw).sample(n_patients, n_sites, site_strength=1.8, seed=seed,
                                                              site_prefix="X", name="external")
