"""BNF grammar parsing and grammatical-evolution genotype -> phenotype mapping.

The mapper is a standard GE mapper (codon mod #choices, left-most derivation,
wrapping) implemented here so the package has no dependency on PonyGE2/GRAPE.
Every derivation records which production was chosen for every non-terminal,
which is what the rediscovery analysis (E4/E7) consumes.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

NT_RE = re.compile(r"<[^<>\s]+>")


@dataclass
class Derivation:
    phenotype: str
    valid: bool
    used_codons: int
    wraps: int
    choices: List[Tuple[str, int]] = field(default_factory=list)  # (non-terminal, production index)
    depth: int = 0

    def spec(self) -> Optional[dict]:
        if not self.valid:
            return None
        return json.loads(self.phenotype)

    def production_counts(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for nt, idx in self.choices:
            key = f"{nt}#{idx}"
            out[key] = out.get(key, 0) + 1
        return out


class Grammar:
    def __init__(self, rules: Dict[str, List[List[str]]], start: str):
        self.rules = rules
        self.start = start
        self._validate()

    # ------------------------------------------------------------------ parsing
    @classmethod
    def from_file(cls, path: str) -> "Grammar":
        with open(path) as f:
            return cls.from_text(f.read())

    @classmethod
    def from_text(cls, text: str) -> "Grammar":
        rules: Dict[str, List[List[str]]] = {}
        start = None
        # join continuation lines, strip comments
        lines = [ln for ln in text.splitlines() if ln.strip() and not ln.strip().startswith("#")]
        for ln in lines:
            if "::=" not in ln:
                raise ValueError(f"Bad grammar line: {ln}")
            lhs, rhs = ln.split("::=", 1)
            lhs = lhs.strip()
            if start is None:
                start = lhs
            alts = [alt.strip() for alt in _split_alternatives(rhs)]
            rules[lhs] = [_tokenize(alt) for alt in alts]
        assert start is not None
        return cls(rules, start)

    def _validate(self) -> None:
        for lhs, alts in self.rules.items():
            for alt in alts:
                for tok in alt:
                    if NT_RE.fullmatch(tok) and tok not in self.rules:
                        raise ValueError(f"Undefined non-terminal {tok} in rule {lhs}")

    def override(self, overrides: Dict[str, str]) -> "Grammar":
        """Return a copy with some rules replaced, e.g. {"<align>": "null"} for an ablation."""
        rules = {k: [list(a) for a in v] for k, v in self.rules.items()}
        for lhs, rhs in overrides.items():
            if lhs not in rules:
                raise KeyError(lhs)
            rules[lhs] = [_tokenize(a.strip()) for a in _split_alternatives(rhs)]
        return Grammar(rules, self.start)

    def n_choices(self, nt: str) -> int:
        return len(self.rules[nt])

    # ------------------------------------------------------------------ mapping
    def map(self, genome: Sequence[int], max_wraps: int = 3, max_depth: int = 20) -> Derivation:
        """Left-most GE derivation. Returns an invalid Derivation on wrap/depth exhaustion."""
        n = len(genome)
        if n == 0:
            return Derivation("", False, 0, 0)
        stack: List[Tuple[str, int]] = [(self.start, 0)]  # (symbol, depth)
        out: List[str] = []
        choices: List[Tuple[str, int]] = []
        i = 0
        wraps = 0
        max_seen_depth = 0
        while stack:
            sym, depth = stack.pop()
            if not NT_RE.fullmatch(sym):
                out.append(sym)
                continue
            if depth > max_depth:
                return Derivation("", False, i, wraps, choices, depth)
            max_seen_depth = max(max_seen_depth, depth)
            if i >= n * (wraps + 1):
                wraps += 1
                if wraps > max_wraps:
                    return Derivation("", False, i, wraps, choices, max_seen_depth)
            codon = genome[i % n]
            i += 1
            alts = self.rules[sym]
            k = codon % len(alts)
            choices.append((sym, k))
            for tok in reversed(alts[k]):
                stack.append((tok, depth + 1))
        return Derivation(_join(out), True, i, wraps, choices, max_seen_depth)


# ---------------------------------------------------------------------- helpers
def _split_alternatives(rhs: str) -> List[str]:
    """Split on '|' that are not inside JSON string literals."""
    alts, buf, in_str = [], [], False
    for ch in rhs:
        if ch == '"':
            in_str = not in_str
        if ch == "|" and not in_str:
            alts.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    alts.append("".join(buf))
    return alts


def _tokenize(alt: str) -> List[str]:
    """Split an alternative into non-terminal tokens and literal chunks."""
    toks: List[str] = []
    pos = 0
    for m in NT_RE.finditer(alt):
        if m.start() > pos:
            toks.append(alt[pos:m.start()])
        toks.append(m.group(0))
        pos = m.end()
    if pos < len(alt):
        toks.append(alt[pos:])
    return [t for t in toks if t != ""]


def _join(chunks: List[str]) -> str:
    return "".join(chunks)


def production_labels(grammar: Grammar) -> Dict[str, str]:
    """Human-readable label for each '<nt>#k' key, used in analysis tables."""
    labels = {}
    for nt, alts in grammar.rules.items():
        for k, alt in enumerate(alts):
            labels[f"{nt}#{k}"] = "".join(alt).strip()
    return labels
