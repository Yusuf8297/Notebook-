"""Study runners: selection, construction, and the configuration ablation.

Every runner is resumable. Results are appended to a CSV keyed by (study, dataset,
arm, seed); a run skips any cell already present, so a long campaign can be restarted
after an interruption or executed in bounded time slices.
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

from . import config, datasets, engine, grammar, priors

CELL_KEYS = ["study", "dataset", "arm", "seed"]


# checkpointing
def _load_checkpoint(path: Path) -> pd.DataFrame:
    if path.exists():
        return pd.read_csv(path)
    return pd.DataFrame(columns=CELL_KEYS)


def _completed(done: pd.DataFrame) -> set:
    if done.empty:
        return set()
    return set(map(tuple, done[CELL_KEYS].astype(str).values))


def _append(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    frame = pd.DataFrame(rows)
    frame.to_csv(path, mode="a", header=not path.exists(), index=False)


# selection study
def run_selection_study(dataset_keys=None, seeds=None, arms=None,
                        checkpoint: Path = None, time_budget: float = None,
                        n_restarts: int = 1, verbose: bool = True) -> pd.DataFrame:
    """Selection study: vary only the source of a fixed-size feature prior.

    With n_restarts > 1 a rank-averaged ensemble over independent searches is also
    reported, matching the bagged black-box comparator. The single rule is reported
    regardless, since it carries the interpretability claim.
    """
    dataset_keys = dataset_keys or list(datasets.DATASETS)
    seeds = seeds or range(1, config.N_SEEDS + 1)
    arms = arms or config.SELECTION_ARMS
    checkpoint = Path(checkpoint or config.RESULTS_DIR / "selection.csv")

    done = _completed(_load_checkpoint(checkpoint))
    started, pending = time.time(), []

    for key in dataset_keys:
        for seed in seeds:
            split = None
            for arm in arms:
                cell = ("selection", key, arm, str(seed))
                if cell in done:
                    continue
                if time_budget and (time.time() - started) > time_budget:
                    _append(checkpoint, pending)
                    if verbose:
                        print(f"time budget reached; {len(pending)} cells written")
                    return pd.read_csv(checkpoint)

                if split is None:
                    split = datasets.prepare_split(key, seed)
                idx = priors.selection_indices(arm, split.X_train, split.y_train,
                                               split.features, split.budget, seed, key)
                bnf = grammar.build_grammar(idx, tag=f"{key}_{arm}")

                members, primary = [], None
                for restart in range(max(1, n_restarts)):
                    search_seed = config.SEARCH_SEED_OFFSET + 1_000 * restart + seed
                    result = engine.search(bnf, split, seed=search_seed)
                    members.append(result.best_phenotype)
                    if restart == 0:
                        primary = result

                rule = engine.evaluate_rule(primary, split.X_test, split.y_test)
                if n_restarts > 1:
                    ens_scores = engine.ensemble_score(members, split.X_test)
                    ens_auc = engine.fast_auc(split.y_test, ens_scores)
                else:
                    ens_auc = rule["roc_auc"]

                train = engine.evaluate_rule(primary, split.X_train, split.y_train)
                used = engine.used_feature_indices(primary.best_phenotype, split.n_features)

                pending.append(dict(
                    study="selection", dataset=key, arm=arm, seed=seed,
                    **{f"test_{k}": v for k, v in rule.items()},
                    ensemble_roc_auc=ens_auc,
                    train_roc_auc=train["roc_auc"], train_accuracy=train["accuracy"],
                    generalisation_gap=train["roc_auc"] - rule["roc_auc"],
                    effective_length=primary.effective_length, depth=primary.depth,
                    structural_diversity=primary.structural_diversity,
                    invalids=primary.invalids, threshold=primary.threshold,
                    n_candidates=primary.n_candidates,
                    phenotype_coverage=len(used) / max(1, len(idx)),
                    budget=len(idx), phenotype=primary.best_phenotype))

            if pending and len(pending) >= 10:
                _append(checkpoint, pending)
                pending = []
        if verbose:
            print(f"  selection: {key} complete ({time.time() - started:.0f}s)", flush=True)

    _append(checkpoint, pending)
    return pd.read_csv(checkpoint)


# construction study
def run_construction_study(dataset_keys=None, seeds=None, arms=None,
                           checkpoint: Path = None, time_budget: float = None,
                           verbose: bool = True) -> pd.DataFrame:
    """Construction study: augment the full feature set, then let GE run unrestricted.

    Constructions use raw-scale values and the augmented matrix is re-standardised on
    training rows only, so engineered columns cannot leak test statistics.
    """
    dataset_keys = dataset_keys or list(datasets.DATASETS)
    seeds = seeds or range(1, config.N_SEEDS + 1)
    arms = arms or config.CONSTRUCTION_ARMS
    checkpoint = Path(checkpoint or config.RESULTS_DIR / "construction.csv")

    done = _completed(_load_checkpoint(checkpoint))
    started, pending = time.time(), []

    for key in dataset_keys:
        for seed in seeds:
            split = None
            for arm in arms:
                cell = ("construction", key, arm, str(seed))
                if cell in done:
                    continue
                if time_budget and (time.time() - started) > time_budget:
                    _append(checkpoint, pending)
                    if verbose:
                        print(f"time budget reached; {len(pending)} cells written")
                    return pd.read_csv(checkpoint)

                if split is None:
                    split = datasets.prepare_split(key, seed)
                cons = priors.construction_set(arm, split.features, config.N_CONSTRUCTED,
                                               seed, key)
                Xtr_aug, names = priors.apply_constructions(split.X_train_raw,
                                                            split.features, cons)
                Xte_aug, _ = priors.apply_constructions(split.X_test_raw,
                                                        split.features, cons)
                scaler = StandardScaler().fit(Xtr_aug)
                Xtr, Xte = scaler.transform(Xtr_aug), scaler.transform(Xte_aug)

                Xf, yf, Xv, yv = datasets.rebuild_inner_split(Xtr, split.y_train, seed)
                view = _MatrixView(Xf, yf, Xv, yv)

                bnf = grammar.build_grammar(range(Xtr.shape[1]), tag=f"{key}_constr_{arm}")
                result = engine.search(bnf, view, seed=config.SEARCH_SEED_OFFSET + seed)
                metrics = engine.evaluate(
                    engine.phenotype_score(result.best_phenotype, Xte),
                    split.y_test, result.threshold)

                pending.append(dict(
                    study="construction", dataset=key, arm=arm, seed=seed,
                    **{f"test_{k}": v for k, v in metrics.items()},
                    effective_length=result.effective_length,
                    structural_diversity=result.structural_diversity,
                    n_constructed=len(cons), n_features=Xtr.shape[1],
                    phenotype=result.best_phenotype))

            if pending and len(pending) >= 10:
                _append(checkpoint, pending)
                pending = []
        if verbose:
            print(f"  construction: {key} complete ({time.time() - started:.0f}s)", flush=True)

    _append(checkpoint, pending)
    return pd.read_csv(checkpoint)


class _MatrixView:
    """Minimal duck-type of Split for augmented matrices in the construction study."""

    def __init__(self, X_fit, y_fit, X_val, y_val):
        self.X_fit, self.y_fit, self.X_val, self.y_val = X_fit, y_fit, X_val, y_val


# configuration ablation
# Each variant adds one configuration choice to the one above it, so the effect of a
# choice is attributed to that choice rather than to the pipeline as a whole.
ABLATION_VARIANTS = {
    "Base":                    dict(grammar="unweighted", fitness="accuracy", threshold="zero",
                                    select_on_validation=False),
    "+ AUC objective":         dict(grammar="unweighted", fitness="auc", threshold="zero",
                                    select_on_validation=False),
    "+ weighted grammar":      dict(grammar="weighted", fitness="auc", threshold="zero",
                                    select_on_validation=False),
    "+ validation selection":  dict(grammar="weighted", fitness="auc", threshold="zero",
                                    select_on_validation=True),
    "+ threshold calibration": dict(grammar="weighted", fitness="auc", threshold="calibrated",
                                    select_on_validation=True),
}


def run_ablation(dataset_keys=None, seeds=None, arm: str = "llm",
                 variants=None, checkpoint: Path = None, time_budget: float = None,
                 verbose: bool = True) -> pd.DataFrame:
    """Cumulative configuration ablation on one selection arm.

    Fitted on the inner partition throughout, so variants differing only in model
    selection see identical training data.
    """
    dataset_keys = dataset_keys or list(datasets.DATASETS)
    seeds = seeds or range(1, config.ABLATION_SEEDS + 1)
    variants = variants or list(ABLATION_VARIANTS)
    checkpoint = Path(checkpoint or config.RESULTS_DIR / "ablation.csv")

    done = _completed(_load_checkpoint(checkpoint))
    started, pending = time.time(), []

    for key in dataset_keys:
        for seed in seeds:
            split = None
            for variant in variants:
                cell = ("ablation", key, variant, str(seed))
                if cell in done:
                    continue
                if time_budget and (time.time() - started) > time_budget:
                    _append(checkpoint, pending)
                    if verbose:
                        print(f"time budget reached; {len(pending)} cells written")
                    return pd.read_csv(checkpoint)

                if split is None:
                    split = datasets.prepare_split(key, seed)
                spec = ABLATION_VARIANTS[variant]
                idx = priors.selection_indices(arm, split.X_train, split.y_train,
                                               split.features, split.budget, seed, key)
                bnf = grammar.build_grammar(idx, family=spec["grammar"],
                                            tag=f"abl_{key}_{spec['grammar']}")

                hof, population, logbook = engine.evolve(
                    bnf, split.X_fit, split.y_fit,
                    seed=config.SEARCH_SEED_OFFSET + seed, fitness=spec["fitness"])

                if spec["select_on_validation"]:
                    ordered = engine.rank_candidates(list(hof), split.X_val, split.y_val)
                    best = ordered[0] if ordered else hof[0]
                else:
                    best = hof[0]                 # training-fitness leader

                tau = engine.calibrate_threshold(best.phenotype, split.X_val, split.y_val,
                                                 spec["threshold"])
                metrics = engine.evaluate(
                    engine.phenotype_score(best.phenotype, split.X_test),
                    split.y_test, tau)

                pending.append(dict(
                    study="ablation", dataset=key, arm=variant, seed=seed,
                    variant=variant, prior_arm=arm,
                    **{f"test_{k}": v for k, v in metrics.items()},
                    effective_length=int(best.used_codons), threshold=tau,
                    phenotype=best.phenotype))

            if len(pending) >= 10:
                _append(checkpoint, pending)
                pending = []
        if verbose:
            print(f"  ablation: {key} complete ({time.time() - started:.0f}s)", flush=True)

    _append(checkpoint, pending)
    return pd.read_csv(checkpoint)


# soft-prior study
def run_soft_prior_study(dataset_keys=None, seeds=None, arms=None,
                         checkpoint: Path = None, time_budget: float = None,
                         verbose: bool = True) -> pd.DataFrame:
    """Soft-prior study: the prior reweights the grammar instead of restricting it.

    Every feature stays a reachable terminal. An importance score per feature (the
    LLM-Score query of LLM-Select for the knowledge arm, min-max mutual information
    for the data arm, a permutation of the knowledge scores for the noise arm) sets
    how many times that terminal is listed in <v>, hence how often the search
    proposes it. Nothing else differs from the selection study, so the contrast with
    the hard arms isolates the mechanism: does the prior act by removing features
    from reach, or by steering proposals?
    """
    dataset_keys = dataset_keys or list(datasets.DATASETS)
    seeds = seeds or range(1, config.N_SEEDS + 1)
    arms = arms or config.SOFT_ARMS
    checkpoint = Path(checkpoint or config.RESULTS_DIR / "soft_prior.csv")

    done = _completed(_load_checkpoint(checkpoint))
    started, pending = time.time(), []

    for key in dataset_keys:
        for seed in seeds:
            split = None
            for arm in arms:
                cell = ("soft", key, arm, str(seed))
                if cell in done:
                    continue
                if time_budget and (time.time() - started) > time_budget:
                    _append(checkpoint, pending)
                    if verbose:
                        print(f"time budget reached; {len(pending)} cells written")
                    return pd.read_csv(checkpoint)

                if split is None:
                    split = datasets.prepare_split(key, seed)
                scores = priors.soft_scores(arm, split.X_train, split.y_train,
                                            split.features, seed, key)
                copies = priors.production_copies(scores)
                bnf = grammar.build_grammar(range(split.n_features), tag=f"{key}_{arm}",
                                            copies=copies)
                result = engine.search(bnf, split, seed=config.SEARCH_SEED_OFFSET + seed)
                rule = engine.evaluate_rule(result, split.X_test, split.y_test)
                train = engine.evaluate_rule(result, split.X_train, split.y_train)
                used = engine.used_feature_indices(result.best_phenotype, split.n_features)
                favoured = [i for i, s in enumerate(scores) if s >= 0.75]

                pending.append(dict(
                    study="soft", dataset=key, arm=arm, seed=seed,
                    **{f"test_{k}": v for k, v in rule.items()},
                    train_roc_auc=train["roc_auc"],
                    generalisation_gap=train["roc_auc"] - rule["roc_auc"],
                    effective_length=result.effective_length, depth=result.depth,
                    structural_diversity=result.structural_diversity,
                    invalids=result.invalids, threshold=result.threshold,
                    n_terminal_alternatives=sum(copies.values()),
                    favoured_share_of_rule=(len(set(used) & set(favoured)) / len(used)
                                            if used else np.nan),
                    n_used=len(used), phenotype=result.best_phenotype))

            if len(pending) >= 10:
                _append(checkpoint, pending)
                pending = []
        if verbose:
            print(f"  soft prior: {key} complete ({time.time() - started:.0f}s)", flush=True)

    _append(checkpoint, pending)
    return pd.read_csv(checkpoint)


# compute-equivalence study
def run_budget_study(dataset_keys=None, seeds=None, arms=None, checkpoints=None,
                     checkpoint: Path = None, curve_path: Path = None,
                     time_budget: float = None, verbose: bool = True) -> pd.DataFrame:
    """Compute-equivalence study: can more search recover what the prior supplies?

    One traced search per (dataset, arm, seed) runs to the largest checkpoint and is
    model-selected as if stopped at each smaller one, which is exact because GRAPE's
    loop reads ngen only to stop. The per-generation validation AUC of the
    training-fitness leader is written alongside, so generations-to-match can be
    computed: the first generation at which the no-prior search reaches the
    validation AUC the prior arm had at its base budget.
    """
    dataset_keys = dataset_keys or list(datasets.DATASETS)
    seeds = seeds or range(1, config.N_SEEDS + 1)
    arms = arms or config.BUDGET_ARMS
    checkpoints = tuple(checkpoints or config.BUDGET_CHECKPOINTS)
    checkpoint = Path(checkpoint or config.RESULTS_DIR / "budget.csv")
    curve_path = Path(curve_path or config.RESULTS_DIR / "budget_curves.csv")

    done = _completed(_load_checkpoint(checkpoint))
    started, pending, curves = time.time(), [], []

    def flush():
        _append(checkpoint, pending)
        _append(curve_path, curves)
        pending.clear()
        curves.clear()

    for key in dataset_keys:
        for seed in seeds:
            split = None
            for arm in arms:
                cell = ("budget", key, arm, str(seed))
                if cell in done:
                    continue
                if time_budget and (time.time() - started) > time_budget:
                    flush()
                    if verbose:
                        print("time budget reached")
                    return pd.read_csv(checkpoint)

                if split is None:
                    split = datasets.prepare_split(key, seed)
                idx = priors.selection_indices(arm, split.X_train, split.y_train,
                                               split.features, split.budget, seed, key)
                bnf = grammar.build_grammar(idx, tag=f"{key}_{arm}")
                results, curve = engine.search_at_checkpoints(
                    bnf, split, seed=config.SEARCH_SEED_OFFSET + seed,
                    checkpoints=checkpoints)

                for g, result in results.items():
                    rule = engine.evaluate_rule(result, split.X_test, split.y_test)
                    pending.append(dict(
                        study="budget", dataset=key, arm=arm, seed=seed,
                        generations=g, budget_multiple=g / checkpoints[0],
                        evaluations=g * config.GE.population_size,
                        **{f"test_{k}": v for k, v in rule.items()},
                        val_roc_auc_selected=float(curve["selected"][g]),
                        val_roc_auc_leader=float(curve["leader"][g]),
                        effective_length=result.effective_length,
                        phenotype=result.best_phenotype))
                curves.append(dict(dataset=key, arm=arm, seed=seed,
                                   leader=" ".join(f"{v:.5f}" for v in curve["leader"]),
                                   selected=" ".join(f"{v:.5f}" for v in curve["selected"])))

            if len(pending) >= 3 * len(checkpoints):
                flush()
        if verbose:
            print(f"  budget: {key} complete ({time.time() - started:.0f}s)", flush=True)

    flush()
    return pd.read_csv(checkpoint)
