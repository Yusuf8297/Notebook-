"""Figure generation. Each figure is standalone with its own savefig call and is
written to FIGURES_DIR as both PNG and PDF."""
from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from . import config, statistics as stats

ARM_COLOURS = {"none": "#555555", "random": "#1f77b4", "mi": "#ff7f0e",
               "corr": "#2ca02c", "llm": "#d62728", "raw": "#7f7f7f"}

plt.rcParams.update({"figure.dpi": 120, "savefig.bbox": "tight",
                     "font.size": 10, "axes.grid": True, "grid.alpha": 0.3})


def _save(fig, name: str) -> None:
    for ext in ("png", "pdf"):
        fig.savefig(config.FIGURES_DIR / f"{name}.{ext}", dpi=200)
    plt.close(fig)


def plot_arm_medians(df: pd.DataFrame, arms, dataset_keys, name: str,
                     metric: str = None, title: str = None, ylim=(0.6, 1.0)):
    """Grouped bars of median test ROC-AUC by dataset and arm."""
    metric = metric or f"test_{config.PRIMARY_METRIC}"
    table = stats.median_table(df, arms, metric, dataset_keys)

    fig, ax = plt.subplots(figsize=(9, 4.5))
    n_arms = len(table.columns)
    positions = np.arange(len(table.index))
    width = 0.8 / n_arms
    for i, arm in enumerate(table.columns):
        ax.bar(positions + i * width - 0.4 + width / 2, table[arm].values, width,
               label=arm, color=ARM_COLOURS.get(arm, None))
    ax.set_xticks(positions)
    ax.set_xticklabels(table.index)
    ax.set_ylim(*ylim)
    ax.set_ylabel("median test ROC-AUC")
    ax.set_xlabel("dataset")
    ax.set_title(title or "Prior arms by dataset (median over seeds)")
    ax.legend(title="prior", ncol=n_arms, fontsize=8)
    _save(fig, name)
    return table


def plot_rank_heatmap(rank_table: pd.DataFrame, name: str = "rank_heatmap"):
    """Average rank per arm per dataset, 1 = best."""
    fig, ax = plt.subplots(figsize=(7, 3.2))
    image = ax.imshow(rank_table.values, cmap="RdYlGn_r", aspect="auto",
                      vmin=1, vmax=rank_table.shape[1])
    ax.set_xticks(range(rank_table.shape[1]))
    ax.set_xticklabels(rank_table.columns)
    ax.set_yticks(range(rank_table.shape[0]))
    ax.set_yticklabels(rank_table.index)
    ax.grid(False)
    for i in range(rank_table.shape[0]):
        for j in range(rank_table.shape[1]):
            ax.text(j, i, f"{rank_table.values[i, j]:.2f}", ha="center", va="center",
                    fontsize=10)
    ax.set_title("Average rank by prior and dataset (1 = best)")
    fig.colorbar(image, ax=ax, label="average rank")
    _save(fig, name)


def plot_length_vs_generalisation(selection: pd.DataFrame, arms,
                                  name: str = "length_vs_generalisation"):
    """Effective length against test ROC-AUC, coloured by prior source."""
    metric = f"test_{config.PRIMARY_METRIC}"
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    for arm in arms:
        sub = selection[selection.arm == arm]
        if sub.empty:
            continue
        ax.scatter(sub["effective_length"], sub[metric], s=20, alpha=0.55,
                   label=arm, color=ARM_COLOURS.get(arm, None))
    ax.set_xlabel("effective length (used codons)")
    ax.set_ylabel("test ROC-AUC")
    ax.set_title("Effective length versus generalisation, by prior source")
    ax.legend(title="prior", fontsize=8)
    _save(fig, name)


def plot_configuration_ablation(ablation: pd.DataFrame,
                                name: str = "configuration_ablation"):
    """Test ROC-AUC per dataset across the cumulative configuration ablation."""
    table = ablation.groupby(["dataset", "variant"])["test_roc_auc"].median().unstack("variant")
    order = [v for v in _ABLATION_ORDER if v in table.columns]
    if order:
        table = table[order]
    fig, ax = plt.subplots(figsize=(9, 4.5))
    positions = np.arange(len(table.index))
    width = 0.8 / max(1, table.shape[1])
    for i, variant in enumerate(table.columns):
        ax.bar(positions + i * width - 0.4 + width / 2, table[variant].values, width,
               label=variant)
    ax.set_xticks(positions)
    ax.set_xticklabels(table.index)
    ax.set_ylabel("median test ROC-AUC")
    ax.set_ylim(0.6, 1.0)
    ax.set_title("Configuration ablation (llm arm)")
    ax.legend(fontsize=8, ncol=3)
    _save(fig, name)
    return table


_ABLATION_ORDER = ["Base", "+ AUC objective", "+ weighted grammar",
                   "+ validation selection", "+ threshold calibration"]


def plot_interpretability_cost(comparison: pd.DataFrame,
                               name: str = "interpretability_cost"):
    """Single interpretable rule, matched GE ensemble, and the black-box comparator."""
    fig, ax = plt.subplots(figsize=(8.5, 4.5))
    positions = np.arange(len(comparison.index))
    width = 0.8 / comparison.shape[1]
    for i, column in enumerate(comparison.columns):
        ax.bar(positions + i * width - 0.4 + width / 2, comparison[column].values,
               width, label=column)
    ax.set_xticks(positions)
    ax.set_xticklabels(comparison.index)
    ax.set_ylabel("median test ROC-AUC")
    ax.set_ylim(0.6, 1.0)
    ax.set_title("Interpretable rule versus matched ensemble versus black box")
    ax.legend(fontsize=8)
    _save(fig, name)


def plot_confusion(y_true, y_pred, title: str, name: str):
    """Confusion matrix of a single evolved rule on a held-out partition."""
    from sklearn.metrics import confusion_matrix
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(4.3, 3.9))
    ax.imshow(cm, cmap="Blues")
    ax.grid(False)
    for i in range(2):
        for j in range(2):
            ax.text(j, i, cm[i, j], ha="center", va="center", fontsize=13,
                    color="white" if cm[i, j] > cm.max() / 2 else "black")
    ax.set_xticks([0, 1], ["neg", "pos"])
    ax.set_yticks([0, 1], ["neg", "pos"])
    ax.set_xlabel("predicted")
    ax.set_ylabel("true")
    ax.set_title(title)
    _save(fig, name)
    return cm


def plot_critical_difference(rank_table: pd.DataFrame, name: str = "critical_difference"):
    """Demsar critical-difference diagram. Provided for an extended dataset panel; the
    driver does not produce it for the four-dataset panel, which cannot power it."""
    k, n = rank_table.shape[1], rank_table.shape[0]
    cd = stats.critical_difference(k, n)
    average = rank_table.mean(axis=0).sort_values()

    fig, ax = plt.subplots(figsize=(7.5, 2.4))
    ax.hlines(1, 1, k, color="black", lw=1)
    for i, (arm, rank) in enumerate(average.items()):
        ax.plot(rank, 1, "o", color=ARM_COLOURS.get(arm, "black"))
        ax.annotate(f"{arm}\n{rank:.2f}", (rank, 1), textcoords="offset points",
                    xytext=(0, 12 if i % 2 == 0 else -28), ha="center", fontsize=8)
    ax.plot([1, 1 + cd], [1.35, 1.35], color="crimson", lw=2)
    ax.annotate(f"CD = {cd:.3f}  (k={k}, N={n})", (1 + cd / 2, 1.35),
                textcoords="offset points", xytext=(0, 6), ha="center", fontsize=8)
    ax.set_ylim(0.6, 1.6)
    ax.set_xlim(0.8, k + 0.2)
    ax.set_yticks([])
    ax.grid(False)
    ax.set_xlabel("average rank (1 = best)")
    _save(fig, name)
    return cd


# second wave
ARM_COLOURS.update({"llm_soft": "#e377c2", "mi_soft": "#bcbd22", "random_soft": "#17becf"})


def plot_interaction(gain_table: pd.DataFrame, name: str = "prior_learner_interaction",
                     title: str = "Gain from the knowledge prior (llm - random) by learner"):
    """Median paired gain of the knowledge prior over the noise prior, per learner and
    dataset. The GE rule is the first group; a bar that stands clear of the
    fixed-capacity learners on the same dataset is the interaction."""
    fig, ax = plt.subplots(figsize=(9.5, 4.5))
    positions = np.arange(len(gain_table.index))
    width = 0.8 / max(1, gain_table.shape[1])
    palette = iter(["#1f77b4", "#ff7f0e", "#2ca02c", "#9467bd", "#8c564b", "#17becf"])
    for i, learner in enumerate(gain_table.columns):
        ax.bar(positions + i * width - 0.4 + width / 2, gain_table[learner].values, width,
               label=learner, color="#d62728" if learner == "GE rule" else next(palette),
               edgecolor="black" if learner == "GE rule" else None)
    ax.axhline(0, color="black", lw=0.8)
    ax.set_xticks(positions)
    ax.set_xticklabels(gain_table.index)
    ax.set_ylabel("median paired gain in test ROC-AUC")
    ax.set_title(title)
    ax.legend(fontsize=8, ncol=2)
    _save(fig, name)


def plot_soft_vs_hard(table: pd.DataFrame, name: str = "soft_vs_hard_prior"):
    """Hard (restricting) and soft (reweighting) prior arms by dataset."""
    fig, ax = plt.subplots(figsize=(10, 4.5))
    positions = np.arange(len(table.index))
    width = 0.8 / table.shape[1]
    for i, arm in enumerate(table.columns):
        ax.bar(positions + i * width - 0.4 + width / 2, table[arm].values, width,
               label=arm, color=ARM_COLOURS.get(arm, None),
               hatch="//" if arm.endswith("_soft") else None)
    ax.set_xticks(positions)
    ax.set_xticklabels(table.index)
    ax.set_ylim(0.6, 1.0)
    ax.set_ylabel("median test ROC-AUC")
    ax.set_title("Mechanism: hard restriction (solid) versus soft reweighting (hatched)")
    ax.legend(title="prior", fontsize=8, ncol=4)
    _save(fig, name)


def plot_budget_curves(curves: pd.DataFrame, dataset_keys, name: str = "budget_curves",
                       series: str = "leader"):
    """Median per-generation validation AUC of the training-fitness leader, by arm.
    The vertical line marks the base budget; the horizontal dotted line is the prior
    arm's level there, which the no-prior arm must reach to match it."""
    fig, axes = plt.subplots(1, len(dataset_keys), figsize=(3.4 * len(dataset_keys), 3.6),
                             sharey=False)
    axes = np.atleast_1d(axes)
    base = config.BUDGET_CHECKPOINTS[0]
    for ax, key in zip(axes, dataset_keys):
        sub = curves[curves.dataset == key]
        for arm in config.BUDGET_ARMS:
            rows = sub[sub.arm == arm]
            if rows.empty:
                continue
            mat = np.array([np.array(s.split(), float) for s in rows[series]])
            med = np.median(mat, axis=0)
            ax.plot(np.arange(len(med)), med, label=arm, color=ARM_COLOURS.get(arm))
            if arm == "llm":
                ax.axhline(med[base], color=ARM_COLOURS["llm"], ls=":", lw=1)
        ax.axvline(base, color="grey", ls="--", lw=1)
        ax.set_title(key)
        ax.set_xlabel("generation")
    axes[0].set_ylabel("median validation ROC-AUC (leader)")
    axes[0].legend(fontsize=8)
    fig.suptitle("Compute-equivalence: search progress with and without a prior")
    _save(fig, name)


def plot_budget_bars(budget: pd.DataFrame, dataset_keys, name: str = "budget_scaling"):
    """Median test ROC-AUC at each generation checkpoint, arms side by side."""
    metric = f"test_{config.PRIMARY_METRIC}"
    checkpoints = list(config.BUDGET_CHECKPOINTS)
    fig, axes = plt.subplots(1, len(dataset_keys), figsize=(3.4 * len(dataset_keys), 3.6))
    axes = np.atleast_1d(axes)
    for ax, key in zip(axes, dataset_keys):
        sub = budget[budget.dataset == key]
        tab = sub.groupby(["arm", "generations"])[metric].median().unstack("generations")
        tab = tab.reindex(index=[a for a in config.BUDGET_ARMS if a in tab.index],
                          columns=checkpoints)
        x = np.arange(len(checkpoints))
        width = 0.8 / max(1, len(tab.index))
        for i, arm in enumerate(tab.index):
            ax.bar(x + i * width - 0.4 + width / 2, tab.loc[arm].values, width,
                   label=arm, color=ARM_COLOURS.get(arm))
        lo = np.nanmin(tab.values) - 0.02
        ax.set_ylim(max(0.5, lo), min(1.0, np.nanmax(tab.values) + 0.02))
        ax.set_xticks(x)
        ax.set_xticklabels([f"{g} gen\n({g // checkpoints[0]}x)" for g in checkpoints])
        ax.set_title(key)
    axes[0].set_ylabel("median test ROC-AUC")
    axes[0].legend(fontsize=8)
    fig.suptitle("Test performance against search budget")
    _save(fig, name)


def plot_discovery_overlap(overlap: pd.DataFrame, name: str = "discovery_overlap"):
    """Jaccard overlap between the unconstrained rule's features and each prior's subset."""
    table = overlap["jaccard"]
    fig, ax = plt.subplots(figsize=(8, 4.2))
    positions = np.arange(len(table.index))
    width = 0.8 / table.shape[1]
    for i, arm in enumerate(table.columns):
        ax.bar(positions + i * width - 0.4 + width / 2, table[arm].values, width,
               label=arm, color=ARM_COLOURS.get(arm))
    ax.set_xticks(positions)
    ax.set_xticklabels(table.index)
    ax.set_ylabel("median Jaccard (rule features vs prior subset)")
    ax.set_title("What unconstrained search discovers versus what each prior anticipated")
    ax.legend(title="prior", fontsize=8)
    _save(fig, name)
