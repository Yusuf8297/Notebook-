"""BNF grammar construction.

A hard prior is injected only by restricting the terminal rule <v> to the arm's
chosen feature indices; a soft prior keeps every feature in <v> and lists the
favoured ones more than once, which shifts the production probability without
removing anything from reach. Every other production, the constant menu and all
operators are identical across arms.

Two families are provided. The weighted family scores a phenotype as a signed
weighted sum of feature terms with optional nonlinear transforms, which is the
functional form of a clinical risk score. The unweighted family has no coefficient
rule, so a phenotype is close to an unweighted sum of standardised features; it is
retained for the configuration ablation.
"""
from __future__ import annotations

from typing import Iterable, Mapping, Sequence

from . import config
from .vendor import ensure_grape

# coefficient menu for the weighted grammar, log-spaced over ~two decades
WEIGHTS = ("0.1", "0.25", "0.5", "0.75", "1.0", "1.5", "2.0", "3.0", "5.0")

# constant menu for the unweighted grammar
UNWEIGHTED_CONSTANTS = ("1.0", "2.0", "5.0", "0.1", "0.5")


def _terminals(feature_idx: Iterable[int], copies: Mapping[int, int] = None) -> str:
    """Terminal alternatives. With `copies`, terminal i is listed copies[i] times, so
    GE's codon-mod-alternatives choice proposes it proportionally more often: a soft
    prior that biases the search without removing any feature from reach."""
    copies = copies or {}
    return " | ".join(f"x[:,{i}]" for i in feature_idx for _ in range(copies.get(i, 1)))


def weighted_grammar_text(feature_idx: Sequence[int],
                          copies: Mapping[int, int] = None) -> str:
    """Signed weighted-additive grammar.

    <e>  signed sum of weighted terms
    <t>  a weighted feature or weighted nonlinear transform
    <nl> pairwise interaction, protected ratio, or monotone unary transform
    <w>  coefficient menu
    """
    return (
        "<e> ::= <t> | add(<e>,<t>) | sub(<e>,<t>)\n"
        "<t> ::= mul(<w>,<v>) | mul(<w>,<nl>)\n"
        "<nl> ::= mul(<v>,<v>) | pdiv(<v>,<v>) | psqrt(<v>) | plog(<v>)\n"
        f"<v> ::= {_terminals(feature_idx, copies)}\n"
        f"<w> ::= {' | '.join(WEIGHTS)}\n"
    )


def unweighted_grammar_text(feature_idx: Sequence[int],
                            copies: Mapping[int, int] = None) -> str:
    """Unweighted grammar (no coefficient rule)."""
    return (
        "<e> ::= <v> | <c> | add(<v>,<v>) | sub(<v>,<v>) | mul(<v>,<v>) | pdiv(<v>,<v>) | "
        "add(<v>,<c>) | mul(<v>,<c>) | add(<e>,<e>) | sub(<e>,<e>)\n"
        f"<v> ::= {_terminals(feature_idx, copies)}\n"
        f"<c> ::= {' | '.join(UNWEIGHTED_CONSTANTS)}\n"
    )


def build_grammar(feature_idx: Sequence[int], family: str = None, tag: str = "arm",
                  copies: Mapping[int, int] = None):
    """Write the BNF to disk and return the parsed GRAPE grammar object.

    `copies` turns the hard restriction into a soft prior: pass every feature index
    and a copies map, and the terminal rule keeps all features reachable while
    proposing the favoured ones more often.
    """
    family = family or config.GRAMMAR
    text = (weighted_grammar_text(feature_idx, copies) if family == "weighted"
            else unweighted_grammar_text(feature_idx, copies))
    path = config.GRAMMAR_DIR / f"{tag}_{family}.bnf"
    path.write_text(text, encoding="utf-8")
    ensure_grape()
    import grape
    return grape.Grammar(str(path))
