"""Grammatical Evolution search engine.

Fitness minimises 1 - ROC-AUC, which is continuous in the ranking and threshold-free.
The decision threshold is calibrated on an inner validation fold. Model selection
picks the best candidate from the hall of fame by validation AUC with a parsimony
tie-break. An optional rank-averaged ensemble is harvested from the final population;
the single rule is always reported alongside it.
"""
from __future__ import annotations

import contextlib
import io
import random
import re
from dataclasses import dataclass, field

import numpy as np
from scipy.stats import rankdata
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, f1_score,
                             precision_score, recall_score, roc_auc_score,
                             average_precision_score)

from . import config
from .vendor import ensure_grape

ensure_grape()

import grape                                                       # noqa: E402
import algorithms                                                  # noqa: E402
from deap import base, creator, tools                              # noqa: E402
from functions import add, sub, mul, pdiv, psqrt, plog             # noqa: E402

# namespace exposed to phenotype evaluation: protected operators plus numpy
EVAL_NAMESPACE = {"add": add, "sub": sub, "mul": mul, "pdiv": pdiv,
                  "psqrt": psqrt, "plog": plog, "np": np}

_TERMINAL_RE = re.compile(r"x\[:,(\d+)\]")

# DEAP creator classes are process-global; guard against re-registration on reimport
if not hasattr(creator, "FitnessMin"):
    creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
if not hasattr(creator, "Individual"):
    creator.create("Individual", grape.Individual, fitness=creator.FitnessMin)

REPORT_ITEMS = ["gen", "invalid", "min", "best_ind_used_codons", "avg_used_codons",
                "structural_diversity", "best_ind_length", "best_ind_nodes",
                "best_ind_depth"]


def set_seeds(seed: int) -> None:
    """Seed both RNGs GRAPE draws from."""
    random.seed(seed)
    np.random.seed(seed)


# scoring
def phenotype_score(phenotype: str, X: np.ndarray):
    """Evaluate a phenotype to a finite real-valued score vector, or None if degenerate.

    Returns the raw continuous score, which lets fitness, model selection and
    threshold calibration be kept separate.
    """
    try:
        raw = eval(phenotype, {"x": X, **EVAL_NAMESPACE})
    except Exception:
        return None
    values = np.asarray(raw, dtype=float)
    if values.ndim == 0:                       # constant phenotype broadcasts to all rows
        values = np.full(X.shape[0], float(values))
    if values.shape[0] != X.shape[0]:
        return None
    return np.nan_to_num(values, nan=0.0, posinf=1e12, neginf=-1e12)


def fast_auc(y: np.ndarray, scores: np.ndarray) -> float:
    """ROC-AUC via the Mann-Whitney rank statistic. Matches sklearn to machine
    precision but is much faster on the fitness hot path."""
    n_pos = int(y.sum())
    n_neg = len(y) - n_pos
    if n_pos == 0 or n_neg == 0:
        return 0.5
    ranks = rankdata(scores)
    return float((ranks[y == 1].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def score_auc(phenotype: str, X: np.ndarray, y: np.ndarray) -> float:
    """ROC-AUC of a phenotype's continuous score. Constant scores return chance."""
    s = phenotype_score(phenotype, X)
    if s is None or np.ptp(s) == 0:
        return 0.5
    return fast_auc(y, s)


def used_feature_indices(phenotype: str, n_features: int) -> list[int]:
    """Feature indices a phenotype references, for coverage diagnostics."""
    return sorted({i for i in (int(m) for m in _TERMINAL_RE.findall(phenotype))
                   if i < n_features})


# fitness
def fitness_auc(individual, points):
    """Minimise 1 - ROC-AUC on the inner fit partition."""
    if individual.invalid:
        return np.nan,
    s = phenotype_score(individual.phenotype, points[0])
    if s is None:
        return np.nan,
    if np.ptp(s) == 0:
        return 0.5,
    return 1.0 - fast_auc(points[1], s),


def fitness_accuracy(individual, points):
    """Minimise classification error at the fixed threshold zero (ablation baseline)."""
    if individual.invalid:
        return np.nan,
    s = phenotype_score(individual.phenotype, points[0])
    if s is None:
        return np.nan,
    return 1.0 - float(np.mean((s > 0).astype(int) == points[1])),


FITNESS_FUNCTIONS = {"auc": fitness_auc, "accuracy": fitness_accuracy}


# calibration
def calibrate_threshold(phenotype: str, X_val, y_val, mode: str = None) -> float:
    """Choose the decision threshold on held-out validation data.

    Maximises balanced accuracy over candidate cut-points from the validation score
    distribution. mode="zero" pins the threshold at zero.
    """
    mode = mode or config.THRESHOLD_MODE
    if mode == "zero":
        return 0.0
    s = phenotype_score(phenotype, X_val)
    if s is None or np.ptp(s) == 0:
        return 0.0
    candidates = np.unique(np.quantile(s, np.linspace(0.02, 0.98, 49)))
    best_tau, best_score = 0.0, -np.inf
    for tau in candidates:
        value = balanced_accuracy_score(y_val, (s > tau).astype(int))
        if value > best_score:
            best_tau, best_score = float(tau), value
    return best_tau


# search
@dataclass
class SearchResult:
    best_phenotype: str
    threshold: float
    ensemble: list[str] = field(default_factory=list)
    effective_length: int = 0
    depth: int = 0
    structural_diversity: float = np.nan
    invalids: int = 0
    n_candidates: int = 0


@dataclass
class Candidate:
    """Detached copy of a hall-of-fame member, so a per-generation trace does not pin
    DEAP individuals in memory. Duck-types what rank_candidates needs."""
    phenotype: str
    used_codons: int
    depth: int
    invalid: bool = False


class TracingHallOfFame(tools.HallOfFame):
    """Hall of fame that snapshots its members after every generation.

    GRAPE calls update() exactly once per generation (once after initialisation,
    then once per generation), so snapshot index g is the hall of fame as it stood
    after generation g. Snapshotting reads state only and draws no random numbers,
    so the trajectory is identical to an untraced run with the same seed.
    """

    def __init__(self, maxsize):
        super().__init__(maxsize)
        self.snapshots: list[list[Candidate]] = []

    def update(self, population):
        super().update(population)
        self.snapshots.append([Candidate(ind.phenotype, int(ind.used_codons),
                                         int(ind.depth), bool(ind.invalid))
                               for ind in self.items])


def evolve(grammar, X_fit, y_fit, seed: int, params=None, fitness: str = None,
           n_generations: int = None, trace: bool = False):
    """Run one GE search and return (hall_of_fame, final_population, logbook).

    The hall of fame is larger than one: it is the candidate pool for validation-based
    selection, not the answer. With trace=True the third return value is replaced by
    the TracingHallOfFame itself, whose per-generation snapshots the
    compute-equivalence study reads.
    """
    params = params or config.GE
    fitness_fn = FITNESS_FUNCTIONS[fitness or config.FITNESS]
    n_generations = n_generations or params.n_generations
    set_seeds(seed)

    toolbox = base.Toolbox()
    toolbox.register("evaluate", fitness_fn)
    toolbox.register("select", tools.selTournament, tournsize=params.tournament_size)
    toolbox.register("mate", grape.crossover_onepoint)
    toolbox.register("mutate", grape.mutation_int_flip_per_codon)

    population = grape.sensible_initialisation(
        creator.Individual, params.population_size, grammar,
        params.min_init_depth, params.max_init_depth, params.codon_size,
        params.codon_consumption, params.genome_representation)

    hof = (TracingHallOfFame(params.hall_of_fame_size) if trace
           else tools.HallOfFame(params.hall_of_fame_size))
    stats = tools.Statistics(key=lambda ind: ind.fitness.values)
    stats.register("min", np.nanmin)

    with contextlib.redirect_stdout(io.StringIO()):   # GRAPE prints progress unconditionally
        population, logbook = algorithms.ge_eaSimpleWithElitism(
            population, toolbox, cxpb=params.p_crossover, mutpb=params.p_mutation_per_codon,
            ngen=n_generations, elite_size=params.elite_size, bnf_grammar=grammar,
            codon_size=params.codon_size, max_tree_depth=params.max_tree_depth,
            max_genome_length=None, points_train=[X_fit, y_fit], points_test=None,
            codon_consumption=params.codon_consumption, report_items=REPORT_ITEMS,
            genome_representation=params.genome_representation, stats=stats,
            halloffame=hof, verbose=False)

    if trace:
        return list(hof.items), population, hof
    return list(hof.items), population, logbook


def rank_candidates(candidates, X_val, y_val):
    """Order distinct phenotypes by validation AUC, breaking ties on brevity.

    Deduplicating on the phenotype string matters: elitism fills the hall of fame with
    copies, and an ensemble of nine identical rules is one rule.
    """
    seen, scored = set(), []
    for ind in candidates:
        if getattr(ind, "invalid", False) or ind.phenotype in seen:
            continue
        seen.add(ind.phenotype)
        scored.append((score_auc(ind.phenotype, X_val, y_val), -int(ind.used_codons), ind))
    scored.sort(key=lambda t: (-t[0], -t[1]))
    return [ind for _, _, ind in scored]


def ensemble_score(phenotypes: list[str], X: np.ndarray) -> np.ndarray:
    """Rank-average the member scores, since evolved phenotypes have different scales."""
    ranks = []
    for phen in phenotypes:
        s = phenotype_score(phen, X)
        ranks.append(rankdata(s) / len(s) if s is not None else np.full(X.shape[0], 0.5))
    return np.mean(ranks, axis=0)


def search(grammar, split_like, seed: int, params=None, fitness: str = None,
           ensemble_size: int = None, threshold_mode: str = None) -> SearchResult:
    """Evolve, select on validation, calibrate, and harvest an ensemble.

    split_like must expose X_fit, y_fit, X_val, y_val. The test partition is never
    passed into this function.
    """
    params = params or config.GE
    ensemble_size = config.ENSEMBLE_SIZE if ensemble_size is None else ensemble_size

    hof, population, logbook = evolve(grammar, split_like.X_fit, split_like.y_fit,
                                      seed, params, fitness)

    # candidates come from the hall of fame only; ranking hundreds of candidates on the
    # small inner fold invites a winner's curse
    ordered = rank_candidates(list(hof), split_like.X_val, split_like.y_val)
    if not ordered:                                   # every individual degenerate
        return SearchResult(best_phenotype="0.0", threshold=0.0)

    best = ordered[0]
    members = [ind.phenotype for ind in ordered[:max(1, ensemble_size)]]
    tau = calibrate_threshold(best.phenotype, split_like.X_val, split_like.y_val,
                              threshold_mode)

    return SearchResult(
        best_phenotype=best.phenotype, threshold=tau, ensemble=members,
        effective_length=int(best.used_codons), depth=int(best.depth),
        structural_diversity=float(logbook.select("structural_diversity")[-1]),
        invalids=int(logbook.select("invalid")[-1]), n_candidates=len(ordered))


def search_at_checkpoints(grammar, split_like, seed: int, checkpoints, params=None,
                          fitness: str = None, threshold_mode: str = None):
    """One long search, model-selected as if it had been stopped at each checkpoint.

    GRAPE's loop does not read ngen except to stop, so the state after generation g
    of a run with ngen = max(checkpoints) is exactly the state of a run with
    ngen = g under the same seed. One traced run therefore yields the results of
    every shorter budget at no extra cost, and the checkpoints are paired within a
    single trajectory rather than being independent restarts.

    Returns (results, curves): results maps checkpoint -> SearchResult; curves has
    two per-generation validation-AUC series, "leader" for the training-fitness
    leader (no selection on validation, so it is the honest progress signal used
    for generations-to-match) and "selected" for the validation-selected best.
    """
    params = params or config.GE
    checkpoints = sorted(checkpoints)
    _, _, hof = evolve(grammar, split_like.X_fit, split_like.y_fit, seed, params,
                       fitness, n_generations=checkpoints[-1], trace=True)

    leader, selected = [], []
    for snapshot in hof.snapshots:
        leader.append(score_auc(snapshot[0].phenotype, split_like.X_val, split_like.y_val)
                      if snapshot and not snapshot[0].invalid else 0.5)
        ordered = rank_candidates(snapshot, split_like.X_val, split_like.y_val)
        selected.append(score_auc(ordered[0].phenotype, split_like.X_val, split_like.y_val)
                        if ordered else 0.5)

    results = {}
    for g in checkpoints:
        snapshot = hof.snapshots[min(g, len(hof.snapshots) - 1)]
        ordered = rank_candidates(snapshot, split_like.X_val, split_like.y_val)
        if not ordered:
            results[g] = SearchResult(best_phenotype="0.0", threshold=0.0)
            continue
        best = ordered[0]
        tau = calibrate_threshold(best.phenotype, split_like.X_val, split_like.y_val,
                                  threshold_mode)
        results[g] = SearchResult(best_phenotype=best.phenotype, threshold=tau,
                                  effective_length=int(best.used_codons),
                                  depth=int(best.depth), n_candidates=len(ordered))
    return results, {"leader": np.asarray(leader, float),
                     "selected": np.asarray(selected, float)}


# metrics
def evaluate(scores: np.ndarray, y: np.ndarray, threshold: float = 0.0) -> dict:
    """Threshold-free and thresholded metrics from a continuous score vector."""
    if scores is None:
        return dict(roc_auc=np.nan, pr_auc=np.nan, accuracy=np.nan, f1=np.nan,
                    precision=np.nan, recall=np.nan, balanced_accuracy=np.nan)
    yhat = (scores > threshold).astype(int)
    try:
        auc = float(roc_auc_score(y, scores))
        pr = float(average_precision_score(y, scores))
    except ValueError:
        auc, pr = np.nan, np.nan
    return dict(roc_auc=auc, pr_auc=pr,
                accuracy=float(accuracy_score(y, yhat)),
                f1=float(f1_score(y, yhat, zero_division=0)),
                precision=float(precision_score(y, yhat, zero_division=0)),
                recall=float(recall_score(y, yhat, zero_division=0)),
                balanced_accuracy=float(balanced_accuracy_score(y, yhat)))


def evaluate_rule(result: SearchResult, X: np.ndarray, y: np.ndarray) -> dict:
    """Metrics for the single interpretable rule."""
    return evaluate(phenotype_score(result.best_phenotype, X), y, result.threshold)


def evaluate_ensemble(result: SearchResult, X_val, y_val, X: np.ndarray, y: np.ndarray) -> dict:
    """Metrics for the rank-averaged ensemble, threshold recalibrated on validation."""
    if len(result.ensemble) <= 1:
        return evaluate_rule(result, X, y)
    val_scores = ensemble_score(result.ensemble, X_val)
    taus = np.unique(np.quantile(val_scores, np.linspace(0.02, 0.98, 49)))
    best_tau, best_value = 0.5, -np.inf
    for tau in taus:
        value = balanced_accuracy_score(y_val, (val_scores > tau).astype(int))
        if value > best_value:
            best_tau, best_value = float(tau), value
    return evaluate(ensemble_score(result.ensemble, X), y, best_tau)


def readable_rule(phenotype: str, feature_names: list[str]) -> str:
    """Substitute feature names back into a phenotype for presentation."""
    text = phenotype
    for i in sorted(used_feature_indices(phenotype, len(feature_names)), reverse=True):
        text = text.replace(f"x[:,{i}]", feature_names[i])
    return text
