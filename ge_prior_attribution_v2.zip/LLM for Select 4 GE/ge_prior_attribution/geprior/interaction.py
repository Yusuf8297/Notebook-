"""Prior x learner interaction study.

LLM-Select (Jeong, Lipton & Ravikumar, TMLR 2025) establishes that an LLM can pick a
competitive feature subset from names alone, with the subset placed in front of a
fixed-capacity learner such as L2 logistic regression. This module replicates that
protocol inside the present pipeline: the identical per-seed K-subsets that each
selection arm hands to GE are handed instead to conventional learners. The GE arm
from the selection study is joined on (dataset, arm, seed), so every cell of the
prior x learner table is computed on the same rows.

The quantity of interest is not the main effect of the prior (which LLM-Select has
already measured) but the interaction: whether the same prior is worth more to a
symbolic search over a grammar than to a learner whose hypothesis class is fixed.
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

from . import config, datasets, priors
from .experiments import CELL_KEYS, _append, _completed, _load_checkpoint

GE_LABEL = "GE rule"


def build_learners(seed: int) -> dict:
    """Fixed-capacity learners. Logistic regression is LLM-Select's small-scale
    learner; the depth-3 tree is an interpretable fixed-hypothesis-class control, so
    an interaction cannot be attributed to interpretability or low capacity alone."""
    return {
        "Logistic Regression": LogisticRegression(max_iter=2000, random_state=seed),
        "Decision Tree (depth 3)": DecisionTreeClassifier(max_depth=3, random_state=seed),
        "Random Forest": RandomForestClassifier(n_estimators=400, random_state=seed),
        "SVM (RBF)": SVC(probability=True, random_state=seed),
        "Gradient Boosting": GradientBoostingClassifier(random_state=seed),
    }


def run_interaction_study(dataset_keys=None, seeds=None, arms=None, learners=None,
                          checkpoint: Path = None, time_budget: float = None,
                          verbose: bool = True) -> pd.DataFrame:
    """Every (dataset, arm, seed) subset in front of every fixed-capacity learner.

    Resumable and keyed like the GE studies; the `arm` column carries the prior
    source and a `learner` column the downstream model. Subsets are computed by the
    same priors.selection_indices call the GE runner uses, so they are identical.
    """
    dataset_keys = dataset_keys or list(datasets.DATASETS)
    seeds = list(seeds or range(1, config.N_SEEDS + 1))
    arms = arms or config.SELECTION_ARMS
    learners = learners or config.INTERACTION_LEARNERS
    checkpoint = Path(checkpoint or config.RESULTS_DIR / "interaction.csv")

    done = _completed(_load_checkpoint(checkpoint))
    started, pending = time.time(), []

    for key in dataset_keys:
        for seed in seeds:
            split = None
            for arm in arms:
                cell = ("interaction", key, arm, str(seed))
                if cell in done:
                    continue
                if time_budget and (time.time() - started) > time_budget:
                    _append(checkpoint, pending)
                    return pd.read_csv(checkpoint)
                if split is None:
                    split = datasets.prepare_split(key, seed)
                idx = priors.selection_indices(arm, split.X_train, split.y_train,
                                               split.features, split.budget, seed, key)
                Xtr, Xte = split.X_train[:, idx], split.X_test[:, idx]
                for name, model in build_learners(seed).items():
                    if name not in learners:
                        continue
                    model.fit(Xtr, split.y_train)
                    proba = model.predict_proba(Xte)[:, 1]
                    pending.append(dict(
                        study="interaction", dataset=key, arm=arm, seed=seed,
                        learner=name, test_roc_auc=float(roc_auc_score(split.y_test, proba)),
                        budget=len(idx)))
            if len(pending) >= 25:
                _append(checkpoint, pending)
                pending = []
        if verbose:
            print(f"  interaction: {key} complete ({time.time() - started:.0f}s)", flush=True)

    _append(checkpoint, pending)
    return pd.read_csv(checkpoint)


def join_with_ge(interaction: pd.DataFrame, selection: pd.DataFrame) -> pd.DataFrame:
    """Long table over (dataset, arm, seed, learner) with the GE rule as one learner."""
    ge = selection[["dataset", "arm", "seed", "test_roc_auc"]].copy()
    ge["learner"] = GE_LABEL
    cols = ["dataset", "arm", "seed", "learner", "test_roc_auc"]
    return pd.concat([interaction[cols], ge[cols]], ignore_index=True)


def prior_gain_table(joined: pd.DataFrame, arm_a: str = "llm", arm_b: str = "random",
                     dataset_keys=None) -> pd.DataFrame:
    """Median paired gain (arm_a - arm_b) by dataset and learner, over seeds."""
    dataset_keys = dataset_keys or sorted(joined.dataset.unique())
    wide = joined.pivot_table(index=["dataset", "seed", "learner"], columns="arm",
                              values="test_roc_auc")
    gain = (wide[arm_a] - wide[arm_b]).rename("gain").reset_index()
    table = gain.groupby(["dataset", "learner"])["gain"].median().unstack("learner")
    order = [GE_LABEL] + [l for l in config.INTERACTION_LEARNERS if l in table.columns]
    return table.reindex(index=dataset_keys, columns=[c for c in order if c in table.columns])


def interaction_contrast(joined: pd.DataFrame, key: str, arm_a: str = "llm",
                         arm_b: str = "random",
                         reference: str = None) -> dict:
    """Paired difference-of-differences on one dataset.

    d_seed = (GE[arm_a] - GE[arm_b]) - (REF[arm_a] - REF[arm_b]), tested one-sided
    (d > 0) with the Wilcoxon signed-rank test; Cliff's delta of the GE gains against
    the reference gains is reported as the effect size.
    """
    from scipy.stats import wilcoxon
    from .statistics import cliffs_delta, interpret_delta

    reference = reference or config.INTERACTION_REFERENCE_LEARNER
    sub = joined[joined.dataset == key]
    wide = sub.pivot_table(index="seed", columns=["learner", "arm"], values="test_roc_auc")
    needed = [(GE_LABEL, arm_a), (GE_LABEL, arm_b), (reference, arm_a), (reference, arm_b)]
    if any(c not in wide.columns for c in needed):
        return dict(dataset=key, n=0, median_ge_gain=np.nan, median_ref_gain=np.nan,
                    median_interaction=np.nan, cliffs_delta=np.nan, magnitude="n/a",
                    p_raw=np.nan)
    wide = wide[needed].dropna()
    ge_gain = wide[(GE_LABEL, arm_a)] - wide[(GE_LABEL, arm_b)]
    ref_gain = wide[(reference, arm_a)] - wide[(reference, arm_b)]
    d = (ge_gain - ref_gain).values
    try:
        _, p = wilcoxon(d, alternative="greater")
    except ValueError:
        p = 1.0
    delta = cliffs_delta(ge_gain.values, ref_gain.values)
    return dict(dataset=key, n=len(d), reference=reference,
                median_ge_gain=float(ge_gain.median()),
                median_ref_gain=float(ref_gain.median()),
                median_interaction=float(np.median(d)), cliffs_delta=float(delta),
                magnitude=interpret_delta(delta), p_raw=float(p))


def redundancy_table(joined: pd.DataFrame, dataset_keys=None) -> pd.DataFrame:
    """LLM-Select's own finding, replicated: for each learner, the median paired
    difference (llm - none). Near zero means the prior is redundant for that learner:
    it neither helps nor hurts relative to giving the learner every feature."""
    dataset_keys = dataset_keys or sorted(joined.dataset.unique())
    return prior_gain_table(joined, "llm", "none", dataset_keys)
