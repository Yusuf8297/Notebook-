"""Driver: runs the study in resumable, time-bounded slices.

Usage:  python run_study.py <stage> [time_budget_seconds]
Stages: selection | ensemble | construction | baselines | blackbox | ablation
        interaction | soft | budget          (second wave: mechanism studies)
Every stage is safe to re-run; completed cells are skipped.

Optional third argument: a comma-separated dataset list, e.g.
    python run_study.py soft 0 wbcd,pima
which lets two processes share a campaign; each writes its own checkpoint under
results/parts/ and `python run_study.py merge` folds the parts into the canonical files.
"""
import sys, time
sys.path.insert(0, __file__.rsplit("/", 1)[0])

from geprior import config, baselines, experiments, interaction

SEEDS = range(1, config.N_SEEDS + 1)
PARTS = config.RESULTS_DIR / "parts"


def _checkpoint(name, keys):
    if keys is None:
        return config.RESULTS_DIR / name
    PARTS.mkdir(exist_ok=True)
    return PARTS / f"{'-'.join(keys)}__{name}"


def merge():
    """Fold per-dataset part files into the canonical checkpoint, dropping duplicates."""
    import pandas as pd
    for part in sorted(PARTS.glob("*.csv")):
        name = part.name.split("__", 1)[1]
        target = config.RESULTS_DIR / name
        frames = [pd.read_csv(target)] if target.exists() else []
        frames.append(pd.read_csv(part))
        merged = pd.concat(frames, ignore_index=True)
        keys = [c for c in ("study", "dataset", "arm", "seed", "learner", "generations")
                if c in merged.columns]
        merged = merged.drop_duplicates(subset=keys, keep="last")
        merged.to_csv(target, index=False)
        print(f"merged {part.name} -> {target.name} ({len(merged)} rows)")


def main():
    stage = sys.argv[1]
    budget = float(sys.argv[2]) if len(sys.argv) > 2 and float(sys.argv[2]) > 0 else None
    keys = sys.argv[3].split(",") if len(sys.argv) > 3 else None
    t0 = time.time()
    if stage == "merge":
        merge()
        return
    if stage == "interaction":
        interaction.run_interaction_study(dataset_keys=keys, seeds=SEEDS, time_budget=budget,
                                          checkpoint=_checkpoint("interaction.csv", keys))
    elif stage == "soft":
        experiments.run_soft_prior_study(dataset_keys=keys, seeds=SEEDS, time_budget=budget,
                                         checkpoint=_checkpoint("soft_prior.csv", keys))
    elif stage == "budget":
        experiments.run_budget_study(dataset_keys=keys, seeds=SEEDS, time_budget=budget,
                                     checkpoint=_checkpoint("budget.csv", keys),
                                     curve_path=_checkpoint("budget_curves.csv", keys))
    elif stage == "selection":
        experiments.run_selection_study(seeds=SEEDS, time_budget=budget, n_restarts=1)
    elif stage == "ensemble":
        experiments.run_selection_study(
            seeds=SEEDS, arms=["llm"], n_restarts=5, time_budget=budget,
            checkpoint=config.RESULTS_DIR / "ensemble.csv")
    elif stage == "construction":
        experiments.run_construction_study(seeds=SEEDS, time_budget=budget)
    elif stage == "baselines":
        baselines.run_baselines(seeds=SEEDS)
    elif stage == "ablation":
        experiments.run_ablation(time_budget=budget)
    elif stage == "blackbox":
        baselines.run_blackbox_baseline(seeds=SEEDS)
    else:
        raise SystemExit(f"unknown stage: {stage}")
    print(f"{stage}: {time.time()-t0:.0f}s | {config.summary()}")


if __name__ == "__main__":
    main()
