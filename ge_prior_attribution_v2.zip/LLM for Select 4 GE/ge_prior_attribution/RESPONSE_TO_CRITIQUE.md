# Response to the LLM-Select critique

The critique: LLM-Select (Jeong, Lipton and Ravikumar, TMLR 2025) already shows that an
LLM given feature names and a task description selects predictive features at a level
competitive with the best data-driven methods, so "LLM selects features for the GE
terminal set" carries no novelty, and the citation count suggests the subject is
saturated.

The critique is right about the premise and this revision concedes it in full. That an
LLM can pick a good subset from names alone is treated as established, and the
pipeline now reproduces LLM-Select's own result on its own terms: the per-seed subsets
each arm supplies are placed in front of logistic regression (LLM-Select's small-scale
learner) and four other conventional learners, and for those learners the knowledge
prior is indeed redundant against the full feature set (`results/table_llmselect_replication.csv`).

Where the critique does not reach is the learner. LLM-Select's protocol, and every
feature-selection study it is compared against, uses the subset as a column filter in
front of a learner whose hypothesis class does not change when the columns do. In a
grammar-based learner the subset is not an input filter; it is the terminal rule of the
grammar that defines the space being searched. That makes three questions askable that
are not askable in a fixed-learner protocol, and the revision runs all three at 30
seeds with pre-registered contrasts (`config.SECOND_WAVE_CONTRASTS`):

1. Interaction. Is the same subset, on the same rows, worth more to the search than to
   the fixed learner? Yes: the redundancy interaction (GE llm − none) − (LR llm − none)
   is positive on all four datasets and Holm-significant on three, with medium-to-large
   effects. The prior that LLM-Select finds redundant for logistic regression is worth
   +0.008 to +0.025 test ROC-AUC to the evolved rule.

2. Mechanism. Does the prior act by removing features or by steering proposals? By
   removing them. A soft version of the same knowledge, in which LLM-Select's own
   importance scores become grammar production weights and every feature stays
   reachable, is indistinguishable from a permuted score vector on every dataset, while
   the hard version beats the soft one on the smallest dataset. There is no soft form
   of a column filter, so this question has no counterpart in LLM-Select.

3. Compute-equivalence. Can more search recover what the prior supplies? Not on the
   two smallest datasets: the no-prior search at four times the generations still
   trails the prior at one times (Heart Failure p < 0.0001; Pima p = 0.008), and on
   Heart Failure the unconstrained search degrades as it runs. On Cleveland it does
   recover it, so there the prior is an accelerator worth about three budget-multiples.
   A fixed learner has no search budget to trade.

The result these three point to is that in a search-based learner the knowledge prior
functions as a hypothesis-space constraint rather than as a search heuristic, which is
why it is worth nothing to a learner that already has a regulariser, why it survives
being out-searched on small data, and why it stops working when made soft. That
finding is not in LLM-Select, cannot be produced by LLM-Select's protocol, and runs
against the "LLM guides the search" intuition with which the first wave of this study
was itself designed.

On saturation: the citations to LLM-Select are for LLM feature selection with fixed
downstream learners. The literature on priors inside grammar-based or genetic search
that come from a language model, evaluated against noise and data priors at matched
budget, with the mechanism and the compute exchange rate measured, is not saturated;
to our knowledge it is empty.

Everything above is reproducible from `python run_study.py interaction | soft | budget`
followed by `python analyse.py`; the tables and figures quoted are in `results/` and
`figures/`, and the README's "What the second wave found" section gives the numbers.
