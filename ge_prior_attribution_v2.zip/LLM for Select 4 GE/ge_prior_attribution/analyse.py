"""Analysis: statistical protocol, summary tables and all figures."""
import sys
sys.path.insert(0, __file__.rsplit("/", 1)[0])
import pandas as pd
from geprior import config, statistics as st, figures as fg, interaction as ix

R = config.RESULTS_DIR
sel = pd.read_csv(R / "selection.csv"); con = pd.read_csv(R / "construction.csv")
base = pd.read_csv(R / "baselines.csv"); blackbox = pd.read_csv(R / "blackbox_fe.csv")
ens = pd.read_csv(R / "ensemble.csv"); abl = pd.read_csv(R / "ablation.csv")
KEYS = ["wbcd", "pima", "cleveland", "heart_failure"]
ARMS = list(config.SELECTION_ARMS); CARMS = list(config.CONSTRUCTION_ARMS)

out = []
def show(title, obj):
    out.append(f"\n=== {title} ===\n{obj if isinstance(obj, str) else obj.to_string()}")

show("Baselines: median test ROC-AUC",
     base.groupby(["model", "dataset"])["roc_auc"].median().unstack("dataset")[KEYS].round(3))
show("Selection arms: median test ROC-AUC", st.median_table(sel, ARMS, dataset_keys=KEYS).round(3))
show("Selection arms: median test F1",
     st.median_table(sel, ARMS, metric="test_f1", dataset_keys=KEYS).round(3))
show("Construction arms: median test ROC-AUC",
     st.median_table(con, CARMS, dataset_keys=KEYS).round(3))

fried, ranks = st.per_dataset_friedman(sel, ARMS, dataset_keys=KEYS)
show("Per-dataset Friedman over seed-resamples, average ranks (1 = best)", fried.round(4))
show("Mean rank across datasets (descriptive only)", ranks.mean(axis=0).round(2))

contr = st.preregistered_contrasts(sel, con, dataset_keys=KEYS)
show("Pre-registered contrasts, Holm-corrected within dataset", contr.round(4))
show("Structural diagnostics, median by selection arm", st.structural_diagnostics(sel, ARMS))

cmp_tbl = pd.DataFrame({
    "GE rule (llm)": sel[sel.arm == "llm"].groupby("dataset")["test_roc_auc"].median(),
    "GE ensemble (llm)": ens.groupby("dataset")["ensemble_roc_auc"].median(),
    "Black-box FE": blackbox.groupby("dataset")["roc_auc"].median(),
    "Logistic Regression": base[base.model == "Logistic Regression"].groupby("dataset")["roc_auc"].median(),
}).reindex(KEYS)
show("Interpretability cost: matched comparison", cmp_tbl.round(3))

abl_tbl = abl.groupby(["dataset", "variant"])["test_roc_auc"].median().unstack("variant").reindex(KEYS)
show("Configuration ablation (llm arm)", abl_tbl.round(3))
show("Ablation: median effective length",
     abl.groupby(["dataset", "variant"])["effective_length"].median().unstack("variant").reindex(KEYS).round(1))
show("Ablation: median test F1",
     abl.groupby(["dataset", "variant"])["test_f1"].median().unstack("variant").reindex(KEYS).round(3))

fg.plot_arm_medians(sel, ARMS, KEYS, "selection_by_dataset",
                    title="Selection-prior arms by dataset (median over seeds)")
fg.plot_arm_medians(con, CARMS, KEYS, "construction_by_dataset",
                    title="Construction-prior arms by dataset (median over seeds)")
fg.plot_rank_heatmap(ranks.reindex(KEYS))
fg.plot_length_vs_generalisation(sel, ARMS)
fg.plot_configuration_ablation(abl)
fg.plot_interpretability_cost(cmp_tbl)

# second wave: the questions LLM-Select cannot pose
# The three files are produced by `run_study.py interaction | soft | budget`; each
# block is skipped, with a note, until its file exists.
second_wave_tables = {}

if (R / "interaction.csv").exists():
    inter = pd.read_csv(R / "interaction.csv")
    joined = ix.join_with_ge(inter, sel)
    full = joined.pivot_table(index=["dataset", "learner"], columns="arm",
                              values="test_roc_auc", aggfunc="median")
    full = full.reindex(columns=ARMS).round(3)
    show("Prior x learner: median test ROC-AUC (same K-subsets, same seeds)", full)
    gain = ix.prior_gain_table(joined, "llm", "random", KEYS)
    show("Prior x learner: median paired gain llm - random, by learner", gain.round(3))
    redund = ix.redundancy_table(joined, KEYS)
    show("LLM-Select replicated: median paired difference llm - none, by learner "
         "(near zero = the prior is redundant for that learner)", redund.round(3))
    c4 = pd.DataFrame([ix.interaction_contrast(joined, k) for k in KEYS])
    c4["p_holm"] = st.holm_correction(c4["p_raw"].fillna(1.0).values)
    c4["significant"] = c4["p_holm"] < config.ALPHA
    show("C4 interaction contrast: (GE llm - GE random) - (LR llm - LR random) > 0, "
         "one-sided Wilcoxon, Holm across datasets", c4.round(4))
    # exploratory, fixed after seeing the C4 result: the redundancy interaction.
    # C4 measures the prior against noise, which every learner suffers from alike;
    # LLM-Select's own claim is about the prior against the full feature set, and
    # that is the contrast on which the learners diverge.
    c4x = pd.DataFrame([ix.interaction_contrast(joined, k, "llm", "none") for k in KEYS])
    c4x["p_holm"] = st.holm_correction(c4x["p_raw"].fillna(1.0).values)
    c4x["significant"] = c4x["p_holm"] < config.ALPHA
    show("EXPLORATORY C4x (post hoc, not pre-registered): (GE llm - GE none) - "
         "(LR llm - LR none) > 0, one-sided Wilcoxon, Holm across datasets", c4x.round(4))
    fg.plot_interaction(gain)
    fg.plot_interaction(redund, name="prior_learner_redundancy",
                        title="Prior against the full feature set (llm - none) by learner")
    second_wave_tables.update(table_interaction_full=full, table_interaction_gain=gain,
                              table_llmselect_replication=redund, table_contrast_C4=c4,
                              table_contrast_C4x_exploratory=c4x)
else:
    show("Prior x learner", "not run yet: python run_study.py interaction")

if (R / "soft_prior.csv").exists():
    soft = pd.read_csv(R / "soft_prior.csv")
    svh = st.soft_vs_hard_table(sel, soft, KEYS)
    show("Mechanism: hard (restricting) versus soft (reweighting) arms, median test ROC-AUC",
         svh.round(3))
    c5 = st.soft_contrasts(soft, KEYS)
    show("C5 soft contrasts: llm_soft vs random_soft (C5) and vs mi_soft, Holm within dataset",
         c5.round(4))
    hvs = st.hard_vs_soft_contrast(sel, soft, KEYS)
    show("Same knowledge, two mechanisms: llm (hard) vs llm_soft, paired on seed", hvs.round(4))
    show("Soft arms: share of the evolved rule's features that the prior favoured (median)",
         soft.groupby(["dataset", "arm"])["favoured_share_of_rule"].median().unstack("arm")
         .reindex(KEYS).round(3))
    fg.plot_soft_vs_hard(svh)
    second_wave_tables.update(table_soft_vs_hard=svh, table_contrast_C5=c5,
                              table_hard_vs_soft=hvs)
else:
    show("Soft prior", "not run yet: python run_study.py soft")

if (R / "budget.csv").exists():
    bud = pd.read_csv(R / "budget.csv")
    curves = pd.read_csv(R / "budget_curves.csv")
    show("Compute-equivalence: median test ROC-AUC by arm and generation checkpoint",
         st.budget_table(bud, KEYS).round(3))
    c6 = st.budget_contrasts(bud, KEYS)
    show("C6 and companions: llm at base budget vs none / mi at each budget, one-sided Wilcoxon",
         c6.round(4))
    g2m = st.generations_to_match(curves)
    show("Generations the no-prior search needs to reach the prior arm's base-budget "
         "validation level (leader curve; censored = never within trace)", g2m.round(2))
    g2m_mi = st.generations_to_match(curves, search_arm="mi")
    show("Same, for the data prior (mi) as the searching arm", g2m_mi.round(2))
    fg.plot_budget_curves(curves, KEYS)
    fg.plot_budget_bars(bud, KEYS)
    second_wave_tables.update(table_budget=st.budget_table(bud, KEYS), table_contrast_C6=c6,
                              table_generations_to_match=g2m,
                              table_generations_to_match_mi=g2m_mi)
else:
    show("Compute-equivalence", "not run yet: python run_study.py budget")

overlap = st.discovery_overlap(sel, KEYS)
show("Discovery overlap: unconstrained rule's features vs each prior's subset (median Jaccard, "
     "median share of rule inside prior)", overlap.round(3))
usage = st.feature_usage_by_prior_membership(sel, KEYS)
show("Feature usage under the none arm, inside vs outside the knowledge prior's set", usage.round(3))
fg.plot_discovery_overlap(overlap)
second_wave_tables.update(table_discovery_overlap=overlap, table_feature_usage=usage)

report = "\n".join(out)
(R / "analysis_report.txt").write_text(report)
for name, tbl in [("table_baselines", base.groupby(["model", "dataset"])["roc_auc"].median().unstack("dataset")[KEYS]),
                  ("table_selection", st.median_table(sel, ARMS, dataset_keys=KEYS)),
                  ("table_construction", st.median_table(con, CARMS, dataset_keys=KEYS)),
                  ("table_friedman", fried), ("table_contrasts", contr),
                  ("table_diagnostics", st.structural_diagnostics(sel, ARMS)),
                  ("table_interpretability_cost", cmp_tbl), ("table_ablation", abl_tbl)]:
    tbl.to_csv(R / f"{name}.csv")
for name, tbl in second_wave_tables.items():
    tbl.to_csv(R / f"{name}.csv")
print(report)
