# Feature Priors in Grammatical Evolution: Interaction, Mechanism and Compute-Equivalence

Code for an attribution-controlled study of feature priors in LLM-guided Grammatical
Evolution (GE). The first wave separates noise, data and knowledge as sources of a
feature prior at matched budget, evolves an interpretable symbolic classifier under
each prior, and situates it against a black-box feature-engineering comparator
following the CAAFE paradigm (Hollmann et al., 2023). The second wave asks three
questions about that prior which can only be posed when the learner is a search
over a grammar, and which are therefore outside the reach of feature-selection
studies whose downstream learner has a fixed hypothesis class.

Search uses GRAPE. A hard prior is injected only by restricting the grammar's terminal
rule to the arm's chosen feature indices; a soft prior keeps every feature reachable
and reweights how often the grammar proposes each one. The recursive productions,
the constant menu and every evolutionary operator are held fixed across arms.

## Relation to LLM-Select

LLM-Select (Jeong, Lipton and Ravikumar, *Transactions on Machine Learning
Research*, 2025; arXiv:2407.02694) establishes that a large language model, given
only feature names and a task description, selects a feature subset whose downstream
performance is competitive with LASSO, MRMR, mutual information and other data-driven
selectors. Its downstream learners are L2 logistic regression, LightGBM and an MLP:
the subset is a column filter placed in front of a learner whose hypothesis class does
not change when the columns do.

That result is taken here as established, and Section 15 of the notebook replicates
it inside this pipeline: the same per-seed subsets that each arm hands to GE are
handed to logistic regression and four other fixed-capacity learners, and the
knowledge prior is indeed close to redundant for them. The contribution of this study
is not that an LLM can choose the terminal set. It is what happens to the prior when
the learner is a stochastic search over a combinatorial space, where the prior
changes the landscape being searched rather than the inputs of a fixed estimator.
Three consequences follow, none of which has a counterpart in a fixed-learner
protocol, and each is a pre-registered contrast:

**C4, interaction.** Is the identical subset, on the identical rows, worth more to
the symbolic search than to LLM-Select's own learner? The pre-registered test is a
paired difference-of-differences per seed, (GE llm − GE random) − (LR llm − LR random);
the findings below explain why that form was the wrong one and what replaced it.
A fixed learner can measure only the main effect of the prior; the interaction
requires a second learner whose capacity to use a prior differs, and that is what
a grammar-based search is.

**C5, mechanism.** Can the prior act without removing anything? In the soft arms
every feature stays a reachable terminal and LLM-Select's own importance scores
(the LLM-Score query) become grammar production weights, so the knowledge only
shifts what the search proposes first. The noise control permutes the same score
vector, holding the grammar's production entropy fixed. A column filter has no soft
form; a grammar does.

**C6, compute-equivalence.** Is the prior an accelerator, which the no-prior search
recovers given more generations, or does it supply something search does not find? One traced search per arm is model-selected as if stopped at 1×, 2×
and 4× the base budget, exactly and within a single trajectory, and the no-prior
arm at 4× is tested against the prior arm at 1×. Generations-to-match on the
validation curve gives the exchange rate between knowledge and compute. A fixed
learner has no search budget to trade against.

A fourth analysis, discovery overlap, needs no new runs: it measures how much of
what the unconstrained search ends up using the prior had anticipated, and how
much of the prior the search would never have found.

The selection contrasts C1–C3 of the first wave remain the attribution result that
motivates the second: on the three datasets away from ceiling the knowledge prior
beats noise with large effects and is at least level with the data priors, at a
budget where the search would otherwise spend part of its evaluations on feature
discovery.

## What the second wave found

All numbers are medians over 30 seed-resamples of test ROC-AUC; the full tables are in
`results/analysis_report.txt` and `results/table_*.csv`, the figures in `figures/`.

**The prior is redundant for fixed-capacity learners and not for the search.** With
the identical K-subsets on the identical rows, giving logistic regression, a random
forest or gradient boosting the knowledge prior instead of every feature changes
nothing or costs a little (llm − none between −0.015 and +0.010 on the three datasets
away from ceiling), which is LLM-Select's finding reproduced. For the GE rule the same
substitution is worth +0.008 on Pima, +0.012 on Cleveland and +0.025 on Heart Failure.
The pre-registered C4, which measured the prior against noise, is null: every learner
suffers from a random subset alike, so the noise contrast carries no interaction. The
redundancy interaction (GE llm − none) − (LR llm − none), fixed after that result and
labelled exploratory throughout, is positive on every dataset and Holm-significant on
three of four (Cliff's delta 0.39–0.52 on WBCD, Pima and Cleveland; 0.20, p = 0.06 on
Heart Failure). The depth-3 tree, whose only capacity control is likewise which
features it may split on, patterns with GE rather than with the regularised learners.

**The prior acts by restriction, not by steering.** The soft arms, in which every
feature stays reachable and LLM-Select's own importance scores only make favoured
terminals more frequent in the grammar, are indistinguishable from a permuted score
vector (C5 null on all four datasets, Cliff's delta ≤ 0.20) and from a soft data
prior. The same knowledge applied as a hard restriction beats its soft form on Heart
Failure (0.785 vs 0.748, p = 0.013) and is level with it elsewhere; only at the WBCD
ceiling does restriction cost (0.988 vs 0.992, p = 0.004), because there is nothing
to regularise. The evolved rules under `llm_soft` draw 67–83 % of their features from
the favoured set, so the bias is followed; following it is simply not what helps.

**More search does not buy the prior back where the data are small.** The no-prior
search at four times the generations does not reach the prior arm at one times on
Heart Failure (0.747 vs 0.785, one-sided p < 0.0001, Cliff's delta 0.34) or Pima
(0.826 vs 0.835, p = 0.008), and on Heart Failure the unconstrained search gets worse
as it runs (0.752 → 0.738 → 0.747), which is the signature of a search whose
capacity is unconstrained overfitting the inner fold. On Cleveland the extra budget
does recover it (0.887 at 4× against 0.877), so there the prior is an accelerator
worth about three budget-multiples. Generations-to-match on the validation curve is
heavily censored: 13 of 30 Heart Failure seeds and 8 of 30 Pima seeds never reach the
prior arm's base-budget level within 160 generations.

**Unconstrained search does find the prior's features, and others besides.** Under
the none arm the evolved rule uses a feature in the knowledge prior's set at roughly
twice the rate of one outside it (1.7–2.2× across datasets), and the median Jaccard
between the rule's features and the LLM subset is 0.44–0.55 away from ceiling,
comparable to the data priors. What the prior removes is not features the search
would never find; it is the additional features the search also picks up and, on
small data, overfits with.

Taken together: in a grammar-based learner the knowledge prior functions as a
hypothesis-space constraint, not as a search heuristic. That is why it is worth
nothing to a learner that already has a regulariser, why it survives being
out-searched on small datasets, and why it stops working the moment it is made
soft. None of these three facts is observable in a protocol where the prior is a
column filter in front of a fixed learner, and the third runs against the intuition
with which the first wave was designed.

## Layout

```
geprior/
  config.py        tunable constants; a run is described by this module plus the seeds
  datasets.py      loaders, per-seed resampling, inner fit/validation partitioning
  priors.py        noise, data and knowledge prior sources; LLM-Score ratings; soft weights
  grammar.py       BNF construction, hard (restricting) and soft (reweighting) terminal rules
  vendor.py        GRAPE fetch and compatibility patching
  engine.py        fitness, search, model selection, calibration, traced checkpointed search
  baselines.py     conventional classifiers and the black-box FE comparator
  interaction.py   prior x learner study: the same subsets in front of fixed-capacity learners
  experiments.py   resumable runners: selection, construction, ablation, soft prior, budget
  statistics.py    Friedman, Wilcoxon, Holm, Cliff's delta, second-wave contrasts, overlap
  figures.py       standalone figures, PNG and PDF
run_study.py       command-line driver, one stage per invocation, optional dataset split
analyse.py         statistical protocol and all figures from saved results
notebooks/         driver notebook (Sections 15-18 are the second wave) and a Colab variant
results/           checkpoints and derived tables
figures/           generated figures
```

## Running

```bash
pip install numpy pandas scipy scikit-learn deap matplotlib
python run_study.py baselines
python run_study.py blackbox
python run_study.py selection      # optional: append a seconds budget, e.g. 600
python run_study.py construction
python run_study.py ensemble
python run_study.py ablation
python run_study.py interaction    # second wave: prior x learner
python run_study.py soft           # second wave: soft-prior arms
python run_study.py budget         # second wave: compute-equivalence (heaviest stage)
python analyse.py
```

Every stage is resumable. Results are appended to a CSV keyed by study, dataset, arm
and seed, and any cell already present is skipped, so an interrupted campaign restarts
without recomputation. Passing a time budget in seconds bounds a slice and writes a
checkpoint before returning. A third argument restricts a stage to a comma-separated
dataset list and writes to `results/parts/`, so two processes can share a campaign;
`python run_study.py merge` folds the parts into the canonical files:

```bash
python run_study.py budget 0 wbcd,pima &
python run_study.py budget 0 cleveland,heart_failure &
wait && python run_study.py merge
```

`config.N_SEEDS` is 30. The first wave is roughly two hours on a single core. The
budget stage runs each of 360 searches to 160 generations and is roughly four hours
on a single core; the soft and interaction stages add about half an hour together.

For a live knowledge prior, set `LLM_BACKEND = "api"` in `config.py` and export
`ANTHROPIC_API_KEY`. This draws a fresh response per seed for the selection,
construction and LLM-Score queries, and removes the cached prior's sampling and
tiered-score emulation.

## The second-wave studies in detail

### Prior x learner interaction (`interaction.py`)

For each dataset, seed and selection arm, `priors.selection_indices` returns the
same K indices the GE runner used; those columns are placed in front of logistic
regression (LLM-Select's small-scale learner), a depth-3 decision tree (an
interpretable fixed-hypothesis-class control, so an interaction cannot be
attributed to interpretability or low capacity alone), a random forest, an RBF SVM
and gradient boosting. The GE rule from `selection.csv` joins on (dataset, arm,
seed) as one more learner. Three tables come out: the full prior x learner grid,
the paired gain llm − random per learner, and the LLM-Select replication llm − none
per learner. C4 is tested one-sided with Wilcoxon on the per-seed difference of
differences, Holm-corrected across datasets, with Cliff's delta of the GE gains
against the reference gains as the effect size.

### Soft prior (`experiments.run_soft_prior_study`)

`priors.soft_scores` returns one importance in [0, 1] per feature: the LLM-Score
rating for `llm_soft` (tiered from the cached response when the backend is cached;
a per-feature rating from the model when live), min-max mutual information for
`mi_soft`, and a seed-specific permutation of the llm vector for `random_soft`.
`priors.production_copies` maps a score to max(1, round(score × SOFT_MULTIPLIER))
copies of that terminal in `<v>`. Since GE picks a production as codon mod the number
of alternatives, a terminal listed m times is proposed with probability proportional
to m; the search engine is untouched. The runner also records the share of each
evolved rule's features that the prior favoured, which shows whether the search
followed the bias or overrode it.

### Compute-equivalence (`experiments.run_budget_study`, `engine.search_at_checkpoints`)

GRAPE's generational loop reads `ngen` only to know when to stop, so the population
after generation g of a 160-generation run is bit-identical to the final population
of a 40- or 80-generation run under the same seed. A `TracingHallOfFame` snapshots
the hall of fame after every generation without drawing random numbers; validation
selection and threshold calibration are then applied to the snapshot at each
checkpoint, giving the result of every shorter budget from one run, paired within a
trajectory. Two validation curves are written per run: the training-fitness leader
(no selection on validation, the honest progress signal) and the validation-selected
best. Generations-to-match is the first generation at which the no-prior leader
reaches the level the prior arm's leader had at the base budget, censored at the
trace end when it never does.

### Discovery overlap (`statistics.discovery_overlap`)

From the existing selection results: for every none-arm rule, the features it
references are compared with the subset each informed arm would have supplied on the
same seed, as a Jaccard index and as the share of the rule inside the subset.
`feature_usage_by_prior_membership` reports how often unconstrained search uses a
feature inside versus outside the knowledge prior's set.

## Statistical protocol

Median-based throughout. Per-dataset Friedman tests over the seed-paired resamples
carry the inference; the cross-dataset mean rank is descriptive only, since four
datasets cannot power a Demsar critical-difference diagram. `critical_difference`
raises rather than falling back when `k` is outside the tabulated range, since a
fallback to a smaller `k` yields a critical difference that is too small. The
confirmatory contrasts in `config.PREREGISTERED_CONTRASTS` (C1–C3) were fixed before
the first-wave runs and those in `config.SECOND_WAVE_CONTRASTS` (C4–C6) before the
second-wave runs; any comparison computed after the fact is exploratory.

## Reproducibility notes

GRAPE requires two behaviour-preserving compatibility patches to run under NumPy 2.x
and Python 3.12, applied in `vendor.py`: a float bound in a `random.randint` call, and
the removed `np.NaN` alias.

The test partition is never passed to `engine.search` or
`engine.search_at_checkpoints`, which is the structural guarantee against leakage;
model selection and threshold calibration see only the inner validation fold carved
from the training partition. The traced search was checked against the untraced one:
the checkpoint-40 result of a traced 160-generation run reproduces the phenotype and
test AUC of the plain 40-generation search under the same seed exactly.

## Running the notebook

`notebooks/GE_Prior_Attribution_Study.ipynb` locates the repository root itself, so it
can be opened from the repository root, from `notebooks/`, or from a workspace folder
that contains the repository somewhere beneath it. For a quick end-to-end check, set
`SMOKE = True` in the first cell: it shrinks the search, the seed count and the budget
checkpoints and writes to `results/_smoke`, leaving the full-run checkpoints untouched.

### If imports fail

Run the bundled checker first; it reports missing files, missing dependencies and the
interpreter in use:

```bash
python VERIFY_INSTALL.py
```

`No module named 'geprior'` means the project is not unpacked where the notebook can
see it. `No module named 'numpy'` means the Jupyter kernel points at an interpreter
without the dependencies: a freshly selected "Python 3" kernel is often a bare
environment. The notebook's first cell installs into whichever interpreter is running
it, so re-running that cell is usually enough; otherwise select the matching kernel
through Kernel > Change Kernel.

An editable install makes `geprior` importable from any working directory:

```bash
cd ge_prior_attribution
pip install -e .
```

If the package still cannot be found, set the path explicitly in the first cell:

```python
import sys
sys.path.insert(0, r"C:\path\to\ge_prior_attribution")
```

The folder given must be the one that directly contains `geprior/`.

## Running in VS Code on Windows

```powershell
powershell -ExecutionPolicy Bypass -File .\SETUP_WINDOWS.ps1
```

This creates `.venv`, installs the dependencies, registers a Jupyter kernel named
`Python (geprior)`, writes `.vscode/settings.json`, and runs the verifier. To target a
specific interpreter:

```powershell
powershell -ExecutionPolicy Bypass -File .\SETUP_WINDOWS.ps1 -Python "C:\Program Files\Python312\python.exe"
```

Then in VS Code: **File > Open Folder** on the folder that directly contains
`geprior\`, `Ctrl+Shift+P` > **Python: Select Interpreter** > `.venv\Scripts\python.exe`,
open the notebook and select the **Python (geprior)** kernel. `.vscode/launch.json`
provides run configurations for the verifier, the selection stage and the analysis.

### Windows Application Control blocking SciPy

On a managed Windows machine the import may fail with an Application Control policy
blocking SciPy's compiled extensions. This is a machine policy, not a project fault;
scikit-learn requires SciPy, so SciPy cannot be removed. Diagnose the mechanism with:

```powershell
powershell -ExecutionPolicy Bypass -File .\DIAGNOSE_WINDOWS.ps1
```

Workarounds, in rough order of convenience: run under WSL2 (`wsl --install -d Ubuntu`,
then `bash SETUP_WSL.sh`), which stays entirely local; use `notebooks/Run_On_Colab.ipynb`;
install a system-wide Miniforge/Anaconda distribution, which managed policies often
permit where a per-user install is not; or request an IT allow-list exemption for the
Python installation directory.

## References

Hollmann, N., Müller, S. and Hutter, F. (2023). Large language models for automated
data science: introducing CAAFE for context-aware automated feature engineering.
*NeurIPS 2023*.

Jeong, D. P., Lipton, Z. C. and Ravikumar, P. (2025). LLM-Select: feature selection
with large language models. *Transactions on Machine Learning Research*.
arXiv:2407.02694.
