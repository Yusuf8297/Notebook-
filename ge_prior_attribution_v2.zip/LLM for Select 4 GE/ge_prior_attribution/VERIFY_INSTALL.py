"""Standalone check that the project is unpacked correctly and can run.

Run this first if anything fails to import:  python VERIFY_INSTALL.py
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQUIRED = ["geprior/__init__.py", "geprior/config.py", "geprior/engine.py",
            "geprior/datasets.py", "geprior/priors.py", "geprior/grammar.py",
            "geprior/experiments.py", "geprior/baselines.py", "geprior/interaction.py",
            "geprior/statistics.py", "geprior/figures.py", "geprior/vendor.py",
            "run_study.py", "analyse.py",
            "notebooks/GE_Prior_Attribution_Study.ipynb"]

missing = [f for f in REQUIRED if not (ROOT / f).exists()]
print(f"project root: {ROOT}")
if missing:
    print("\nMISSING FILES -- the download is incomplete:")
    for f in missing:
        print("   ", f)
    sys.exit(1)
print("all required files present")
print("interpreter:", sys.executable)

REQUIRED_PACKAGES = {"numpy": "numpy", "pandas": "pandas", "scipy": "scipy",
                     "sklearn": "scikit-learn", "deap": "deap",
                     "matplotlib": "matplotlib"}
import importlib.util

absent = [pip_name for module, pip_name in REQUIRED_PACKAGES.items()
          if importlib.util.find_spec(module) is None]
if absent:
    print("\nMISSING DEPENDENCIES:", ", ".join(absent))
    print("install them into THIS interpreter:")
    print(f"    {sys.executable} -m pip install " + " ".join(absent))
    print("\nIf the notebook fails but this script passes, the Jupyter kernel is a")
    print("different interpreter: pick the matching kernel in the notebook.")
    sys.exit(1)
print("all dependencies present")

sys.path.insert(0, str(ROOT))
try:
    from geprior import config, datasets, engine, grammar, priors  # noqa: F401
    from geprior import experiments, baselines, statistics, figures  # noqa: F401
except ImportError as exc:
    print(f"\nimport failed: {exc}")
    print("install the dependencies:  pip install -r requirements.txt")
    sys.exit(1)
print("all modules import cleanly")
print("configuration:", config.summary())

split = datasets.prepare_split("pima", seed=1)
idx = priors.selection_indices("llm", split.X_train, split.y_train,
                               split.features, split.budget, 1, "pima")
bnf = grammar.build_grammar(idx, tag="verify")
result = engine.search(bnf, split, seed=config.SEARCH_SEED_OFFSET + 1)
metrics = engine.evaluate_rule(result, split.X_test, split.y_test)
print(f"end-to-end search OK: pima llm arm, test ROC-AUC = {metrics['roc_auc']:.3f}")
print("\nready. Open notebooks/GE_Prior_Attribution_Study.ipynb, "
      "or run: python run_study.py selection")
