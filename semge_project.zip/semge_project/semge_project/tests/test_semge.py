"""Minimal test-suite:  python -m pytest tests  (or  python tests/test_semge.py)."""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from semge import (Evaluator, FitnessConfig, GEConfig, Grammar,  # noqa: E402
                   GrammaticalEvolution, compile_expression, simulate, systems)
from semge.grammar import DEFAULT_ODE_GRAMMAR  # noqa: E402
from semge.motifs import (composition_distance, prior_violation,  # noqa: E402
                          semantic_distance, semantic_representation)


def test_grammar_maps_to_valid_expressions():
    g = Grammar.from_text(DEFAULT_ODE_GRAMMAR)
    rng = np.random.default_rng(0)
    n_valid = 0
    for _ in range(200):
        ph, used = g.map(rng.integers(0, 256, size=60))
        if ph is not None:
            assert compile_expression(ph) is not None, ph
            n_valid += 1
    assert n_valid > 100


def test_simulate_matches_closed_form():
    f = compile_expression("-0.5*x")
    t = np.linspace(0, 4, 41)
    X = simulate(f, np.array([1.0, 2.0]), t)
    assert np.allclose(X, np.outer([1.0, 2.0], np.exp(-0.5 * t)), atol=1e-4)


def test_semantic_representation_logistic():
    t = np.linspace(0, 10, 200)
    x = 2.8 / (1 + (2.8 / 0.4 - 1) * np.exp(-t))
    r = semantic_representation(t, x, smooth=False)
    assert r.composition == ("++b", "+-h")
    assert abs(r.asymptote - 2.8) < 0.05
    above = semantic_representation(t, 2.8 / (1 + (2.8 / 4.0 - 1) * np.exp(-t)), smooth=False)
    assert above.composition == ("-+h",)


def test_semantic_representation_pk_noisy():
    t = np.linspace(0, 8, 60)
    x = 5 * (np.exp(-0.3 * t) - np.exp(-1.5 * t))
    clean = semantic_representation(t, x, smooth=False)
    assert clean.composition == ("+-b", "--b", "-+h")
    dists = []
    for seed in range(6):
        rng = np.random.default_rng(seed)
        noisy = semantic_representation(t, x + 0.01 * np.ptp(x) * rng.standard_normal(60), smooth=True)
        dists.append(composition_distance(clean.composition, noisy.composition))
    assert max(dists) < 0.5 and np.mean(dists) < 0.25, dists


def test_semantic_distance_orders_candidates():
    t = np.linspace(0, 8, 60)
    ref = semantic_representation(t, 2.8 / (1 + 6 * np.exp(-t)), smooth=False)
    good = semantic_representation(t, 3.0 / (1 + 5 * np.exp(-1.2 * t)), smooth=False)
    bad = semantic_representation(t, np.exp(0.2 * t), smooth=False)
    assert semantic_distance(ref, good) < semantic_distance(ref, bad)
    assert semantic_distance(ref, ref) == 0.0


def test_prior_violation():
    t = np.linspace(0, 8, 60)
    r = semantic_representation(t, 2.8 / (1 + 6 * np.exp(-t)), smooth=False)
    assert prior_violation(r, {"ends_with": "+-h"}) == 0.0
    assert prior_violation(r, {"ends_with": "-+u"}) > 0.5
    assert prior_violation(r, {"max_motifs": 1}) > 0.0


def test_oracle_truth_beats_distractors_at_low_noise():
    """Under the hybrid+prior fitness, the true RHS must score better than
    plausible wrong models on every benchmark system at 1 % noise."""
    distractors = ["0.3*x", "0.3", "sin(sin(1.14*x))", "exp(-0.2*t*x)", "sqrt(2.9*x)-x", "-0.5*x+1"]
    for name, sysm in systems.SYSTEMS.items():
        data = systems.make_dataset(sysm, n_traj=8, n_points=60, noise=0.01, seed=0)
        px0 = np.linspace(*sysm.prior_x0, 6) if sysm.prior else None
        ev = Evaluator(data, FitnessConfig(mode="hybrid", prior=sysm.prior, prior_x0=px0))
        truth = ev.evaluate(sysm.formula.replace("^", "**"))["fitness"]
        best_wrong = min(ev.evaluate(d)["fitness"] for d in distractors if d != sysm.formula)
        assert truth < best_wrong, (name, truth, best_wrong)


def test_ge_finds_something_sensible_quickly():
    sysm = systems.SYSTEMS["logistic"]
    data = systems.make_dataset(sysm, n_traj=4, n_points=40, noise=0.0, seed=0)
    ev = Evaluator(data, FitnessConfig(mode="hybrid", prior=sysm.prior))
    ge = GrammaticalEvolution(Grammar.from_text(DEFAULT_ODE_GRAMMAR), ev,
                              GEConfig(pop_size=60, generations=8, seed=1, refine_constants=False))
    res = ge.run()
    assert res.best.phenotype is not None
    assert res.best.fitness < 1e3
    assert len(res.history) == 8


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok", name)
