| system | noise | condition | metric | win-rate vs baseline | median Δ | p (Wilcoxon) |
|---|---|---|---|---|---|---|
| logistic | 0.01 | GE-HYB+VPRIOR | nrmse_x0 | 0.00 | +0.040 | - |
| logistic | 0.01 | GE-HYB+VPRIOR | nrmse_time | 0.00 | +0.037 | - |
| logistic | 0.01 | GE-HYB+VPRIOR | comp_acc_x0 | 0.00 | -0.250 | - |
| logistic | 0.01 | GE-HYB+VPRIOR | nrmse_in | 0.00 | +0.049 | - |
| pk_bateman | 0.01 | GE-HYB+VPRIOR | nrmse_x0 | 0.00 | +0.062 | - |
| pk_bateman | 0.01 | GE-HYB+VPRIOR | nrmse_time | 0.00 | +0.307 | - |
| pk_bateman | 0.01 | GE-HYB+VPRIOR | comp_acc_x0 | 0.00 | -0.875 | - |
| pk_bateman | 0.01 | GE-HYB+VPRIOR | nrmse_in | 1.00 | -0.005 | - |
