# SemGE — manuscript readiness assessment

*Based on 286 GE runs executed in this session (all 6 systems × 8 conditions × 2 noise levels × 3 seeds,
population 200 × 40 generations), after two corrections to the evaluation and the method described in §3.
Raw data: `results/results.csv`; tables: `results/summary.md`, `results/wins.md`; figures: `results/figures/`.*

## 1. Verdict

**Not ready for a manuscript yet — but the experiment now has a defensible, publishable story if it is
framed correctly and the remaining work in §4 is done.** The story is *not* "semantic guidance makes GE fit
better". It is: **semantic guidance makes GE find the right *behaviour* — sooner and more often, and this
transfers to unseen initial conditions — at a measurable cost in in-domain fit that the Pareto variant
reduces but does not remove.**

The submitted `results_quick.csv` (4 runs, 1 seed) contained no usable evidence; the numbers below replace it.

## 2. What the data support (pooled over systems, noise, seeds; paired against `GE-RMSE`, n = 35)

| claim | evidence | status |
|---|---|---|
| **H3 — semantically correct models appear far earlier.** | median generation of first correct composition: 9 (`GE-RMSE`) → 2–3 (all semantic conditions, 2.5 for `GE-RMSE+PRIOR`) | **supported** |
| **H1a — behaviour transfers to unseen initial conditions.** | composition accuracy on OOD x₀: 0.41 → 0.57 (`GE-HYB+VPRIOR`, Wilcoxon p = 0.006), 0.60 (`GE-NSGA+VPRIOR`, p = 0.010) | **supported** |
| **H1b — lower OOD-x₀ error.** | median nRMSE 0.135 → 0.093 (`GE-HYB+VPRIOR`, win-rate 0.63) / 0.074 (`GE-NSGA+VPRIOR`, win-rate 0.56); pooled p = 0.15 / 0.33; very large per-system effects on von Bertalanffy (0.347 → 0.048) and Gompertz (0.114 → 0.046), harm on Allee and cooling | **suggestive, not significant** — needs more seeds and per-system tests |
| **H1c — time extrapolation.** | median nRMSE 0.057 → 0.034 (`GE-NSGA+VPRIOR`), 0.040 (`GE-RMSE+PRIOR`) | **suggestive** |
| **H4 — priors help, and virtual-x₀ enforcement adds to them.** | `+VPRIOR` beats `+PRIOR` on OOD x₀ (0.093 vs 0.097 hybrid; Bertalanffy 0.073 vs 0.129); `GE-RMSE+PRIOR` costs nothing in-domain (p = 0.70) and improves Bertalanffy 0.347 → 0.098 | **supported qualitatively**, needs power |
| **H5 — semantic-only is insufficient.** | `GE-SEM` in-domain nRMSE 0.307 vs 0.044; blow-ups 6 % | **supported** (clean ablation) |
| **H2 — robustness to noise.** | at 5 % noise the semantic conditions keep OOD composition accuracy (0.50–0.69 vs 0.00 median for baseline) but the oracle check shows the data-side extraction is unreliable there | **mixed**; frame as a limitation, not a claim |
| **Cost: in-domain fit is worse.** | median nRMSE 0.044 → 0.061–0.091 for every semantic condition, p < 0.001; NSGA-II knee 0.076–0.084 does not remove it | **a real negative result that must be reported** |

## 3. What was changed in this session (and why it matters for the write-up)

1. **Held-out scoring now uses an adaptive, stiff-capable integrator** (`simulate_adaptive`, LSODA). The
   fixed-step RK4 previously reported nRMSE = 10 942 for a *valid* stiff candidate on [T, 2T]; that was a
   numerical artefact and would have contaminated every time-extrapolation number.
2. **Priors are enforced on an extended horizon [0, 2T] for the virtual initial conditions**
   (`FitnessConfig.prior_t_factor`). A behavioural prior that is only checked inside the data window cannot
   discourage models that blow up just after it.
3. **NSGA-II selection** (`GEConfig.selection="nsga2"`) with objectives (nRMSE + parsimony, semantic
   distance + prior) and a weight-free knee pick from the prior-feasible Pareto front; phenotype
   de-duplication was required because clones are mutually non-dominated and flooded the front. A second
   pick rule, `nsga_pick="fit"` (best-fitting feasible front member), is implemented but **not yet run** —
   it is the obvious next experiment for removing the in-domain cost.
4. Blow-ups are capped at nRMSE = 5 and reported as a rate; means were previously dominated by them.

## 4. What must happen before writing

**Power.** 3 seeds cannot support the extrapolation claims. Run ≥ 10 seeds at population 300 × 60
generations (the notebook is resumable and parallel; ~1 h on 8 cores). Report per-system paired tests with
Holm correction, not only pooled.

**Close the fit gap.** Run `GE-NSGA+VPRIOR-FIT`. If it matches `GE-RMSE` in-domain while keeping the
OOD gains, the headline becomes "same fit, right behaviour" and the paper is much stronger. If it does not,
the trade-off *is* the finding and Fig. 1 (fit vs extrapolation per system) is the main figure.

**Fix two benchmark weaknesses a reviewer will find.**
- *Logistic* is trivially approximated by nested sines (`sin(sin(sin(1.13x)))` has its zero near K),
  so every condition scores well and the system is uninformative. Either remove `sin` from the grammar for
  non-oscillatory systems (defensible: no oscillatory motif in the data — itself a semantic argument) or
  add a genuinely oscillatory system so `sin` earns its place.
- *Allee* has no prior and its OOD range crosses the bistability threshold; *cooling* is non-autonomous
  with a drifting asymptote. Both are where semantic guidance hurts (Allee 1.95 → 2.6–3.2; cooling
  0.072 → 0.12–0.34). Keep them, but present them explicitly as negative controls that delimit when
  behavioural priors are appropriate (prior must hold across the range on which it is enforced).

**Noise.** The oracle check (notebook §4.1) shows the data-side motif extraction is unreliable at 5 %
noise on two systems. Either report results at 1 % as primary and 5 % as a stress test, or add the
noise-adaptive weighting (`alpha` as a function of the estimated noise level) and evaluate it.

**Exact recovery.** `sympy` was unavailable here, so the `exact` column is empty. Install it locally so
the symbolic-recovery rate can be reported; it is the metric SR reviewers expect first.

## 5. Suggested manuscript framing

*Title idea:* "Behaviour before form: semantic inductive biases for grammatical-evolution ODE discovery".

*Contributions:* (i) a semantic fitness for GE built from Kacprzyk et al.'s motif representation,
(ii) behaviour-level priors that can be enforced where no data exist (virtual initial conditions, extended
horizon), (iii) composition accuracy as an evaluation metric for symbolic regression, (iv) an empirical
characterisation of the fit-vs-behaviour trade-off, including where behavioural priors fail (bistable and
non-autonomous systems).

*Main figures:* Fig. 1 (fit vs OOD error per system), Fig. 3 (paired win-rates), Fig. 4 (generations to
semantic correctness). Table: per-system medians with paired p-values.

*Honest limitations paragraph:* scalar ODEs; extraction reliability at ≥ 5 % noise; fixed-step integration
during search penalises very stiff candidates on the extended horizon; the prior language is small.
