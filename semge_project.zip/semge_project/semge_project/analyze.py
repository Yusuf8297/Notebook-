#!/usr/bin/env python3
"""
Aggregate results/results.csv into the tables used to test the hypotheses.

  python experiments/analyze.py results/results.csv

Outputs (printed and written next to the CSV):
  summary.md     mean (std) of every metric per system x noise x condition
  wins.md        per-system win-rate of each condition against GE-RMSE on the
                 same seed (paired comparison), plus Wilcoxon signed-rank p
  curves.png     median best-fitness curves are not stored per generation in
                 the CSV; use --history to re-run one configuration and plot.
"""

from __future__ import annotations

import argparse
import os
import sys

import numpy as np
import pandas as pd

METRICS = ["nrmse_in", "nrmse_time", "nrmse_x0", "comp_acc_in", "comp_acc_time",
           "comp_acc_x0", "size", "gen_first_match", "exact", "blowup"]
BLOWUP_CAP = 5.0   # nRMSE above this (incl. the 1e3 sentinel) counts as a blow-up and is capped
LOWER_IS_BETTER = {"nrmse_in", "nrmse_time", "nrmse_x0", "size", "gen_first_match"}


def cap_blowups(df: pd.DataFrame) -> pd.DataFrame:
    """Cap nRMSE columns at BLOWUP_CAP and add a `blowup` indicator. Idempotent,
    so every public function below applies it and callers (e.g. the notebook)
    need not."""
    df = df.copy()
    if "condition" in df.columns:
        df["condition"] = df["condition"].astype(str)
    cols = ["nrmse_in", "nrmse_time", "nrmse_x0"]
    if "blowup" not in df.columns:
        df["blowup"] = (df[cols].max(axis=1) >= BLOWUP_CAP).astype(float)
    for c in cols:
        df[c] = df[c].clip(upper=BLOWUP_CAP)
    return df


def _metrics(df: pd.DataFrame):
    return [m for m in METRICS if m in df.columns]


def fmt(m, s):
    return f"{m:.3f} ({s:.3f})" if np.isfinite(m) else "-"


def summary_table(df: pd.DataFrame) -> str:
    df = cap_blowups(df)
    g = df.groupby(["system", "noise", "condition"])
    rows = []
    for key, sub in g:
        row = {"system": key[0], "noise": key[1], "condition": key[2], "n": len(sub)}
        for m in _metrics(df):
            v = sub[m].astype(float)
            v = v.replace([np.inf, -np.inf], np.nan)
            row[m] = fmt(v.mean(), v.std())
        rows.append(row)
    out = pd.DataFrame(rows)
    return out.to_markdown(index=False)


def paired_wins(df: pd.DataFrame, baseline: str = "GE-RMSE") -> str:
    df = cap_blowups(df)
    try:
        from scipy.stats import wilcoxon
    except ImportError:
        wilcoxon = None
    lines = ["| system | noise | condition | metric | win-rate vs baseline | median Δ | p (Wilcoxon) |",
             "|---|---|---|---|---|---|---|"]
    for (sys_, noise), sub in df.groupby(["system", "noise"]):
        base = sub[sub.condition == baseline].set_index("seed")
        for cond, cs in sub.groupby("condition"):
            if cond == baseline:
                continue
            cs = cs.set_index("seed")
            common = base.index.intersection(cs.index)
            if len(common) == 0:
                continue
            for m in ["nrmse_x0", "nrmse_time", "comp_acc_x0", "nrmse_in"]:
                a = cs.loc[common, m].astype(float).values
                b = base.loc[common, m].astype(float).values
                ok = np.isfinite(a) & np.isfinite(b)
                if ok.sum() == 0:
                    continue
                a, b = a[ok], b[ok]
                better = (a < b) if m in LOWER_IS_BETTER else (a > b)
                win = better.mean()
                delta = np.median(a - b)
                p = np.nan
                if wilcoxon is not None and len(a) >= 5 and np.any(a != b):
                    try:
                        p = wilcoxon(a, b).pvalue
                    except ValueError:
                        pass
                lines.append(f"| {sys_} | {noise} | {cond} | {m} | {win:.2f} | {delta:+.3f} | "
                             f"{p:.3f} |" if np.isfinite(p) else
                             f"| {sys_} | {noise} | {cond} | {m} | {win:.2f} | {delta:+.3f} | - |")
    return "\n".join(lines)


def overall(df: pd.DataFrame) -> str:
    df = cap_blowups(df)
    g = df.groupby("condition")
    rows = []
    for cond, sub in g:
        row = {"condition": cond, "runs": len(sub)}
        for m in _metrics(df):
            v = sub[m].astype(float).replace([np.inf, -np.inf], np.nan)
            row[m] = fmt(v.mean(), v.std())
        rows.append(row)
    return pd.DataFrame(rows).to_markdown(index=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="?", default="results/results.csv")
    args = ap.parse_args()
    df = pd.read_csv(args.csv)
    df = df.drop_duplicates(subset=["system", "condition", "noise", "seed"], keep="last")
    df = df.drop(columns=[c for c in ["history"] if c in df.columns])
    outdir = os.path.dirname(args.csv) or "."

    s = "# Overall (all systems, noise levels and seeds pooled)\n\n" + overall(df)
    s += "\n\n# Per system x noise x condition: mean (std)\n\n" + summary_table(df)
    w = "# Paired comparison against GE-RMSE (same system / noise / seed)\n\n" + paired_wins(df)
    with open(os.path.join(outdir, "summary.md"), "w") as f:
        f.write(s + "\n")
    with open(os.path.join(outdir, "wins.md"), "w") as f:
        f.write(w + "\n")
    print(s)
    print()
    print(w)
    print(f"\nwritten to {outdir}/summary.md and {outdir}/wins.md")


if __name__ == "__main__":
    main()
