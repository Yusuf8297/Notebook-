# SemGE — Semantically-Guided Grammatical Evolution for ODE discovery

A research codebase for one novel experiment at the intersection of
**grammatical-evolution-based symbolic regression** (your PhD topic) and the
**semantic modelling** line of work presented in Krzysztof Kacprzyk's
*Transparent Machine Learning for Scientific Discovery* talk
(Semantic ODE, ICLR 2025; EPISODE, ICML 2025; "Towards Transparent Time Series
Forecasting", ICLR 2024).

> **Assumptions.** I did not have access to earlier conversations, so the
> design assumes a standard GE setup (BNF grammar, integer codons, mod-rule
> mapping) applied to *scalar* ODE discovery `dx/dt = f(x, t)`. Everything is
> modular: drop in your own grammar (`Grammar.from_text`), your own GE engine
> (only `Evaluator.evaluate(phenotype)` is needed), or vector-valued systems.

---

## 1. The idea in one paragraph

The talk draws a line between the **syntactic** representation of a dynamical
system (the equation) and its **semantic** representation (what the trajectory
*does*: a composition of shape motifs such as *increasing-concave*, the
transition points between them, and properties like the horizontal asymptote
and half-life). Kacprzyk's Semantic ODE / EPISODE *replace* equations with the
semantic representation. Symbolic regression — and GE in particular — still
optimises a purely syntactic object against a purely numeric loss (RMSE). The
experiment here asks: **what happens if the semantic representation is used as
a fitness signal and as an inductive bias *inside* grammatical evolution, while
keeping the equation as the output?** Concretely, every candidate ODE produced
by the grammar is simulated, its trajectories are decomposed into motifs, and
the candidate is scored on the *semantic distance* to the motif decomposition of
the data — optionally with an expert *semantic prior* ("the concentration must
end in a decreasing-convex motif approaching an asymptote") injected as a
penalty. This is the "easy to inject prior knowledge / edit / provide
feedback" channel from the slides, transplanted into equation discovery, and
it is a behaviour-level constraint that syntactic knobs (term count `n ≤ 5`,
depth limits) cannot express.

## 2. Hypotheses the benchmark tests

| | Hypothesis | Metric in `results.csv` |
|---|---|---|
| H1 | Semantic fitness improves **extrapolation** to unseen initial conditions and to `t > T`, because it rewards the right qualitative mechanism rather than local curve-fit | `nrmse_x0`, `nrmse_time`, `comp_acc_x0`, `comp_acc_time` |
| H2 | Semantic fitness is more **robust to noise**, because the motif decomposition is extracted from a noise-aware smoother and is coarser than pointwise residuals | all metrics at `noise = 0.05` vs `0.01` |
| H3 | Semantic guidance reaches a *qualitatively correct* model in **fewer generations** | `gen_first_match` |
| H4 | A **semantic prior** is a stronger inductive bias than syntactic size limits, and helps even the RMSE baseline | `GE-RMSE+PRIOR` vs `GE-RMSE`; `GE-HYB+PRIOR` vs `GE-HYB` |
| H5 | Semantic-only fitness is **not sufficient** (it under-determines constants) — the hybrid is needed | `GE-SEM` vs `GE-HYB` on `nrmse_in` |

## 3. Experimental design

**Conditions** (identical grammar, engine, population, budget and seeds; only
the fitness differs):

| condition | fitness |
|---|---|
| `GE-RMSE` | trajectory nRMSE (baseline: what GE-SR normally does) |
| `GE-SEM` | semantic distance only (ablation) |
| `GE-HYB` | `0.5·nRMSE + 0.5·semantic` |
| `GE-HYB+PRIOR` | hybrid + expert semantic prior (per system, see `semge/systems.py`) |
| `GE-RMSE+PRIOR` | baseline + prior (isolates the prior's effect) |
| `GE-HYB+VPRIOR` | hybrid + prior, additionally enforced on 6 *virtual* initial conditions spanning the expert's plausible range (no data there), on an extended horizon [0, 2T] |
| `GE-NSGA`, `GE-NSGA+VPRIOR` | NSGA-II with objectives (nRMSE, semantic + prior); final model = knee of the prior-feasible Pareto front |
| `GE-NSGA+VPRIOR-FIT` | as above, final model = best-fitting prior-feasible front member (implemented, not yet benchmarked) |

**Systems** (`semge/systems.py`): logistic, Gompertz, one-compartment PK with
absorption (Bateman; non-autonomous), von Bertalanffy, strong Allee effect
(bistable — OOD initial conditions flip the behaviour, a deliberately hard
case for semantic priors), Newton cooling with drifting ambient. Each has a
training range and an out-of-distribution range of `x0`, mirroring the
`x0 ∈ (0,1)` vs `x0 ∈ (1,1.5)` extrapolation test in the talk.

**Data**: 8 trajectories × 60 samples on `[0, T]`, Gaussian noise at 1 % and 5 %
of the data range, 5 seeds.

**Held-out metrics** per run: in-distribution nRMSE, time-extrapolation nRMSE
on `[T, 2T]`, `x0`-extrapolation nRMSE, and *composition accuracy* — the
fraction of held-out trajectories whose motif composition the discovered
model reproduces (a semantic correctness metric that has no analogue in
standard SR benchmarks). Also expression size, the generation at which the
best individual first became semantically correct, and (if `sympy` is
installed) exact symbolic recovery.

**Analysis**: `experiments/analyze.py` gives mean (std) tables and *paired*
win-rates / Wilcoxon tests against `GE-RMSE` on the same seed.

## 4. What is new here (for the thesis)

1. **Semantic fitness for GE.** Fitness = distance between motif
   decompositions (graded edit distance over motif labels + transition-point
   mismatch + asymptote / half-life mismatch). `semge/motifs.py`.
2. **Semantic priors as behaviour-level constraints.** `{"ends_with": "-+h",
   "max_motifs": 3, "monotone": "+", "asymptote_range": (lo, hi)}` (motif
   patterns take `*` wildcards, e.g. `"**h"` = reaches an asymptote from either
   side) — a channel for expert knowledge that grammars cannot express.
   `prior_violation()`. With `FitnessConfig.prior_x0` the prior is also
   enforced on *virtual* initial conditions where no data exist
   (condition `GE-HYB+VPRIOR`), which is how SemGE targets extrapolation.
3. **Noise-aware motif extraction.** Smoothing spline with a robust noise
   estimate, derivative dead-zones widened to 2 s.e. of the derivative estimates
   (via perturbation replicates), minimum-length merging and curvature-chatter
   collapse. This is itself a contribution/ablation axis: the talk's methods
   assume the composition is *learned*; here it must be *read off* noisy data.
4. **Composition accuracy** as an evaluation metric for symbolic regression.

Natural follow-ups already supported by the code: semantic *lexicase* or
NSGA-II selection (RMSE and semantic distance as separate objectives), semantic
*repair* operators (mutate toward the missing motif), using the semantic
representation to *prune the grammar* (e.g. drop `sin` when no oscillatory
motifs are present), and multi-trajectory *personalised* systems à la EPISODE
where the prior depends on covariates.

## 5. Layout

```
semge/
  grammar.py     BNF parser + GE mapping (DEFAULT_ODE_GRAMMAR)
  expression.py  phenotype -> protected numpy callable f(x, t)
  simulate.py    batched RK4 over many initial conditions
  motifs.py      semantic representation, semantic distance, priors   <-- core novelty
  fitness.py     FitnessConfig / Evaluator (rmse | semantic | hybrid, + prior)
  evolution.py   GE loop (tournament, crossover, mutation, elitism, NM constant refinement)
  systems.py     benchmark ODEs + noisy dataset generation
experiments/
  run_benchmark.py   full factorial run -> results/results.csv (supports --jobs)
  analyze.py         summary tables + paired tests -> summary.md, wins.md
  demo.py            one system, baseline vs semantic, figure
tests/test_semge.py
```

## 6. Running

**Notebook (recommended):** open `SemGE_Experiment.ipynb` in Jupyter / Colab and run top to
bottom. It walks through the systems, the semantic representation, the fitness, the full
benchmark (resumable, parallel) and the analysis of every hypothesis. Set `QUICK = False` in
section 2 for the real experiment.

**Command line:**

```bash
pip install numpy scipy pandas matplotlib tabulate   # sympy optional (exact-recovery metric)
python tests/test_semge.py                          # ~30 s
python experiments/run_benchmark.py --quick         # ~1 min smoke test
python experiments/demo.py --system pk_bateman      # figure in results/demo.png

# full benchmark (360 runs; ~1-2 min each at pop=300, gens=60 -> use --jobs)
python experiments/run_benchmark.py --jobs 8
python experiments/analyze.py results/results.csv
```

Key knobs: `FitnessConfig.alpha` (hybrid weight), `w_comp/w_time/w_prop`
(semantic distance weights), `prior_weight`, `semantic_representation(...)`
tolerances, `GEConfig` (population, generations, genome length, depth).

## 7. Current results and manuscript readiness

See `results/READINESS_ASSESSMENT.md` for the full assessment of the 286-run
experiment (3 seeds, pop 200 × 40 gens) executed with this code, including what
is supported, what is not, and what must be done before writing. Short version:
semantic guidance finds behaviourally correct models earlier (generation 2–3
vs 9) and more often on unseen initial conditions (composition accuracy
0.41 → 0.57–0.60, p ≤ 0.01), at a significant cost in in-domain fit; OOD-error
gains are large on some systems but not yet significant pooled over 3 seeds.

## 7a. Fitness validation (oracle check)

Before trusting a search result, check that the fitness *could* find the
truth: `tests/test_semge.py::test_oracle_truth_beats_distractors_at_low_noise`
verifies that, on every benchmark system at 1 % noise, the true RHS scores
better under the hybrid + prior fitness than six plausible wrong models
(exponential, constant, nested-sine artefact, `sqrt(2.9x) − x`, ...). At 5 %
noise this fails on logistic and Gompertz: the motif composition read off
the noisy data is sometimes wrong (a short initial convex phase is lost), so a
close-but-wrong model can edge out the truth. The notebook (section 4.1)
prints this table for every condition; H2 is exactly the question of how much
this costs GE in practice, and `FitnessConfig.alpha` is the knob.

## 8. Known limitations / things to decide

* Motif extraction is reliable at ≤ 1 % noise on 60 samples; at 5–10 % the
  composition of the *data* is sometimes a near-miss (graded distance softens
  this). A consensus across trajectories, or learning the composition as in
  Semantic ODE, are options.
* Scalar ODEs only. Vector systems need a per-dimension semantic distance.
* Fitness costs ~2–4 ms per candidate (simulation dominates); semantic
  extraction on clean candidate trajectories is cheap (no smoothing).
* The `allee` system is included as a *negative control*: a prior that holds
  in the training range is wrong out of distribution.
