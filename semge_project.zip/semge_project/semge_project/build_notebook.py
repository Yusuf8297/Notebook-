"""Generates SemGE_Experiment.ipynb (run once; the notebook is the deliverable)."""
import json

cells = []


def md(src):
    cells.append({"cell_type": "markdown", "metadata": {}, "source": src.strip("\n")})


def code(src):
    cells.append({"cell_type": "code", "metadata": {}, "execution_count": None,
                  "outputs": [], "source": src.strip("\n")})


# ----------------------------------------------------------------------------- 0
md(r"""
# SemGE — Semantically-Guided Grammatical Evolution for ODE discovery
### Full experiment notebook

**Research question.** Grammatical-evolution symbolic regression (GE-SR) searches a *syntactic*
object (an equation) with a purely numeric loss (RMSE). Kacprzyk & van der Schaar's *semantic
representation* of a trajectory (motif composition such as $(s_{+-b},\,s_{--b},\,s_{-+h})$,
transition points, asymptote, half-life) captures what a dynamical system *does*.
**What happens if that semantic representation is used as a fitness signal and an inductive bias
inside GE, while the equation remains the output?**

Hypotheses tested here (details in `README.md`):

| | Hypothesis | Metric |
|---|---|---|
| H1 | Semantic fitness improves extrapolation to unseen $x_0$ and to $t>T$ | `nrmse_x0`, `nrmse_time`, `comp_acc_*` |
| H2 | Semantic fitness is more robust to observation noise | all metrics at noise 5 % vs 1 % |
| H3 | Semantic guidance reaches a qualitatively correct model sooner | `gen_first_match` |
| H4 | A semantic *prior* (esp. enforced on **virtual** initial conditions) is a stronger inductive bias than syntactic size limits | `+PRIOR`, `+VPRIOR` vs their base |
| H5 | Semantic-only fitness under-determines constants — the hybrid is needed | `GE-SEM` vs `GE-HYB` |

**How to run.** Execute top to bottom. Section 2 has a `QUICK` switch: `True` runs a
~5-minute miniature of the whole pipeline (2 systems, 2 conditions, 1 seed) so you can check that
everything works; `False` runs the full factorial design (6 systems × 9 conditions × 2 noise
levels × 5 seeds = 540 GE runs, roughly 1–2 min each on one core — use `N_JOBS`). Results are
appended to a CSV after every run, so the benchmark is **resumable**: re-running the cell skips
finished configurations.
""")

# ----------------------------------------------------------------------------- 1
md(r"""
## 1. Setup

The notebook expects to live in the root of `semge_project/` (next to the `semge/` package).
On Google Colab, upload `semge_project.zip` and run the first cell to unpack it.
""")
code(r"""
import os, sys, zipfile, glob

# --- Colab / fresh-environment bootstrap: unpack the project if needed
if not os.path.isdir("semge") and os.path.exists("semge_project.zip"):
    zipfile.ZipFile("semge_project.zip").extractall(".")
    os.chdir("semge_project")
elif not os.path.isdir("semge") and os.path.isdir("semge_project"):
    os.chdir("semge_project")

PROJECT_ROOT = os.path.abspath(".")
assert os.path.isdir("semge"), "run this notebook from the semge_project folder"
sys.path.insert(0, PROJECT_ROOT)
sys.path.insert(0, os.path.join(PROJECT_ROOT, "experiments"))

# --- dependencies (all pure-Python wheels; sympy is optional)
try:
    import numpy, scipy, pandas, matplotlib, tabulate  # noqa
except ImportError:
    import subprocess
    subprocess.run([sys.executable, "-m", "pip", "install", "-q",
                    "numpy", "scipy", "pandas", "matplotlib", "tabulate"], check=False)

import json, time, warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
warnings.filterwarnings("ignore")
%matplotlib inline

from semge import (Evaluator, FitnessConfig, GEConfig, Grammar, GrammaticalEvolution,
                   compile_expression, simulate, systems)
from semge.grammar import DEFAULT_ODE_GRAMMAR
from semge.motifs import (semantic_representation, semantic_distance, composition_distance,
                          prior_violation, composition_string)
from semge.fitness import composition_accuracy, nrmse
import importlib
import run_benchmark as rb
import analyze as an
import make_figures
# always pick up the code that is on disk, even if the kernel imported an older copy earlier
for _m in (rb, an, make_figures):
    importlib.reload(_m)
assert hasattr(an, "cap_blowups"), "stale experiments/analyze.py -- replace it with the current version"

print("project root:", PROJECT_ROOT)
print("analyze.py  :", an.__file__)
print("systems     :", list(systems.SYSTEMS))
print("conditions  :", list(rb.CONDITIONS))
""")

# ----------------------------------------------------------------------------- 2
md(r"""
## 2. Experiment configuration

Set `QUICK = False` for the real experiment. Everything else can stay at its default.
""")
code(r"""
QUICK = True            # True: ~5 min sanity run.  False: full factorial design.

if QUICK:
    SYSTEMS    = ["logistic", "pk_bateman"]
    CONDITIONS = ["GE-RMSE", "GE-HYB+VPRIOR"]
    NOISE      = [0.01]
    SEEDS      = [0]
    POP, GENS  = 120, 20
else:
    SYSTEMS    = list(systems.SYSTEMS)          # 6 benchmark ODEs
    CONDITIONS = list(rb.CONDITIONS)            # 6 fitness regimes
    NOISE      = [0.01, 0.05]
    SEEDS      = [0, 1, 2, 3, 4]
    POP, GENS  = 300, 60

N_JOBS      = max(1, (os.cpu_count() or 2) - 1)   # parallel GE runs
RESULTS_CSV = "results/results_quick.csv" if QUICK else "results/results.csv"
os.makedirs("results", exist_ok=True)

n_runs = len(SYSTEMS) * len(CONDITIONS) * len(NOISE) * len(SEEDS)
print(f"{n_runs} GE runs  |  pop={POP} gens={GENS}  |  jobs={N_JOBS}  |  -> {RESULTS_CSV}")
""")

# ----------------------------------------------------------------------------- 3
md(r"""
## 3. The benchmark systems and their semantic representations

Each system has a **training range** of initial conditions, an **out-of-distribution (OOD)
range** used to test extrapolation (the $x_0\in(0,1)$ vs $x_0\in(1,1.5)$ test from the talk),
and an optional **expert semantic prior** — a statement about behaviour such as
*"the trajectory ends with a decreasing-convex motif that approaches an asymptote"*
(`{"ends_with": "-+h"}`), or with wildcards, *"it reaches a horizontal asymptote from either side"*
(`{"ends_with": "**h"}`). Priors are written to hold over the whole `prior_holds_for_x0` range,
because `GE-HYB+VPRIOR` enforces them on virtual initial conditions there.
""")
code(r"""
rows = []
for name, s in systems.SYSTEMS.items():
    rows.append(dict(system=name, equation=f"dx/dt = {s.formula}", x0_train=s.x0_train,
                     x0_OOD=s.x0_test, T=s.t_end, prior=s.prior, prior_holds_for_x0=s.prior_x0))
pd.DataFrame(rows)
""")
code(r"""
# motif composition of every system, on clean and on noisy (1 %) data
fig, axes = plt.subplots(2, 3, figsize=(14, 7))
for ax, (name, s) in zip(axes.ravel(), systems.SYSTEMS.items()):
    d = systems.make_dataset(s, n_traj=5, n_points=60, noise=0.01, seed=0)
    for i in range(5):
        r_clean = semantic_representation(d.t, d.X_clean[i], smooth=False)
        r_noisy = semantic_representation(d.t, d.X[i], smooth=True)
        ax.plot(d.t, d.X[i], ".", ms=3, alpha=0.5)
        ax.plot(d.t, d.X_clean[i], "-", lw=1,
                label=f"x0={d.x0[i]:.2f} {r_clean}" + ("" if r_noisy.composition == r_clean.composition else "  [noisy≠]"))
        # mark transition points
        ax.plot(r_clean.transition_t, r_clean.transition_x, "k|", ms=8)
    ax.set_title(f"{name}: dx/dt = {s.formula}", fontsize=9)
    ax.legend(fontsize=6)
plt.tight_layout()
plt.show()
""")

md(r"""
### 3.1 How reliably can the composition be read off noisy data?

This matters because the semantic fitness compares candidates against the representation
extracted from the *observed* (noisy) trajectories. The extractor uses a smoothing spline with
a robust noise estimate and widens the derivative dead-zones to 2 s.e. (perturbation
replicates), so the composition should be stable at low noise and degrade gracefully.
""")
code(r"""
noise_levels = [0.0, 0.01, 0.02, 0.05, 0.1]
rec = []
for name, s in systems.SYSTEMS.items():
    for nz in noise_levels:
        d = systems.make_dataset(s, n_traj=8, n_points=60, noise=nz, seed=1)
        exact, graded = [], []
        for i in range(8):
            a = semantic_representation(d.t, d.X_clean[i], smooth=False).composition
            b = semantic_representation(d.t, d.X[i], smooth=True).composition
            exact.append(a == b)
            graded.append(1 - composition_distance(a, b))
        rec.append(dict(system=name, noise=nz, exact_match=np.mean(exact), graded_similarity=np.mean(graded)))
ext = pd.DataFrame(rec)
piv = ext.pivot(index="system", columns="noise", values="exact_match")
display(piv.round(2))
ax = ext.pivot(index="noise", columns="system", values="graded_similarity").plot(marker="o", figsize=(7, 3.5))
ax.set_ylabel("graded composition similarity"); ax.set_ylim(0, 1.05); ax.grid(alpha=.3)
plt.show()
""")

# ----------------------------------------------------------------------------- 4
md(r"""
## 4. The semantic fitness, illustrated

For a reference trajectory (logistic growth) we score a few hand-written candidate ODEs with
(a) trajectory nRMSE and (b) the semantic distance. Note how the semantic distance rewards a
candidate with the **right behaviour but wrong constants** more than one that fits well
locally but has the wrong mechanism.
""")
code(r"""
s = systems.SYSTEMS["logistic"]
train = systems.make_dataset(s, n_traj=8, n_points=60, noise=0.01, seed=0)
ev_r = Evaluator(train, FitnessConfig(mode="rmse"))
ev_h = Evaluator(train, FitnessConfig(mode="hybrid", prior=s.prior))

candidates = {
    "truth            x*(1 - x/2.8)": "x*(1 - x/2.8)",
    "right mechanism  0.7*x*(1 - x/3.5)": "0.7*x*(1 - x/3.5)",
    "saturating       sqrt(2.9*x) - x": "sqrt(2.9*x) - x",
    "pure exponential 0.3*x": "0.3*x",
    "linear drift     0.3": "0.3",
    "oscillator       sin(3*t)": "sin(3*t)",
    "curve-fit artefact sin(sin(1.14*x))": "sin(sin(1.14*x))",
}
rows = []
for label, ph in candidates.items():
    sc = ev_h.evaluate(ph)
    X = ev_h.simulate_phenotype(ph)
    comp = semantic_representation(train.t, X[0], smooth=False)
    rows.append(dict(candidate=label, nRMSE=round(sc["nrmse"], 4), semantic_dist=round(sc["semantic"], 3),
                     prior_violation=round(sc["prior"], 3), composition_x0_lo=str(comp)))
pd.DataFrame(rows)
""")

md(r"""
### 4.1 Oracle check — does the *true* equation win under each fitness?

A fitness function is only usable for search if the ground truth scores better than plausible
wrong models. The table shows, for every system, noise level and condition, the fitness of the
true RHS and of the best of six hand-written distractors; `truth_wins` should be `True`. Where
it is `False` (expect this at 5 % noise on some systems) the semantic reference extracted from the
noisy data is itself unreliable — that is the limitation H2 probes, and `FitnessConfig.alpha`
(the RMSE weight of the hybrid) is the knob to trade it off.
""")
code(r"""
DISTRACTORS = ["0.3*x", "0.3", "sin(sin(1.14*x))", "exp(-0.2*t*x)", "sqrt(2.9*x)-x", "-0.5*x+1"]
rows = []
for name, s in systems.SYSTEMS.items():
    for nz in sorted(set(NOISE) | {0.01}):
        train = systems.make_dataset(s, n_traj=8, n_points=60, noise=nz, seed=0)
        for cname in CONDITIONS:
            cond = rb.CONDITIONS[cname]
            px0 = np.linspace(*s.prior_x0, cond["virtual_x0"]) if cond.get("virtual_x0") and s.prior else None
            ev = Evaluator(train, FitnessConfig(mode=cond["mode"], prior=s.prior if cond["prior"] else None, prior_x0=px0))
            truth = ev.evaluate(s.formula.replace("^", "**"))["fitness"]
            wrong = {d: ev.evaluate(d)["fitness"] for d in DISTRACTORS if d != s.formula}
            b = min(wrong, key=wrong.get)
            rows.append(dict(system=name, noise=nz, condition=cname, truth_fitness=round(truth, 3),
                             best_distractor=b, distractor_fitness=round(wrong[b], 3), truth_wins=truth < wrong[b]))
oracle = pd.DataFrame(rows)
display(oracle.pivot_table(index=["system", "noise"], columns="condition", values="truth_wins", aggfunc="first"))
oracle[~oracle.truth_wins]
""")

# ----------------------------------------------------------------------------- 5
md(r"""
## 5. Run the benchmark

Six fitness regimes share the same grammar, engine, population, budget and seeds:

| condition | fitness |
|---|---|
| `GE-RMSE` | trajectory nRMSE (baseline) |
| `GE-SEM` | semantic distance only (ablation) |
| `GE-HYB` | 0.5·nRMSE + 0.5·semantic |
| `GE-HYB+PRIOR` | hybrid + expert semantic prior |
| `GE-RMSE+PRIOR` | baseline + prior (isolates the prior) |
| `GE-HYB+VPRIOR` | hybrid + prior **also enforced on 6 virtual initial conditions** spanning the expert's plausible range, where no data exist, on an extended horizon [0, 2T] |
| `GE-NSGA` / `GE-NSGA+VPRIOR` | NSGA-II with fit (nRMSE) and behaviour (semantic + prior) as two objectives; final model = weight-free knee of the prior-feasible Pareto front |
| `GE-NSGA+VPRIOR-FIT` | same search, final model = best-fitting prior-feasible front member |

The cell below is resumable: finished (system, condition, noise, seed) combinations are skipped.
""")
code(r"""
from multiprocessing import Pool

def already_done(csv):
    if not os.path.exists(csv):
        return set()
    d = pd.read_csv(csv)
    return set(zip(d.system, d.condition, d.noise, d.seed))

done = already_done(RESULTS_CSV)
jobs = [(sname, cname, nz, seed, POP, GENS, False)
        for sname in SYSTEMS for nz in NOISE for seed in SEEDS for cname in CONDITIONS
        if (sname, cname, nz, seed) not in done]
print(f"{len(done)} runs already in {RESULTS_CSV}; {len(jobs)} to go")

t_start = time.time()
def _save(row):
    pd.DataFrame([row]).to_csv(RESULTS_CSV, mode="a", index=False, header=not os.path.exists(RESULTS_CSV))
    print(f"[{time.time()-t_start:6.0f}s] {row['system']:12s} {row['condition']:14s} "
          f"noise={row['noise']} seed={row['seed']} | in={row['nrmse_in']:.3f} "
          f"x0={row['nrmse_x0']:.3f} comp_x0={row['comp_acc_x0']:.2f} | {row['phenotype']}", flush=True)

if N_JOBS > 1 and len(jobs) > 1:
    with Pool(N_JOBS) as pool:
        for row in pool.imap_unordered(rb._run_job, jobs):
            _save(row)
else:
    for job in jobs:
        _save(rb._run_job(job))
print("done")
""")

# ----------------------------------------------------------------------------- 6
md(r"""
## 6. Results

### 6.1 Load and tidy
""")
code(r"""
df = pd.read_csv(RESULTS_CSV)
df = df.drop_duplicates(subset=["system", "condition", "noise", "seed"], keep="last")
df["condition"] = pd.Categorical(df["condition"], categories=[c for c in rb.CONDITIONS if c in set(df.condition)])
METRICS = ["nrmse_in", "nrmse_time", "nrmse_x0", "comp_acc_in", "comp_acc_time", "comp_acc_x0", "size", "gen_first_match"]
# blown-up models (nRMSE = 1000 sentinel) are capped so means stay readable; count them separately
for m in ["nrmse_in", "nrmse_time", "nrmse_x0"]:
    df[m + "_blowup"] = df[m] >= 100
    df[m] = df[m].clip(upper=5.0)
print(len(df), "runs")
df.groupby("condition", observed=True)[["nrmse_in_blowup", "nrmse_time_blowup", "nrmse_x0_blowup"]].mean().round(2)
""")

md(r"""
### 6.2 Headline table — mean (std) over systems, noise levels and seeds
""")
code(r"""
def mean_std(g):
    return g.agg(lambda v: f"{np.nanmean(v):.3f} ({np.nanstd(v):.3f})")
headline = df.groupby("condition", observed=True)[METRICS].apply(mean_std)
headline
""")

md(r"""
### 6.3 H1 — extrapolation (per system)
Lower is better for nRMSE; higher is better for composition accuracy.
""")
code(r"""
def bar_by_system(metric, ylabel, log=False):
    piv = df.groupby(["system", "condition"], observed=True)[metric].mean().unstack("condition")
    err = df.groupby(["system", "condition"], observed=True)[metric].sem().unstack("condition")
    ax = piv.plot.bar(yerr=err, figsize=(12, 4), capsize=2, width=0.8)
    ax.set_ylabel(ylabel); ax.grid(axis="y", alpha=.3); ax.legend(fontsize=7, ncol=3)
    if log: ax.set_yscale("log")
    plt.xticks(rotation=0); plt.tight_layout(); plt.show()
    return piv

_ = bar_by_system("nrmse_x0", "nRMSE, OOD initial conditions", log=True)
_ = bar_by_system("nrmse_time", "nRMSE, time extrapolation t in [T, 2T]", log=True)
_ = bar_by_system("comp_acc_x0", "composition accuracy, OOD x0")
""")

md(r"""
### 6.4 Paired comparison against the RMSE baseline (same system / noise / seed)
Win-rate = fraction of seeds on which the condition beat `GE-RMSE`; Wilcoxon signed-rank p when ≥ 5 seeds.
""")
code(r"""
from IPython.display import Markdown
Markdown(an.paired_wins(df.astype({"condition": str})))
""")

md(r"""
### 6.5 H2 — robustness to noise
""")
code(r"""
if len(NOISE) > 1:
    fig, axes = plt.subplots(1, 3, figsize=(14, 3.8))
    for ax, m in zip(axes, ["nrmse_in", "nrmse_x0", "comp_acc_x0"]):
        piv = df.groupby(["noise", "condition"], observed=True)[m].mean().unstack("condition")
        piv.plot(marker="o", ax=ax); ax.set_title(m); ax.grid(alpha=.3); ax.legend(fontsize=6)
    plt.tight_layout(); plt.show()
else:
    print("only one noise level in this run — set QUICK=False for H2")
""")

md(r"""
### 6.6 H3 — how fast does each regime become *qualitatively* right?
`gen_first_match` is the first generation at which the best individual reproduced the true motif
composition on every training trajectory (NaN = never within the budget). We also plot the median
best-fitness curves (per-generation history is stored with every run).
""")
code(r"""
gfm = df.groupby(["system", "condition"], observed=True)["gen_first_match"].agg(
    median="median", never=lambda v: v.isna().mean()).unstack("condition")
display(gfm.round(2))

fig, axes = plt.subplots(1, 2, figsize=(12, 4))
for cond, sub in df.groupby("condition", observed=True):
    H = [pd.DataFrame(json.loads(h)) for h in sub["history"]]
    L = min(len(h) for h in H)
    nr = np.median([h["best_nrmse"].values[:L] for h in H], axis=0)
    se = np.nanmedian([h["best_semantic"].values[:L] for h in H], axis=0)
    axes[0].plot(nr, label=cond); axes[1].plot(se, label=cond)
axes[0].set_title("median train nRMSE of best individual"); axes[0].set_yscale("log")
axes[1].set_title("median semantic distance of best individual (where tracked)")
for ax in axes: ax.set_xlabel("generation"); ax.grid(alpha=.3); ax.legend(fontsize=7)
plt.tight_layout(); plt.show()
""")

md(r"""
### 6.7 H4 / H5 — ablations
""")
code(r"""
pairs = [("GE-RMSE", "GE-RMSE+PRIOR", "prior alone"),
         ("GE-HYB", "GE-HYB+PRIOR", "prior on top of hybrid"),
         ("GE-HYB+PRIOR", "GE-HYB+VPRIOR", "virtual-x0 enforcement"),
         ("GE-SEM", "GE-HYB", "adding RMSE to semantic-only"),
         ("GE-HYB+VPRIOR", "GE-NSGA+VPRIOR", "NSGA-II instead of fixed-weight hybrid"),
         ("GE-NSGA+VPRIOR", "GE-NSGA+VPRIOR-FIT", "fit-first pick from the Pareto front")]
rows = []
present = set(df.condition.astype(str))
for a, b, what in pairs:
    if a in present and b in present:
        A = df[df.condition == a].set_index(["system", "noise", "seed"])
        B = df[df.condition == b].set_index(["system", "noise", "seed"])
        idx = A.index.intersection(B.index)
        for m in ["nrmse_in", "nrmse_x0", "comp_acc_x0"]:
            d = (B.loc[idx, m] - A.loc[idx, m]).astype(float)
            better = (d < 0) if m.startswith("nrmse") else (d > 0)
            rows.append(dict(ablation=what, base=a, variant=b, metric=m, n=len(idx),
                             median_delta=round(d.median(), 4), variant_wins=round(better.mean(), 2)))
pd.DataFrame(rows) if rows else print("ablation pairs not present in this run (set QUICK=False)")
""")

md(r"""
### 6.8 What did GE actually discover?
Best equation per (system, condition) by OOD-$x_0$ error, with its semantic score.
""")
code(r"""
best = (df.sort_values("nrmse_x0")
          .groupby(["system", "condition"], observed=True).head(1)
          [["system", "condition", "noise", "seed", "phenotype", "size", "nrmse_in", "nrmse_x0", "comp_acc_x0", "train_semantic"]]
          .sort_values(["system", "condition"]))
pd.set_option("display.max_colwidth", 80)
best.reset_index(drop=True)
""")

md(r"""
### 6.9 Visual check on one system
Training fit (left) and behaviour on out-of-distribution initial conditions (right) for the best
model of each condition.
""")
code(r"""
SHOW_SYSTEM = SYSTEMS[0]
s = systems.SYSTEMS[SHOW_SYSTEM]
train = systems.make_dataset(s, n_traj=6, n_points=60, noise=NOISE[0], seed=0)
ood = systems.make_dataset(s, n_traj=6, n_points=60, noise=0.0, split="test", seed=7)
sub = best[best.system == SHOW_SYSTEM]

fig, axes = plt.subplots(1, 2, figsize=(12, 4))
for i in range(6):
    axes[0].plot(train.t, train.X[i], ".", color="0.6", ms=3)
    axes[1].plot(ood.t, ood.X_clean[i], ":", color="k", lw=1)
for _, r in sub.iterrows():
    f = compile_expression(r.phenotype)
    Xi = simulate(f, train.x0, train.t); Xo = simulate(f, ood.x0, ood.t)
    l = axes[0].plot(train.t, Xi.T, lw=1)[0]
    axes[0].plot([], [], color=l.get_color(), label=f"{r.condition}: {r.phenotype}")
    axes[1].plot(ood.t, Xo.T, lw=1, color=l.get_color())
axes[0].set_title(f"{SHOW_SYSTEM}: training range (dots = data)"); axes[0].legend(fontsize=6)
axes[1].set_title("OOD initial conditions (dotted = truth)")
ymax = 1.5 * np.max(np.abs(ood.X_clean)); axes[1].set_ylim(-ymax, ymax)
plt.tight_layout(); plt.show()
""")

# ----------------------------------------------------------------------------- 7
md(r"""
## 7. Interactive: edit the prior and re-run one system

Because the prior is a *behavioural* statement, you can edit it without touching the grammar.
Try a wrong prior (e.g. `{"ends_with": "++u"}` on logistic) to see the model being pushed toward
the wrong mechanism — that is the "editing" channel from the talk, now inside SR.
""")
code(r"""
SYSTEM = "logistic"
PRIOR  = {"ends_with": "**h", "max_motifs": 2}     # <- edit me ('*' = wildcard)
MODE   = "hybrid"
s = systems.SYSTEMS[SYSTEM]
train = systems.make_dataset(s, n_traj=8, n_points=60, noise=0.01, seed=0)
vx0 = np.linspace(*s.prior_x0, 6)
ev = Evaluator(train, FitnessConfig(mode=MODE, prior=PRIOR, prior_x0=vx0))
ge = GrammaticalEvolution(Grammar.from_text(DEFAULT_ODE_GRAMMAR), ev,
                          GEConfig(pop_size=POP, generations=GENS, seed=0, verbose=False))
res = ge.run()
b = res.best
print("discovered: dx/dt =", b.phenotype)
print("train nRMSE =", round(b.scores["nrmse"], 4), "| prior violation =", round(b.scores["prior"], 3))
print("held-out:", {k: round(v, 3) for k, v in rb.evaluate_on_heldout(b.phenotype, s, 0.01, 0).items()})
""")

# ----------------------------------------------------------------------------- 8
md(r"""
## 8. Export

Markdown tables for the thesis / paper are written to `results/summary.md` and `results/wins.md`,
and manuscript figures to `results/figures/` (`experiments/make_figures.py`).
""")
code(r"""
importlib.reload(an); importlib.reload(make_figures)
if RESULTS_CSV == "results/results.csv":
    make_figures.main()
else:
    print("figures: run  python experiments/make_figures.py", RESULTS_CSV)
os.makedirs("results", exist_ok=True)
export = df.astype({"condition": str}).copy()
if "blowup" not in export.columns:          # analyze.py computes this itself; belt and braces
    export["blowup"] = (export[["nrmse_in", "nrmse_time", "nrmse_x0"]].max(axis=1) >= 5.0).astype(float)
with open("results/summary.md", "w") as f:
    f.write("# Overall\n\n" + an.overall(export) + "\n\n# Per system x noise x condition\n\n"
            + an.summary_table(export) + "\n")
with open("results/wins.md", "w") as f:
    f.write(an.paired_wins(export) + "\n")
print("written results/summary.md and results/wins.md from", RESULTS_CSV)
""")

md(r"""
## 9. Reading the results — checklist

* **H1 holds** if `GE-HYB*` conditions have lower `nrmse_x0` / `nrmse_time` and higher `comp_acc_x0` than `GE-RMSE` with win-rates clearly above 0.5 and small Wilcoxon p.
* **H2 holds** if the gap to `GE-RMSE` widens from noise 0.01 to 0.05.
* **H3 holds** if `gen_first_match` is smaller (and "never" rarer) for semantic conditions.
* **H4 holds** if `+PRIOR` beats its base and `+VPRIOR` beats `+PRIOR` on `nrmse_x0` — and note the `allee` system has *no* prior: it is the negative control where a prior valid in-range would be wrong out-of-range.
* **H5 holds** if `GE-SEM` has poor `nrmse_in` but decent `comp_acc_*`, and `GE-HYB` fixes the former without losing the latter.

If a hypothesis fails, the ablation table in 6.7 tells you which ingredient is responsible.
""")

nb = {"cells": cells, "metadata": {
    "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
    "language_info": {"name": "python"}}, "nbformat": 4, "nbformat_minor": 5}
for c in nb["cells"]:
    c["source"] = c["source"].splitlines(keepends=True)
with open("SemGE_Experiment.ipynb", "w") as f:
    json.dump(nb, f, indent=1)
print("wrote SemGE_Experiment.ipynb with", len(cells), "cells")
