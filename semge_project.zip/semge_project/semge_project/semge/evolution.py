"""
A compact, dependency-free grammatical evolution engine.

Genotype: list of integer codons in [0, codon_max).
Operators: tournament selection, one-point crossover (in the effective
region of the genome), per-codon mutation, elitism, invalid-individual
replacement. Optionally the numeric literals of the final best individual
are refined with Nelder-Mead (applied identically to every experimental
condition, so it does not confound the comparison).
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
from scipy.optimize import minimize

from .fitness import Evaluator
from .grammar import Grammar

_NUM_RE = re.compile(r"(?<![\w.])(-?\d+\.\d+|-?\d+)(?![\w.])")


@dataclass
class GEConfig:
    pop_size: int = 200
    generations: int = 40
    genome_len: int = 60
    codon_max: int = 256
    tournament: int = 4
    p_crossover: float = 0.8
    p_mutation: float = 0.03        # per codon
    elitism: int = 4
    max_depth: int = 10
    refine_constants: bool = True
    selection: str = "tournament"   # "tournament" (scalar fitness) | "nsga2" (fit vs behaviour as two objectives)
    nsga_pick: str = "knee"         # final model from the Pareto front: "knee" (weight-free compromise)
                                    # or "fit" (lowest nRMSE among prior-feasible members)
    seed: int = 0
    verbose: bool = False
    time_limit_s: Optional[float] = None


@dataclass
class Individual:
    genome: np.ndarray
    phenotype: Optional[str] = None
    used: int = 0
    scores: Dict[str, float] = field(default_factory=dict)

    @property
    def fitness(self) -> float:
        return self.scores.get("fitness", 1e3)


@dataclass
class RunResult:
    best: Individual
    history: List[Dict[str, float]]
    evaluations: int
    wall_time_s: float
    gen_first_composition_match: Optional[int] = None


class GrammaticalEvolution:
    def __init__(self, grammar: Grammar, evaluator: Evaluator, cfg: GEConfig,
                 comp_monitor: Optional[Callable[[str], bool]] = None):
        """
        comp_monitor(phenotype) -> True if the candidate's composition matches
        the ground truth on the training trajectories; used only to log the
        generation at which a qualitatively correct model first appears.
        """
        self.g = grammar
        self.ev = evaluator
        self.cfg = cfg
        self.rng = np.random.default_rng(cfg.seed)
        self.comp_monitor = comp_monitor

    # --------------------------------------------------------------- helpers
    def _random_genome(self) -> np.ndarray:
        return self.rng.integers(0, self.cfg.codon_max, size=self.cfg.genome_len)

    def _decode(self, ind: Individual) -> None:
        ind.phenotype, ind.used = self.g.map(ind.genome, self.cfg.max_depth)
        ind.scores = self.ev.evaluate(ind.phenotype)

    def _tournament(self, pop: List[Individual]) -> Individual:
        idx = self.rng.integers(0, len(pop), size=self.cfg.tournament)
        return min((pop[i] for i in idx), key=lambda z: z.fitness)

    def _crossover(self, a: Individual, b: Individual) -> np.ndarray:
        if self.rng.random() > self.cfg.p_crossover:
            return a.genome.copy()
        # cut inside the effective (used) region so crossover is meaningful
        la = max(1, min(a.used, len(a.genome) - 1))
        lb = max(1, min(b.used, len(b.genome) - 1))
        ca = self.rng.integers(1, la + 1)
        cb = self.rng.integers(1, lb + 1)
        child = np.concatenate([a.genome[:ca], b.genome[cb:]])
        if len(child) < self.cfg.genome_len:
            child = np.concatenate([child, self._random_genome()[: self.cfg.genome_len - len(child)]])
        return child[: self.cfg.genome_len]

    def _mutate(self, genome: np.ndarray) -> np.ndarray:
        mask = self.rng.random(len(genome)) < self.cfg.p_mutation
        if mask.any():
            genome = genome.copy()
            genome[mask] = self.rng.integers(0, self.cfg.codon_max, size=mask.sum())
        return genome

    # ------------------------------------------------------------- nsga-ii
    @staticmethod
    def _objectives(ind: Individual, size_penalty: float, prior_weight: float) -> Tuple[float, float]:
        """(fit, behaviour): nRMSE + parsimony ; semantic distance + prior violation."""
        sc = ind.scores
        if ind.phenotype is None or sc.get("nrmse", 1e3) >= 1e3:
            return (1e3, 1e3)
        return (sc["nrmse"] + size_penalty * sc.get("size", 0),
                sc.get("semantic", 1.0) + prior_weight * sc.get("prior", 0.0))

    @staticmethod
    def _nondominated_sort(F: np.ndarray) -> List[List[int]]:
        n = len(F)
        dominated_by = [[] for _ in range(n)]
        n_dom = np.zeros(n, dtype=int)
        fronts: List[List[int]] = [[]]
        for i in range(n):
            le = np.all(F[i] <= F, axis=1)
            lt = np.any(F[i] < F, axis=1)
            dom = np.flatnonzero(le & lt)              # i dominates these
            dominated_by[i] = list(dom)
            n_dom[i] = int(np.sum(np.all(F <= F[i], axis=1) & np.any(F < F[i], axis=1)))
            if n_dom[i] == 0:
                fronts[0].append(i)
        k = 0
        while fronts[k]:
            nxt = []
            for i in fronts[k]:
                for j in dominated_by[i]:
                    n_dom[j] -= 1
                    if n_dom[j] == 0:
                        nxt.append(j)
            k += 1
            fronts.append(nxt)
        return [f for f in fronts if f]

    @staticmethod
    def _crowding(F: np.ndarray, front: List[int]) -> np.ndarray:
        d = np.zeros(len(front))
        if len(front) <= 2:
            d[:] = np.inf
            return d
        sub = F[front]
        for m in range(F.shape[1]):
            order = np.argsort(sub[:, m])
            d[order[0]] = d[order[-1]] = np.inf
            rng_m = sub[order[-1], m] - sub[order[0], m]
            if rng_m <= 0:
                continue
            d[order[1:-1]] += (sub[order[2:], m] - sub[order[:-2], m]) / rng_m
        return d

    def _nsga2_rank(self, pop: List[Individual]) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        F = np.array([self._objectives(z, self.ev.cfg.size_penalty, self.ev.cfg.prior_weight) for z in pop])
        rank = np.zeros(len(pop), dtype=int)
        crowd = np.zeros(len(pop))
        for r, front in enumerate(self._nondominated_sort(F)):
            rank[front] = r
            crowd[front] = self._crowding(F, front)
        return F, rank, crowd

    def _nsga2_select_parent(self, pop, rank, crowd) -> Individual:
        i, j = self.rng.integers(0, len(pop), size=2)
        if rank[i] != rank[j]:
            return pop[i] if rank[i] < rank[j] else pop[j]
        return pop[i] if crowd[i] >= crowd[j] else pop[j]

    def _knee(self, pop: List[Individual]) -> Individual:
        """Final model from the first Pareto front: the member closest to the
        ideal point after normalising both objectives over the front (a
        weight-free 'knee'); prior-satisfying members are preferred."""
        F, rank, _ = self._nsga2_rank(pop)
        front = np.flatnonzero(rank == 0)
        feas = [i for i in front if pop[i].scores.get("prior", 0.0) == 0.0]
        front = np.array(feas) if feas else front
        if self.cfg.nsga_pick == "fit":
            return pop[front[int(np.argmin(F[front, 0]))]]
        sub = F[front]
        lo, hi = sub.min(axis=0), sub.max(axis=0)
        norm = (sub - lo) / np.where(hi - lo > 0, hi - lo, 1.0)
        return pop[front[int(np.argmin(np.linalg.norm(norm, axis=1)))]]

    def _run_nsga2(self, t0: float) -> RunResult:
        pop = [Individual(self._random_genome()) for _ in range(self.cfg.pop_size)]
        for ind in pop:
            self._decode(ind)
        evals = len(pop)
        history: List[Dict[str, float]] = []
        first_match: Optional[int] = None
        for gen in range(self.cfg.generations):
            F, rank, crowd = self._nsga2_rank(pop)
            knee = self._knee(pop)
            history.append({"gen": gen, "best_fitness": knee.fitness,
                            "best_nrmse": knee.scores.get("nrmse", np.nan),
                            "best_semantic": knee.scores.get("semantic", np.nan),
                            "valid_frac": float(np.mean(F[:, 0] < 1e3)),
                            "best_size": knee.scores.get("size", np.nan),
                            "front_size": int(np.sum(rank == 0))})
            if first_match is None and self.comp_monitor and knee.phenotype and self.comp_monitor(knee.phenotype):
                first_match = gen
            if self.cfg.verbose:
                print(f"gen {gen:3d}  front={int(np.sum(rank == 0))}  knee nrmse={knee.scores.get('nrmse', 0):.4f}"
                      f"  sem={knee.scores.get('semantic', 0):.3f}  {knee.phenotype}")
            if self.cfg.time_limit_s and time.time() - t0 > self.cfg.time_limit_s:
                break
            offspring = []
            while len(offspring) < self.cfg.pop_size:
                a = self._nsga2_select_parent(pop, rank, crowd)
                b = self._nsga2_select_parent(pop, rank, crowd)
                child = Individual(self._mutate(self._crossover(a, b)))
                self._decode(child)
                evals += 1
                if child.phenotype is None:
                    child = Individual(self._random_genome())
                    self._decode(child)
                    evals += 1
                offspring.append(child)
            # (mu + lambda) environmental selection on *unique* phenotypes:
            # clones are mutually non-dominated and would otherwise flood the front
            seen = set()
            union = []
            for z in pop + offspring:
                if z.phenotype not in seen:
                    seen.add(z.phenotype)
                    union.append(z)
            Fu, ranku, crowdu = self._nsga2_rank(union)
            order = np.lexsort((-crowdu, ranku))
            pop = [union[i] for i in order[: self.cfg.pop_size]]
            while len(pop) < self.cfg.pop_size:            # top up with fresh material
                z = Individual(self._random_genome())
                self._decode(z)
                evals += 1
                pop.append(z)
        best = self._knee(pop)
        if self.cfg.refine_constants and best.phenotype is not None and best.fitness < 1e3:
            best = self.refine(best)
        return RunResult(best, history, evals, time.time() - t0, first_match)

    # ------------------------------------------------------------------ run
    def run(self) -> RunResult:
        if self.cfg.selection == "nsga2":
            return self._run_nsga2(time.time())
        return self._run_scalar()

    def _run_scalar(self) -> RunResult:
        t0 = time.time()
        pop = [Individual(self._random_genome()) for _ in range(self.cfg.pop_size)]
        for ind in pop:
            self._decode(ind)
        evals = len(pop)
        history: List[Dict[str, float]] = []
        first_match: Optional[int] = None

        for gen in range(self.cfg.generations):
            pop.sort(key=lambda z: z.fitness)
            best = pop[0]
            valid = sum(1 for z in pop if z.phenotype is not None and z.fitness < 1e3)
            history.append({"gen": gen, "best_fitness": best.fitness,
                            "best_nrmse": best.scores.get("nrmse", np.nan),
                            "best_semantic": best.scores.get("semantic", np.nan),
                            "valid_frac": valid / len(pop),
                            "best_size": best.scores.get("size", np.nan)})
            if first_match is None and self.comp_monitor and best.phenotype and self.comp_monitor(best.phenotype):
                first_match = gen
            if self.cfg.verbose:
                print(f"gen {gen:3d}  fit={best.fitness:.4f}  nrmse={best.scores.get('nrmse', 0):.4f}"
                      f"  sem={best.scores.get('semantic', 0):.3f}  {best.phenotype}")
            if self.cfg.time_limit_s and time.time() - t0 > self.cfg.time_limit_s:
                break

            new_pop = [Individual(z.genome.copy(), z.phenotype, z.used, dict(z.scores))
                       for z in pop[: self.cfg.elitism]]
            while len(new_pop) < self.cfg.pop_size:
                a = self._tournament(pop)
                b = self._tournament(pop)
                child = Individual(self._mutate(self._crossover(a, b)))
                self._decode(child)
                evals += 1
                if child.phenotype is None:          # replace invalid with fresh
                    child = Individual(self._random_genome())
                    self._decode(child)
                    evals += 1
                new_pop.append(child)
            pop = new_pop

        pop.sort(key=lambda z: z.fitness)
        best = pop[0]
        if self.cfg.refine_constants and best.phenotype is not None and best.fitness < 1e3:
            best = self.refine(best)
        return RunResult(best, history, evals, time.time() - t0, first_match)

    # --------------------------------------------------------------- refine
    def refine(self, ind: Individual, max_iter: int = 200) -> Individual:
        """Nelder-Mead over the numeric literals of the phenotype."""
        ph = ind.phenotype
        nums = _NUM_RE.findall(ph)
        if not nums or len(nums) > 8:
            return ind
        template = _NUM_RE.sub("{}", ph)
        theta0 = np.array([float(v) for v in nums])

        def build(theta):
            return template.format(*[f"{v:.6g}" if v >= 0 else f"({v:.6g})" for v in theta])

        def obj(theta):
            return self.ev.evaluate(build(theta))["fitness"]

        try:
            res = minimize(obj, theta0, method="Nelder-Mead",
                           options={"maxiter": max_iter, "xatol": 1e-4, "fatol": 1e-6})
        except Exception:
            return ind
        if res.fun < ind.fitness:
            new = Individual(ind.genome.copy(), build(res.x), ind.used, self.ev.evaluate(build(res.x)))
            return new
        return ind
