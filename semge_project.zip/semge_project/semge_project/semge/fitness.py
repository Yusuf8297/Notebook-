"""
Fitness functions for GE-based ODE discovery.

Four regimes are compared in the experiment:

  rmse      classic trajectory RMSE (the "syntactic" baseline)
  semantic  distance between the semantic representation of the data and
            of the candidate's simulated trajectory
  hybrid    alpha * nRMSE + (1 - alpha) * semantic
  + prior   any of the above plus lambda * prior_violation, where the prior is
            expert semantic knowledge such as "ends with s_{-+h}"

All fitness values are minimised.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np

from .expression import compile_expression, expression_size
from .motifs import (SemanticRepresentation, prior_violation, semantic_distance,
                     semantic_representation, semantic_representation_bootstrap)
from .simulate import simulate
from .systems import Dataset

BAD = 1e3


@dataclass
class FitnessConfig:
    mode: str = "rmse"               # rmse | semantic | hybrid
    alpha: float = 0.5               # weight on nRMSE in hybrid mode
    prior: Optional[Dict] = None     # semantic prior; None = no prior
    prior_weight: float = 1.0
    # "Virtual" initial conditions on which the prior is enforced although no
    # data exist there. A semantic prior is a statement about behaviour, so it
    # can be checked anywhere the expert says it holds -- this is the channel
    # through which SemGE targets extrapolation to unseen initial conditions.
    prior_x0: Optional[np.ndarray] = None
    prior_t_factor: float = 2.0      # virtual trajectories are simulated on [0, factor*T]: a
                                     # behavioural prior must also hold beyond the data window
    size_penalty: float = 1e-3       # parsimony pressure per token
    smooth_data: bool = True         # smooth noisy data before motif extraction
    n_boot: int = 0                  # bootstrap replicates of the data representation (0 = single reference; >0 is slower and did not help in pilots)
    w_comp: float = 0.5              # semantic distance weights (see motifs.semantic_distance)
    w_time: float = 1.0
    w_prop: float = 0.5


class Evaluator:
    """Scores a phenotype string against a training Dataset."""

    def __init__(self, data: Dataset, cfg: FitnessConfig):
        self.data = data
        self.cfg = cfg
        self.x_scale = max(np.ptp(data.X), 1e-8)
        # Semantic representation of every observed trajectory (from the
        # *noisy* observations, smoothed -- this is what a practitioner has).
        self.ref_reps: List[List[SemanticRepresentation]] = [
            semantic_representation_bootstrap(data.t, data.X[i], n_boot=cfg.n_boot)
            if cfg.smooth_data else [semantic_representation(data.t, data.X[i], smooth=False)]
            for i in range(data.X.shape[0])
        ]
        self.cache: Dict[str, Dict[str, float]] = {}
        T = data.t[-1] - data.t[0]
        n_ext = int(round(len(data.t) * cfg.prior_t_factor))
        self.t_virtual = data.t[0] + np.linspace(0.0, cfg.prior_t_factor * T, n_ext)

    # ------------------------------------------------------------------ core
    def simulate_phenotype(self, phenotype: str, x0=None, t=None) -> Optional[np.ndarray]:
        f = compile_expression(phenotype)
        if f is None:
            return None
        x0 = self.data.x0 if x0 is None else x0
        t = self.data.t if t is None else t
        return simulate(f, x0, t)

    def evaluate(self, phenotype: Optional[str]) -> Dict[str, float]:
        if phenotype is None:
            return {"fitness": BAD, "nrmse": BAD, "semantic": 1.0, "prior": 1.0, "size": 10 ** 6}
        if phenotype in self.cache:
            return self.cache[phenotype]

        use_virtual = bool(self.cfg.prior) and self.cfg.prior_x0 is not None
        X = self.simulate_phenotype(phenotype)
        bad = X is None or not np.all(np.isfinite(X)) or np.max(np.abs(X)) >= 1e4
        Xv = None
        if not bad and use_virtual:
            # virtual initial conditions on an extended horizon [0, factor * T]
            Xv = self.simulate_phenotype(phenotype, x0=self.cfg.prior_x0, t=self.t_virtual)
            if Xv is None or not np.all(np.isfinite(Xv)) or np.max(np.abs(Xv)) >= 1e4:
                Xv = None                                  # blown up beyond T -> full prior penalty
        if bad:
            res = {"fitness": BAD, "nrmse": BAD, "semantic": 1.0, "prior": 1.0,
                   "size": expression_size(phenotype)}
            self.cache[phenotype] = res
            return res

        nrmse = float(np.sqrt(np.mean((X - self.data.X) ** 2)) / self.x_scale)

        sem, prior = 0.0, 0.0
        if self.cfg.mode in ("semantic", "hybrid") or self.cfg.prior:
            ds, ps = [], []
            for i, refs in enumerate(self.ref_reps):
                try:
                    cand = semantic_representation(self.data.t, X[i], smooth=False)
                except Exception:
                    ds.append(1.0)
                    ps.append(1.0)
                    continue
                ds.append(float(np.mean([semantic_distance(ref, cand, self.cfg.w_comp,
                                                           self.cfg.w_time, self.cfg.w_prop)
                                         for ref in refs])))
                ps.append(prior_violation(cand, self.cfg.prior))
            sem = float(np.mean(ds))
            prior = float(np.mean(ps))
            if use_virtual:
                if Xv is None:
                    pv = [1.0]
                else:
                    pv = []
                    for i in range(Xv.shape[0]):
                        try:
                            pv.append(prior_violation(
                                semantic_representation(self.t_virtual, Xv[i], smooth=False), self.cfg.prior))
                        except Exception:
                            pv.append(1.0)
                prior = 0.5 * (prior + float(np.mean(pv)))

        size = expression_size(phenotype)
        if self.cfg.mode == "rmse":
            fit = nrmse
        elif self.cfg.mode == "semantic":
            fit = sem
        elif self.cfg.mode == "hybrid":
            fit = self.cfg.alpha * nrmse + (1.0 - self.cfg.alpha) * sem
        else:
            raise ValueError(self.cfg.mode)
        if self.cfg.prior:
            fit += self.cfg.prior_weight * prior
        fit += self.cfg.size_penalty * size

        res = {"fitness": float(fit), "nrmse": nrmse, "semantic": sem, "prior": prior, "size": size}
        self.cache[phenotype] = res
        return res


# ---------------------------------------------------------------------- metrics

def composition_accuracy(true_X: np.ndarray, pred_X: np.ndarray, t: np.ndarray) -> float:
    """Fraction of trajectories whose motif composition matches the truth."""
    hits = []
    for i in range(true_X.shape[0]):
        try:
            a = semantic_representation(t, true_X[i], smooth=False).composition
            b = semantic_representation(t, pred_X[i], smooth=False).composition
            hits.append(float(a == b))
        except Exception:
            hits.append(0.0)
    return float(np.mean(hits))


def nrmse(true_X: np.ndarray, pred_X: np.ndarray, scale: Optional[float] = None) -> float:
    scale = max(np.ptp(true_X) if scale is None else scale, 1e-8)
    if pred_X is None or not np.all(np.isfinite(pred_X)):
        return BAD
    return float(np.sqrt(np.mean((true_X - pred_X) ** 2)) / scale)
