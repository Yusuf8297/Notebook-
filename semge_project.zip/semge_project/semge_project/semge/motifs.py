"""
Semantic representation of a scalar trajectory, following the formalism of
Kacprzyk, Liu & van der Schaar (ICLR 2024) and Kacprzyk & van der Schaar
(ICLR 2025):

  * a trajectory is a *composition* of motifs, each motif being a maximal
    segment with constant sign of the first and second derivative:
        s_{++b}  increasing convex   (bounded, i.e. not the last motif)
        s_{+-b}  increasing concave
        s_{-+b}  decreasing convex
        s_{--b}  decreasing concave
    the final motif is *unbounded* and tagged
        u  -> keeps growing/decaying without a horizontal asymptote
        h  -> approaches a horizontal asymptote
  * *transition points* (t_i, x_i) between motifs, and
  * *properties* of the unbounded motif (horizontal asymptote, half-life).

This module extracts that representation numerically from a sampled
trajectory and defines a distance between two representations. The distance
is what SemGE uses as a fitness signal.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import warnings

import numpy as np
from scipy.interpolate import UnivariateSpline
from scipy.signal import savgol_filter


@dataclass
class Motif:
    s1: int          # sign of first derivative: +1 / -1 / 0
    s2: int          # sign of second derivative: +1 / -1 / 0
    kind: str        # 'b' bounded, 'u' unbounded, 'h' horizontal asymptote, 'c' constant
    start: int       # index into the trajectory
    end: int         # inclusive index

    @property
    def label(self) -> str:
        if self.kind == "c":
            return "0"
        return f"{'+' if self.s1 > 0 else '-'}{'+' if self.s2 > 0 else '-'}{self.kind}"


@dataclass
class SemanticRepresentation:
    motifs: List[Motif]
    transition_t: np.ndarray            # t-coordinates of motif boundaries (incl. start & end)
    transition_x: np.ndarray            # x-coordinates
    asymptote: Optional[float] = None   # only for a final 'h' motif
    half_life: Optional[float] = None   # only for a final 'h' motif
    end_slope: float = 0.0              # x'(t_end)
    t_span: float = 1.0
    x_scale: float = 1.0

    @property
    def composition(self) -> Tuple[str, ...]:
        return tuple(m.label for m in self.motifs)

    def __str__(self) -> str:
        return composition_string(self.composition)


def composition_string(comp: Sequence[str]) -> str:
    return "(" + ", ".join(f"s_{{{c}}}" for c in comp) + ")"


# --------------------------------------------------------------------------- extraction

def _signs(v: np.ndarray, tol) -> np.ndarray:
    """Sign with a dead-zone; `tol` may be a scalar or a per-sample array."""
    s = np.zeros_like(v, dtype=int)
    s[v > tol] = 1
    s[v < -tol] = -1
    # carry the previous sign through dead-zone samples
    for i in range(1, len(s)):
        if s[i] == 0:
            s[i] = s[i - 1]
    if s[0] == 0:                       # leading dead zone: borrow first non-zero
        nz = np.nonzero(s)[0]
        s[: (nz[0] if len(nz) else len(s))] = s[nz[0]] if len(nz) else 0
    return s


def _median(v: np.ndarray) -> float:
    """np.median is slow on tiny arrays (~50 us); sorting is ~5 us."""
    v = np.sort(np.asarray(v, dtype=float).ravel())
    n = v.size
    if n == 0:
        return float("nan")
    return float(v[n // 2]) if n % 2 else float(0.5 * (v[n // 2 - 1] + v[n // 2]))


def _gradient(y: np.ndarray, t: np.ndarray) -> np.ndarray:
    """Central differences on a uniform grid (np.gradient is ~10x slower)."""
    h = t[1] - t[0]
    g = np.empty_like(y)
    g[1:-1] = (y[2:] - y[:-2]) / (2 * h)
    g[0] = (y[1] - y[0]) / h
    g[-1] = (y[-1] - y[-2]) / h
    return g


def _estimate_noise(x: np.ndarray) -> float:
    """Robust noise std from second differences (MAD estimator)."""
    d2 = np.diff(x, 2)
    if len(d2) < 3:
        return 0.0
    return float(_median(np.abs(d2 - _median(d2))) / (0.6745 * np.sqrt(6.0)))


def _smooth_derivatives(t: np.ndarray, x: np.ndarray, sigma: float):
    """
    Smoothing spline with s = n * sigma^2; returns xs, x', x''.
    A cubic spline is used deliberately: quintic splines have 3-5x larger
    boundary slope errors under noise, which turned a saturating tail into
    "accelerating growth" in early experiments.
    """
    n = len(t)
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            sp = UnivariateSpline(t, x, k=3, s=n * sigma ** 2)
        return sp(t), sp.derivative(1)(t), sp.derivative(2)(t)
    except Exception:
        w = max(7, int(0.15 * n) | 1)
        w = min(w, n if n % 2 else n - 1)
        xs = savgol_filter(x, w, polyorder=3)
        d1 = np.gradient(xs, t)
        return xs, d1, np.gradient(d1, t)


def semantic_representation(t: np.ndarray,
                            x: np.ndarray,
                            smooth: bool = True,
                            min_len_frac: float = 0.08,
                            sign_tol: float = 0.03,
                            noise_z: float = 2.0,
                            noise_reps: int = 8,
                            asymptote_tol: float = 3.0,
                            seed: int = 0) -> SemanticRepresentation:
    """
    Extract the semantic representation of a single trajectory x(t).

    smooth        treat x as noisy: estimate the noise level, fit a smoothing
                  spline, and widen the derivative dead-zones to `noise_z`
                  standard deviations of the derivative estimates (obtained by
                  re-fitting on `noise_reps` perturbed copies). With
                  smooth=False the trajectory is taken as exact (use this for
                  simulated candidate trajectories).
    min_len_frac  motifs shorter than this fraction of the samples are merged
                  into their larger neighbour (suppresses spurious sign flips)
    sign_tol      minimum derivative dead-zone, relative to the average slope
                  x_scale / t_span (and curvature x_scale / t_span^2)
    asymptote_tol final motif is 'h' if the trajectory is decelerating
                  (s1 * s2 < 0) and the extrapolated remaining distance to its
                  asymptote, |x'(t_end)| / rate, is < asymptote_tol * x_scale
                  (or if the trajectory is already flat at t_end)
    """
    t = np.asarray(t, dtype=float)
    x = np.asarray(x, dtype=float)
    n = len(t)
    if n < 7:
        raise ValueError("need at least 7 samples")

    t_span = t[-1] - t[0]
    if smooth:
        sigma = _estimate_noise(x)
        xs, d1, d2 = _smooth_derivatives(t, x, sigma)
        sd1 = np.zeros(n)
        sd2 = np.zeros(n)
        if sigma > 0 and noise_reps > 0:
            rng = np.random.default_rng(seed)
            D1, D2 = [], []
            for _ in range(noise_reps):
                _, a, b = _smooth_derivatives(t, xs + sigma * rng.standard_normal(n), sigma)
                D1.append(a)
                D2.append(b)
            sd1 = np.std(D1, axis=0)
            sd2 = np.std(D2, axis=0)
    else:
        xs = x
        d1 = _gradient(xs, t)
        d2 = _gradient(d1, t)
        sd1 = np.zeros(n)
        sd2 = np.zeros(n)

    x_scale = max(np.ptp(xs), 1e-8)
    m1 = np.max(np.abs(d1)) + 1e-12
    # dead-zone tolerances are relative to the *average* slope / curvature of
    # the trajectory (x_scale / t_span) rather than to the maximum, so that an
    # early fast transient does not swamp a slow late approach to an asymptote;
    # under noise they are widened to noise_z standard errors.
    tol1 = np.maximum(sign_tol * x_scale / t_span, noise_z * sd1)
    tol2 = np.maximum(sign_tol * x_scale / t_span ** 2, noise_z * sd2)

    if m1 * t_span < 1e-6 * x_scale or np.ptp(xs) < 1e-9:
        motifs = [Motif(0, 0, "c", 0, n - 1)]
        return SemanticRepresentation(motifs, np.array([t[0], t[-1]]),
                                      np.array([xs[0], xs[-1]]), asymptote=float(xs[-1]),
                                      half_life=None, end_slope=0.0,
                                      t_span=t_span, x_scale=x_scale)

    s1 = _signs(d1, tol1)
    s2 = _signs(d2, tol2)

    # --- segment into runs of constant (s1, s2)
    runs: List[List[int]] = []  # [s1, s2, start, end]
    for i in range(n):
        if runs and runs[-1][0] == s1[i] and runs[-1][1] == s2[i]:
            runs[-1][3] = i
        else:
            runs.append([int(s1[i]), int(s2[i]), i, i])

    # --- iteratively merge the shortest run into its larger neighbour
    min_len = max(3, int(min_len_frac * n))
    while len(runs) > 1:
        lens = [r[3] - r[2] + 1 for r in runs]
        j = int(np.argmin(lens))
        if lens[j] >= min_len:
            break
        if j == 0:
            runs[1][2] = runs[0][2]
        elif j == len(runs) - 1:
            runs[j - 1][3] = runs[j][3]
        else:
            if lens[j - 1] >= lens[j + 1]:
                runs[j - 1][3] = runs[j][3]
            else:
                runs[j + 1][2] = runs[j][2]
        del runs[j]
        # merge adjacent runs that became identical
        merged: List[List[int]] = []
        for r in runs:
            if merged and merged[-1][0] == r[0] and merged[-1][1] == r[1]:
                merged[-1][3] = r[3]
            else:
                merged.append(r)
        runs = merged

    # --- collapse curvature "chatter": >= 3 consecutive runs with the same
    # monotonicity but alternating curvature are a noise signature, not three
    # genuine inflection points -> replace by one run with the dominant curvature
    if len(runs) >= 3:
        collapsed: List[List[int]] = []
        i = 0
        while i < len(runs):
            j = i
            while j + 1 < len(runs) and runs[j + 1][0] == runs[i][0]:
                j += 1
            block = runs[i:j + 1]
            if len(block) >= 3:
                st, en = block[0][2], block[-1][3]
                curv = 1 if np.sum(d2[st:en + 1]) >= 0 else -1
                collapsed.append([block[0][0], curv, st, en])
            else:
                collapsed.extend(block)
            i = j + 1
        runs = collapsed

    # --- label motifs
    # end-of-trajectory quantities use the median over the last ~10% of samples,
    # never the single (least reliable) last sample
    tail_n = max(4, n // 10)
    tol1_arr = np.broadcast_to(np.asarray(tol1, dtype=float), (n,))
    end_slope = _median(d1[-tail_n:])
    tol1_end = _median(tol1_arr[-tail_n:])
    motifs: List[Motif] = []
    for j, (a, b, st, en) in enumerate(runs):
        last = j == len(runs) - 1
        if not last:
            kind = "b"
        else:
            decel = a * b < 0
            flat_end = abs(end_slope) < tol1_end
            tail = slice(max(st, n - max(5, (en - st) // 3)), n)
            d1t, d2t = d1[tail], d2[tail]
            ok = np.abs(d1t) > tol1_arr[tail]
            rate = _median(-d2t[ok] / d1t[ok]) if ok.sum() >= 3 else 0.0
            remaining = abs(end_slope / rate) if rate > 1e-9 else np.inf
            kind = "h" if (flat_end or (decel and rate > 0 and remaining < asymptote_tol * x_scale)) else "u"
        motifs.append(Motif(a, b, kind, st, en))

    bounds = [m.start for m in motifs] + [n - 1]
    trans_t = t[bounds]
    trans_x = xs[bounds]

    # --- properties of the unbounded motif
    asymptote = None
    half_life = None
    fm = motifs[-1]
    if fm.kind == "h":
        seg = slice(max(fm.start, n - max(5, (fm.end - fm.start) // 2)), n)
        dd1 = d1[seg]
        dd2 = d2[seg]
        ok = np.abs(dd1) > tol1_arr[seg]
        if ok.sum() >= 3:
            rate = _median(-dd2[ok] / dd1[ok])       # x' = -rate (x - a)
            if rate > 1e-6:
                asymptote = _median(xs[seg][ok] + dd1[ok] / rate)
                half_life = float(np.log(2.0) / rate)
        if asymptote is None:
            asymptote = float(xs[-1])                 # already flat: end value
            half_life = None                          # unknown -> not penalised

    return SemanticRepresentation(motifs, trans_t, trans_x, asymptote, half_life,
                                  end_slope=end_slope, t_span=t_span, x_scale=x_scale)


def semantic_representation_bootstrap(t: np.ndarray, x: np.ndarray, n_boot: int = 4,
                                      seed: int = 0, **kw) -> List[SemanticRepresentation]:
    """
    A *soft* reference for noisy data: the representation of the smoothed
    trajectory plus `n_boot` representations of perturbed re-fits
    (xs + sigma * eps). Averaging a distance over this list marginalises over
    the uncertainty of the extraction instead of committing to one composition
    that may be wrong at high noise.
    """
    t = np.asarray(t, dtype=float)
    x = np.asarray(x, dtype=float)
    reps = [semantic_representation(t, x, smooth=True, seed=seed, **kw)]
    sigma = _estimate_noise(x)
    if sigma <= 0 or n_boot <= 0:
        return reps
    xs, _, _ = _smooth_derivatives(t, x, sigma)
    rng = np.random.default_rng(seed + 1)
    for b in range(n_boot):
        xb = xs + sigma * rng.standard_normal(len(x))
        reps.append(semantic_representation(t, xb, smooth=True, seed=seed + 10 + b, **kw))
    return reps


# --------------------------------------------------------------------------- distance

def _levenshtein(a: Sequence[str], b: Sequence[str]) -> int:
    la, lb = len(a), len(b)
    D = np.zeros((la + 1, lb + 1), dtype=int)
    D[:, 0] = np.arange(la + 1)
    D[0, :] = np.arange(lb + 1)
    for i in range(1, la + 1):
        for j in range(1, lb + 1):
            D[i, j] = min(D[i - 1, j] + 1, D[i, j - 1] + 1,
                          D[i - 1, j - 1] + (a[i - 1] != b[j - 1]))
    return int(D[la, lb])


def _motif_dist(a: str, b: str) -> float:
    """Graded distance between two motif labels (0 identical .. 1 opposite)."""
    if a == b:
        return 0.0
    if a == "0" or b == "0":
        return 0.75
    d = 0.0
    d += 0.5 if a[0] != b[0] else 0.0      # monotonicity direction is the big one
    d += 0.25 if a[1] != b[1] else 0.0     # curvature
    d += 0.25 if a[2] != b[2] else 0.0     # boundedness / asymptote
    return d


def _pattern_dist(label: str, pattern: str) -> float:
    """
    Like _motif_dist but `pattern` may contain '*' wildcards, e.g. "**h" =
    "approaches a horizontal asymptote, in either direction", "+**" =
    "increasing". Used for priors, which are often direction-agnostic.
    """
    if label == "0":
        return 0.0 if pattern.replace("*", "") == "" else 0.75
    d = 0.0
    if pattern[0] != "*" and label[0] != pattern[0]:
        d += 0.5
    if pattern[1] != "*" and label[1] != pattern[1]:
        d += 0.25
    if pattern[2] != "*" and label[2] != pattern[2]:
        d += 0.25
    return d


def composition_distance(ca: Sequence[str], cb: Sequence[str]) -> float:
    """Normalised edit distance in [0, 1] with graded substitution cost."""
    la, lb = len(ca), len(cb)
    if la == 0 or lb == 0:
        return 1.0
    D = np.zeros((la + 1, lb + 1))
    D[:, 0] = np.arange(la + 1)
    D[0, :] = np.arange(lb + 1)
    for i in range(1, la + 1):
        for j in range(1, lb + 1):
            D[i, j] = min(D[i - 1, j] + 1, D[i, j - 1] + 1,
                          D[i - 1, j - 1] + _motif_dist(ca[i - 1], cb[j - 1]))
    return float(D[la, lb] / max(la, lb))


def _label_codes(rep: SemanticRepresentation) -> np.ndarray:
    """(s1, s2, kind) integer codes per motif; constant motif = (0, 0, 0)."""
    codes = np.zeros((len(rep.motifs), 3), dtype=int)
    for i, m in enumerate(rep.motifs):
        if m.kind != "c":
            codes[i] = (m.s1, m.s2, {"b": 1, "u": 2, "h": 3}[m.kind])
    return codes


def motif_profile(rep: SemanticRepresentation, n_grid: int = 100) -> np.ndarray:
    """Motif code (n_grid x 3) active at each of n_grid equally spaced times."""
    grid = np.linspace(rep.transition_t[0], rep.transition_t[-1], n_grid)
    idx = np.searchsorted(rep.transition_t[1:], grid, side="right")
    idx = np.clip(idx, 0, len(rep.motifs) - 1)
    return _label_codes(rep)[idx]


def profile_distance(a: SemanticRepresentation, b: SemanticRepresentation, n_grid: int = 100) -> float:
    """
    Time-weighted motif disagreement in [0, 1]: the graded motif distance
    averaged over a common time grid. A short missing motif or a slightly
    shifted transition point costs proportionally to its duration, instead of
    the all-or-nothing penalty of an edit distance.
    """
    pa, pb = motif_profile(a, n_grid), motif_profile(b, n_grid)
    const = (pa[:, 2] == 0) | (pb[:, 2] == 0)
    d = 0.5 * (pa[:, 0] != pb[:, 0]) + 0.25 * (pa[:, 1] != pb[:, 1]) + 0.25 * (pa[:, 2] != pb[:, 2])
    d = np.where(const, np.where((pa[:, 2] == 0) & (pb[:, 2] == 0), 0.0, 0.75), d)
    return float(d.mean())


def semantic_distance(ref: SemanticRepresentation,
                      cand: SemanticRepresentation,
                      w_comp: float = 0.5,
                      w_time: float = 1.0,
                      w_prop: float = 0.5) -> float:
    """
    Distance between the semantic representation of the data (`ref`) and of a
    candidate model (`cand`). Each term is in [0, 1]:

      comp   graded edit distance between motif compositions (exact-structure signal)
      time   time-weighted motif disagreement (robust to short/shifted motifs)
      prop   mismatch of asymptote and half-life of the final motif
    """
    comp = composition_distance(ref.composition, cand.composition)
    tdist = profile_distance(ref, cand)

    prop = 0.0
    rk, ck = ref.motifs[-1].kind, cand.motifs[-1].kind
    if rk == "h" and ck == "h":
        da = abs(ref.asymptote - cand.asymptote) / ref.x_scale
        if ref.half_life is not None and cand.half_life is not None:
            dh = abs(np.log(ref.half_life / cand.half_life)) / np.log(10.0)   # one decade = 1
            prop = float(np.clip(0.5 * da + 0.5 * dh, 0.0, 1.0))
        else:
            prop = float(np.clip(da, 0.0, 1.0))
    elif rk != ck:
        prop = 1.0
    else:  # both 'u' or both 'c': compare end slope
        prop = float(np.clip(abs(ref.end_slope - cand.end_slope) * ref.t_span / ref.x_scale, 0, 1))

    return (w_comp * comp + w_time * tdist + w_prop * prop) / (w_comp + w_time + w_prop)


# --------------------------------------------------------------------------- priors

def prior_violation(rep: SemanticRepresentation, prior: Optional[Dict]) -> float:
    """
    Semantic prior knowledge, e.g. {"ends_with": "-+h", "max_motifs": 3,
    "monotone": "+"}. Motif patterns accept '*' wildcards ("**h": ends at a
    horizontal asymptote from either side). Returns a violation score >= 0 (0 = satisfied). This is
    the "easy to inject prior knowledge" channel from the semantic-modelling
    slides, transplanted into GE as a fitness penalty.
    """
    if not prior:
        return 0.0
    v = 0.0
    comp = rep.composition
    if "ends_with" in prior:
        v += _pattern_dist(comp[-1], prior["ends_with"])
    if "starts_with" in prior:
        v += _pattern_dist(comp[0], prior["starts_with"])
    if "max_motifs" in prior and len(comp) > prior["max_motifs"]:
        v += (len(comp) - prior["max_motifs"]) / prior["max_motifs"]
    if "monotone" in prior:
        want = prior["monotone"]
        v += np.mean([0.0 if c == "0" or c[0] == want else 1.0 for c in comp])
    if "asymptote_range" in prior and rep.asymptote is not None:
        lo, hi = prior["asymptote_range"]
        if rep.asymptote < lo:
            v += (lo - rep.asymptote) / rep.x_scale
        elif rep.asymptote > hi:
            v += (rep.asymptote - hi) / rep.x_scale
    return float(v)
