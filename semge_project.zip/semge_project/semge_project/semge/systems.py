"""
Benchmark scalar ODE systems and noisy dataset generation.

Each system provides a ground-truth RHS f(x, t), a human-readable formula,
a training range of initial conditions and an *out-of-distribution* range
used to test extrapolation (the "x0 in (1, 1.5)" test from the slides), and
an optional semantic prior an expert could plausibly supply.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Optional, Tuple

import numpy as np

from .simulate import simulate


@dataclass
class System:
    name: str
    formula: str
    f: Callable[[np.ndarray, float], np.ndarray]
    x0_train: Tuple[float, float]
    x0_test: Tuple[float, float]
    t_end: float
    prior: Optional[Dict] = None
    # The expert's "the prior holds for any x0 in here". Priors are written so that
    # they are TRUE over this whole range (e.g. "**h" = reaches an asymptote from
    # either side, since x0 above the carrying capacity decays towards it).
    prior_x0: Tuple[float, float] = (0.0, 1.0)
    description: str = ""


def _logistic(x, t):
    return 1.0 * x * (1.0 - x / 2.8)


def _gompertz(x, t):
    return 0.6 * x * np.log(3.0 / np.maximum(x, 1e-6))


def _bateman(x, t):
    # one-compartment PK with first-order absorption, dose already in the source term
    return 3.0 * np.exp(-3.0 * t) - 0.6 * x


def _bertalanffy(x, t):
    return 1.2 * np.abs(x) ** (2.0 / 3.0) - 0.5 * x


def _allee(x, t):
    # strong Allee effect: threshold at 0.5, capacity 2
    return 0.8 * x * (x / 0.5 - 1.0) * (1.0 - x / 2.0)


def _cooling_forced(x, t):
    # Newton cooling towards a slowly rising ambient temperature
    return -0.7 * (x - (1.0 + 0.3 * t))


SYSTEMS: Dict[str, System] = {
    "logistic": System(
        "logistic", "x*(1 - x/2.8)", _logistic, (0.1, 1.4), (1.4, 4.0), 8.0,
        prior={"ends_with": "**h"}, prior_x0=(0.05, 6.0), description="Logistic growth, K = 2.8"),
    "gompertz": System(
        "gompertz", "0.6*x*log(3/x)", _gompertz, (0.1, 1.5), (1.5, 5.0), 8.0,
        prior={"ends_with": "**h", "max_motifs": 2}, prior_x0=(0.05, 8.0),
        description="Gompertz tumour growth"),
    "pk_bateman": System(
        "pk_bateman", "3*exp(-3*t) - 0.6*x", _bateman, (0.0, 0.3), (0.3, 1.5), 8.0,
        prior={"ends_with": "-+h", "max_motifs": 4}, prior_x0=(0.0, 2.0),
        description="1-compartment PK with absorption"),
    "bertalanffy": System(
        "bertalanffy", "1.2*x^(2/3) - 0.5*x", _bertalanffy, (0.2, 3.0), (3.0, 15.0), 10.0,
        prior={"ends_with": "**h"}, prior_x0=(0.1, 20.0), description="von Bertalanffy growth"),
    "allee": System(
        "allee", "0.8*x*(x/0.5 - 1)*(1 - x/2)", _allee, (0.55, 1.5), (0.1, 0.5), 10.0,
        prior=None, prior_x0=(0.1, 2.5),
        description="Strong Allee effect (bistable; OOD x0 flips the behaviour)"),
    "cooling": System(
        "cooling", "-0.7*(x - (1 + 0.3*t))", _cooling_forced, (2.0, 5.0), (-1.0, 2.0), 8.0,
        prior={"max_motifs": 3}, prior_x0=(-2.0, 6.0),
        description="Newton cooling with drifting ambient (non-autonomous)"),
}


@dataclass
class Dataset:
    system: str
    t: np.ndarray                 # (T,)
    x0: np.ndarray                # (N,)
    X_clean: np.ndarray           # (N, T)
    X: np.ndarray                 # (N, T) noisy observations
    noise: float
    split: str = "train"


def make_dataset(system: System, n_traj: int = 8, n_points: int = 60,
                 noise: float = 0.01, split: str = "train", seed: int = 0,
                 t_end: Optional[float] = None) -> Dataset:
    """
    Sample `n_traj` initial conditions from the train or test range, integrate
    the true system on a fine grid, subsample to `n_points`, and add Gaussian
    noise with std = `noise` * (range of the clean data).
    """
    rng = np.random.default_rng(seed)
    lo, hi = system.x0_train if split == "train" else system.x0_test
    x0 = rng.uniform(lo, hi, size=n_traj)
    t_end = t_end or system.t_end
    t_fine = np.linspace(0.0, t_end, 20 * n_points)
    Xf = simulate(system.f, x0, t_fine, substeps=1)
    idx = np.linspace(0, len(t_fine) - 1, n_points).astype(int)
    t = t_fine[idx]
    Xc = Xf[:, idx]
    sigma = noise * max(np.ptp(Xc), 1e-8)
    X = Xc + sigma * rng.standard_normal(Xc.shape)
    return Dataset(system.name, t, x0, Xc, X, noise, split)
