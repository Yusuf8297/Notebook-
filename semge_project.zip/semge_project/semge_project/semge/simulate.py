"""
Batched fixed-step RK4 integrator for scalar ODEs dx/dt = f(x, t).

`x0` is a 1-D array of initial conditions; all trajectories are integrated
simultaneously so a candidate expression is evaluated once per time step for
every initial condition (fast for GE where thousands of candidates are
simulated per generation). Trajectories are clipped to +-`clip` to keep
divergent candidates finite; the caller penalises them.
"""

from __future__ import annotations

from typing import Callable

import numpy as np


def simulate(f: Callable[[np.ndarray, float], np.ndarray],
             x0: np.ndarray,
             t: np.ndarray,
             substeps: int = 1,
             clip: float = 1e4) -> np.ndarray:
    """
    Returns an array X of shape (len(x0), len(t)) with X[:, 0] = x0.
    Divergent trajectories saturate at +-clip (and may contain NaN); the caller
    treats both as invalid. One RK4 substep per sample is accurate for the
    benchmark systems (60 samples over T); raise `substeps` for stiffer ODEs.
    """
    x0 = np.atleast_1d(np.asarray(x0, dtype=float))
    t = np.asarray(t, dtype=float)
    X = np.empty((x0.shape[0], t.shape[0]), dtype=float)
    X[:, 0] = x0
    x = x0.copy()
    for k in range(1, t.shape[0]):
        h = (t[k] - t[k - 1]) / substeps
        tt = t[k - 1]
        for _ in range(substeps):
            k1 = f(x, tt)
            k2 = f(x + 0.5 * h * k1, tt + 0.5 * h)
            k3 = f(x + 0.5 * h * k2, tt + 0.5 * h)
            k4 = f(x + h * k3, tt + h)
            x = x + (h / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
            x = np.clip(x, -clip, clip)          # nan stays nan -> caller marks it bad
            tt += h
        X[:, k] = x
    return X


def simulate_adaptive(f: Callable[[np.ndarray, float], np.ndarray],
                      x0: np.ndarray,
                      t: np.ndarray,
                      clip: float = 1e4) -> np.ndarray:
    """
    Adaptive-step integration (scipy LSODA, stiff-capable) for *evaluation*.
    The fixed-step RK4 above is fine for fitness inside the training window,
    but a discovered model can be stiff outside it (e.g. dx/dt = -3 t x) and
    RK4 then blows up numerically on [T, 2T]; that would be scored as a model
    failure. Returns the same (len(x0), len(t)) layout; rows that diverge or
    fail are filled with `clip` (and are scored as blow-ups by the caller).
    """
    from scipy.integrate import solve_ivp

    x0 = np.atleast_1d(np.asarray(x0, dtype=float))
    t = np.asarray(t, dtype=float)
    out = np.full((x0.shape[0], t.shape[0]), clip, dtype=float)

    def rhs(tt, y):
        v = f(y, tt)
        return np.where(np.isfinite(v), v, 0.0)

    try:
        with np.errstate(all="ignore"):
            sol = solve_ivp(rhs, (t[0], t[-1]), x0, t_eval=t, method="LSODA",
                            rtol=1e-6, atol=1e-8)
        if sol.success and sol.y.shape[1] == t.shape[0]:
            y = sol.y
            y = np.where(np.isfinite(y), y, clip)
            out = np.clip(y, -clip, clip)
    except Exception:
        pass
    return out
