"""
BNF grammar and standard GE genotype-to-phenotype mapping.

Grammar file format (one rule per line, `|` separates productions, `<x>` are
non-terminals, everything else is terminal text):

    <expr> ::= <expr> + <expr> | <func>(<expr>) | <var> | <const>

The mapping is the classic O'Neill & Ryan scheme: for the leftmost
non-terminal, read the next codon c and choose production
`c mod n_choices`. Wrapping is allowed a fixed number of times; if the
derivation does not terminate the individual is invalid.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

_NT_RE = re.compile(r"<[^<>]+>")

# The default grammar for a scalar, possibly non-autonomous ODE  dx/dt = f(x, t).
# Constants are built digit-wise so GE can tune them (a classic GE trick);
# `<const>` may optionally be replaced by a placeholder `C` that is optimised
# numerically (see Evaluator.optimise_constants).
DEFAULT_ODE_GRAMMAR = r"""
<expr> ::= <expr> <op> <expr> | <term> | <term>
<op>   ::= + | - | * | /
<term> ::= <func>(<expr>) | <var> | <const> | <var> | <const> | <var> * <var> | <const> * <var>
<func> ::= exp | log | sqrt | sin
<var>  ::= x | t | x | x
<const> ::= <sign><d>.<d><d> | <d>.<d> | <d>
<sign> ::=  | -
<d>    ::= 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9
"""


@dataclass
class Grammar:
    rules: Dict[str, List[List[str]]]
    start: str
    max_wraps: int = 2

    # ------------------------------------------------------------------ parse
    @classmethod
    def from_text(cls, text: str, start: Optional[str] = None, max_wraps: int = 2) -> "Grammar":
        rules: Dict[str, List[List[str]]] = {}
        first: Optional[str] = None
        for raw in text.strip().splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            lhs, rhs = line.split("::=")
            lhs = lhs.strip()
            if first is None:
                first = lhs
            prods = []
            for prod in rhs.split("|"):
                prods.append(cls._tokenise(prod.strip()))
            rules[lhs] = prods
        return cls(rules=rules, start=start or first, max_wraps=max_wraps)

    @staticmethod
    def _tokenise(prod: str) -> List[str]:
        """Split a production into non-terminal / terminal tokens."""
        tokens: List[str] = []
        pos = 0
        for m in _NT_RE.finditer(prod):
            if m.start() > pos:
                tokens.append(prod[pos:m.start()])
            tokens.append(m.group(0))
            pos = m.end()
        if pos < len(prod):
            tokens.append(prod[pos:])
        return tokens  # an empty production yields []

    # -------------------------------------------------------------------- map
    def map(self, genome: Sequence[int], max_depth: int = 12) -> Tuple[Optional[str], int]:
        """
        Map a codon sequence to a phenotype string.

        Returns (phenotype, codons_used). phenotype is None if the derivation
        fails to terminate within `max_wraps` wraps or exceeds `max_depth`
        levels of nesting (depth limit acts as a syntactic size bias).
        """
        if len(genome) == 0:
            return None, 0
        stack: List[Tuple[str, int]] = [(self.start, 0)]  # (symbol, depth)
        out: List[str] = []
        idx = 0
        wraps = 0
        used = 0
        while stack:
            sym, depth = stack.pop()
            if sym not in self.rules:
                out.append(sym)
                continue
            if depth > max_depth:
                return None, used
            if idx >= len(genome):
                wraps += 1
                if wraps > self.max_wraps:
                    return None, used
                idx = 0
            choices = self.rules[sym]
            prod = choices[genome[idx] % len(choices)]
            idx += 1
            used += 1
            # push in reverse so leftmost symbol is expanded first
            for tok in reversed(prod):
                stack.append((tok, depth + 1))
        return "".join(out), used

    def non_terminals(self) -> List[str]:
        return list(self.rules.keys())
