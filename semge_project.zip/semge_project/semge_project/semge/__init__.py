"""
SemGE: Semantically-Guided Grammatical Evolution for ODE discovery.

The idea (inspired by Kacprzyk & van der Schaar's "semantic representation"
of trajectories, ICLR 2024 / ICLR 2025 / ICML 2025) is to give grammatical
evolution (GE) a *semantic* inductive bias: candidate ODEs are scored not only
on how closely their simulated trajectory matches the data numerically, but on
whether the trajectory has the right *behaviour* (motif composition,
transition points, asymptote / half-life properties).

Modules
-------
grammar     BNF grammar parsing and GE genotype -> phenotype mapping
expression  compile a phenotype string into a safe numpy callable
simulate    batched fixed-step RK4 integrator for scalar ODEs dx/dt = f(x, t)
motifs      extraction of the semantic representation of a trajectory and
            the semantic distance between two representations
fitness     RMSE, semantic, hybrid and prior-constrained fitness functions
evolution   the GE search loop (tournament selection, crossover, mutation, elitism)
systems     benchmark ODE systems and noisy dataset generation
"""

from .grammar import Grammar
from .expression import compile_expression
from .simulate import simulate, simulate_adaptive
from .motifs import semantic_representation, semantic_distance, composition_string
from .fitness import FitnessConfig, Evaluator
from .evolution import GEConfig, GrammaticalEvolution
from . import systems

__all__ = [
    "Grammar", "compile_expression", "simulate", "simulate_adaptive",
    "semantic_representation", "semantic_distance", "composition_string",
    "FitnessConfig", "Evaluator", "GEConfig", "GrammaticalEvolution", "systems",
]
