"""
Compile a phenotype string such as ``"1.2*x - 0.3*x*x + exp(-t)"`` into a
safe, vectorised numpy callable f(x, t).

All operators are *protected* so that the integrator never sees NaN/inf from
a candidate: log(|z|+eps), sqrt(|z|), protected division, and clipped exp.
"""

from __future__ import annotations

import math
from typing import Callable, Optional

import numpy as np

_EPS = 1e-9
_EXP_CLIP = 50.0


def _p_log(z):
    return np.log(np.abs(z) + _EPS)


def _p_sqrt(z):
    return np.sqrt(np.abs(z))


def _p_exp(z):
    return np.exp(np.clip(z, -_EXP_CLIP, _EXP_CLIP))


_NAMESPACE = {
    "exp": _p_exp,
    "log": _p_log,
    "sqrt": _p_sqrt,
    "sin": np.sin,
    "cos": np.cos,
    "abs": np.abs,
    "np": np,
    "__builtins__": {},
}


def compile_expression(phenotype: str) -> Optional[Callable[[np.ndarray, float], np.ndarray]]:
    """
    Return f(x, t) -> dx/dt, vectorised over x (a 1-D array of trajectories
    evaluated at the same time t). Returns None if the phenotype does not
    compile.
    """
    if phenotype is None:
        return None
    src = phenotype.replace("^", "**")
    try:
        code = compile(src, "<phenotype>", "eval")
    except SyntaxError:
        return None

    env = dict(_NAMESPACE)          # one namespace per compiled expression

    def f(x: np.ndarray, t: float) -> np.ndarray:
        env["x"] = x
        env["t"] = t
        with np.errstate(all="ignore"):
            try:
                out = eval(code, env)  # noqa: S307 - namespace is locked down
            except (ZeroDivisionError, OverflowError, ValueError, TypeError):
                return np.full(x.shape, 1e6)
        if not isinstance(out, np.ndarray) or out.shape != x.shape:
            out = np.broadcast_to(np.asarray(out, dtype=float), x.shape).copy()
        # protected division etc.: non-finite -> large finite of the same sign so
        # the trajectory blows up and is penalised rather than raising
        bad = ~np.isfinite(out)
        if bad.any():
            out = out.copy()
            out[bad] = np.where(out[bad] > 0, 1e6, -1e6)
        return out

    # quick sanity check with a dummy input
    try:
        test = f(np.array([0.5, 1.0]), 0.1)
        if test.shape != (2,):
            return None
    except Exception:
        return None
    return f


def expression_size(phenotype: str) -> int:
    """Crude complexity: number of operators, functions and variables."""
    if phenotype is None:
        return 10 ** 6
    n = 0
    for tok in ("+", "-", "*", "/", "exp", "log", "sqrt", "sin", "x", "t"):
        n += phenotype.count(tok)
    return n
