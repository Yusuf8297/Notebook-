#!/usr/bin/env python3
"""
Single-run demo: evolve an ODE for one system under one fitness regime, print
the discovered equation and its semantic representation, and save a figure
comparing training data, in-distribution fit, and initial-condition
extrapolation for the RMSE baseline vs the semantic variant.

  python experiments/demo.py --system pk_bateman --pop 300 --gens 60
"""

from __future__ import annotations

import argparse
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from semge import (Evaluator, FitnessConfig, GEConfig, Grammar,  # noqa: E402
                   GrammaticalEvolution, compile_expression, simulate, systems)
from semge.grammar import DEFAULT_ODE_GRAMMAR  # noqa: E402
from semge.motifs import semantic_representation  # noqa: E402


def evolve(system, train, mode, prior, prior_x0, pop, gens, seed, verbose):
    ev = Evaluator(train, FitnessConfig(mode=mode, prior=prior, prior_x0=prior_x0))
    ge = GrammaticalEvolution(Grammar.from_text(DEFAULT_ODE_GRAMMAR), ev,
                              GEConfig(pop_size=pop, generations=gens, seed=seed, verbose=verbose))
    return ge.run()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", default="pk_bateman", choices=list(systems.SYSTEMS))
    ap.add_argument("--noise", type=float, default=0.01)
    ap.add_argument("--pop", type=int, default=300)
    ap.add_argument("--gens", type=int, default=60)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--out", default="results/demo.png")
    args = ap.parse_args()

    system = systems.SYSTEMS[args.system]
    train = systems.make_dataset(system, n_traj=8, n_points=60, noise=args.noise, seed=args.seed)
    ood = systems.make_dataset(system, n_traj=6, n_points=60, noise=0.0, split="test", seed=args.seed + 7)

    print(f"System: {system.name}   truth: dx/dt = {system.formula}")
    print("Semantic representation of the (noisy) training trajectories:")
    for i in range(train.X.shape[0]):
        r = semantic_representation(train.t, train.X[i])
        print(f"  x0={train.x0[i]:.2f}  {r}   asymptote={r.asymptote}")

    runs = {}
    reporter = Evaluator(train, FitnessConfig(mode="hybrid"))
    vx0 = np.linspace(system.prior_x0[0], system.prior_x0[1], 6)
    for name, mode, prior, px0 in [("GE-RMSE", "rmse", None, None),
                                   ("GE-HYB+VPRIOR", "hybrid", system.prior, vx0)]:
        print(f"\n=== {name} ===")
        res = evolve(system, train, mode, prior, px0, args.pop, args.gens, args.seed, args.verbose)
        b = res.best
        sem = reporter.evaluate(b.phenotype)["semantic"]
        print(f"discovered: dx/dt = {b.phenotype}")
        print(f"train nRMSE={b.scores['nrmse']:.4f}  semantic={sem:.3f}  size={b.scores['size']}")
        f = compile_expression(b.phenotype)
        X_in = simulate(f, train.x0, train.t)
        X_ood = simulate(f, ood.x0, ood.t)
        for i in range(2):
            print(f"  x0={train.x0[i]:.2f}  candidate: {semantic_representation(train.t, X_in[i], smooth=False)}")
        runs[name] = (b.phenotype, X_in, X_ood)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    colors = plt.cm.tab10(np.arange(8))
    for k, (name, (ph, X_in, X_ood)) in enumerate(runs.items()):
        ls = "--" if k == 0 else "-"
        for i in range(train.X.shape[0]):
            axes[0].plot(train.t, train.X[i], ".", color=colors[i], ms=3, alpha=0.5)
            axes[0].plot(train.t, X_in[i], ls, color=colors[i], lw=1.2,
                         label=f"{name}: {ph}" if i == 0 else None)
        for i in range(ood.X.shape[0]):
            axes[1].plot(ood.t, ood.X_clean[i], ":", color="k", lw=1, label="truth" if (i == 0 and k == 0) else None)
            axes[1].plot(ood.t, X_ood[i], ls, color=colors[i], lw=1.2,
                         label=name if i == 0 else None)
    axes[0].set_title("training range of x0 (dots = noisy data)")
    axes[1].set_title("out-of-distribution x0 (dotted = truth)")
    for ax in axes:
        ax.set_xlabel("t")
        ax.set_ylabel("x")
        ax.legend(fontsize=7)
    fig.suptitle(f"{system.name}: dx/dt = {system.formula}")
    fig.tight_layout()
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    fig.savefig(args.out, dpi=130)
    print(f"\nfigure saved to {args.out}")


if __name__ == "__main__":
    main()
