#!/usr/bin/env python3
"""
SemGE benchmark: does a semantic inductive bias help grammatical evolution
discover ODEs that are *behaviourally* right and extrapolate?

Conditions (all share the same grammar, GE engine, population, budget and seeds;
only the fitness differs):

  GE-RMSE          trajectory nRMSE                                (baseline)
  GE-SEM           semantic distance only                          (ablation)
  GE-HYB           0.5 * nRMSE + 0.5 * semantic distance
  GE-HYB+PRIOR     GE-HYB + expert semantic prior (e.g. "ends with s_{-+h}")
  GE-RMSE+PRIOR    baseline + prior  (isolates the effect of the prior alone)
  GE-HYB+VPRIOR    GE-HYB+PRIOR with the prior also enforced on virtual initial
                   conditions spanning the expert's plausible range (no data there)
  GE-NSGA          NSGA-II with objectives (nRMSE, semantic distance); knee of the front
  GE-NSGA+VPRIOR   NSGA-II with objectives (nRMSE, semantic + virtual-x0 prior)

For each (system, noise, seed) we report on held-out data:

  nrmse_in     in-distribution: new x0 from the training range, t in [0, T]
  nrmse_time   time extrapolation: same x0, t in [T, 2T]
  nrmse_x0     initial-condition extrapolation: x0 from the OOD range
  comp_acc_*   fraction of trajectories with the *correct motif composition*
  size         expression complexity
  gen_first_match   generation at which the best-so-far individual first had
                    the correct composition on the training data
  exact        1 if the discovered RHS is symbolically equivalent to the truth
               (needs sympy; otherwise NaN)

Usage
-----
  python experiments/run_benchmark.py --quick                 # smoke test
  python experiments/run_benchmark.py --systems logistic pk_bateman \
        --noise 0.01 0.05 --seeds 0 1 2 3 4 --pop 300 --gens 60
Results are appended to results/results.csv (one row per run).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from typing import Dict, List

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from semge import (Evaluator, FitnessConfig, GEConfig, Grammar,  # noqa: E402
                   GrammaticalEvolution, compile_expression, simulate, simulate_adaptive, systems)
from semge.fitness import composition_accuracy, nrmse  # noqa: E402
from semge.grammar import DEFAULT_ODE_GRAMMAR  # noqa: E402
from semge.motifs import semantic_representation  # noqa: E402

CONDITIONS: Dict[str, Dict] = {
    "GE-RMSE":       dict(mode="rmse", prior=False),
    "GE-SEM":        dict(mode="semantic", prior=False),
    "GE-HYB":        dict(mode="hybrid", prior=False),
    "GE-HYB+PRIOR":  dict(mode="hybrid", prior=True),
    "GE-RMSE+PRIOR": dict(mode="rmse", prior=True),
    # prior additionally enforced on 6 *virtual* initial conditions spanning the
    # expert's plausible range (no data there) -> targets x0-extrapolation
    "GE-HYB+VPRIOR": dict(mode="hybrid", prior=True, virtual_x0=6),
    # NSGA-II: fit (nRMSE) and behaviour (semantic + prior) as two objectives,
    # final model = weight-free knee of the Pareto front (prior-feasible preferred)
    "GE-NSGA":        dict(mode="hybrid", prior=False, selection="nsga2"),
    "GE-NSGA+VPRIOR": dict(mode="hybrid", prior=True, virtual_x0=6, selection="nsga2"),
    # same search, but the final model is the best-fitting prior-feasible front member
    "GE-NSGA+VPRIOR-FIT": dict(mode="hybrid", prior=True, virtual_x0=6, selection="nsga2", nsga_pick="fit"),
}


def symbolic_match(pheno: str, truth: str) -> float:
    """1.0 if sympy can show pheno == truth (up to simplification), else 0.0."""
    try:
        import sympy as sp
    except ImportError:
        return float("nan")
    try:
        x, t = sp.symbols("x t", positive=True)
        loc = {"x": x, "t": t, "exp": sp.exp, "log": sp.log, "sqrt": sp.sqrt, "sin": sp.sin}
        a = sp.sympify(pheno.replace("^", "**"), locals=loc)
        b = sp.sympify(truth.replace("^", "**"), locals=loc)
        d = sp.simplify(a - b)
        if d == 0:
            return 1.0
        # numeric tolerance check on a grid
        f = sp.lambdify((x, t), d, "numpy")
        xs = np.linspace(0.2, 3.0, 15)
        ts = np.linspace(0.0, 5.0, 15)
        vals = np.array([[f(xx, tt) for tt in ts] for xx in xs], dtype=float)
        return float(np.max(np.abs(vals)) < 1e-2)
    except Exception:
        return 0.0


def evaluate_on_heldout(pheno: str, system: systems.System, noise: float, seed: int) -> Dict[str, float]:
    """Held-out metrics. Uses an adaptive (stiff-capable) integrator so that a
    stiff-but-valid discovered model is not scored as a blow-up."""
    f = compile_expression(pheno)
    out: Dict[str, float] = {}
    # in-distribution
    d_in = systems.make_dataset(system, n_traj=8, n_points=60, noise=noise, split="train", seed=seed + 1000)
    X = simulate_adaptive(f, d_in.x0, d_in.t)
    out["nrmse_in"] = nrmse(d_in.X_clean, X)
    out["comp_acc_in"] = composition_accuracy(d_in.X_clean, X, d_in.t)
    # time extrapolation: integrate both to 2T, score on [T, 2T]
    t2 = np.linspace(0, 2 * system.t_end, 120)
    Xt_true = simulate_adaptive(system.f, d_in.x0, t2)
    Xt = simulate_adaptive(f, d_in.x0, t2)
    half = t2 >= system.t_end
    out["nrmse_time"] = nrmse(Xt_true[:, half], Xt[:, half], scale=np.ptp(Xt_true))
    out["comp_acc_time"] = composition_accuracy(Xt_true, Xt, t2)
    # x0 extrapolation
    d_ood = systems.make_dataset(system, n_traj=8, n_points=60, noise=noise, split="test", seed=seed + 2000)
    Xo = simulate_adaptive(f, d_ood.x0, d_ood.t)
    out["nrmse_x0"] = nrmse(d_ood.X_clean, Xo)
    out["comp_acc_x0"] = composition_accuracy(d_ood.X_clean, Xo, d_ood.t)
    return out


def run_one(system: systems.System, cond_name: str, noise: float, seed: int,
            pop: int, gens: int, verbose: bool = False) -> Dict:
    cond = CONDITIONS[cond_name]
    train = systems.make_dataset(system, n_traj=8, n_points=60, noise=noise, split="train", seed=seed)
    prior_x0 = None
    if cond.get("virtual_x0") and system.prior:
        prior_x0 = np.linspace(system.prior_x0[0], system.prior_x0[1], cond["virtual_x0"])
    fcfg = FitnessConfig(mode=cond["mode"], alpha=0.5,
                         prior=system.prior if cond["prior"] else None, prior_weight=1.0,
                         prior_x0=prior_x0)
    ev = Evaluator(train, fcfg)
    # a neutral evaluator used only to *report* the semantic score of the result
    reporter = Evaluator(train, FitnessConfig(mode="hybrid"))
    grammar = Grammar.from_text(DEFAULT_ODE_GRAMMAR)

    # monitor: does the candidate reproduce the true composition on train?
    true_comps = [semantic_representation(train.t, train.X_clean[i], smooth=False).composition
                  for i in range(train.X.shape[0])]

    def monitor(pheno: str) -> bool:
        X = ev.simulate_phenotype(pheno)
        if X is None or not np.all(np.isfinite(X)):
            return False
        hits = 0
        for i in range(X.shape[0]):
            try:
                hits += semantic_representation(train.t, X[i], smooth=False).composition == true_comps[i]
            except Exception:
                pass
        return hits == X.shape[0]

    gcfg = GEConfig(pop_size=pop, generations=gens, seed=seed, verbose=verbose,
                    selection=cond.get("selection", "tournament"),
                    nsga_pick=cond.get("nsga_pick", "knee"))
    ge = GrammaticalEvolution(grammar, ev, gcfg, comp_monitor=monitor)
    res = ge.run()
    best = res.best
    row = dict(system=system.name, condition=cond_name, noise=noise, seed=seed,
               phenotype=best.phenotype, train_fitness=best.fitness,
               train_nrmse=best.scores.get("nrmse"),
               train_semantic=reporter.evaluate(best.phenotype)["semantic"],
               size=best.scores.get("size"), gen_first_match=res.gen_first_composition_match,
               evaluations=res.evaluations, wall_time_s=res.wall_time_s,
               exact=symbolic_match(best.phenotype, system.formula) if best.phenotype else 0.0,
               history=json.dumps(res.history))
    if best.phenotype is not None and best.fitness < 1e3:
        row.update(evaluate_on_heldout(best.phenotype, system, noise, seed))
    else:
        row.update({k: np.nan for k in ["nrmse_in", "comp_acc_in", "nrmse_time",
                                         "comp_acc_time", "nrmse_x0", "comp_acc_x0"]})
    return row


def _run_job(job):
    sname, cname, noise, seed, pop, gens, verbose = job
    return run_one(systems.SYSTEMS[sname], cname, noise, seed, pop, gens, verbose)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--systems", nargs="+", default=list(systems.SYSTEMS))
    ap.add_argument("--conditions", nargs="+", default=list(CONDITIONS))
    ap.add_argument("--noise", nargs="+", type=float, default=[0.01, 0.05])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4])
    ap.add_argument("--pop", type=int, default=300)
    ap.add_argument("--gens", type=int, default=60)
    ap.add_argument("--out", default="results/results.csv")
    ap.add_argument("--quick", action="store_true", help="tiny smoke-test configuration")
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--jobs", type=int, default=1, help="parallel worker processes")
    args = ap.parse_args()

    if args.quick:
        args.systems = ["logistic", "pk_bateman"]
        args.conditions = ["GE-RMSE", "GE-HYB+PRIOR"]
        args.noise = [0.01]
        args.seeds = [0]
        args.pop, args.gens = 80, 12

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    jobs = [(sname, cname, noise, seed, args.pop, args.gens, args.verbose)
            for sname in args.systems for noise in args.noise
            for seed in args.seeds for cname in args.conditions]
    total = len(jobs)
    rows: List[Dict] = []

    def report(k: int, row: Dict) -> None:
        print(f"[{k}/{total}] {row['system']:12s} {row['condition']:14s} noise={row['noise']} "
              f"seed={row['seed']} | in={row['nrmse_in']:.3f} time={row['nrmse_time']:.3f} "
              f"x0={row['nrmse_x0']:.3f} comp_x0={row['comp_acc_x0']:.2f} "
              f"| {row['phenotype']}  ({row['wall_time_s']:.0f}s)", flush=True)
        pd.DataFrame([row]).to_csv(args.out, mode="a", index=False,
                                   header=not os.path.exists(args.out))

    if args.jobs > 1:
        from multiprocessing import Pool
        with Pool(args.jobs) as pool:
            for k, row in enumerate(pool.imap_unordered(_run_job, jobs), 1):
                rows.append(row)
                report(k, row)
    else:
        for k, job in enumerate(jobs, 1):
            row = _run_job(job)
            rows.append(row)
            report(k, row)
    print(f"\nwrote {len(rows)} rows to {args.out}")


if __name__ == "__main__":
    main()
