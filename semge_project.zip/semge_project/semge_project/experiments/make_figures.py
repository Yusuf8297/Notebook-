#!/usr/bin/env python3
"""
Manuscript figures from results/results.csv.

  python experiments/make_figures.py results/results.csv

Writes to results/figures/:
  fig1_tradeoff.png     in-domain fit vs OOD-x0 error, one point per condition (median), per system
  fig2_metrics.png      median nRMSE (in / time / x0) and mean composition accuracy per condition
  fig3_wins.png         paired win-rate vs GE-RMSE per metric and condition
  fig4_convergence.png  median generation at which the best model first became semantically correct
"""

from __future__ import annotations

import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

ORDER = ["GE-RMSE", "GE-RMSE+PRIOR", "GE-SEM", "GE-HYB", "GE-HYB+PRIOR", "GE-HYB+VPRIOR",
         "GE-NSGA", "GE-NSGA+VPRIOR", "GE-NSGA+VPRIOR-FIT"]
# fixed categorical assignment (validated default palette, light mode)
COLORS = {"GE-RMSE": "#2a78d6", "GE-RMSE+PRIOR": "#eb6834", "GE-SEM": "#1baf7a", "GE-HYB": "#eda100",
          "GE-HYB+PRIOR": "#e87ba4", "GE-HYB+VPRIOR": "#008300", "GE-NSGA": "#4a3aa7",
          "GE-NSGA+VPRIOR": "#e34948", "GE-NSGA+VPRIOR-FIT": "#52514e"}
CAP = 5.0
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.alpha": 0.25, "grid.linewidth": 0.5})


def load(path):
    df = pd.read_csv(path)
    df = df.drop_duplicates(subset=["system", "condition", "noise", "seed"], keep="last")
    for c in ["nrmse_in", "nrmse_time", "nrmse_x0"]:
        df[c] = df[c].clip(upper=CAP)
    conds = [c for c in ORDER if c in set(df.condition)]
    return df, conds


def fig_tradeoff(df, conds, out):
    systems = sorted(df.system.unique())
    fig, axes = plt.subplots(1, len(systems), figsize=(2.6 * len(systems), 3.0), sharey=False)
    for ax, sysm in zip(np.atleast_1d(axes), systems):
        sub = df[df.system == sysm]
        for c in conds:
            s = sub[sub.condition == c]
            x, y = s.nrmse_in.median(), s.nrmse_x0.median()
            ax.scatter(x, y, s=36, color=COLORS[c], edgecolor="white", linewidth=1.2, zorder=3,
                       label=c if sysm == systems[0] else None)
        ax.set_title(sysm, fontsize=9)
        ax.set_xlabel("in-domain nRMSE (median)")
        ax.set_xscale("log")
        ax.set_yscale("log")
    np.atleast_1d(axes)[0].set_ylabel("OOD-x0 nRMSE (median)")
    fig.legend(loc="lower center", ncol=min(len(conds), 4), fontsize=7, frameon=False,
               bbox_to_anchor=(0.5, -0.12))
    fig.suptitle("Fit vs extrapolation: lower-left is better", fontsize=10)
    fig.tight_layout()
    fig.savefig(out, dpi=160, bbox_inches="tight")
    plt.close(fig)


def fig_metrics(df, conds, out):
    metrics = [("nrmse_in", "in-domain nRMSE", "median"), ("nrmse_time", "time-extrapolation nRMSE", "median"),
               ("nrmse_x0", "OOD-x0 nRMSE", "median"), ("comp_acc_x0", "composition accuracy, OOD x0", "mean")]
    fig, axes = plt.subplots(1, 4, figsize=(13, 3.2))
    for ax, (m, title, agg) in zip(axes, metrics):
        vals = df.groupby("condition")[m].agg(agg).reindex(conds)
        lo = df.groupby("condition")[m].quantile(0.25).reindex(conds)
        hi = df.groupby("condition")[m].quantile(0.75).reindex(conds)
        y = np.arange(len(conds))
        ax.barh(y, vals.values, color=[COLORS[c] for c in conds], height=0.6)
        if agg == "median":
            ax.errorbar(vals.values, y, xerr=[vals.values - lo.values, hi.values - vals.values],
                        fmt="none", ecolor="#52514e", elinewidth=0.8, capsize=2)
        for yi, v in zip(y, vals.values):
            ax.text(v, yi, f" {v:.3f}", va="center", fontsize=7, color="#0b0b0b")
        ax.set_yticks(y)
        ax.set_yticklabels(conds if ax is axes[0] else [""] * len(conds))
        ax.invert_yaxis()
        ax.set_title(title + (" (median, IQR)" if agg == "median" else " (mean)"), fontsize=8)
        ax.grid(axis="y", visible=False)
    fig.tight_layout()
    fig.savefig(out, dpi=160)
    plt.close(fig)


def fig_wins(df, conds, out, baseline="GE-RMSE"):
    metrics = ["nrmse_in", "nrmse_time", "nrmse_x0", "comp_acc_x0"]
    base = df[df.condition == baseline].set_index(["system", "noise", "seed"])
    rows = []
    for c in conds:
        if c == baseline:
            continue
        o = df[df.condition == c].set_index(["system", "noise", "seed"])
        idx = base.index.intersection(o.index)
        for m in metrics:
            a, b = o.loc[idx, m].values, base.loc[idx, m].values
            better = (a < b) if m.startswith("nrmse") else (a > b)
            tie = a == b
            rows.append(dict(condition=c, metric=m, win=better.mean(), tie=tie.mean(), n=len(idx)))
    w = pd.DataFrame(rows)
    fig, axes = plt.subplots(1, 4, figsize=(13, 3.0), sharey=True)
    cc = [c for c in conds if c != baseline]
    for ax, m in zip(axes, metrics):
        s = w[w.metric == m].set_index("condition").reindex(cc)
        y = np.arange(len(cc))
        ax.barh(y, s.win.values, color=[COLORS[c] for c in cc], height=0.6)
        ax.barh(y, s.tie.values, left=s.win.values, color="#c3c2b7", height=0.6)
        ax.axvline(0.5, color="#52514e", lw=0.8, ls="--")
        for yi, v in zip(y, s.win.values):
            ax.text(v + 0.01, yi, f"{v:.2f}", va="center", fontsize=7)
        ax.set_yticks(y)
        ax.set_yticklabels(cc)
        ax.invert_yaxis()
        ax.set_xlim(0, 1.05)
        ax.set_title(f"{m}: win-rate vs {baseline} (grey = tie)", fontsize=8)
        ax.grid(axis="y", visible=False)
    fig.tight_layout()
    fig.savefig(out, dpi=160)
    plt.close(fig)


def fig_convergence(df, conds, out):
    g = df.groupby("condition")["gen_first_match"]
    med = g.median().reindex(conds)
    never = g.apply(lambda v: v.isna().mean()).reindex(conds)
    fig, axes = plt.subplots(1, 2, figsize=(8, 3.0))
    y = np.arange(len(conds))
    axes[0].barh(y, med.values, color=[COLORS[c] for c in conds], height=0.6)
    axes[0].set_yticks(y); axes[0].set_yticklabels(conds); axes[0].invert_yaxis()
    axes[0].set_title("median generation of first semantically-correct model", fontsize=8)
    axes[1].barh(y, never.values, color=[COLORS[c] for c in conds], height=0.6)
    axes[1].set_yticks(y); axes[1].set_yticklabels([""] * len(conds)); axes[1].invert_yaxis()
    axes[1].set_xlim(0, 1)
    axes[1].set_title("fraction of runs never semantically correct", fontsize=8)
    for ax in axes:
        ax.grid(axis="y", visible=False)
    fig.tight_layout()
    fig.savefig(out, dpi=160)
    plt.close(fig)


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "results/results.csv"
    df, conds = load(path)
    outdir = os.path.join(os.path.dirname(path) or ".", "figures")
    os.makedirs(outdir, exist_ok=True)
    fig_tradeoff(df, conds, os.path.join(outdir, "fig1_tradeoff.png"))
    fig_metrics(df, conds, os.path.join(outdir, "fig2_metrics.png"))
    fig_wins(df, conds, os.path.join(outdir, "fig3_wins.png"))
    fig_convergence(df, conds, os.path.join(outdir, "fig4_convergence.png"))
    print("figures written to", outdir)


if __name__ == "__main__":
    main()
