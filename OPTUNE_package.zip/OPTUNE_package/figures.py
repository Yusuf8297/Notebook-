"""OPTUNE v2 — publication figures (matplotlib, journal style)."""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

# --- palette (validated categorical order; light surface) ---
SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
BASE = "#c3c2b7"
SLOTS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100",
         "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
MODELS = ["TabNet", "LogisticRegression", "SVM", "RandomForest",
          "XGBoost", "LightGBM", "CatBoost", "MLP"]
MODEL_COLOR = dict(zip(MODELS, SLOTS))
MODEL_LABEL = {"TabNet": "TabNet", "LogisticRegression": "LR", "SVM": "SVM",
               "RandomForest": "RF", "XGBoost": "XGBoost",
               "LightGBM": "LightGBM", "CatBoost": "CatBoost", "MLP": "MLP"}
DS_LABEL = {"wdbc": "WDBC (n=569)", "coimbra": "Coimbra (n=116)",
            "mammographic": "Mammographic (n=961)", "cervical": "Cervical (n=858)"}
SEQ_BLUE = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
    "savefig.facecolor": SURFACE,
    "font.family": "DejaVu Sans", "font.size": 9,
    "axes.edgecolor": BASE, "axes.linewidth": 0.8,
    "axes.labelcolor": INK, "axes.titlecolor": INK,
    "xtick.color": MUTED, "ytick.color": MUTED,
    "xtick.labelcolor": INK2, "ytick.labelcolor": INK2,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
    "axes.spines.top": False, "axes.spines.right": False,
    "legend.frameon": False,
})

FIG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figures")
os.makedirs(FIG, exist_ok=True)


def _ci95(x):
    x = np.asarray(x)
    se = stats.sem(x)
    return se * stats.t.ppf(0.975, len(x) - 1)


def fig_forest_auc(folds, metric="roc_auc", fname="fig2_forest_auc.png"):
    """Mean ± 95% CI per model per dataset (tuned), forest style."""
    datasets = [d for d in ["wdbc", "coimbra", "mammographic", "cervical"]
                if d in folds.dataset.unique()]
    fig, axes = plt.subplots(1, len(datasets), figsize=(3.1 * len(datasets), 3.4),
                             sharey=True)
    if len(datasets) == 1:
        axes = [axes]
    for ax, ds in zip(axes, datasets):
        sub = folds[(folds.dataset == ds) & (folds.variant == "tuned")]
        ypos = np.arange(len(MODELS))[::-1]
        for i, m in enumerate(MODELS):
            v = sub[sub.model == m][metric].values
            mu, h = v.mean(), _ci95(v)
            ax.errorbar(mu, ypos[i], xerr=h, fmt="o", color=MODEL_COLOR[m],
                        ecolor=MODEL_COLOR[m], ms=5, capsize=2.5, lw=1.6)
            ax.text(0.005 + ax.get_xlim()[0], ypos[i], "", fontsize=7)
        ax.set_yticks(ypos)
        ax.set_yticklabels([MODEL_LABEL[m] for m in MODELS], fontsize=8.5)
        ax.set_title(DS_LABEL[ds], fontsize=9.5, pad=6)
        ax.set_xlabel("ROC-AUC (outer folds)", fontsize=8.5)
        ax.grid(axis="x", alpha=.8)
        ax.grid(axis="y", visible=False)
    fig.suptitle("Nested-CV performance: mean ROC-AUC with 95% CI (10 outer folds)",
                 fontsize=10.5, y=1.02)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, fname), dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig_tuned_vs_default(tv, fname="fig3_tuned_vs_default.png"):
    """Dumbbell: default -> tuned AUC per model, one panel per dataset."""
    datasets = [d for d in ["wdbc", "coimbra", "mammographic", "cervical"]
                if d in tv.dataset.unique()]
    fig, axes = plt.subplots(1, len(datasets), figsize=(3.1 * len(datasets), 3.4),
                             sharey=True)
    if len(datasets) == 1:
        axes = [axes]
    for ax, ds in zip(axes, datasets):
        sub = tv[tv.dataset == ds].set_index("model").reindex(MODELS)
        ypos = np.arange(len(MODELS))[::-1]
        for i, m in enumerate(MODELS):
            d0, d1 = sub.loc[m, "auc_default"], sub.loc[m, "auc_tuned"]
            c = MODEL_COLOR[m]
            ax.plot([d0, d1], [ypos[i], ypos[i]], color=c, lw=1.4, alpha=.65,
                    zorder=1)
            ax.scatter([d0], [ypos[i]], s=26, facecolor=SURFACE, edgecolor=c,
                       lw=1.4, zorder=2)
            ax.scatter([d1], [ypos[i]], s=30, color=c, zorder=3)
        ax.set_yticks(ypos)
        ax.set_yticklabels([MODEL_LABEL[m] for m in MODELS], fontsize=8.5)
        ax.set_title(DS_LABEL[ds], fontsize=9.5, pad=6)
        ax.set_xlabel("ROC-AUC", fontsize=8.5)
        ax.grid(axis="y", visible=False)
    handles = [plt.Line2D([], [], marker="o", ls="", mfc=SURFACE, mec=INK2,
                          label="default"),
               plt.Line2D([], [], marker="o", ls="", color=INK2, label="TPE-tuned")]
    fig.legend(handles=handles, loc="upper right", fontsize=8.5,
               bbox_to_anchor=(0.995, 1.06), ncol=2)
    fig.suptitle("Benefit of Bayesian optimization: default vs tuned (mean over folds)",
                 fontsize=10.5, y=1.04, x=0.42)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, fname), dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig_cd_diagram(avg_ranks, cd, fname="fig4_cd_diagram.png"):
    """Critical-difference diagram (Demsar style)."""
    ranks = avg_ranks.sort_values()
    k = len(ranks)
    fig, ax = plt.subplots(figsize=(7.0, 2.6))
    lo, hi = 1, k
    ax.set_xlim(lo - 0.3, hi + 0.3)
    ax.set_ylim(0, 3.6)
    ax.axis("off")
    # axis line
    ax.plot([lo, hi], [3.0, 3.0], color=INK, lw=1.2)
    for t in range(lo, hi + 1):
        ax.plot([t, t], [3.0, 3.06], color=INK, lw=1.0)
        ax.text(t, 3.14, str(t), ha="center", fontsize=8.5, color=INK2)
    # CD bar
    ax.plot([lo, lo + cd], [3.42, 3.42], color=INK, lw=2.2)
    ax.text(lo + cd / 2, 3.50, f"CD = {cd:.2f}", ha="center", fontsize=8.5,
            color=INK)
    # model lines
    items = list(ranks.items())
    left = items[: (k + 1) // 2]
    right = items[(k + 1) // 2:]
    for i, (m, r) in enumerate(left):
        y = 2.55 - i * 0.55
        ax.plot([r, r], [3.0, y], color=MODEL_COLOR[m], lw=1.3)
        ax.plot([r, lo - 0.25], [y, y], color=MODEL_COLOR[m], lw=1.3)
        ax.text(lo - 0.28, y, f"{MODEL_LABEL[m]} ({r:.2f})", ha="right",
                va="center", fontsize=8.8, color=INK)
    for i, (m, r) in enumerate(right):
        y = 2.55 - (len(right) - 1 - i) * 0.55
        ax.plot([r, r], [3.0, y], color=MODEL_COLOR[m], lw=1.3)
        ax.plot([r, hi + 0.25], [y, y], color=MODEL_COLOR[m], lw=1.3)
        ax.text(hi + 0.28, y, f"({r:.2f}) {MODEL_LABEL[m]}", ha="left",
                va="center", fontsize=8.8, color=INK)
    ax.set_title("Average ranks across datasets (ROC-AUC), Nemenyi CD at α=0.05",
                 fontsize=10, color=INK, pad=14)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, fname), dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig_calibration(oof, datasets=None, models_to_show=None,
                    fname="fig5_calibration.png", n_bins=8):
    """Reliability curves from out-of-fold predictions."""
    from sklearn.calibration import calibration_curve
    datasets = datasets or [d for d in ["wdbc", "coimbra", "mammographic", "cervical"]
                            if d in oof.dataset.unique()]
    models_to_show = models_to_show or ["TabNet", "LogisticRegression",
                                        "LightGBM", "SVM"]
    fig, axes = plt.subplots(1, len(datasets), figsize=(3.0 * len(datasets), 3.2),
                             sharey=True)
    if len(datasets) == 1:
        axes = [axes]
    for ax, ds in zip(axes, datasets):
        ax.plot([0, 1], [0, 1], color=BASE, lw=1.0, ls="--", zorder=1)
        for m in models_to_show:
            g = oof[(oof.dataset == ds) & (oof.model == m)]
            if g.empty:
                continue
            frac, mean_p = calibration_curve(g.y_true, g.proba, n_bins=n_bins,
                                             strategy="quantile")
            ax.plot(mean_p, frac, marker="o", ms=3.5, lw=1.6,
                    color=MODEL_COLOR[m], label=MODEL_LABEL[m])
        ax.set_title(DS_LABEL[ds], fontsize=9.5)
        ax.set_xlabel("Predicted probability", fontsize=8.5)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
    axes[0].set_ylabel("Observed frequency", fontsize=8.5)
    axes[0].legend(fontsize=8, loc="upper left")
    fig.suptitle("Calibration of out-of-fold predictions (quantile bins)",
                 fontsize=10.5, y=1.03)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, fname), dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig_decision_curves(oof, net_benefit_fn, datasets=None,
                        models_to_show=None, fname="fig6_dca.png"):
    datasets = datasets or [d for d in ["wdbc", "coimbra", "mammographic", "cervical"]
                            if d in oof.dataset.unique()]
    models_to_show = models_to_show or ["TabNet", "LogisticRegression", "LightGBM"]
    fig, axes = plt.subplots(1, len(datasets), figsize=(3.0 * len(datasets), 3.2))
    if len(datasets) == 1:
        axes = [axes]
    for ax, ds in zip(axes, datasets):
        sub = oof[oof.dataset == ds]
        prev = sub[sub.model == models_to_show[0]].y_true.mean()
        thr = np.linspace(0.01, min(0.6, prev * 4), 60)
        first = True
        for m in models_to_show:
            g = sub[sub.model == m]
            if g.empty:
                continue
            nb = net_benefit_fn(g.y_true.values, g.proba.values, thr)
            if first:
                ax.plot(nb.threshold, nb.treat_all, color=MUTED, lw=1.2, ls="--",
                        label="treat all")
                ax.axhline(0, color=BASE, lw=1.0, label="treat none")
                first = False
            ax.plot(nb.threshold, nb.net_benefit, lw=1.7, color=MODEL_COLOR[m],
                    label=MODEL_LABEL[m])
        ax.set_ylim(bottom=-0.02)
        ax.set_title(DS_LABEL[ds], fontsize=9.5)
        ax.set_xlabel("Threshold probability", fontsize=8.5)
    axes[0].set_ylabel("Net benefit", fontsize=8.5)
    axes[0].legend(fontsize=7.5, loc="best")
    fig.suptitle("Decision-curve analysis (out-of-fold predictions)",
                 fontsize=10.5, y=1.03)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, fname), dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig_importance_stability(M, names, cors, top_k=12,
                             fname="fig7_attention_stability.png"):
    """Boxplot of TabNet per-fold importances for top features + fold-pair
    Spearman distribution."""
    order = np.argsort(M.mean(axis=0))[::-1][:top_k]
    fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.6),
                             gridspec_kw={"width_ratios": [2.4, 1]})
    ax = axes[0]
    data = [M[:, i] for i in order][::-1]
    labels = [names[i] for i in order][::-1]
    bp = ax.boxplot(data, vert=False, patch_artist=True, widths=0.55,
                    medianprops={"color": INK, "lw": 1.2},
                    flierprops={"marker": "o", "ms": 3, "mfc": MUTED,
                                "mec": "none"})
    for patch in bp["boxes"]:
        patch.set_facecolor(SEQ_BLUE[1])
        patch.set_edgecolor(SEQ_BLUE[4])
        patch.set_linewidth(1.0)
    for el in ["whiskers", "caps"]:
        for line in bp[el]:
            line.set_color(SEQ_BLUE[4])
    ax.set_yticklabels(labels, fontsize=8)
    ax.set_xlabel("TabNet attention importance", fontsize=8.5)
    ax.set_title("Per-fold global importances (top features)", fontsize=9.5)
    ax.grid(axis="y", visible=False)

    ax = axes[1]
    ax.hist(cors, bins=12, color=SEQ_BLUE[3], edgecolor=SURFACE)
    ax.axvline(np.median(cors), color=INK, lw=1.3)
    ax.text(np.median(cors), ax.get_ylim()[1] * 0.95,
            f" median ρ = {np.median(cors):.2f}", fontsize=8.5, color=INK,
            va="top")
    ax.set_xlabel("Fold-pair Spearman ρ", fontsize=8.5)
    ax.set_ylabel("Count", fontsize=8.5)
    ax.set_title("Attribution stability across folds", fontsize=9.5)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, fname), dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig_attribution_agreement(imp_df, fname="fig8_attribution_agreement.png"):
    """imp_df: DataFrame with columns [feature, tabnet, shap_xgb, permutation],
    normalized. Scatter + Kendall tau annotations."""
    pairs = [("tabnet", "shap_xgb", "TabNet attention vs XGBoost |SHAP|"),
             ("tabnet", "permutation", "TabNet attention vs permutation")]
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.4))
    for ax, (a, b, title) in zip(axes, pairs):
        x, y = imp_df[a], imp_df[b]
        tau = stats.kendalltau(x, y).correlation
        rho = stats.spearmanr(x, y).correlation
        ax.scatter(x, y, s=26, color=SLOTS[0], alpha=0.85, edgecolor=SURFACE,
                   lw=0.6)
        top = imp_df.nlargest(4, a)
        for _, r in top.iterrows():
            ax.annotate(r["feature"], (r[a], r[b]), fontsize=7, color=INK2,
                        xytext=(4, 3), textcoords="offset points")
        ax.set_title(f"{title}\nKendall τ = {tau:.2f}, Spearman ρ = {rho:.2f}",
                     fontsize=9)
        ax.set_xlabel("TabNet importance", fontsize=8.5)
        ax.set_ylabel("Reference importance", fontsize=8.5)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, fname), dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig_instance_masks(masks, feature_names, y_true, fname="fig9_instance_masks.png",
                       max_instances=40, top_k=15):
    """Instance-level aggregated attention masks (test fold), sorted by class."""
    order_feat = np.argsort(masks.mean(axis=0))[::-1][:top_k]
    order_inst = np.argsort(y_true)
    Msub = masks[order_inst][:, order_feat]
    ysub = np.array(y_true)[order_inst]
    if len(ysub) > max_instances:
        keep = np.linspace(0, len(ysub) - 1, max_instances).astype(int)
        Msub, ysub = Msub[keep], ysub[keep]
    from matplotlib.colors import LinearSegmentedColormap
    cmap = LinearSegmentedColormap.from_list("seqblue", ["#ffffff"] + SEQ_BLUE)
    fig, ax = plt.subplots(figsize=(7.6, 4.2))
    im = ax.imshow(Msub.T, aspect="auto", cmap=cmap)
    ax.set_yticks(range(top_k))
    ax.set_yticklabels([feature_names[i] for i in order_feat], fontsize=7.5)
    ax.set_xlabel("Test-fold patients (sorted: benign → malignant)", fontsize=8.5)
    # class divider
    split = np.searchsorted(ysub, 1)
    ax.axvline(split - 0.5, color=INK, lw=1.2)
    ax.text(split / 2, -1.2, "benign", ha="center", fontsize=8, color=INK2)
    ax.text((split + len(ysub)) / 2, -1.2, "malignant", ha="center", fontsize=8,
            color=INK2)
    cb = fig.colorbar(im, ax=ax, shrink=0.85, pad=0.01)
    cb.set_label("Aggregated attention mask", fontsize=8)
    cb.outline.set_visible(False)
    ax.set_title("Instance-level TabNet attention (WDBC held-out fold)",
                 fontsize=10, pad=10)
    ax.grid(visible=False)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, fname), dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig_hp_importance(series_by_ds, fname="fig10_hp_importance.png"):
    """Bar panels of surrogate hyperparameter importance per dataset (TabNet)."""
    datasets = list(series_by_ds.keys())
    fig, axes = plt.subplots(1, len(datasets), figsize=(2.9 * len(datasets), 3.0),
                             sharey=False)
    if len(datasets) == 1:
        axes = [axes]
    for ax, ds in zip(axes, datasets):
        s = series_by_ds[ds]
        ax.barh(range(len(s))[::-1], s.values, color=SEQ_BLUE[3],
                edgecolor=SURFACE, height=0.6)
        ax.set_yticks(range(len(s))[::-1])
        ax.set_yticklabels(s.index, fontsize=8)
        ax.set_title(DS_LABEL[ds], fontsize=9.5)
        ax.set_xlabel("Surrogate importance", fontsize=8.5)
        ax.grid(axis="y", visible=False)
    fig.suptitle("TabNet hyperparameter importance (RF surrogate on pooled TPE trials)",
                 fontsize=10.5, y=1.04)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, fname), dpi=300, bbox_inches="tight")
    plt.close(fig)
