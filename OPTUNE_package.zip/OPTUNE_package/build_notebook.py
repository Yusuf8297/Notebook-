"""Assemble the OPTUNE v2 notebook (framework inline + executed analysis)."""
import nbformat as nbf

BASE = "/home/claude/optune_v2"

with open(f"{BASE}/framework.py") as f:
    FRAMEWORK_SRC = f.read()
with open(f"{BASE}/analysis.py") as f:
    ANALYSIS_SRC = f.read()
with open(f"{BASE}/figures.py") as f:
    FIGURES_SRC = f.read()

nb = nbf.v4.new_notebook()
nb.metadata.kernelspec = {"display_name": "Python 3", "language": "python",
                          "name": "python3"}
C = []


def md(text):
    C.append(nbf.v4.new_markdown_cell(text))


def code(src):
    C.append(nbf.v4.new_code_cell(src))


md(r"""# OPTUNE v2 — Bayesian-Optimized TabNet for Cancer Classification
## A Rigorous Multi-Dataset Nested Cross-Validation Benchmark

**Upgraded experimental framework** accompanying the manuscript revision of
*"Bayesian-Optimized TabNet for Cancer Classification: A Comprehensive Benchmarking Study"*.

This notebook replaces the v1 single-dataset holdout experiment with a methodologically
rigorous, publication-grade study. The ten key upgrades over v1:

| # | v1 weakness | v2 fix |
|---|-------------|--------|
| 1 | Single 80/10/10 holdout; paper claimed 3×10 CV | Repeated stratified **nested** cross-validation (2×5 outer folds, 3-fold inner tuning) — code and manuscript now match |
| 2 | Best-of-30-runs selected and reported on validation AUC (selection bias) | Hyperparameters tuned **inside** each outer training fold only; outer test folds never touched during tuning |
| 3 | Single saturated dataset (WDBC) | **Four public cancer datasets** spanning n=116–961, 4–30 features, 6–55% prevalence |
| 4 | Unequal search spaces (TabNet rich, baselines tiny grids) | **Equal HPO budget**: identical TPE sampler, trial count, and inner-CV protocol for all 8 models |
| 5 | SMOTE inflated training metrics; "negative generalization gap" artifact | **Cost-sensitive class weighting**; natural data distributions preserved |
| 6 | Wilcoxon on CV folds (violates independence) | **Nadeau–Bengio variance-corrected t-tests** + Holm correction + effect sizes + Friedman/Nemenyi across datasets |
| 7 | No modern baselines | **LightGBM + CatBoost + MLP** added under identical budget |
| 8 | No probability quality assessment | **Calibration** (Brier, ECE, reliability curves) + **decision-curve analysis** |
| 9 | Interpretability = one global importance bar chart | **Attribution stability across folds** + three-way agreement (attention vs SHAP vs permutation) + instance-level masks |
| 10 | No leakage control in preprocessing | All imputation/scaling **fit inside each training fold** |

*TabPFN was evaluated for inclusion but its pretrained weights could not be retrieved in the
execution environment; the framework supports it as an optional model.*
""")

md("## 1. Environment and configuration")
code("""import platform, sklearn, torch, optuna, xgboost, lightgbm, catboost, pytorch_tabnet, numpy, pandas, scipy
for m in [numpy, pandas, scipy, sklearn, torch, optuna, xgboost, lightgbm, catboost]:
    print(f"{m.__name__:15s} {m.__version__}")
print(f"python          {platform.python_version()}")""")

md("""## 2. Datasets

Four public cancer classification datasets, chosen to span sample size, dimensionality,
class balance, and difficulty:

| Dataset | Source | n | Features | Positive class | Prevalence |
|---|---|---|---|---|---|
| **WDBC** | UCI / sklearn | 569 | 30 (FNA nuclear morphology) | malignant | 37.3% |
| **Coimbra** | UCI 451 | 116 | 9 (serum biomarkers) | breast cancer patient | 55.2% |
| **Mammographic Mass** | UCI 161 | 961 | 4 (age, shape, margin, density) | malignant | 46.3% |
| **Cervical (Risk Factors)** | UCI 383 | 858 | 30 (demographics, history, STDs) | positive biopsy | 6.4% |

Preprocessing decisions (documented for reproducibility):
- **Mammographic**: the BI-RADS column is an expert *assessment*, not a patient measurement — it is
  dropped to prevent target leakage. Missing values (`?`) are median-imputed inside each training fold.
- **Cervical**: the three co-recorded screening outcomes (Hinselmann, Schiller, Citology) are dropped
  (using them to predict biopsy would be leakage); two columns with >85% missingness are dropped.
- All imputation and standardization is fit on each outer-training fold only.""")
code("""import pandas as pd, numpy as np
rows = []
for name in ["wdbc", "coimbra", "mammographic", "cervical"]:
    d = pd.read_csv(f"data/{name}.csv")
    rows.append({"dataset": name, "n": len(d), "features": d.shape[1]-1,
                 "prevalence": round(d.target.mean(), 3),
                 "missing_cells": int(d.isna().sum().sum())})
pd.DataFrame(rows)""")

md(r"""## 3. Methods

**Nested cross-validation.** The outer loop is stratified 5-fold CV repeated twice
(10 outer folds). Within each outer training fold, every model's hyperparameters are tuned by
Optuna TPE (15 trials, multivariate) scored by **mean 3-fold inner-CV ROC-AUC**. The winning
configuration is refit on the full outer-training fold and evaluated once on the outer test fold.
Test folds therefore never influence hyperparameter selection, model selection, or preprocessing —
the estimates below are unbiased estimates of the *whole pipeline's* generalization.

**Equal tuning budget.** All eight models receive the same sampler, the same number of trials, and
the same inner-validation protocol. Default-configuration versions of every model are also evaluated
on the same outer folds, isolating the causal benefit of Bayesian optimization (Section 5).

**Class imbalance.** Cost-sensitive weighting (class-balanced loss / inverse-frequency sampling for
TabNet) instead of SMOTE: synthetic oversampling distorts training distributions, inflates training
metrics, and produced the misleading "negative generalization gap" in v1.

**Statistics.** Paired model comparisons use the Nadeau–Bengio variance-corrected t-test
(accounts for the dependence between overlapping training folds in repeated CV), with Holm
correction over the model family and paired Cohen's d_z effect sizes. Cross-dataset behaviour is
summarized with the Friedman test and Nemenyi critical distance. Wilcoxon signed-rank p-values are
reported alongside for continuity with v1.

**TabNet training.** Early stopping (patience 15, max 100 epochs) on an internal 15% stratified
split of the training fold; StepLR schedule; inverse-frequency sample weighting; batch-size guard
against single-sample BatchNorm batches.""")

code(FRAMEWORK_SRC + "\nprint('framework loaded')")
code(ANALYSIS_SRC.replace('os.path.dirname(os.path.abspath(__file__))',
                          "'.'") + "\nprint('analysis loaded')")
code(FIGURES_SRC.replace('os.path.dirname(os.path.abspath(__file__))',
                         "'.'") + "\nprint('figures loaded')")

md("""### Running the benchmark

The full benchmark (~2 h on 2 CPU cores) writes per-fold metrics, out-of-fold predictions, tuning
traces, and TabNet attention importances to `results/`. The cell below skips execution when
results already exist, so this notebook re-runs analysis instantly on cached results.""")
code("""import os
RUN_FULL = not os.path.exists("results/wdbc_fold_metrics_merged.csv")
if RUN_FULL:
    for ds, path in [("wdbc", "data/wdbc.csv"), ("coimbra", "data/coimbra.csv"),
                     ("mammographic", "data/mammographic.csv"),
                     ("cervical", "data/cervical.csv")]:
        run_benchmark(ds, path, "results")
    print("benchmark complete — run run_analysis.py to merge and analyze")
else:
    print("cached results found — skipping (delete results/ to re-run)")""")

md("""## 4. Results — discrimination performance

Mean ROC-AUC over the 10 outer folds, with 95% CIs. Note how different these honest nested-CV
numbers are from v1's selection-biased holdout numbers: on WDBC, v1 reported a validation AUC of
0.9996 for TabNet; the unbiased estimate for the strongest models is ≈0.99, and **no model separates
from the others on WDBC** — the dataset is saturated, which is precisely why a multi-dataset design
is necessary.""")
code("""DATASETS = ["wdbc", "coimbra", "mammographic", "cervical"]
folds = pd.concat([pd.read_csv(f"results/{d}_fold_metrics_merged.csv") for d in DATASETS],
                  ignore_index=True)
oof = pd.concat([pd.read_csv(f"results/{d}_oof_merged.csv") for d in DATASETS],
                ignore_index=True)
main = (folds[folds.variant == "tuned"]
        .groupby(["dataset", "model"])[["roc_auc", "pr_auc", "balanced_accuracy",
                                        "sensitivity", "specificity", "mcc", "brier"]]
        .mean().round(4))
main.unstack(0)["roc_auc"][ [d for d in DATASETS] ]""")
code("""fig_forest_auc(folds)
from IPython.display import Image, display
display(Image("figures/fig2_forest_auc.png", width=980))""")

md("""### Statistical comparison (TabNet vs each baseline)

Nadeau–Bengio corrected paired t-tests on outer-fold ROC-AUC, Holm-adjusted within each dataset.
Positive `mean_diff` favours TabNet.""")
code("""t3 = pairwise_vs_reference(folds, metric="roc_auc")
t3[["dataset", "comparison", "mean_diff", "t_nb", "p_nb", "p_nb_holm", "dz",
    "p_wilcoxon"]].round(4)""")
code("""means, avg_ranks, fr_stat, fr_p, cd = friedman_ranks(folds)
print(f"Friedman chi-square = {fr_stat:.2f}, p = {fr_p:.4f}; Nemenyi CD (alpha=.05) = {cd:.2f}")
fig_cd_diagram(avg_ranks, cd)
display(Image("figures/fig4_cd_diagram.png", width=760))""")

md("""## 5. The value of Bayesian optimization (RQ3 revisited)

Because tuned and default variants of every model were evaluated on identical outer folds, the
tuned-default difference is a paired, unbiased estimate of what TPE search contributes.""")
code("""tv = tuned_vs_default(folds)
tv.round(4).sort_values(["dataset", "delta"], ascending=[True, False])""")
code("""fig_tuned_vs_default(tv)
display(Image("figures/fig3_tuned_vs_default.png", width=980))""")
code("""import json
series = {}
for ds in DATASETS:
    with open(f"results/{ds}_tuning_merged.json") as f:
        recs = json.load(f)
    from sklearn.ensemble import RandomForestRegressor
    rows, vals = [], []
    for r in recs:
        if r["model"] != "TabNet":
            continue
        for t in r["trials"]:
            if t["value"] and t["value"] > 0:
                rows.append(t["params"]); vals.append(t["value"])
    X = pd.DataFrame(rows)
    for c in X.columns:
        if X[c].dtype == object:
            X[c] = pd.factorize(X[c])[0]
    rf = RandomForestRegressor(n_estimators=500, random_state=0).fit(X.fillna(-1), vals)
    series[ds] = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)
fig_hp_importance(series)
display(Image("figures/fig10_hp_importance.png", width=980))""")

md("""## 6. Clinical utility — calibration, decision curves, operating points

Discrimination alone is not clinical utility. Out-of-fold predicted probabilities (every patient
scored by a model that never saw them) support honest calibration and net-benefit analysis.""")
code("""fig_calibration(oof)
display(Image("figures/fig5_calibration.png", width=980))""")
code("""cal = calibration_table(oof); op = operating_points(oof)
cal.merge(op, on=["dataset", "model"]).round(4).sort_values(["dataset", "brier"])""")
code("""fig_decision_curves(oof, net_benefit, models_to_show=["TabNet", "LogisticRegression", "LightGBM"])
display(Image("figures/fig6_dca.png", width=980))""")

md("""## 7. Interpretability with rigor

v1 showed a single feature-importance bar chart from one trained model. A claim that "TabNet's
attention aligns with clinical knowledge" requires showing that attributions are (a) **stable**
across resampling and (b) **consistent** with independent attribution methods.""")
code("""import numpy as np, json
from scipy import stats as st
with open("results/wdbc_tabnet_importances_merged.json") as f:
    recs = json.load(f)
M = np.array([r["importances"] for r in recs]); names = recs[0]["feature_names"]
cors = [st.spearmanr(M[i], M[j]).correlation
        for i in range(len(M)) for j in range(i+1, len(M))]
fig_importance_stability(M, names, np.array(cors))
display(Image("figures/fig7_attention_stability.png", width=980))""")
code("""perm = pd.read_csv("results/wdbc_tabnet_permutation.csv")
shp = pd.read_csv("results/wdbc_xgb_shap.csv")
feat_cols = [c for c in perm.columns if c not in ("repeat", "fold")]
imp_df = pd.DataFrame({
    "feature": feat_cols,
    "tabnet": pd.Series(M.mean(axis=0), index=names).reindex(feat_cols).values,
    "shap_xgb": (shp[feat_cols].mean() / shp[feat_cols].mean().sum()).values,
    "permutation": (perm[feat_cols].mean().clip(lower=0)
                    / perm[feat_cols].mean().clip(lower=0).sum()).values})
fig_attribution_agreement(imp_df)
display(Image("figures/fig8_attribution_agreement.png", width=880))""")
code("""z = np.load("results/wdbc_instance_masks.npz", allow_pickle=True)
masks = z["masks"]; masks = masks / masks.sum(axis=1, keepdims=True).clip(min=1e-9)
fig_instance_masks(masks, list(z["feature_names"]), z["y_true"])
display(Image("figures/fig9_instance_masks.png", width=880))""")

md("""## 8. Key findings

1. **Honest performance estimates.** Under leakage-free nested CV, no single model dominates:
   WDBC is saturated (seven of eight models above 0.99 AUC within one SD of each other), while harder
   tasks (Coimbra, cervical biopsy, AUC ceilings ~0.82 and ~0.66) expose real differences. Claims
   built on a single saturated benchmark do not generalize - the multi-dataset design is the
   substance of the contribution.
2. **TabNet does not earn its complexity on these datasets.** With equal tuning budgets it has
   the worst average rank (7.75/8 across datasets), although no pairwise difference survives the
   conservative Nadeau-Bengio correction on 10 folds. This reframes the paper from "TabNet wins"
   to "when does attention-based tabular DL earn its complexity?" - consistent with, and adding
   cancer-specific evidence to, Grinsztajn et al. (2022) and Shwartz-Ziv & Armon (2022).
3. **Bayesian optimization helps most where variance is high** (small n, weak signal) and helps
   deep/complex models more than linear ones (Section 5).
4. **Calibration and net benefit differ across models with similar AUC** — the clinically relevant
   distinction v1 could not see.
5. **TabNet's attention explanations are less trustworthy than v1 claimed.** Averaged over folds
   the importance profile recovers the classical extreme-morphology ("worst") features and agrees
   moderately with permutation importance (Kendall tau ~ 0.55), but per-fold attention rankings are
   unstable (median fold-pair Spearman rho ~ 0.14) and agreement with TreeSHAP is weak (tau ~ 0.29).
   Attention masks should not be presented as reliable per-patient explanations without a
   stabilization strategy - an important, publishable negative finding.

## 9. Limitations and reproducibility

- All datasets are retrospective public benchmarks; external, temporally separated validation
  remains necessary before any clinical claim.
- The TPE budget (15 trials × 3 inner folds) is deliberately modest and equal across models;
  larger budgets could change absolute numbers but not the fairness of the comparison.
- TabPFN could not be included in this run (pretrained weights unavailable in the sandbox);
  the framework supports it via `eval_model_on_split`.
- Every random seed is fixed and derived from `(repeat, fold)`; per-fold tuning traces,
  out-of-fold predictions, and all tables/figures are written to `results/` and `figures/`.
""")

nb["cells"] = C
nbf.write(nb, f"{BASE}/OPTUNE_v2.ipynb")
print("notebook written:", len(C), "cells")
