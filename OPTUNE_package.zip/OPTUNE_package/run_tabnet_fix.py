"""Re-run TabNet only (post BatchNorm fix) and write to results_tabnet/."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from framework import run_benchmark

DATA = {
    "wdbc": "data/wdbc.csv",
    "coimbra": "data/coimbra.csv",
    "mammographic": "data/mammographic.csv",
    "cervical": "data/cervical.csv",
}

if __name__ == "__main__":
    base = os.path.dirname(os.path.abspath(__file__))
    os.chdir(base)
    for name in sys.argv[1:]:
        marker = os.path.join("results_tabnet", f"{name}_fold_metrics.csv")
        if os.path.exists(marker):
            print(f"skip {name}")
            continue
        run_benchmark(name, DATA[name], "results_tabnet", models=["TabNet"])
        print(f"finished {name}")
