"""Collect final numbers from results tables into report_data.json."""
import json

import numpy as np
import pandas as pd

DATASETS = ["wdbc", "coimbra", "mammographic", "cervical"]
MODELS = ["TabNet", "LogisticRegression", "SVM", "RandomForest",
          "XGBoost", "LightGBM", "CatBoost", "MLP"]

folds = pd.concat([pd.read_csv(f"results/{d}_fold_metrics_merged.csv")
                   for d in DATASETS], ignore_index=True)

out = {}

# main AUC matrix mean±sd
auc = {}
for ds in DATASETS:
    auc[ds] = {}
    for m in MODELS:
        sub = folds[(folds.dataset == ds) & (folds.model == m) & (folds.variant == "tuned")]
        auc[ds][m] = {"mean": round(sub.roc_auc.mean(), 4),
                      "sd": round(sub.roc_auc.std(), 4)}
out["auc"] = auc

# per-dataset best model
out["best_model"] = {ds: max(auc[ds], key=lambda m: auc[ds][m]["mean"]) for ds in DATASETS}

# tabnet rank per dataset
for ds in DATASETS:
    means = {m: auc[ds][m]["mean"] for m in MODELS}
    ranked = sorted(means, key=means.get, reverse=True)
    out.setdefault("tabnet_rank", {})[ds] = ranked.index("TabNet") + 1

# stats tests
t3 = pd.read_csv("results/tables/T3_stat_tests_auc.csv")
out["n_sig_tabnet_wins"] = int(((t3.mean_diff > 0) & (t3.p_nb_holm < 0.05)).sum())
out["n_sig_tabnet_losses"] = int(((t3.mean_diff < 0) & (t3.p_nb_holm < 0.05)).sum())
out["n_comparisons"] = len(t3)

# tuned vs default
t4 = pd.read_csv("results/tables/T4_tuned_vs_default.csv")
out["tuned_vs_default"] = {
    ds: {r["model"]: round(r["delta"], 4)
         for _, r in t4[t4.dataset == ds].iterrows()} for ds in DATASETS}
tn = t4[t4.model == "TabNet"]
out["tabnet_tuning_delta"] = {r["dataset"]: round(r["delta"], 4) for _, r in tn.iterrows()}

# friedman
with open("results/tables/T6_friedman.json") as f:
    out["friedman"] = json.load(f)
ranks = pd.read_csv("results/tables/T6_avg_ranks.csv", index_col=0)
out["avg_ranks"] = {k: round(float(v), 2) for k, v in ranks.iloc[:, 0].items()}

# calibration & operating
t5 = pd.read_csv("results/tables/T5_calibration_operating.csv")
out["calibration"] = {
    ds: {r["model"]: {"brier": round(r["brier"], 4), "ece": round(r["ece"], 4),
                      "sens_at_95spec": round(r["sens_at_95spec"], 3)}
         for _, r in t5[t5.dataset == ds].iterrows()} for ds in DATASETS}

# attention stability
with open("results/wdbc_tabnet_importances_merged.json") as f:
    recs = json.load(f)
from scipy import stats as st
M = np.array([r["importances"] for r in recs])
cors = [st.spearmanr(M[i], M[j]).correlation
        for i in range(len(M)) for j in range(i + 1, len(M))]
out["attention_stability_median_rho"] = round(float(np.median(cors)), 3)
names = recs[0]["feature_names"]
top = pd.Series(M.mean(axis=0), index=names).sort_values(ascending=False)
out["tabnet_top_features"] = list(top.index[:5])

# agreement
t7 = pd.read_csv("results/tables/T7_attribution_agreement.csv")
out["agreement_tau_shap"] = round(float(st.kendalltau(t7.tabnet, t7.shap_xgb).correlation), 3)
out["agreement_tau_perm"] = round(float(st.kendalltau(t7.tabnet, t7.permutation).correlation), 3)

with open("report_data.json", "w") as f:
    json.dump(out, f, indent=1)
print(json.dumps(out, indent=1)[:1500])
