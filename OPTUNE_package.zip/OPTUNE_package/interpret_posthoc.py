"""
OPTUNE v2 — post-hoc interpretability analysis on WDBC.

Reconstructs the exact outer folds used in the benchmark, refits the per-fold
tuned TabNet and XGBoost models, and computes:
  - per-fold TabNet permutation importance (AUC drop on the held-out fold),
  - per-fold XGBoost TreeSHAP global attributions (mean |SHAP| on the fold),
  - instance-level TabNet attention masks for one representative held-out fold.
Together with the per-fold TabNet attention importances saved during the
benchmark, this yields a three-way attribution agreement analysis
(ante-hoc attention vs post-hoc SHAP vs model-agnostic permutation).
"""
import json
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import framework as fw
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold

import shap

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
DATASET = "wdbc"


def permutation_importance_auc(predict_proba, X, y, n_repeats=5, seed=0):
    rng = np.random.default_rng(seed)
    base = roc_auc_score(y, predict_proba(X))
    imps = np.zeros(X.shape[1])
    for j in range(X.shape[1]):
        drops = []
        for r in range(n_repeats):
            Xp = X.copy()
            rng.shuffle(Xp[:, j])
            drops.append(base - roc_auc_score(y, predict_proba(Xp)))
        imps[j] = np.mean(drops)
    return imps


def main():
    cfg = fw.CONFIG
    X, y, feature_names = fw.load_dataset(os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "data", f"{DATASET}.csv"))
    with open(os.path.join(RES, f"{DATASET}_tuning_merged.json")) as f:
        tuning = json.load(f)
    best = {(r["model"], r["repeat"], r["fold"]): r["best_params"] for r in tuning}

    perm_rows, shap_rows = [], []
    masks_saved = False
    seed0 = cfg["random_seed"]
    for rep in range(cfg["n_repeats"]):
        outer = StratifiedKFold(n_splits=cfg["n_outer_folds"], shuffle=True,
                                random_state=seed0 + rep)
        for k, (tr_idx, te_idx) in enumerate(outer.split(X, y)):
            Xtr, Xte = fw.preprocess_fold(X[tr_idx], X[te_idx])
            ytr, yte = y[tr_idx], y[te_idx]
            fold_seed = seed0 + 1000 * rep + 10 * k

            # ---- TabNet: refit tuned model, permutation importance ----
            params = best[("TabNet", rep, k)]
            proba, tabnet = fw.eval_model_on_split("TabNet", params, Xtr, ytr,
                                                   Xte, fold_seed)
            pi = permutation_importance_auc(
                lambda Z: tabnet.predict_proba(Z)[:, 1], Xte, yte,
                n_repeats=5, seed=fold_seed)
            perm_rows.append({"repeat": rep, "fold": k,
                              **{feature_names[j]: pi[j] for j in range(len(pi))}})

            if not masks_saved:
                explain, _ = tabnet.explain(Xte)
                np.savez(os.path.join(RES, "wdbc_instance_masks.npz"),
                         masks=explain, y_true=yte,
                         feature_names=np.array(feature_names))
                masks_saved = True

            # ---- XGBoost: refit tuned model, TreeSHAP ----
            params_x = best[("XGBoost", rep, k)]
            _, xgb = fw.eval_model_on_split("XGBoost", params_x, Xtr, ytr,
                                            Xte, fold_seed)
            explainer = shap.TreeExplainer(xgb)
            sv = explainer.shap_values(Xte)
            if isinstance(sv, list):
                sv = sv[1]
            mean_abs = np.abs(sv).mean(axis=0)
            shap_rows.append({"repeat": rep, "fold": k,
                              **{feature_names[j]: float(mean_abs[j])
                                 for j in range(len(mean_abs))}})
            print(f"rep{rep} fold{k} done", flush=True)

    pd.DataFrame(perm_rows).to_csv(
        os.path.join(RES, "wdbc_tabnet_permutation.csv"), index=False)
    pd.DataFrame(shap_rows).to_csv(
        os.path.join(RES, "wdbc_xgb_shap.csv"), index=False)
    print("DONE")


if __name__ == "__main__":
    main()
