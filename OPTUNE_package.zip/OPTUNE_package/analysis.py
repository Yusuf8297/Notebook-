"""
OPTUNE v2 — Statistical analysis of nested-CV benchmark results.

Implements:
  - Nadeau-Bengio variance-corrected paired t-tests (repeated k-fold CV),
    with Holm correction and paired effect sizes (Cohen's dz).
  - Friedman test + average ranks across datasets (Nemenyi critical distance).
  - Calibration: reliability data, Brier score, expected calibration error.
  - Decision-curve analysis (net benefit).
  - Operating points: sensitivity at fixed specificity (and vice versa).
"""
import json
import os

import numpy as np
import pandas as pd
from scipy import stats

MODELS = ["TabNet", "LogisticRegression", "SVM", "RandomForest",
          "XGBoost", "LightGBM", "CatBoost", "MLP"]
DATASETS = ["wdbc", "coimbra", "mammographic", "cervical"]
RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")


def load_all_folds():
    dfs = []
    for d in DATASETS:
        p = os.path.join(RES, f"{d}_fold_metrics.csv")
        if os.path.exists(p):
            dfs.append(pd.read_csv(p))
    return pd.concat(dfs, ignore_index=True)


def load_all_oof():
    dfs = []
    for d in DATASETS:
        p = os.path.join(RES, f"{d}_oof_predictions.csv")
        if os.path.exists(p):
            dfs.append(pd.read_csv(p))
    return pd.concat(dfs, ignore_index=True)


# ---------------------------------------------------------------------------
# Nadeau-Bengio corrected paired t-test
# ---------------------------------------------------------------------------
def nadeau_bengio_ttest(scores_a, scores_b, n_train_frac=0.8):
    """Variance-corrected paired t-test for repeated k-fold CV
    (Nadeau & Bengio 2003). n2/n1 = test/train size ratio."""
    d = np.asarray(scores_a) - np.asarray(scores_b)
    k = len(d)
    mean_d = d.mean()
    var_d = d.var(ddof=1)
    if var_d == 0:
        return (np.inf if mean_d > 0 else (-np.inf if mean_d < 0 else 0.0)), \
               (0.0 if mean_d != 0 else 1.0), mean_d
    ratio = (1 - n_train_frac) / n_train_frac
    se = np.sqrt(var_d * (1.0 / k + ratio))
    t = mean_d / se
    p = 2 * stats.t.sf(abs(t), df=k - 1)
    return t, p, mean_d


def cohens_dz(scores_a, scores_b):
    d = np.asarray(scores_a) - np.asarray(scores_b)
    sd = d.std(ddof=1)
    return d.mean() / sd if sd > 0 else np.inf * np.sign(d.mean())


def holm_correction(pvals):
    """Holm step-down adjusted p-values."""
    p = np.asarray(pvals, dtype=float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    running_max = 0.0
    for rank, idx in enumerate(order):
        val = min(1.0, (m - rank) * p[idx])
        running_max = max(running_max, val)
        adj[idx] = running_max
    return adj


def pairwise_vs_reference(folds, metric="roc_auc", reference="TabNet",
                          variant="tuned", n_train_frac=0.8):
    """TabNet (reference) vs each baseline, per dataset, NB-corrected + Holm."""
    rows = []
    for ds in folds.dataset.unique():
        sub = folds[(folds.dataset == ds) & (folds.variant == variant)]
        piv = sub.pivot_table(index="fold_id", columns="model", values=metric)
        pvals, entries = [], []
        for m in MODELS:
            if m == reference or m not in piv.columns:
                continue
            a, b = piv[reference].values, piv[m].values
            t, p, diff = nadeau_bengio_ttest(a, b, n_train_frac)
            w_p = stats.wilcoxon(a, b).pvalue if not np.allclose(a, b) else 1.0
            entries.append({
                "dataset": ds, "comparison": f"{reference} vs {m}",
                "mean_diff": diff, "t_nb": t, "p_nb": p,
                "p_wilcoxon": w_p, "dz": cohens_dz(a, b)})
            pvals.append(p)
        adj = holm_correction(pvals)
        for e, a_p in zip(entries, adj):
            e["p_nb_holm"] = a_p
            rows.append(e)
    return pd.DataFrame(rows)


def tuned_vs_default(folds, metric="roc_auc", n_train_frac=0.8):
    """Per model+dataset: benefit of Bayesian optimization over defaults."""
    rows = []
    for ds in folds.dataset.unique():
        for m in folds.model.unique():
            sub = folds[(folds.dataset == ds) & (folds.model == m)]
            piv = sub.pivot_table(index="fold_id", columns="variant", values=metric)
            if "tuned" not in piv or "default" not in piv:
                continue
            t, p, diff = nadeau_bengio_ttest(piv["tuned"].values,
                                             piv["default"].values, n_train_frac)
            rows.append({"dataset": ds, "model": m,
                         "auc_tuned": piv["tuned"].mean(),
                         "auc_default": piv["default"].mean(),
                         "delta": diff, "t_nb": t, "p_nb": p})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Friedman / ranks across datasets
# ---------------------------------------------------------------------------
def friedman_ranks(folds, metric="roc_auc", variant="tuned"):
    """Mean metric per model per dataset -> Friedman test + average ranks."""
    means = (folds[folds.variant == variant]
             .groupby(["dataset", "model"])[metric].mean().unstack())
    means = means[[m for m in MODELS if m in means.columns]]
    ranks = means.rank(axis=1, ascending=False)
    fr_stat, fr_p = stats.friedmanchisquare(
        *[means[m].values for m in means.columns])
    k = means.shape[1]
    n = means.shape[0]
    # Nemenyi critical difference at alpha=.05
    Q_ALPHA = {2: 1.960, 3: 2.343, 4: 2.569, 5: 2.728, 6: 2.850,
               7: 2.949, 8: 3.031, 9: 3.102, 10: 3.164}
    cd = Q_ALPHA[k] * np.sqrt(k * (k + 1) / (6.0 * n))
    return means, ranks.mean(), fr_stat, fr_p, cd


# ---------------------------------------------------------------------------
# Calibration
# ---------------------------------------------------------------------------
def ece(y_true, proba, n_bins=10):
    bins = np.linspace(0, 1, n_bins + 1)
    idx = np.clip(np.digitize(proba, bins) - 1, 0, n_bins - 1)
    total = len(y_true)
    err = 0.0
    for b in range(n_bins):
        mask = idx == b
        if mask.sum() == 0:
            continue
        err += mask.sum() / total * abs(y_true[mask].mean() - proba[mask].mean())
    return err


def calibration_table(oof, n_bins=10):
    rows = []
    for (ds, m), g in oof.groupby(["dataset", "model"]):
        y, p = g.y_true.values, g.proba.values
        rows.append({"dataset": ds, "model": m,
                     "brier": np.mean((p - y) ** 2),
                     "ece": ece(y, p, n_bins),
                     "oof_auc": stats.rankdata(p)[y == 1].mean()})  # placeholder
    from sklearn.metrics import roc_auc_score
    for r in rows:
        g = oof[(oof.dataset == r["dataset"]) & (oof.model == r["model"])]
        r["oof_auc"] = roc_auc_score(g.y_true, g.proba)
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Decision curve analysis
# ---------------------------------------------------------------------------
def net_benefit(y_true, proba, thresholds):
    n = len(y_true)
    prevalence = y_true.mean()
    out = []
    for pt in thresholds:
        pred = proba >= pt
        tp = np.sum(pred & (y_true == 1))
        fp = np.sum(pred & (y_true == 0))
        nb = tp / n - fp / n * (pt / (1 - pt))
        nb_all = prevalence - (1 - prevalence) * (pt / (1 - pt))
        out.append({"threshold": pt, "net_benefit": nb, "treat_all": nb_all,
                    "treat_none": 0.0})
    return pd.DataFrame(out)


# ---------------------------------------------------------------------------
# Operating points
# ---------------------------------------------------------------------------
def sens_at_spec(y_true, proba, target_spec=0.95):
    from sklearn.metrics import roc_curve
    fpr, tpr, thr = roc_curve(y_true, proba)
    ok = (1 - fpr) >= target_spec
    return tpr[ok].max() if ok.any() else 0.0


def spec_at_sens(y_true, proba, target_sens=0.95):
    from sklearn.metrics import roc_curve
    fpr, tpr, thr = roc_curve(y_true, proba)
    ok = tpr >= target_sens
    return (1 - fpr[ok]).max() if ok.any() else 0.0


def operating_points(oof):
    rows = []
    for (ds, m), g in oof.groupby(["dataset", "model"]):
        y, p = g.y_true.values, g.proba.values
        rows.append({"dataset": ds, "model": m,
                     "sens_at_95spec": sens_at_spec(y, p, 0.95),
                     "spec_at_95sens": spec_at_sens(y, p, 0.95)})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# TabNet attention stability
# ---------------------------------------------------------------------------
def attention_stability(dataset):
    with open(os.path.join(RES, f"{dataset}_tabnet_importances.json")) as f:
        recs = json.load(f)
    M = np.array([r["importances"] for r in recs])  # folds x features
    names = recs[0]["feature_names"]
    n = M.shape[0]
    cors = []
    for i in range(n):
        for j in range(i + 1, n):
            cors.append(stats.spearmanr(M[i], M[j]).correlation)
    return M, names, np.array(cors)


def hyperparameter_importance(dataset, model="TabNet"):
    """Surrogate (random forest / fANOVA-style) importance of hyperparameters,
    pooled over all outer-fold Optuna studies for one dataset."""
    from sklearn.ensemble import RandomForestRegressor
    with open(os.path.join(RES, f"{dataset}_tuning.json")) as f:
        recs = json.load(f)
    rows, vals = [], []
    for r in recs:
        if r["model"] != model:
            continue
        for t in r["trials"]:
            if t["value"] is None or t["value"] <= 0:
                continue
            rows.append(t["params"])
            vals.append(t["value"])
    X = pd.DataFrame(rows)
    for c in X.columns:
        if X[c].dtype == object:
            X[c] = pd.factorize(X[c])[0]
    rf = RandomForestRegressor(n_estimators=500, random_state=0, n_jobs=1)
    rf.fit(X.fillna(-1), vals)
    return pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)
