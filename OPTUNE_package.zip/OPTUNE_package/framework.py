"""
OPTUNE v2 — Methodologically rigorous benchmark of Bayesian-optimized TabNet
against classical and modern tabular baselines for cancer classification.

Key design principles (fixes over v1):
  1. Repeated stratified NESTED cross-validation: hyperparameters are tuned on
     inner folds only; outer test folds are never touched during tuning or
     model selection -> unbiased generalization estimates.
  2. Equal HPO budget (same sampler, same trial count, same inner-CV protocol)
     for every tuned model -> fair comparison.
  3. All preprocessing (imputation, scaling) is fit inside each outer training
     fold only -> no leakage.
  4. Class imbalance handled by cost-sensitive weighting (no synthetic
     oversampling), so training/validation distributions remain natural and
     train-vs-test gaps are interpretable.
  5. Out-of-fold probability predictions are collected for calibration and
     decision-curve analysis.
  6. Default-configuration models are evaluated on the same outer folds to
     quantify the benefit of Bayesian optimization (tuned vs default).
"""
import json
import os
import time
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import torch

torch.set_num_threads(1)

import optuna
from optuna.samplers import TPESampler

optuna.logging.set_verbosity(optuna.logging.WARNING)

from pytorch_tabnet.tab_model import TabNetClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier

# ---------------------------------------------------------------------------
# Experiment configuration
# ---------------------------------------------------------------------------
CONFIG = {
    "n_repeats": 2,          # outer CV repeats
    "n_outer_folds": 5,      # outer CV folds
    "n_inner_folds": 3,      # inner CV folds for HPO scoring
    "n_trials": 15,          # Optuna TPE trials per (model, outer fold)
    "random_seed": 42,
    "tabnet_max_epochs": 100,
    "tabnet_patience": 15,
    "tabnet_batch_size": 128,
}

TUNED_MODELS = [
    "TabNet",
    "LogisticRegression",
    "SVM",
    "RandomForest",
    "XGBoost",
    "LightGBM",
    "CatBoost",
    "MLP",
]


# ---------------------------------------------------------------------------
# Model factory: default configs, search spaces, builders
# ---------------------------------------------------------------------------
def suggest_params(model_name, trial):
    if model_name == "TabNet":
        nd = trial.suggest_categorical("n_d", [8, 16, 24, 32])
        return {
            "n_d": nd,
            "n_a": nd,  # tied, as recommended by Arik & Pfister
            "n_steps": trial.suggest_int("n_steps", 3, 6),
            "gamma": trial.suggest_float("gamma", 1.0, 2.0),
            "lambda_sparse": trial.suggest_float("lambda_sparse", 1e-6, 1e-2, log=True),
            "lr": trial.suggest_float("lr", 5e-3, 3e-2, log=True),
            # PyTorch BatchNorm momentum semantics (pytorch-tabnet default 0.02):
            # search a small-momentum region that CONTAINS the default. The v1
            # manuscript's 0.90-0.98 range reflects TensorFlow decay semantics
            # and destroys BN running statistics under PyTorch.
            "momentum": trial.suggest_float("momentum", 0.01, 0.4, log=True),
        }
    if model_name == "LogisticRegression":
        return {
            "C": trial.suggest_float("C", 1e-3, 1e2, log=True),
            "penalty": trial.suggest_categorical("penalty", ["l1", "l2"]),
        }
    if model_name == "SVM":
        return {
            "C": trial.suggest_float("C", 1e-2, 1e2, log=True),
            "gamma": trial.suggest_float("gamma", 1e-4, 1e0, log=True),
        }
    if model_name == "RandomForest":
        return {
            "n_estimators": trial.suggest_int("n_estimators", 100, 500, step=50),
            "max_depth": trial.suggest_int("max_depth", 3, 16),
            "min_samples_leaf": trial.suggest_int("min_samples_leaf", 1, 8),
            "max_features": trial.suggest_categorical("max_features", ["sqrt", "log2", None]),
        }
    if model_name == "XGBoost":
        return {
            "n_estimators": trial.suggest_int("n_estimators", 100, 600, step=50),
            "learning_rate": trial.suggest_float("learning_rate", 1e-2, 0.3, log=True),
            "max_depth": trial.suggest_int("max_depth", 2, 8),
            "subsample": trial.suggest_float("subsample", 0.6, 1.0),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 1.0),
            "min_child_weight": trial.suggest_int("min_child_weight", 1, 10),
            "reg_lambda": trial.suggest_float("reg_lambda", 1e-3, 10.0, log=True),
        }
    if model_name == "LightGBM":
        return {
            "n_estimators": trial.suggest_int("n_estimators", 100, 600, step=50),
            "learning_rate": trial.suggest_float("learning_rate", 1e-2, 0.3, log=True),
            "num_leaves": trial.suggest_int("num_leaves", 7, 63),
            "min_child_samples": trial.suggest_int("min_child_samples", 5, 40),
            "subsample": trial.suggest_float("subsample", 0.6, 1.0),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 1.0),
            "reg_lambda": trial.suggest_float("reg_lambda", 1e-3, 10.0, log=True),
        }
    if model_name == "CatBoost":
        return {
            "iterations": trial.suggest_int("iterations", 100, 600, step=50),
            "learning_rate": trial.suggest_float("learning_rate", 1e-2, 0.3, log=True),
            "depth": trial.suggest_int("depth", 3, 8),
            "l2_leaf_reg": trial.suggest_float("l2_leaf_reg", 1.0, 30.0, log=True),
        }
    if model_name == "MLP":
        width = trial.suggest_categorical("width", [32, 64, 128])
        depth = trial.suggest_int("depth", 1, 3)
        return {
            "width": width,
            "depth": depth,
            "alpha": trial.suggest_float("alpha", 1e-6, 1e-1, log=True),
            "learning_rate_init": trial.suggest_float("learning_rate_init", 1e-4, 1e-2, log=True),
        }
    raise ValueError(model_name)


DEFAULT_PARAMS = {
    "TabNet": {"n_d": 8, "n_a": 8, "n_steps": 3, "gamma": 1.3, "lambda_sparse": 1e-3,
               "lr": 2e-2, "momentum": 0.02},
    "LogisticRegression": {"C": 1.0, "penalty": "l2"},
    "SVM": {"C": 1.0, "gamma": "scale"},
    "RandomForest": {"n_estimators": 100, "max_depth": None, "min_samples_leaf": 1,
                     "max_features": "sqrt"},
    "XGBoost": {"n_estimators": 100, "learning_rate": 0.3, "max_depth": 6,
                "subsample": 1.0, "colsample_bytree": 1.0, "min_child_weight": 1,
                "reg_lambda": 1.0},
    "LightGBM": {"n_estimators": 100, "learning_rate": 0.1, "num_leaves": 31,
                 "min_child_samples": 20, "subsample": 1.0, "colsample_bytree": 1.0,
                 "reg_lambda": 0.0},
    "CatBoost": {"iterations": 500, "learning_rate": 0.03, "depth": 6, "l2_leaf_reg": 3.0},
    "MLP": {"width": 100, "depth": 1, "alpha": 1e-4, "learning_rate_init": 1e-3},
}


def build_model(model_name, params, seed, pos_weight):
    """pos_weight = n_neg / n_pos on the current training data."""
    if model_name == "LogisticRegression":
        return LogisticRegression(
            C=params["C"], penalty=params["penalty"],
            solver="liblinear", max_iter=4000,
            class_weight="balanced", random_state=seed)
    if model_name == "SVM":
        return SVC(C=params["C"], gamma=params["gamma"], kernel="rbf",
                   probability=True, class_weight="balanced", random_state=seed)
    if model_name == "RandomForest":
        return RandomForestClassifier(
            n_estimators=params["n_estimators"], max_depth=params["max_depth"],
            min_samples_leaf=params["min_samples_leaf"],
            max_features=params["max_features"],
            class_weight="balanced", random_state=seed, n_jobs=1)
    if model_name == "XGBoost":
        return XGBClassifier(
            **{k: params[k] for k in ["n_estimators", "learning_rate", "max_depth",
                                      "subsample", "colsample_bytree",
                                      "min_child_weight", "reg_lambda"]},
            scale_pos_weight=pos_weight, random_state=seed,
            eval_metric="logloss", verbosity=0, n_jobs=1)
    if model_name == "LightGBM":
        return LGBMClassifier(
            **{k: params[k] for k in ["n_estimators", "learning_rate", "num_leaves",
                                      "min_child_samples", "subsample",
                                      "colsample_bytree", "reg_lambda"]},
            scale_pos_weight=pos_weight, random_state=seed, verbosity=-1, n_jobs=1)
    if model_name == "CatBoost":
        return CatBoostClassifier(
            iterations=params["iterations"], learning_rate=params["learning_rate"],
            depth=params["depth"], l2_leaf_reg=params["l2_leaf_reg"],
            class_weights=[1.0, pos_weight], random_seed=seed,
            verbose=0, allow_writing_files=False, thread_count=1)
    if model_name == "MLP":
        hidden = tuple([params["width"]] * params["depth"])
        return MLPClassifier(
            hidden_layer_sizes=hidden, alpha=params["alpha"],
            learning_rate_init=params["learning_rate_init"],
            max_iter=600, early_stopping=True, n_iter_no_change=20,
            random_state=seed)
    raise ValueError(model_name)


def fit_predict_tabnet(params, Xtr, ytr, Xva, yva, Xte, seed, cfg=CONFIG):
    """Fit TabNet with early stopping on (Xva, yva); return probas on Xte and the model."""
    model = TabNetClassifier(
        n_d=params["n_d"], n_a=params.get("n_a", params["n_d"]),
        n_steps=params["n_steps"], gamma=params["gamma"],
        lambda_sparse=params["lambda_sparse"],
        optimizer_params={"lr": params["lr"]},
        scheduler_params={"step_size": 30, "gamma": 0.7},
        scheduler_fn=torch.optim.lr_scheduler.StepLR,
        momentum=max(0.01, min(0.98, params.get("momentum", 0.02))),
        verbose=0, seed=seed, device_name="cpu")
    bs = min(cfg["tabnet_batch_size"], max(32, len(ytr) // 4))
    # BatchNorm cannot process a trailing batch of size 1: drop it if present
    drop_last = (len(ytr) % bs == 1)
    model.fit(
        Xtr, ytr,
        eval_set=[(Xva, yva)], eval_metric=["auc"],
        max_epochs=cfg["tabnet_max_epochs"], patience=cfg["tabnet_patience"],
        batch_size=bs,
        weights=1,  # inverse class-frequency sampling
        drop_last=drop_last)
    proba = model.predict_proba(Xte)[:, 1]
    return proba, model


def eval_model_on_split(model_name, params, Xtr, ytr, Xte, seed):
    """Train on (Xtr,ytr) and return P(y=1) on Xte plus the fitted model.
    For TabNet an internal early-stopping split is carved from the training data."""
    pos_weight = float((ytr == 0).sum() / max(1, (ytr == 1).sum()))
    if model_name == "TabNet":
        Xtr2, Xva, ytr2, yva = train_test_split(
            Xtr, ytr, test_size=0.15, stratify=ytr, random_state=seed)
        proba, model = fit_predict_tabnet(params, Xtr2, ytr2, Xva, yva, Xte, seed)
        return proba, model
    model = build_model(model_name, params, seed, pos_weight)
    model.fit(Xtr, ytr)
    proba = model.predict_proba(Xte)[:, 1]
    return proba, model


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------
def compute_metrics(y_true, proba, threshold=0.5):
    pred = (proba >= threshold).astype(int)
    cm = confusion_matrix(y_true, pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()
    sens = tp / (tp + fn) if (tp + fn) else np.nan
    spec = tn / (tn + fp) if (tn + fp) else np.nan
    out = {
        "roc_auc": roc_auc_score(y_true, proba) if len(np.unique(y_true)) > 1 else np.nan,
        "pr_auc": average_precision_score(y_true, proba),
        "accuracy": accuracy_score(y_true, pred),
        "balanced_accuracy": balanced_accuracy_score(y_true, pred),
        "sensitivity": sens,
        "specificity": spec,
        "f1": f1_score(y_true, pred, zero_division=0),
        "mcc": matthews_corrcoef(y_true, pred),
        "brier": brier_score_loss(y_true, proba),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }
    return out


# ---------------------------------------------------------------------------
# Nested CV driver
# ---------------------------------------------------------------------------
def load_dataset(path):
    df = pd.read_csv(path)
    y = df["target"].values.astype(int)
    X = df.drop(columns=["target"])
    feature_names = X.columns.tolist()
    return X.values.astype(np.float64), y, feature_names


def preprocess_fold(X_tr_raw, X_te_raw):
    """Impute (median) + standardize, fit on training fold only."""
    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    Xtr = scaler.fit_transform(imputer.fit_transform(X_tr_raw)).astype(np.float32)
    Xte = scaler.transform(imputer.transform(X_te_raw)).astype(np.float32)
    return Xtr, Xte


def tune_on_inner(model_name, X_tr, y_tr, seed, cfg=CONFIG):
    """Equal-budget TPE tuning scored by mean inner-CV ROC-AUC."""
    inner = StratifiedKFold(n_splits=cfg["n_inner_folds"], shuffle=True, random_state=seed)
    splits = list(inner.split(X_tr, y_tr))

    def objective(trial):
        params = suggest_params(model_name, trial)
        aucs = []
        for i, (itr, iva) in enumerate(splits):
            try:
                proba, _ = eval_model_on_split(
                    model_name, params, X_tr[itr], y_tr[itr], X_tr[iva],
                    seed=seed + i)
                aucs.append(roc_auc_score(y_tr[iva], proba))
            except Exception:
                return 0.0
        return float(np.mean(aucs))

    study = optuna.create_study(
        direction="maximize",
        sampler=TPESampler(seed=seed, multivariate=True))
    study.optimize(objective, n_trials=cfg["n_trials"], show_progress_bar=False)
    trials_df = [
        {"number": t.number, "value": t.value, "params": t.params}
        for t in study.trials if t.value is not None
    ]
    best = suggest_params(model_name, optuna.trial.FixedTrial(study.best_params))
    return best, study.best_value, trials_df


def run_benchmark(dataset_name, data_path, out_dir, models=TUNED_MODELS, cfg=CONFIG):
    os.makedirs(out_dir, exist_ok=True)
    X, y, feature_names = load_dataset(data_path)
    seed0 = cfg["random_seed"]

    fold_records = []       # per (model, fold) metrics
    oof_records = []        # out-of-fold predictions
    tuning_records = []     # best params + optuna trials per fold
    importance_records = [] # TabNet importances per fold

    log = open(os.path.join(out_dir, f"{dataset_name}.log"), "a")

    def logp(msg):
        stamp = time.strftime("%H:%M:%S")
        log.write(f"[{stamp}] {msg}\n")
        log.flush()

    logp(f"=== {dataset_name}: n={len(y)}, p={X.shape[1]}, pos_rate={y.mean():.3f} ===")

    fold_id = 0
    for rep in range(cfg["n_repeats"]):
        outer = StratifiedKFold(n_splits=cfg["n_outer_folds"], shuffle=True,
                                random_state=seed0 + rep)
        for k, (tr_idx, te_idx) in enumerate(outer.split(X, y)):
            Xtr, Xte = preprocess_fold(X[tr_idx], X[te_idx])
            ytr, yte = y[tr_idx], y[te_idx]
            fold_seed = seed0 + 1000 * rep + 10 * k

            for model_name in models:
                t0 = time.time()
                # --- tuned model ---
                best_params, inner_auc, trials = tune_on_inner(
                    model_name, Xtr, ytr, fold_seed, cfg)
                proba, fitted = eval_model_on_split(
                    model_name, best_params, Xtr, ytr, Xte, fold_seed)
                m = compute_metrics(yte, proba)
                m.update({"model": model_name, "dataset": dataset_name,
                          "repeat": rep, "fold": k, "fold_id": fold_id,
                          "variant": "tuned", "inner_auc": inner_auc,
                          "tune_seconds": time.time() - t0})
                fold_records.append(m)

                # --- default model (same folds, no tuning) ---
                proba_d, _ = eval_model_on_split(
                    model_name, DEFAULT_PARAMS[model_name], Xtr, ytr, Xte, fold_seed)
                md = compute_metrics(yte, proba_d)
                md.update({"model": model_name, "dataset": dataset_name,
                           "repeat": rep, "fold": k, "fold_id": fold_id,
                           "variant": "default", "inner_auc": np.nan,
                           "tune_seconds": 0.0})
                fold_records.append(md)

                for i, idx in enumerate(te_idx):
                    oof_records.append({
                        "dataset": dataset_name, "model": model_name,
                        "repeat": rep, "fold": k, "sample_idx": int(idx),
                        "y_true": int(yte[i]), "proba": float(proba[i]),
                        "proba_default": float(proba_d[i])})

                tuning_records.append({
                    "dataset": dataset_name, "model": model_name,
                    "repeat": rep, "fold": k,
                    "best_params": {kk: (vv if not isinstance(vv, np.generic) else vv.item())
                                    for kk, vv in best_params.items()},
                    "inner_auc": inner_auc, "trials": trials})

                if model_name == "TabNet":
                    imp = fitted.feature_importances_
                    importance_records.append({
                        "dataset": dataset_name, "repeat": rep, "fold": k,
                        "importances": [float(v) for v in imp],
                        "feature_names": feature_names})

                logp(f"rep{rep} fold{k} {model_name:18s} tunedAUC={m['roc_auc']:.4f} "
                     f"defaultAUC={md['roc_auc']:.4f} ({time.time()-t0:.0f}s)")
            fold_id += 1

    pd.DataFrame(fold_records).to_csv(
        os.path.join(out_dir, f"{dataset_name}_fold_metrics.csv"), index=False)
    pd.DataFrame(oof_records).to_csv(
        os.path.join(out_dir, f"{dataset_name}_oof_predictions.csv"), index=False)
    with open(os.path.join(out_dir, f"{dataset_name}_tuning.json"), "w") as f:
        json.dump(tuning_records, f)
    with open(os.path.join(out_dir, f"{dataset_name}_tabnet_importances.json"), "w") as f:
        json.dump(importance_records, f)
    logp("DONE")
    log.close()
    return fold_records
