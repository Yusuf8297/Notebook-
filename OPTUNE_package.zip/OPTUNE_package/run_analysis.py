"""
OPTUNE v2 — full post-benchmark analysis: merge, tables, statistics, figures.
Reads results/ (all models) and results_tabnet/ (TabNet re-run after the
BatchNorm fix), replaces TabNet rows, then produces every table and figure.
"""
import json
import os
import sys

import numpy as np
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
os.chdir(BASE)

import analysis as an
import figures as fg

RES = os.path.join(BASE, "results")
RES_TN = os.path.join(BASE, "results_tabnet")
TBL = os.path.join(BASE, "results", "tables")
os.makedirs(TBL, exist_ok=True)

DATASETS = ["wdbc", "coimbra", "mammographic", "cervical"]
MODELS = an.MODELS


# ---------------------------------------------------------------------------
# 1. Merge TabNet re-run into the master results
# ---------------------------------------------------------------------------
def merge():
    for ds in DATASETS:
        fm = pd.read_csv(os.path.join(RES, f"{ds}_fold_metrics.csv"))
        fm_tn = pd.read_csv(os.path.join(RES_TN, f"{ds}_fold_metrics.csv"))
        fm = pd.concat([fm[fm.model != "TabNet"], fm_tn], ignore_index=True)
        fm.to_csv(os.path.join(RES, f"{ds}_fold_metrics_merged.csv"), index=False)

        oof = pd.read_csv(os.path.join(RES, f"{ds}_oof_predictions.csv"))
        oof_tn = pd.read_csv(os.path.join(RES_TN, f"{ds}_oof_predictions.csv"))
        oof = pd.concat([oof[oof.model != "TabNet"], oof_tn], ignore_index=True)
        oof.to_csv(os.path.join(RES, f"{ds}_oof_merged.csv"), index=False)

        with open(os.path.join(RES, f"{ds}_tuning.json")) as f:
            tun = [r for r in json.load(f) if r["model"] != "TabNet"]
        with open(os.path.join(RES_TN, f"{ds}_tuning.json")) as f:
            tun += json.load(f)
        with open(os.path.join(RES, f"{ds}_tuning_merged.json"), "w") as f:
            json.dump(tun, f)

        # TabNet importances come from the re-run only
        src = os.path.join(RES_TN, f"{ds}_tabnet_importances.json")
        dst = os.path.join(RES, f"{ds}_tabnet_importances_merged.json")
        with open(src) as f:
            json.dump(json.load(f), open(dst, "w"))
    print("merged")


def load_folds():
    return pd.concat([pd.read_csv(os.path.join(RES, f"{d}_fold_metrics_merged.csv"))
                      for d in DATASETS], ignore_index=True)


def load_oof():
    return pd.concat([pd.read_csv(os.path.join(RES, f"{d}_oof_merged.csv"))
                      for d in DATASETS], ignore_index=True)


# ---------------------------------------------------------------------------
# 2. Tables
# ---------------------------------------------------------------------------
def make_tables(folds, oof):
    # T2: main results, tuned variant
    rows = []
    for ds in DATASETS:
        for m in MODELS:
            sub = folds[(folds.dataset == ds) & (folds.model == m)
                        & (folds.variant == "tuned")]
            r = {"dataset": ds, "model": m}
            for met in ["roc_auc", "pr_auc", "accuracy", "balanced_accuracy",
                        "sensitivity", "specificity", "f1", "mcc", "brier"]:
                r[met] = sub[met].mean()
                r[met + "_sd"] = sub[met].std()
            rows.append(r)
    t2 = pd.DataFrame(rows)
    t2.to_csv(os.path.join(TBL, "T2_main_results.csv"), index=False)

    # T3: TabNet vs baselines, NB-corrected
    t3 = an.pairwise_vs_reference(folds, metric="roc_auc")
    t3.to_csv(os.path.join(TBL, "T3_stat_tests_auc.csv"), index=False)
    t3b = an.pairwise_vs_reference(folds, metric="mcc")
    t3b.to_csv(os.path.join(TBL, "T3b_stat_tests_mcc.csv"), index=False)

    # T4: tuned vs default
    t4 = an.tuned_vs_default(folds)
    t4.to_csv(os.path.join(TBL, "T4_tuned_vs_default.csv"), index=False)

    # T5: calibration + operating points
    cal = an.calibration_table(oof)
    op = an.operating_points(oof)
    t5 = cal.merge(op, on=["dataset", "model"])
    t5.to_csv(os.path.join(TBL, "T5_calibration_operating.csv"), index=False)

    # Friedman
    means, avg_ranks, fr_stat, fr_p, cd = an.friedman_ranks(folds)
    means.to_csv(os.path.join(TBL, "T6_auc_matrix.csv"))
    avg_ranks.to_csv(os.path.join(TBL, "T6_avg_ranks.csv"))
    with open(os.path.join(TBL, "T6_friedman.json"), "w") as f:
        json.dump({"friedman_chi2": fr_stat, "p": fr_p, "nemenyi_cd": cd}, f)
    return t2, t3, t4, t5, means, avg_ranks, fr_stat, fr_p, cd


# ---------------------------------------------------------------------------
# 3. Figures
# ---------------------------------------------------------------------------
def make_figures(folds, oof, avg_ranks, cd):
    fg.fig_forest_auc(folds)
    tv = an.tuned_vs_default(folds)
    fg.fig_tuned_vs_default(tv)
    fg.fig_cd_diagram(avg_ranks, cd)
    fg.fig_calibration(oof)
    fg.fig_decision_curves(oof, an.net_benefit,
                           models_to_show=["TabNet", "LogisticRegression", "LightGBM"])

    # attention stability (WDBC)
    M, names, cors = an.attention_stability_merged("wdbc")
    fg.fig_importance_stability(M, names, cors)

    # attribution agreement (WDBC)
    perm = pd.read_csv(os.path.join(RES, "wdbc_tabnet_permutation.csv"))
    shp = pd.read_csv(os.path.join(RES, "wdbc_xgb_shap.csv"))
    feat_cols = [c for c in perm.columns if c not in ("repeat", "fold")]
    tabnet_imp = pd.Series(M.mean(axis=0), index=names)
    perm_imp = perm[feat_cols].mean()
    shap_imp = shp[feat_cols].mean()
    imp_df = pd.DataFrame({
        "feature": feat_cols,
        "tabnet": tabnet_imp.reindex(feat_cols).values,
        "shap_xgb": (shap_imp / shap_imp.sum()).values,
        "permutation": (perm_imp.clip(lower=0) / perm_imp.clip(lower=0).sum()).values,
    })
    imp_df.to_csv(os.path.join(TBL, "T7_attribution_agreement.csv"), index=False)
    fg.fig_attribution_agreement(imp_df)

    # instance masks (WDBC)
    z = np.load(os.path.join(RES, "wdbc_instance_masks.npz"), allow_pickle=True)
    masks = z["masks"]
    masks = masks / masks.sum(axis=1, keepdims=True).clip(min=1e-9)
    fg.fig_instance_masks(masks, list(z["feature_names"]), z["y_true"])

    # hyperparameter importance
    series = {}
    for ds in DATASETS:
        try:
            series[ds] = an.hyperparameter_importance_merged(ds)
        except Exception as e:
            print("hp importance fail", ds, e)
    fg.fig_hp_importance(series)
    pd.DataFrame(series).to_csv(os.path.join(TBL, "T8_hp_importance.csv"))


# helpers reading merged files
def _attention_stability_merged(dataset):
    from scipy import stats as st
    with open(os.path.join(RES, f"{dataset}_tabnet_importances_merged.json")) as f:
        recs = json.load(f)
    M = np.array([r["importances"] for r in recs])
    names = recs[0]["feature_names"]
    cors = []
    for i in range(len(M)):
        for j in range(i + 1, len(M)):
            cors.append(st.spearmanr(M[i], M[j]).correlation)
    return M, names, np.array(cors)


def _hp_importance_merged(dataset, model="TabNet"):
    from sklearn.ensemble import RandomForestRegressor
    with open(os.path.join(RES, f"{dataset}_tuning_merged.json")) as f:
        recs = json.load(f)
    rows, vals = [], []
    for r in recs:
        if r["model"] != model:
            continue
        for t in r["trials"]:
            if t["value"] is None or t["value"] <= 0:
                continue
            rows.append(t["params"])
            vals.append(t["value"])
    X = pd.DataFrame(rows)
    for c in X.columns:
        if X[c].dtype == object:
            X[c] = pd.factorize(X[c])[0]
    rf = RandomForestRegressor(n_estimators=500, random_state=0, n_jobs=1)
    rf.fit(X.fillna(-1), vals)
    return pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)


an.attention_stability_merged = _attention_stability_merged
an.hyperparameter_importance_merged = _hp_importance_merged


if __name__ == "__main__":
    merge()
    folds = load_folds()
    oof = load_oof()
    t2, t3, t4, t5, means, avg_ranks, fr, fr_p, cd = make_tables(folds, oof)
    make_figures(folds, oof, avg_ranks, cd)
    print("\n=== MAIN AUC (tuned) ===")
    print(means.round(4).to_string())
    print(f"\nFriedman chi2={fr:.2f} p={fr_p:.4f} CD={cd:.2f}")
    print("\nAvg ranks:\n", avg_ranks.round(2).to_string())
    print("\nDone. Tables in results/tables, figures in figures/")
