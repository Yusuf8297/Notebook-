import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from framework import run_benchmark

DATA = {
    "wdbc": "data/wdbc.csv",
    "coimbra": "data/coimbra.csv",
    "mammographic": "data/mammographic.csv",
    "cervical": "data/cervical.csv",
}

if __name__ == "__main__":
    base = os.path.dirname(os.path.abspath(__file__))
    os.chdir(base)
    for name in sys.argv[1:]:
        done_marker = os.path.join("results", f"{name}_fold_metrics.csv")
        if os.path.exists(done_marker):
            print(f"skip {name} (already done)")
            continue
        run_benchmark(name, DATA[name], "results")
        print(f"finished {name}")
