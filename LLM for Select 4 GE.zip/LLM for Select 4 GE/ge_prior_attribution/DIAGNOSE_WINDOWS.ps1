<#
    DIAGNOSE_WINDOWS.ps1

    Identifies which Windows Application Control mechanism is blocking SciPy's
    compiled libraries, and prints the fix that applies to that mechanism.

    Run in PowerShell from the project folder:
        powershell -ExecutionPolicy Bypass -File .\DIAGNOSE_WINDOWS.ps1
#>

Write-Host "`n=== Windows Application Control diagnosis ===`n" -ForegroundColor Cyan

# --- 1. Smart App Control -----------------------------------------------------
$sacState = $null
try {
    $sacState = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy" `
                 -Name "VerifiedAndReputablePolicyState" -ErrorAction Stop).VerifiedAndReputablePolicyState
} catch { }

switch ($sacState) {
    0 { Write-Host "Smart App Control : OFF" -ForegroundColor Green }
    1 { Write-Host "Smart App Control : ON  <-- this is very likely the blocker" -ForegroundColor Red }
    2 { Write-Host "Smart App Control : EVALUATION mode (may block intermittently)" -ForegroundColor Yellow }
    default { Write-Host "Smart App Control : not present on this build" -ForegroundColor Green }
}

# --- 2. WDAC / Device Guard ---------------------------------------------------
try {
    $dg = Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard `
                          -ClassName Win32_DeviceGuard -ErrorAction Stop
    $running = $dg.SecurityServicesRunning -join ","
    if ($dg.CodeIntegrityPolicyEnforcementStatus -ge 1) {
        Write-Host "WDAC policy       : ENFORCED (status $($dg.CodeIntegrityPolicyEnforcementStatus))" -ForegroundColor Red
        Write-Host "                    a managed policy usually means IT controls this device" -ForegroundColor Yellow
    } else {
        Write-Host "WDAC policy       : not enforced" -ForegroundColor Green
    }
    Write-Host "Security services : $running"
} catch {
    Write-Host "WDAC policy       : could not query Device Guard" -ForegroundColor Yellow
}

# --- 3. Recent Code Integrity blocks -----------------------------------------
Write-Host "`n--- recent blocked files (CodeIntegrity log) ---"
try {
    $events = Get-WinEvent -LogName "Microsoft-Windows-CodeIntegrity/Operational" `
                           -MaxEvents 200 -ErrorAction Stop |
              Where-Object { $_.Id -in 3077, 3033, 3076 } | Select-Object -First 8
    if ($events) {
        foreach ($e in $events) {
            $line = ($e.Message -split "`n" | Where-Object { $_ -match "File Name|Policy Name" }) -join " | "
            Write-Host ("  [{0}] {1}" -f $e.TimeCreated.ToString("yyyy-MM-dd HH:mm"), $line)
        }
    } else {
        Write-Host "  no recent block events found"
    }
} catch {
    Write-Host "  could not read the CodeIntegrity log (may need an elevated prompt)"
}

# --- 4. Python installation ---------------------------------------------------
Write-Host "`n--- Python installations ---"
$pythons = @()
foreach ($cmd in @("python", "py")) {
    try { $pythons += (& $cmd -c "import sys; print(sys.executable)" 2>$null) } catch { }
}
$pythons = $pythons | Where-Object { $_ } | Select-Object -Unique
foreach ($p in $pythons) {
    $userWritable = $p -like "*\AppData\*" -or $p -like "*\Users\*"
    $tag = if ($userWritable) { "per-user install  <-- commonly blocked" } else { "system-wide install" }
    Write-Host "  $p   [$tag]"
}
if (-not $pythons) { Write-Host "  no python found on PATH" }

# --- 5. Recommendation --------------------------------------------------------
Write-Host "`n=== recommended action ===`n" -ForegroundColor Cyan
if ($sacState -eq 1) {
    Write-Host "Smart App Control is ON. It blocks unsigned compiled extensions such as"
    Write-Host "SciPy's .pyd files, wherever they are installed. Options:"
    Write-Host "  1. Install WSL2 and run the study in Linux   (recommended, keeps everything local)"
    Write-Host "  2. Turn Smart App Control off in Windows Security > App and browser control"
    Write-Host "     (note: it cannot be switched back on without reinstalling Windows)"
} elseif ($dg -and $dg.CodeIntegrityPolicyEnforcementStatus -ge 1) {
    Write-Host "A WDAC policy is enforced, which on a university laptop is normally managed"
    Write-Host "centrally. Options:"
    Write-Host "  1. Install WSL2 and run the study in Linux   (recommended, usually permitted)"
    Write-Host "  2. Ask IT to allow-list your Python directory"
    Write-Host "  3. Try a system-wide Python install under C:\Program Files\, which some"
    Write-Host "     policies permit where per-user installs under AppData are refused"
} else {
    Write-Host "No enforcing policy was detected from this prompt. Re-run PowerShell as"
    Write-Host "Administrator so the CodeIntegrity log can be read, and check which policy"
    Write-Host "name appears against the blocked file above."
}
Write-Host ""
