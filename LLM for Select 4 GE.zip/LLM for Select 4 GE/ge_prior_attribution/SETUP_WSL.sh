#!/usr/bin/env bash
# SETUP_WSL.sh
#
# One-shot setup inside WSL2 (Ubuntu). Run from the project folder:
#     bash SETUP_WSL.sh
#
# WSL runs a Linux userspace on the same machine, so Windows Application Control
# does not apply to its binaries. The study runs entirely locally.

set -euo pipefail

echo "=== Grammatical Evolution prior-attribution study: WSL setup ==="

if ! grep -qi microsoft /proc/version 2>/dev/null; then
    echo "warning: this does not look like WSL, continuing anyway"
fi

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "project directory: $PROJECT_DIR"

# Working inside the Linux filesystem is several times faster than /mnt/c.
case "$PROJECT_DIR" in
    /mnt/*) echo
            echo "note: the project sits on the Windows filesystem (/mnt/...), where file"
            echo "      access is slow. Copying it into the Linux home directory is faster:"
            echo "          cp -r \"$PROJECT_DIR\" ~/ge_prior_attribution && cd ~/ge_prior_attribution"
            echo ;;
esac

echo
echo "--- installing Python and a virtual environment ---"
sudo apt-get update -qq
sudo apt-get install -y -qq python3 python3-pip python3-venv

python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate

echo
echo "--- installing dependencies ---"
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt

echo
echo "--- verifying ---"
python VERIFY_INSTALL.py

cat <<'MESSAGE'

Setup complete. Activate the environment in any new shell with:

    source .venv/bin/activate

Then run the study:

    python run_study.py baselines
    python run_study.py blackbox
    python run_study.py selection
    python run_study.py construction
    python run_study.py ensemble
    python run_study.py ablation
    python analyse.py

Every stage is resumable, so an interrupted run continues where it stopped.
To use the notebook instead:

    pip install jupyterlab && jupyter lab

MESSAGE
