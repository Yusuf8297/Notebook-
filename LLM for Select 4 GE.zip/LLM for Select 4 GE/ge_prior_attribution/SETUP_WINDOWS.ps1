<#
    SETUP_WINDOWS.ps1

    Native Windows setup for VS Code. Creates a virtual environment, installs the
    dependencies, registers a Jupyter kernel and points VS Code at the interpreter.

    Run from the project folder in PowerShell:
        powershell -ExecutionPolicy Bypass -File .\SETUP_WINDOWS.ps1

    Optionally pin a specific interpreter, for instance a system-wide install:
        powershell -ExecutionPolicy Bypass -File .\SETUP_WINDOWS.ps1 -Python "C:\Program Files\Python312\python.exe"
#>

param(
    [string]$Python = ""
)

$ErrorActionPreference = "Stop"
$Project = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location $Project

Write-Host "`n=== prior-attribution study: Windows setup ===" -ForegroundColor Cyan
Write-Host "project: $Project`n"

# --- 1. choose an interpreter -------------------------------------------------
if (-not $Python) {
    $candidates = @()
    foreach ($c in @("python", "py")) {
        try { $candidates += (& $c -c "import sys; print(sys.executable)" 2>$null) } catch { }
    }
    $Python = ($candidates | Where-Object { $_ } | Select-Object -First 1)
}
if (-not $Python) {
    Write-Host "no Python found on PATH. Install Python 3.10 or newer first." -ForegroundColor Red
    exit 1
}
Write-Host "interpreter: $Python"
& $Python --version

if ($Python -like "*\AppData\*") {
    Write-Host "note: this is a per-user install. If an Application Control policy is" -ForegroundColor Yellow
    Write-Host "      enforced, compiled libraries here are the ones usually blocked." -ForegroundColor Yellow
}

# --- 2. virtual environment ---------------------------------------------------
Write-Host "`n--- creating virtual environment (.venv) ---"
if (Test-Path ".venv") {
    Write-Host ".venv already exists, reusing it"
} else {
    & $Python -m venv .venv
}
$VenvPython = Join-Path $Project ".venv\Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
    Write-Host "virtual environment creation failed" -ForegroundColor Red
    exit 1
}

# --- 3. dependencies ----------------------------------------------------------
Write-Host "`n--- installing dependencies ---"
& $VenvPython -m pip install --quiet --upgrade pip
& $VenvPython -m pip install --quiet -r requirements.txt
& $VenvPython -m pip install --quiet ipykernel

# --- 4. the Application Control check -----------------------------------------
Write-Host "`n--- checking that compiled libraries load ---"
$probe = @'
import sys
try:
    import numpy, scipy.stats, sklearn, pandas, matplotlib, deap
    print("OK")
except ImportError as exc:
    print("BLOCKED:" + str(exc))
    sys.exit(2)
'@
$probeFile = Join-Path $env:TEMP "geprior_probe.py"
Set-Content -Path $probeFile -Value $probe -Encoding UTF8
$result = & $VenvPython $probeFile 2>&1
Remove-Item $probeFile -ErrorAction SilentlyContinue

if ($result -match "BLOCKED") {
    Write-Host $result -ForegroundColor Red
    if ($result -match "Application Control|DLL load failed") {
        Write-Host "`nWindows is refusing to load a compiled extension (typically SciPy)." -ForegroundColor Red
        Write-Host "Identify the responsible policy first:" -ForegroundColor Yellow
        Write-Host "    powershell -ExecutionPolicy Bypass -File .\DIAGNOSE_WINDOWS.ps1"
        Write-Host ""
        Write-Host "Smart App Control ON : no native install will work; it blocks unsigned"
        Write-Host "                       binaries wherever they are. Switch it off in"
        Write-Host "                       Windows Security, or use WSL2."
        Write-Host "WDAC policy enforced : retry against a system-wide interpreter, which"
        Write-Host "                       some policies permit:"
        Write-Host "    .\SETUP_WINDOWS.ps1 -Python `"C:\Program Files\Python312\python.exe`""
        Write-Host "                       otherwise ask IT to allow-list the Python folder."
    }
    exit 2
}
Write-Host "compiled libraries load correctly" -ForegroundColor Green

# --- 5. Jupyter kernel --------------------------------------------------------
Write-Host "`n--- registering the Jupyter kernel ---"
& $VenvPython -m ipykernel install --user --name geprior --display-name "Python (geprior)" | Out-Null
Write-Host "kernel registered as 'Python (geprior)'"

# --- 6. VS Code settings ------------------------------------------------------
New-Item -ItemType Directory -Force -Path ".vscode" | Out-Null
$settings = @{
    "python.defaultInterpreterPath" = ".venv\Scripts\python.exe"
    "python.terminal.activateEnvironment" = $true
    "jupyter.notebookFileRoot" = '${workspaceFolder}'
} | ConvertTo-Json -Depth 3
Set-Content -Path ".vscode\settings.json" -Value $settings -Encoding UTF8
Write-Host "wrote .vscode\settings.json"

# --- 7. verify ----------------------------------------------------------------
Write-Host "`n--- verifying the installation ---"
& $VenvPython VERIFY_INSTALL.py

Write-Host @"

Setup complete.

In VS Code:
  1. File > Open Folder, and select this folder (the one containing geprior\).
  2. Ctrl+Shift+P, "Python: Select Interpreter", choose .venv\Scripts\python.exe
  3. Open notebooks\GE_Prior_Attribution_Study.ipynb and pick the
     "Python (geprior)" kernel from the top right.

From the VS Code terminal:
  .\.venv\Scripts\Activate.ps1
  python run_study.py baselines
  python run_study.py selection
  python analyse.py

Every stage is resumable, so an interrupted run continues where it stopped.
"@ -ForegroundColor Cyan
