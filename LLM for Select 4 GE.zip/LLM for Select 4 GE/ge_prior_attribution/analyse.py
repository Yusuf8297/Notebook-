"""Analysis: statistical protocol, summary tables and all figures."""
import sys
sys.path.insert(0, __file__.rsplit("/", 1)[0])
import pandas as pd
from geprior import config, statistics as st, figures as fg

R = config.RESULTS_DIR
sel = pd.read_csv(R / "selection.csv"); con = pd.read_csv(R / "construction.csv")
base = pd.read_csv(R / "baselines.csv"); blackbox = pd.read_csv(R / "blackbox_fe.csv")
ens = pd.read_csv(R / "ensemble.csv"); abl = pd.read_csv(R / "ablation.csv")
KEYS = ["wbcd", "pima", "cleveland", "heart_failure"]
ARMS = list(config.SELECTION_ARMS); CARMS = list(config.CONSTRUCTION_ARMS)

out = []
def show(title, obj):
    out.append(f"\n=== {title} ===\n{obj if isinstance(obj, str) else obj.to_string()}")

show("Baselines: median test ROC-AUC",
     base.groupby(["model", "dataset"])["roc_auc"].median().unstack("dataset")[KEYS].round(3))
show("Selection arms: median test ROC-AUC", st.median_table(sel, ARMS, dataset_keys=KEYS).round(3))
show("Selection arms: median test F1",
     st.median_table(sel, ARMS, metric="test_f1", dataset_keys=KEYS).round(3))
show("Construction arms: median test ROC-AUC",
     st.median_table(con, CARMS, dataset_keys=KEYS).round(3))

fried, ranks = st.per_dataset_friedman(sel, ARMS, dataset_keys=KEYS)
show("Per-dataset Friedman over seed-resamples, average ranks (1 = best)", fried.round(4))
show("Mean rank across datasets (descriptive only)", ranks.mean(axis=0).round(2))

contr = st.preregistered_contrasts(sel, con, dataset_keys=KEYS)
show("Pre-registered contrasts, Holm-corrected within dataset", contr.round(4))
show("Structural diagnostics, median by selection arm", st.structural_diagnostics(sel, ARMS))

cmp_tbl = pd.DataFrame({
    "GE rule (llm)": sel[sel.arm == "llm"].groupby("dataset")["test_roc_auc"].median(),
    "GE ensemble (llm)": ens.groupby("dataset")["ensemble_roc_auc"].median(),
    "Black-box FE": blackbox.groupby("dataset")["roc_auc"].median(),
    "Logistic Regression": base[base.model == "Logistic Regression"].groupby("dataset")["roc_auc"].median(),
}).reindex(KEYS)
show("Interpretability cost: matched comparison", cmp_tbl.round(3))

abl_tbl = abl.groupby(["dataset", "variant"])["test_roc_auc"].median().unstack("variant").reindex(KEYS)
show("Configuration ablation (llm arm)", abl_tbl.round(3))
show("Ablation: median effective length",
     abl.groupby(["dataset", "variant"])["effective_length"].median().unstack("variant").reindex(KEYS).round(1))
show("Ablation: median test F1",
     abl.groupby(["dataset", "variant"])["test_f1"].median().unstack("variant").reindex(KEYS).round(3))

fg.plot_arm_medians(sel, ARMS, KEYS, "selection_by_dataset",
                    title="Selection-prior arms by dataset (median over seeds)")
fg.plot_arm_medians(con, CARMS, KEYS, "construction_by_dataset",
                    title="Construction-prior arms by dataset (median over seeds)")
fg.plot_rank_heatmap(ranks.reindex(KEYS))
fg.plot_length_vs_generalisation(sel, ARMS)
fg.plot_configuration_ablation(abl)
fg.plot_interpretability_cost(cmp_tbl)

report = "\n".join(out)
(R / "analysis_report.txt").write_text(report)
for name, tbl in [("table_baselines", base.groupby(["model", "dataset"])["roc_auc"].median().unstack("dataset")[KEYS]),
                  ("table_selection", st.median_table(sel, ARMS, dataset_keys=KEYS)),
                  ("table_construction", st.median_table(con, CARMS, dataset_keys=KEYS)),
                  ("table_friedman", fried), ("table_contrasts", contr),
                  ("table_diagnostics", st.structural_diagnostics(sel, ARMS)),
                  ("table_interpretability_cost", cmp_tbl), ("table_ablation", abl_tbl)]:
    tbl.to_csv(R / f"{name}.csv")
print(report)
