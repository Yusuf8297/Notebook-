"""Baseline classifiers and the black-box feature-engineering comparator.

The conventional classifiers establish the ceiling against which the interpretable
rules are read. The black-box comparator follows the CAAFE paradigm (Hollmann et al.,
2023): LLM-proposed features are added greedily under a cross-validated acceptance
gate, feeding a logistic regression. The interpretability cost is measured relative
to it.
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from . import config, datasets, priors

try:
    from xgboost import XGBClassifier
    HAS_XGB = True
except ImportError:
    HAS_XGB = False

BLACKBOX_LABEL = "Black-box FE"


def build_models(seed: int) -> dict:
    """Five standard classifiers on the full unrestricted feature set."""
    models = {
        "Logistic Regression": LogisticRegression(max_iter=2000, random_state=seed),
        "Random Forest": RandomForestClassifier(n_estimators=400, random_state=seed),
        "SVM (RBF)": SVC(probability=True, random_state=seed),
        "MLP": MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=600, random_state=seed),
    }
    models["XGBoost" if HAS_XGB else "Gradient Boosting"] = (
        XGBClassifier(eval_metric="logloss", random_state=seed, n_estimators=400,
                      max_depth=4, verbosity=0) if HAS_XGB
        else GradientBoostingClassifier(random_state=seed))
    return models


def run_baselines(dataset_keys=None, seeds=None, checkpoint: Path = None,
                  verbose: bool = True) -> pd.DataFrame:
    """Baseline table over the identical per-seed splits used by every GE condition."""
    dataset_keys = dataset_keys or list(datasets.DATASETS)
    seeds = list(seeds or range(1, config.N_SEEDS + 1))
    checkpoint = Path(checkpoint or config.RESULTS_DIR / "baselines.csv")

    rows, started = [], time.time()
    for key in dataset_keys:
        for seed in seeds:
            split = datasets.prepare_split(key, seed)
            for name, model in build_models(seed).items():
                model.fit(split.X_train, split.y_train)
                proba = model.predict_proba(split.X_test)[:, 1]
                rows.append(dict(dataset=key, model=name, seed=seed,
                                 roc_auc=float(roc_auc_score(split.y_test, proba))))
        if verbose:
            print(f"  baselines: {key} complete ({time.time() - started:.0f}s)", flush=True)

    frame = pd.DataFrame(rows)
    frame.to_csv(checkpoint, index=False)
    return frame


# black-box feature-engineering comparator (CAAFE paradigm)
def blackbox_fe_pipeline(split, key: str, seed: int) -> dict:
    """Greedy LLM-feature-engineering pipeline with a logistic-regression downstream.

    The same LLM-proposed features are added greedily to the raw feature set, each
    retained only if it improves 5-fold cross-validated ROC-AUC on the training
    partition. This reproduces the CAAFE paradigm's structure without its iterative
    code-generation loop; it reuses the cached construction prior rather than an own
    feature-proposal mechanism.
    """
    constructions = priors.construction_set("llm", split.features, config.N_CONSTRUCTED,
                                            seed, key)
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)

    def cv_auc(X, y):
        model = LogisticRegression(max_iter=2000, random_state=seed)
        return float(np.mean(cross_val_score(model, X, y, cv=cv, scoring="roc_auc")))

    accepted = []
    current_train = split.X_train_raw
    baseline = cv_auc(StandardScaler().fit_transform(current_train), split.y_train)

    for spec in constructions:
        trial_train, _ = priors.apply_constructions(split.X_train_raw, split.features,
                                                    accepted + [spec])
        scaled = StandardScaler().fit_transform(trial_train)
        score = cv_auc(scaled, split.y_train)
        if score > baseline:                     # greedy acceptance gate
            accepted.append(spec)
            baseline = score

    Xtr_aug, _ = priors.apply_constructions(split.X_train_raw, split.features, accepted)
    Xte_aug, _ = priors.apply_constructions(split.X_test_raw, split.features, accepted)
    scaler = StandardScaler().fit(Xtr_aug)
    model = LogisticRegression(max_iter=2000, random_state=seed)
    model.fit(scaler.transform(Xtr_aug), split.y_train)
    proba = model.predict_proba(scaler.transform(Xte_aug))[:, 1]

    return dict(roc_auc=float(roc_auc_score(split.y_test, proba)),
                n_accepted=len(accepted), cv_auc=baseline)


def run_blackbox_baseline(dataset_keys=None, seeds=None, checkpoint: Path = None,
                          verbose: bool = True) -> pd.DataFrame:
    """Black-box feature-engineering comparator over the same per-seed splits."""
    dataset_keys = dataset_keys or list(datasets.DATASETS)
    seeds = list(seeds or range(1, config.N_SEEDS + 1))
    checkpoint = Path(checkpoint or config.RESULTS_DIR / "blackbox_fe.csv")

    rows, started = [], time.time()
    for key in dataset_keys:
        for seed in seeds:
            split = datasets.prepare_split(key, seed)
            rows.append(dict(dataset=key, seed=seed, model=BLACKBOX_LABEL,
                             **blackbox_fe_pipeline(split, key, seed)))
        if verbose:
            print(f"  black-box FE: {key} complete ({time.time() - started:.0f}s)", flush=True)

    frame = pd.DataFrame(rows)
    frame.to_csv(checkpoint, index=False)
    return frame
