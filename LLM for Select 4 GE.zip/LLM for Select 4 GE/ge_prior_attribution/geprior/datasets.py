"""Clinical dataset loaders and per-seed resampling.

Loaders return raw, unstandardised values. Standardisation is deferred to
prepare_split, where the scaler is fitted on the training partition only; the raw
matrices are kept alongside because several constructed features (ratios) are only
interpretable on the raw scale.
"""
from __future__ import annotations

import urllib.request
from dataclasses import dataclass
from typing import Callable

import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from . import config

_SOURCES = {
    "pima.csv": ("https://raw.githubusercontent.com/jbrownlee/Datasets/master/"
                 "pima-indians-diabetes.data.csv"),
    "cleveland.csv": ("https://raw.githubusercontent.com/kb22/Heart-Disease-Prediction/"
                      "master/dataset.csv"),
    "heart_failure.csv": ("https://raw.githubusercontent.com/lorenzodenisi/"
                          "Heart-Failure-Clinical-Records/master/"
                          "heart_failure_clinical_records_dataset.csv"),
}


def _cached_csv(fname: str, **read_kw) -> pd.DataFrame:
    """Download once into DATA_DIR, then read from disk on later calls."""
    path = config.DATA_DIR / fname
    if not path.exists():
        urllib.request.urlretrieve(_SOURCES[fname], path)
    return pd.read_csv(path, **read_kw)


# loaders
def load_wbcd() -> tuple[pd.DataFrame, pd.Series]:
    """Wisconsin Breast Cancer. Positive class = malignant."""
    bunch = load_breast_cancer()
    X = pd.DataFrame(bunch.data, columns=list(bunch.feature_names))
    y = pd.Series((bunch.target == 0).astype(int), name="malignant")
    return X, y


def load_pima() -> tuple[pd.DataFrame, pd.Series]:
    """Pima Indians Diabetes. Distributed without a header row."""
    cols = ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness", "Insulin",
            "BMI", "DiabetesPedigreeFunction", "Age", "Outcome"]
    df = _cached_csv("pima.csv", header=None, names=cols)
    return df.drop(columns="Outcome"), df["Outcome"].astype(int).rename("diabetes")


def load_cleveland() -> tuple[pd.DataFrame, pd.Series]:
    """Cleveland Heart Disease. Target collapsed to presence/absence."""
    df = _cached_csv("cleveland.csv", encoding="utf-8-sig")
    y = (df["target"] > 0).astype(int).rename("heart_disease")
    return df.drop(columns="target"), y


def load_heart_failure() -> tuple[pd.DataFrame, pd.Series]:
    """Heart Failure Clinical Records. The time column is dropped as label leakage."""
    df = _cached_csv("heart_failure.csv").drop(columns=["time"])
    return df.drop(columns="DEATH_EVENT"), df["DEATH_EVENT"].astype(int).rename("death")


@dataclass(frozen=True)
class DatasetSpec:
    key: str
    label: str
    loader: Callable[[], tuple[pd.DataFrame, pd.Series]]
    budget: int


DATASETS: dict[str, DatasetSpec] = {
    "wbcd": DatasetSpec("wbcd", "WBCD", load_wbcd, 8),
    "pima": DatasetSpec("pima", "Pima", load_pima, 4),
    "cleveland": DatasetSpec("cleveland", "Cleveland", load_cleveland, 6),
    "heart_failure": DatasetSpec("heart_failure", "Heart Failure", load_heart_failure, 5),
}


@dataclass
class Split:
    """One seed-resample: outer train/test plus the inner fit/validation partition.

    The inner split is carved from the training partition only; the test partition is
    never used for model selection, threshold calibration or early stopping.
    """

    key: str
    seed: int
    features: list[str]
    budget: int
    X_train: np.ndarray
    X_test: np.ndarray
    y_train: np.ndarray
    y_test: np.ndarray
    X_train_raw: np.ndarray
    X_test_raw: np.ndarray
    X_fit: np.ndarray
    y_fit: np.ndarray
    X_val: np.ndarray
    y_val: np.ndarray

    @property
    def n_features(self) -> int:
        return self.X_train.shape[1]


def prepare_split(key: str, seed: int) -> Split:
    """Draw one stratified seed-resample. The split is redrawn per seed, so seeds are
    genuine resamples rather than restarts on a fixed partition."""
    spec = DATASETS[key]
    X, y = spec.loader()
    Xv, yv = X.values.astype(float), y.values.astype(int)

    Xtr_raw, Xte_raw, ytr, yte = train_test_split(
        Xv, yv, test_size=config.TEST_FRACTION, stratify=yv, random_state=seed)

    scaler = StandardScaler().fit(Xtr_raw)          # training data only
    Xtr, Xte = scaler.transform(Xtr_raw), scaler.transform(Xte_raw)

    fit_idx, val_idx = train_test_split(
        np.arange(len(ytr)), test_size=config.VALIDATION_FRACTION,
        stratify=ytr, random_state=seed)

    return Split(key=key, seed=seed, features=list(X.columns), budget=spec.budget,
                 X_train=Xtr, X_test=Xte, y_train=ytr, y_test=yte,
                 X_train_raw=Xtr_raw, X_test_raw=Xte_raw,
                 X_fit=Xtr[fit_idx], y_fit=ytr[fit_idx],
                 X_val=Xtr[val_idx], y_val=ytr[val_idx])


def rebuild_inner_split(X_train: np.ndarray, y_train: np.ndarray, seed: int):
    """Recompute the inner fit/validation partition for an augmented matrix, keeping
    the row partition identical to the selection study."""
    fit_idx, val_idx = train_test_split(
        np.arange(len(y_train)), test_size=config.VALIDATION_FRACTION,
        stratify=y_train, random_state=seed)
    return X_train[fit_idx], y_train[fit_idx], X_train[val_idx], y_train[val_idx]


def describe() -> pd.DataFrame:
    """Samples, features, budget and positive rate per dataset."""
    rows = []
    for spec in DATASETS.values():
        X, y = spec.loader()
        rows.append(dict(key=spec.key, dataset=spec.label, samples=len(X),
                         features=X.shape[1], budget=spec.budget,
                         positive_rate=round(float(y.mean()), 3)))
    return pd.DataFrame(rows)
