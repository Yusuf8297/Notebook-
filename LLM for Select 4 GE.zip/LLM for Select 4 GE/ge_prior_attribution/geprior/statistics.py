"""Statistical protocol.

Median-based throughout, following Demsar. Per-dataset Friedman tests over the
seed-paired resamples carry the inference; the cross-dataset mean rank is reported
descriptively only, since four datasets cannot power a critical-difference diagram.
Pre-registered contrasts are tested with paired Wilcoxon signed-rank, Holm-corrected
within each dataset, with Cliff's delta reported alongside every pairwise claim.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import friedmanchisquare, rankdata, wilcoxon

from . import config

# Studentised range statistic q_alpha at alpha = 0.05 divided by sqrt(2), indexed by
# the number of compared methods k (Demsar 2006, Table 5). A wrong k gives a critical
# difference that is too small, so the lookup raises rather than falls back.
NEMENYI_Q05 = {
    2: 1.960, 3: 2.343, 4: 2.569, 5: 2.728, 6: 2.850, 7: 2.949, 8: 3.031,
    9: 3.102, 10: 3.164, 11: 3.219, 12: 3.268, 13: 3.313, 14: 3.354, 15: 3.391,
    16: 3.426, 17: 3.458, 18: 3.489, 19: 3.517, 20: 3.544,
}


def cliffs_delta(a, b) -> float:
    """Cliff's delta, a nonparametric effect size on [-1, 1]; positive means a > b."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    greater = sum(int((x > b).sum()) for x in a)
    lesser = sum(int((x < b).sum()) for x in a)
    return (greater - lesser) / (len(a) * len(b))


def interpret_delta(delta: float) -> str:
    """Conventional magnitude labels for Cliff's delta (Romano et al.)."""
    d = abs(delta)
    if d < 0.147:
        return "negligible"
    if d < 0.330:
        return "small"
    if d < 0.474:
        return "medium"
    return "large"


def holm_correction(pvalues) -> np.ndarray:
    """Holm step-down adjustment, returning adjusted p-values in input order."""
    pvalues = np.asarray(pvalues, float)
    order = np.argsort(pvalues)
    adjusted = np.empty(len(pvalues))
    running = 0.0
    for rank, idx in enumerate(order):
        running = max(running, (len(pvalues) - rank) * pvalues[idx])
        adjusted[idx] = min(running, 1.0)
    return adjusted


def critical_difference(k: int, n_datasets: int, alpha: float = 0.05) -> float:
    """Nemenyi critical difference for k methods over n datasets. Raises when k is
    outside the table rather than falling back to a wrong lookup."""
    if alpha != 0.05:
        raise ValueError("only alpha = 0.05 is tabulated here")
    if k not in NEMENYI_Q05:
        raise KeyError(f"no tabulated q_alpha for k={k}; extend NEMENYI_Q05")
    return NEMENYI_Q05[k] * np.sqrt(k * (k + 1) / (6.0 * n_datasets))


def _wide(df: pd.DataFrame, key: str, arms, metric: str) -> pd.DataFrame:
    """Seed-by-arm matrix for one dataset, dropping seeds with any missing cell."""
    sub = df[df.dataset == key]
    wide = sub.pivot_table(index="seed", columns="arm", values=metric)
    available = [a for a in arms if a in wide.columns]
    return wide[available].dropna()


def per_dataset_friedman(df: pd.DataFrame, arms, metric: str = None,
                         dataset_keys=None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Friedman omnibus per dataset, plus the average rank of each arm (1 = best)."""
    metric = metric or f"test_{config.PRIMARY_METRIC}"
    dataset_keys = dataset_keys or sorted(df.dataset.unique())
    rows, rank_rows = [], {}

    for key in dataset_keys:
        wide = _wide(df, key, arms, metric)
        if wide.shape[0] < 3 or wide.shape[1] < 3:
            continue
        chi2, p = friedmanchisquare(*[wide[a].values for a in wide.columns])
        ranks = wide.apply(lambda r: rankdata(-r.values), axis=1, result_type="expand")
        ranks.columns = wide.columns
        average = ranks.mean()
        rank_rows[key] = average
        rows.append(dict(dataset=key, n_seeds=wide.shape[0],
                         friedman_chi2=round(float(chi2), 2), p=float(p),
                         **{a: round(float(average[a]), 2) for a in wide.columns}))

    return pd.DataFrame(rows), pd.DataFrame(rank_rows).T


def paired_contrast(df: pd.DataFrame, arm_a: str, arm_b: str, key: str,
                    metric: str = None) -> dict:
    """One paired Wilcoxon signed-rank contrast with median difference and Cliff's delta."""
    metric = metric or f"test_{config.PRIMARY_METRIC}"
    wide = _wide(df, key, [arm_a, arm_b], metric)
    if wide.shape[1] < 2 or wide.shape[0] < 3:
        return dict(dataset=key, contrast=f"{arm_a} vs {arm_b}", median_diff=np.nan,
                    cliffs_delta=np.nan, magnitude="n/a", p_raw=np.nan, n=wide.shape[0])
    a, b = wide[arm_a].values, wide[arm_b].values
    try:
        _, p = wilcoxon(a, b)
    except ValueError:                        # all differences zero
        p = 1.0
    delta = cliffs_delta(a, b)
    return dict(dataset=key, contrast=f"{arm_a} vs {arm_b}",
                median_diff=float(np.median(a - b)), cliffs_delta=float(delta),
                magnitude=interpret_delta(delta), p_raw=float(p), n=len(a))


def preregistered_contrasts(selection: pd.DataFrame, construction: pd.DataFrame,
                            dataset_keys=None, metric: str = None) -> pd.DataFrame:
    """The three pre-registered confirmatory contrasts, Holm-corrected within dataset.
    Fixed before any run; any later comparison is exploratory."""
    dataset_keys = dataset_keys or sorted(selection.dataset.unique())
    sources = {"selection": selection, "construction": construction}

    rows = []
    for key in dataset_keys:
        for label, study, arm_a, arm_b in config.PREREGISTERED_CONTRASTS:
            record = paired_contrast(sources[study], arm_a, arm_b, key, metric)
            record.update(contrast_id=label, study=study)
            rows.append(record)

    frame = pd.DataFrame(rows)
    frame["p_holm"] = np.nan
    for key in dataset_keys:                  # Holm applied across the three contrasts
        mask = frame.dataset == key
        frame.loc[mask, "p_holm"] = holm_correction(frame.loc[mask, "p_raw"].fillna(1.0).values)
    frame["significant"] = frame["p_holm"] < config.ALPHA
    return frame[["dataset", "contrast_id", "study", "contrast", "median_diff",
                  "cliffs_delta", "magnitude", "p_raw", "p_holm", "significant", "n"]]


def median_table(df: pd.DataFrame, arms, metric: str = None,
                 dataset_keys=None) -> pd.DataFrame:
    """Median of `metric` by dataset and arm, ordered as declared in the config."""
    metric = metric or f"test_{config.PRIMARY_METRIC}"
    dataset_keys = dataset_keys or sorted(df.dataset.unique())
    table = df.groupby(["dataset", "arm"])[metric].median().unstack("arm")
    return table.reindex(index=dataset_keys, columns=[a for a in arms if a in table.columns])


def structural_diagnostics(selection: pd.DataFrame, arms) -> pd.DataFrame:
    """Structural diagnostics, median by selection arm, pooled across datasets.
    Structural diversity is the proportion of distinct derivation structures in the
    final population; effective length is used codons; invalids failed to map."""
    columns = ["effective_length", "structural_diversity", "phenotype_coverage",
               "invalids", "depth", "generalisation_gap",
               f"test_{config.PRIMARY_METRIC}"]
    available = [c for c in columns if c in selection.columns]
    table = selection.groupby("arm")[available].median()
    return table.reindex([a for a in arms if a in table.index]).round(3)
