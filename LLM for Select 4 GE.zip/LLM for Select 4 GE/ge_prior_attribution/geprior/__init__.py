"""Feature-prior attribution study in grammar-based evolutionary search."""
from . import config  # noqa: F401

__version__ = "1.0.0"
