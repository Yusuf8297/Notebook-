"""BNF grammar construction.

A prior is injected only by restricting the terminal rule <v> to the arm's chosen
feature indices; every other production, the constant menu and all operators are
identical across arms.

Two families are provided. The weighted family scores a phenotype as a signed
weighted sum of feature terms with optional nonlinear transforms, which is the
functional form of a clinical risk score. The unweighted family has no coefficient
rule, so a phenotype is close to an unweighted sum of standardised features; it is
retained for the configuration ablation.
"""
from __future__ import annotations

from typing import Iterable, Sequence

from . import config
from .vendor import ensure_grape

# coefficient menu for the weighted grammar, log-spaced over ~two decades
WEIGHTS = ("0.1", "0.25", "0.5", "0.75", "1.0", "1.5", "2.0", "3.0", "5.0")

# constant menu for the unweighted grammar
UNWEIGHTED_CONSTANTS = ("1.0", "2.0", "5.0", "0.1", "0.5")


def _terminals(feature_idx: Iterable[int]) -> str:
    return " | ".join(f"x[:,{i}]" for i in feature_idx)


def weighted_grammar_text(feature_idx: Sequence[int]) -> str:
    """Signed weighted-additive grammar.

    <e>  signed sum of weighted terms
    <t>  a weighted feature or weighted nonlinear transform
    <nl> pairwise interaction, protected ratio, or monotone unary transform
    <w>  coefficient menu
    """
    return (
        "<e> ::= <t> | add(<e>,<t>) | sub(<e>,<t>)\n"
        "<t> ::= mul(<w>,<v>) | mul(<w>,<nl>)\n"
        "<nl> ::= mul(<v>,<v>) | pdiv(<v>,<v>) | psqrt(<v>) | plog(<v>)\n"
        f"<v> ::= {_terminals(feature_idx)}\n"
        f"<w> ::= {' | '.join(WEIGHTS)}\n"
    )


def unweighted_grammar_text(feature_idx: Sequence[int]) -> str:
    """Unweighted grammar (no coefficient rule)."""
    return (
        "<e> ::= <v> | <c> | add(<v>,<v>) | sub(<v>,<v>) | mul(<v>,<v>) | pdiv(<v>,<v>) | "
        "add(<v>,<c>) | mul(<v>,<c>) | add(<e>,<e>) | sub(<e>,<e>)\n"
        f"<v> ::= {_terminals(feature_idx)}\n"
        f"<c> ::= {' | '.join(UNWEIGHTED_CONSTANTS)}\n"
    )


def build_grammar(feature_idx: Sequence[int], family: str = None, tag: str = "arm"):
    """Write the BNF to disk and return the parsed GRAPE grammar object."""
    family = family or config.GRAMMAR
    text = (weighted_grammar_text(feature_idx) if family == "weighted"
            else unweighted_grammar_text(feature_idx))
    path = config.GRAMMAR_DIR / f"{tag}_{family}.bnf"
    path.write_text(text, encoding="utf-8")
    ensure_grape()
    import grape
    return grape.Grammar(str(path))
