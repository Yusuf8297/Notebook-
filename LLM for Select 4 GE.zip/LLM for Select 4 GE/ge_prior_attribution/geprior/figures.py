"""Figure generation. Each figure is standalone with its own savefig call and is
written to FIGURES_DIR as both PNG and PDF."""
from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from . import config, statistics as stats

ARM_COLOURS = {"none": "#555555", "random": "#1f77b4", "mi": "#ff7f0e",
               "corr": "#2ca02c", "llm": "#d62728", "raw": "#7f7f7f"}

plt.rcParams.update({"figure.dpi": 120, "savefig.bbox": "tight",
                     "font.size": 10, "axes.grid": True, "grid.alpha": 0.3})


def _save(fig, name: str) -> None:
    for ext in ("png", "pdf"):
        fig.savefig(config.FIGURES_DIR / f"{name}.{ext}", dpi=200)
    plt.close(fig)


def plot_arm_medians(df: pd.DataFrame, arms, dataset_keys, name: str,
                     metric: str = None, title: str = None, ylim=(0.6, 1.0)):
    """Grouped bars of median test ROC-AUC by dataset and arm."""
    metric = metric or f"test_{config.PRIMARY_METRIC}"
    table = stats.median_table(df, arms, metric, dataset_keys)

    fig, ax = plt.subplots(figsize=(9, 4.5))
    n_arms = len(table.columns)
    positions = np.arange(len(table.index))
    width = 0.8 / n_arms
    for i, arm in enumerate(table.columns):
        ax.bar(positions + i * width - 0.4 + width / 2, table[arm].values, width,
               label=arm, color=ARM_COLOURS.get(arm, None))
    ax.set_xticks(positions)
    ax.set_xticklabels(table.index)
    ax.set_ylim(*ylim)
    ax.set_ylabel("median test ROC-AUC")
    ax.set_xlabel("dataset")
    ax.set_title(title or "Prior arms by dataset (median over seeds)")
    ax.legend(title="prior", ncol=n_arms, fontsize=8)
    _save(fig, name)
    return table


def plot_rank_heatmap(rank_table: pd.DataFrame, name: str = "rank_heatmap"):
    """Average rank per arm per dataset, 1 = best."""
    fig, ax = plt.subplots(figsize=(7, 3.2))
    image = ax.imshow(rank_table.values, cmap="RdYlGn_r", aspect="auto",
                      vmin=1, vmax=rank_table.shape[1])
    ax.set_xticks(range(rank_table.shape[1]))
    ax.set_xticklabels(rank_table.columns)
    ax.set_yticks(range(rank_table.shape[0]))
    ax.set_yticklabels(rank_table.index)
    ax.grid(False)
    for i in range(rank_table.shape[0]):
        for j in range(rank_table.shape[1]):
            ax.text(j, i, f"{rank_table.values[i, j]:.2f}", ha="center", va="center",
                    fontsize=10)
    ax.set_title("Average rank by prior and dataset (1 = best)")
    fig.colorbar(image, ax=ax, label="average rank")
    _save(fig, name)


def plot_length_vs_generalisation(selection: pd.DataFrame, arms,
                                  name: str = "length_vs_generalisation"):
    """Effective length against test ROC-AUC, coloured by prior source."""
    metric = f"test_{config.PRIMARY_METRIC}"
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    for arm in arms:
        sub = selection[selection.arm == arm]
        if sub.empty:
            continue
        ax.scatter(sub["effective_length"], sub[metric], s=20, alpha=0.55,
                   label=arm, color=ARM_COLOURS.get(arm, None))
    ax.set_xlabel("effective length (used codons)")
    ax.set_ylabel("test ROC-AUC")
    ax.set_title("Effective length versus generalisation, by prior source")
    ax.legend(title="prior", fontsize=8)
    _save(fig, name)


def plot_configuration_ablation(ablation: pd.DataFrame,
                                name: str = "configuration_ablation"):
    """Test ROC-AUC per dataset across the cumulative configuration ablation."""
    table = ablation.groupby(["dataset", "variant"])["test_roc_auc"].median().unstack("variant")
    order = [v for v in _ABLATION_ORDER if v in table.columns]
    if order:
        table = table[order]
    fig, ax = plt.subplots(figsize=(9, 4.5))
    positions = np.arange(len(table.index))
    width = 0.8 / max(1, table.shape[1])
    for i, variant in enumerate(table.columns):
        ax.bar(positions + i * width - 0.4 + width / 2, table[variant].values, width,
               label=variant)
    ax.set_xticks(positions)
    ax.set_xticklabels(table.index)
    ax.set_ylabel("median test ROC-AUC")
    ax.set_ylim(0.6, 1.0)
    ax.set_title("Configuration ablation (llm arm)")
    ax.legend(fontsize=8, ncol=3)
    _save(fig, name)
    return table


_ABLATION_ORDER = ["Base", "+ AUC objective", "+ weighted grammar",
                   "+ validation selection", "+ threshold calibration"]


def plot_interpretability_cost(comparison: pd.DataFrame,
                               name: str = "interpretability_cost"):
    """Single interpretable rule, matched GE ensemble, and the black-box comparator."""
    fig, ax = plt.subplots(figsize=(8.5, 4.5))
    positions = np.arange(len(comparison.index))
    width = 0.8 / comparison.shape[1]
    for i, column in enumerate(comparison.columns):
        ax.bar(positions + i * width - 0.4 + width / 2, comparison[column].values,
               width, label=column)
    ax.set_xticks(positions)
    ax.set_xticklabels(comparison.index)
    ax.set_ylabel("median test ROC-AUC")
    ax.set_ylim(0.6, 1.0)
    ax.set_title("Interpretable rule versus matched ensemble versus black box")
    ax.legend(fontsize=8)
    _save(fig, name)


def plot_confusion(y_true, y_pred, title: str, name: str):
    """Confusion matrix of a single evolved rule on a held-out partition."""
    from sklearn.metrics import confusion_matrix
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(4.3, 3.9))
    ax.imshow(cm, cmap="Blues")
    ax.grid(False)
    for i in range(2):
        for j in range(2):
            ax.text(j, i, cm[i, j], ha="center", va="center", fontsize=13,
                    color="white" if cm[i, j] > cm.max() / 2 else "black")
    ax.set_xticks([0, 1], ["neg", "pos"])
    ax.set_yticks([0, 1], ["neg", "pos"])
    ax.set_xlabel("predicted")
    ax.set_ylabel("true")
    ax.set_title(title)
    _save(fig, name)
    return cm


def plot_critical_difference(rank_table: pd.DataFrame, name: str = "critical_difference"):
    """Demsar critical-difference diagram. Provided for an extended dataset panel; the
    driver does not produce it for the four-dataset panel, which cannot power it."""
    k, n = rank_table.shape[1], rank_table.shape[0]
    cd = stats.critical_difference(k, n)
    average = rank_table.mean(axis=0).sort_values()

    fig, ax = plt.subplots(figsize=(7.5, 2.4))
    ax.hlines(1, 1, k, color="black", lw=1)
    for i, (arm, rank) in enumerate(average.items()):
        ax.plot(rank, 1, "o", color=ARM_COLOURS.get(arm, "black"))
        ax.annotate(f"{arm}\n{rank:.2f}", (rank, 1), textcoords="offset points",
                    xytext=(0, 12 if i % 2 == 0 else -28), ha="center", fontsize=8)
    ax.plot([1, 1 + cd], [1.35, 1.35], color="crimson", lw=2)
    ax.annotate(f"CD = {cd:.3f}  (k={k}, N={n})", (1 + cd / 2, 1.35),
                textcoords="offset points", xytext=(0, 6), ha="center", fontsize=8)
    ax.set_ylim(0.6, 1.6)
    ax.set_xlim(0.8, k + 0.2)
    ax.set_yticks([])
    ax.grid(False)
    ax.set_xlabel("average rank (1 = best)")
    _save(fig, name)
    return cd
