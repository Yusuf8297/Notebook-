"""Central configuration. A run is described by this module plus the seed list."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

# paths
ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"
FIGURES_DIR = ROOT / "figures"
GRAMMAR_DIR = ROOT / "grammars"
CACHE_DIR = ROOT / ".llm_cache"
for _d in (DATA_DIR, RESULTS_DIR, FIGURES_DIR, GRAMMAR_DIR, CACHE_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# study scale
GLOBAL_SEED = 42
N_SEEDS = 30                     # seeds for the main campaign
ABLATION_SEEDS = 30              # seeds for the configuration ablation (heavier: 5 variants)
TEST_FRACTION = 0.30             # outer hold-out, redrawn per seed
VALIDATION_FRACTION = 0.25       # inner split, carved from the training partition only

# search seeds offset from split seeds so search stochasticity and resampling
# variance are not confounded
SEARCH_SEED_OFFSET = 90_000

# study arms
SELECTION_ARMS = ("none", "random", "mi", "corr", "llm")
CONSTRUCTION_ARMS = ("raw", "random", "llm")
N_CONSTRUCTED = 5                # engineered features added per construction arm

# GE engine
@dataclass(frozen=True)
class GEParams:
    population_size: int = 200
    n_generations: int = 40
    codon_size: int = 255
    max_tree_depth: int = 17
    min_init_depth: int = 4
    max_init_depth: int = 10
    p_crossover: float = 0.80
    p_mutation_per_codon: float = 0.01
    tournament_size: int = 5
    elite_size: int = 3
    hall_of_fame_size: int = 20  # candidate pool for validation-based selection
    codon_consumption: str = "lazy"
    genome_representation: str = "list"


GE = GEParams()

# ensemble members harvested from the final population, ranked by validation AUC
ENSEMBLE_SIZE = 9

# fitness objective: "auc" or "accuracy"
FITNESS = "auc"

# decision threshold: "calibrated" (fit on inner validation) or "zero"
THRESHOLD_MODE = "calibrated"

# grammar family: "weighted" (coefficient rule) or "unweighted"
GRAMMAR = "weighted"

# reporting
PRIMARY_METRIC = "roc_auc"
ALPHA = 0.05

# pre-registered confirmatory contrasts, fixed before any run
PREREGISTERED_CONTRASTS = (
    ("C1", "selection", "llm", "random"),     # knowledge vs noise
    ("C2", "selection", "llm", "mi"),         # knowledge vs data
    ("C3", "construction", "llm", "random"),  # construction analogue of C1
)

# provenance
GRAPE_REPO = "https://raw.githubusercontent.com/bdsul/grape/main"
GRAPE_FILES = ("grape.py", "algorithms.py", "functions.py")

LLM_BACKEND = "cached"           # "api" plus ANTHROPIC_API_KEY for a live run
LLM_MODEL = "claude-sonnet-4-6"

EPS = 1e-8


def summary() -> str:
    return (f"seeds={N_SEEDS} pop={GE.population_size} gens={GE.n_generations} "
            f"fitness={FITNESS} grammar={GRAMMAR} threshold={THRESHOLD_MODE} "
            f"ensemble={ENSEMBLE_SIZE} backend={LLM_BACKEND}")
