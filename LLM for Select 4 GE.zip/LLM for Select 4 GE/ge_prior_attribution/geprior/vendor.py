"""Fetch the GRAPE reference implementation and patch it for current NumPy / Python.

Both substitutions are behaviour-preserving:
  random.randint(0, 1e10)  -> a float bound raises under Python 3.12
  np.NaN / np.NAN          -> removed aliases in NumPy 2.x
"""
from __future__ import annotations

import sys
import urllib.request
from pathlib import Path

from . import config

PATCHES = (
    ("random.randint(0,1e10)", "random.randint(0,10**10)"),
    ("np.NaN", "np.nan"),
    ("np.NAN", "np.nan"),
)


def ensure_grape(target_dir: Path = None) -> Path:
    """Download and patch GRAPE if absent, then put it on the import path."""
    target = Path(target_dir or config.ROOT / "grape_lib")
    target.mkdir(parents=True, exist_ok=True)

    for fname in config.GRAPE_FILES:
        path = target / fname
        if not path.exists():
            urllib.request.urlretrieve(f"{config.GRAPE_REPO}/{fname}", path)
        source = path.read_text(encoding="utf-8")
        patched = source
        for old, new in PATCHES:
            patched = patched.replace(old, new)
        if patched != source:
            path.write_text(patched, encoding="utf-8")

    if str(target) not in sys.path:
        sys.path.insert(0, str(target))
    return target
