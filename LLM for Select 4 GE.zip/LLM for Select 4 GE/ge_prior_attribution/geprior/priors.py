"""Feature priors: noise, data and knowledge sources at matched budget.

Every selection arm hands GE exactly K feature indices; only the source of those
indices varies across arms.
"""
from __future__ import annotations

import hashlib
import json
import os
import random
import re

import numpy as np
from sklearn.feature_selection import mutual_info_classif

from . import config

# protected binary operators; ratio is guarded against division by zero
OPERATORS = {
    "ratio": lambda a, b: a / (np.abs(b) + config.EPS),
    "product": lambda a, b: a * b,
    "diff": lambda a, b: a - b,
    "sum": lambda a, b: a + b,
}

# cached LLM output: reasoning over feature names alone, no access to labels or
# statistics. Retained verbatim with provenance; LLM_BACKEND = "api" replaces this
# with a live per-seed query.
CACHED_LLM_PRIOR = {
    "provenance": {
        "model": "Claude (Anthropic)",
        "method": "clinical reasoning over feature names; no access to labels or statistics",
        "temperature": 0.0,
    },
    "wbcd": {
        "select": [6, 7, 20, 22, 23, 25, 26, 27],
        "construct": [
            ("ratio", "worst area", "mean area", "pleomorphism: worst-cell size versus average"),
            ("ratio", "worst concave points", "mean concave points",
             "escalation of contour indentation"),
            ("product", "mean concavity", "mean compactness", "nuclear border irregularity"),
            ("ratio", "worst perimeter", "worst area", "shape factor"),
            ("diff", "worst radius", "mean radius", "radial size dispersion"),
        ],
    },
    "pima": {
        "select": [1, 5, 6, 7],
        "construct": [
            ("product", "Glucose", "Insulin", "insulin-resistance proxy"),
            ("product", "BMI", "Age", "cumulative adiposity-age risk"),
            ("ratio", "Insulin", "Glucose", "insulin response relative to glycaemia"),
            ("product", "Glucose", "DiabetesPedigreeFunction", "genetic-load-weighted glycaemia"),
            ("ratio", "SkinThickness", "BMI", "fat-distribution proxy"),
        ],
    },
    "cleveland": {
        "select": [2, 7, 8, 9, 11, 12],
        "construct": [
            ("product", "oldpeak", "exang", "exercise-induced ischaemia burden"),
            ("ratio", "thalach", "age", "chronotropic competence versus age"),
            ("product", "ca", "thal", "anatomical and perfusion defect load"),
            ("product", "cp", "oldpeak", "symptom-ischaemia interaction"),
            ("ratio", "chol", "age", "cholesterol burden per year"),
        ],
    },
    "heart_failure": {
        "select": [0, 1, 2, 4, 7],
        "construct": [
            ("ratio", "serum_creatinine", "ejection_fraction", "renal-cardiac dysfunction ratio"),
            ("product", "age", "serum_creatinine", "age-weighted renal impairment"),
            ("ratio", "ejection_fraction", "age", "pump function relative to age"),
            ("diff", "serum_sodium", "serum_creatinine", "electrolyte-renal imbalance"),
            ("product", "anaemia", "ejection_fraction", "anaemia under reduced pump function"),
        ],
    },
    # secondary candidates: with a single cached response per dataset, per-seed
    # variance is emulated by fixing the core and sampling the remaining slots from
    # this margin. A live API run draws a fresh response per seed and ignores this.
    "margin": {
        "wbcd": [0, 1, 2, 3, 21, 24],
        "pima": [0, 4, 2],
        "cleveland": [0, 3, 4, 10],
        "heart_failure": [3, 5, 8, 10],
    },
}


class LLMPrior:
    """Adapter over the knowledge prior, cached or live."""

    def __init__(self, backend: str = config.LLM_BACKEND):
        has_key = bool(os.environ.get("ANTHROPIC_API_KEY"))
        self.backend = "api" if (backend == "api" and has_key) else "cached"
        self.is_live = self.backend == "api"

    # cache helpers
    def _cache_path(self, tag: str, prompt: str):
        digest = hashlib.sha256(f"{tag}||{prompt}".encode()).hexdigest()[:16]
        return config.CACHE_DIR / f"{tag}_{digest}.json"

    # public interface
    def select(self, key: str, names: list[str], budget: int, seed: int) -> list[int]:
        """Return `budget` feature indices chosen by the knowledge prior."""
        if self.backend == "cached":
            return self._cached_select(key, budget, seed)
        path = self._cache_path("select", f"{key};k={budget};seed={seed};{names}")
        if path.exists():
            return json.loads(path.read_text())["idx"]
        idx = self._api_select(names, budget)
        path.write_text(json.dumps({"idx": idx}))
        return idx

    def construct(self, key: str, names: list[str]) -> list[tuple]:
        """Return clinically motivated (op, feature_a, feature_b, rationale) tuples."""
        if self.backend == "cached":
            return [tuple(c) for c in CACHED_LLM_PRIOR[key]["construct"]
                    if c[1] in names and c[2] in names]
        path = self._cache_path("construct", f"{key};{names}")
        if path.exists():
            return [tuple(c) for c in json.loads(path.read_text())["cons"]]
        cons = self._api_construct(names)
        path.write_text(json.dumps({"cons": cons}))
        return cons

    def explain(self, phenotype: str, names: list[str], used_idx: list[int]) -> str:
        """Natural-language gloss of an evolved rule, for the faithfulness check."""
        feats = [names[i] for i in used_idx]
        if not feats:
            return "The rule references no clinical feature."
        if self.backend == "cached":
            return ("The classifier scores the positive class from "
                    + ", ".join(feats) + "; larger values raise the positive score.")
        return self._api_explain(phenotype, feats)

    # cached path
    def _cached_select(self, key: str, budget: int, seed: int) -> list[int]:
        """Fix the core, then sample the remaining slots from the margin."""
        core = list(CACHED_LLM_PRIOR[key]["select"])
        if len(core) >= budget:
            return sorted(core[:budget])
        margin = [i for i in CACHED_LLM_PRIOR["margin"].get(key, []) if i not in core]
        rng = random.Random(7_000 + seed)
        extra = rng.sample(margin, min(budget - len(core), len(margin)))
        return sorted(core + extra)

    # live API path
    def _client(self):
        import anthropic
        return anthropic.Anthropic()

    def _text(self, message) -> str:
        return "".join(b.text for b in message.content if getattr(b, "type", "") == "text")

    def _api_select(self, names: list[str], budget: int) -> list[int]:
        prompt = (f"You are a clinical expert. Using ONLY these feature names, and no data, "
                  f"return the 0-based indices of the {budget} most clinically informative "
                  f"features as a comma-separated list and nothing else:\n"
                  + "\n".join(f"{i}: {n}" for i, n in enumerate(names)))
        msg = self._client().messages.create(
            model=config.LLM_MODEL, max_tokens=150, temperature=0.0,
            messages=[{"role": "user", "content": prompt}])
        found = [int(x) for x in re.findall(r"\d+", self._text(msg)) if int(x) < len(names)]
        return sorted(dict.fromkeys(found))[:budget]

    def _api_construct(self, names: list[str]) -> list[tuple]:
        prompt = ("You are a clinical expert. Propose 5 clinically meaningful engineered "
                  "features as a JSON list of [op, feature_a, feature_b, rationale]; op must "
                  "be one of [ratio, product, diff, sum]; use ONLY these feature names: "
                  + ", ".join(names) + ". Return JSON only.")
        msg = self._client().messages.create(
            model=config.LLM_MODEL, max_tokens=400, temperature=0.0,
            messages=[{"role": "user", "content": prompt}])
        txt = self._text(msg)
        txt = txt[txt.find("["): txt.rfind("]") + 1]
        out = []
        for row in json.loads(txt):
            op, a, b = row[0], row[1], row[2]
            if op in OPERATORS and a in names and b in names:
                out.append((op, a, b, row[3] if len(row) > 3 else ""))
        return out

    def _api_explain(self, phenotype: str, feats: list[str]) -> str:
        prompt = (f"In two plain clinical sentences, explain this decision rule. "
                  f"Features: {', '.join(feats)}. Rule: {phenotype}")
        msg = self._client().messages.create(
            model=config.LLM_MODEL, max_tokens=200, temperature=0.0,
            messages=[{"role": "user", "content": prompt}])
        return self._text(msg)


LLM = LLMPrior()


# selection arms
def selection_indices(arm: str, X_train, y_train, names, budget, seed, key) -> list[int]:
    """Feature indices for one selection arm. Informed arms use the training
    partition only; none is unrestricted, random is the noise control at budget K."""
    n_features = X_train.shape[1]
    if arm == "none":
        return list(range(n_features))
    if arm == "random":
        return sorted(random.Random(1_000 + seed).sample(range(n_features), budget))
    if arm == "mi":
        scores = mutual_info_classif(X_train, y_train, random_state=config.GLOBAL_SEED)
        return sorted(int(i) for i in np.argsort(scores)[::-1][:budget])
    if arm == "corr":
        scores = np.array([abs(np.corrcoef(X_train[:, i], y_train)[0, 1])
                           for i in range(n_features)])
        scores = np.nan_to_num(scores, nan=0.0)
        return sorted(int(i) for i in np.argsort(scores)[::-1][:budget])
    if arm == "llm":
        return LLM.select(key, names, budget, seed)
    raise ValueError(f"unknown selection arm: {arm}")


# construction arms
def construction_set(arm: str, names, n_new, seed, key) -> list[tuple]:
    """Engineered-feature specifications for one construction arm."""
    if arm == "raw":
        return []
    if arm == "random":
        rng = random.Random(2_000 + seed)
        ops = list(OPERATORS)
        return [(rng.choice(ops), *rng.sample(names, 2), "random control")
                for _ in range(n_new)]
    if arm == "llm":
        return LLM.construct(key, names)
    raise ValueError(f"unknown construction arm: {arm}")


def apply_constructions(X_raw: np.ndarray, names: list[str], constructions: list[tuple]):
    """Append engineered columns to a raw-scale matrix. Operates on raw values
    because ratios of standardised features are unstable; the caller re-standardises
    afterwards on training rows only."""
    columns, new_names = [], list(names)
    for op, a, b, _ in constructions:
        values = OPERATORS[op](X_raw[:, names.index(a)], X_raw[:, names.index(b)])
        columns.append(np.nan_to_num(values, nan=0.0, posinf=0.0, neginf=0.0))
        new_names.append(f"{op}({a},{b})")
    augmented = np.column_stack([X_raw] + columns) if columns else X_raw
    return augmented, new_names
