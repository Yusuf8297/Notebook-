"""Driver: runs the study in resumable, time-bounded slices.

Usage:  python run_study.py <stage> [time_budget_seconds]
Stages: selection | ensemble | construction | baselines | blackbox | ablation
Every stage is safe to re-run; completed cells are skipped.
"""
import sys, time
sys.path.insert(0, __file__.rsplit("/", 1)[0])

from geprior import config, baselines, experiments

SEEDS = range(1, config.N_SEEDS + 1)


def main():
    stage = sys.argv[1]
    budget = float(sys.argv[2]) if len(sys.argv) > 2 else None
    t0 = time.time()
    if stage == "selection":
        experiments.run_selection_study(seeds=SEEDS, time_budget=budget, n_restarts=1)
    elif stage == "ensemble":
        experiments.run_selection_study(
            seeds=SEEDS, arms=["llm"], n_restarts=5, time_budget=budget,
            checkpoint=config.RESULTS_DIR / "ensemble.csv")
    elif stage == "construction":
        experiments.run_construction_study(seeds=SEEDS, time_budget=budget)
    elif stage == "baselines":
        baselines.run_baselines(seeds=SEEDS)
    elif stage == "ablation":
        experiments.run_ablation(time_budget=budget)
    elif stage == "blackbox":
        baselines.run_blackbox_baseline(seeds=SEEDS)
    else:
        raise SystemExit(f"unknown stage: {stage}")
    print(f"{stage}: {time.time()-t0:.0f}s | {config.summary()}")


if __name__ == "__main__":
    main()
