# An Attribution-Controlled Study of Feature Priors in LLM-Guided Grammatical Evolution

Code for the attribution study. The pipeline separates noise, data and knowledge as
sources of a feature prior for Grammatical Evolution (GE) at matched budget, evolves
an interpretable symbolic classifier under each prior, and situates it against a
black-box feature-engineering comparator following the CAAFE paradigm
(Hollmann et al., 2023).

Search uses GRAPE. A prior is injected only by restricting the grammar's terminal
rule to the arm's chosen feature indices; the recursive productions, the constant
menu and every evolutionary operator are held fixed across arms, so the only thing
that differs between conditions is which feature indices the grammar can reach.

## Layout

```
geprior/
  config.py        tunable constants; a run is described by this module plus the seeds
  datasets.py      loaders, per-seed resampling, inner fit/validation partitioning
  priors.py        noise, data and knowledge prior sources; feature construction
  grammar.py       BNF construction, weighted and unweighted families
  vendor.py        GRAPE fetch and compatibility patching
  engine.py        fitness, search, model selection, threshold calibration, ensembling
  baselines.py     conventional classifiers and the black-box FE comparator
  experiments.py   resumable study runners, including the configuration ablation
  statistics.py    Friedman, Wilcoxon, Holm, Cliff's delta, Nemenyi critical difference
  figures.py       standalone figures, PNG and PDF
run_study.py       command-line driver, one stage per invocation
analyse.py         statistical protocol and all figures from saved results
notebooks/         driver notebook and a Colab variant
results/           checkpoints and derived tables
figures/           generated figures
```

## Running

```bash
pip install numpy pandas scipy scikit-learn deap matplotlib
python run_study.py baselines
python run_study.py blackbox
python run_study.py selection      # optional: append a seconds budget, e.g. 600
python run_study.py construction
python run_study.py ensemble
python run_study.py ablation
python analyse.py
```

Every stage is resumable. Results are appended to a CSV keyed by study, dataset, arm
and seed, and any cell already present is skipped, so an interrupted campaign restarts
without recomputation. Passing a time budget in seconds bounds a slice and writes a
checkpoint before returning. `config.N_SEEDS` is 30; the full campaign is roughly two
hours on a single core and parallelises trivially across datasets.

For a live knowledge prior, set `LLM_BACKEND = "api"` in `config.py` and export
`ANTHROPIC_API_KEY`. This draws a fresh response per seed and removes the cached
prior's sampling emulation.

## Running the notebook

`notebooks/GE_Prior_Attribution_Study.ipynb` locates the repository root itself, so it
can be opened from the repository root, from `notebooks/`, or from a workspace folder
that contains the repository somewhere beneath it. For a quick end-to-end check, set
`SMOKE = True` in the first cell: it shrinks the search and the seed count and writes
to `results/_smoke`, leaving the full-run checkpoints untouched.

### If imports fail

Run the bundled checker first; it reports missing files, missing dependencies and the
interpreter in use:

```bash
python VERIFY_INSTALL.py
```

`No module named 'geprior'` means the project is not unpacked where the notebook can
see it. `No module named 'numpy'` means the Jupyter kernel points at an interpreter
without the dependencies: a freshly selected "Python 3" kernel is often a bare
environment. The notebook's first cell installs into whichever interpreter is running
it, so re-running that cell is usually enough; otherwise select the matching kernel
through Kernel > Change Kernel.

An editable install makes `geprior` importable from any working directory:

```bash
cd ge_prior_attribution
pip install -e .
```

If the package still cannot be found, set the path explicitly in the first cell:

```python
import sys
sys.path.insert(0, r"C:\path\to\ge_prior_attribution")
```

The folder given must be the one that directly contains `geprior/`.

## Running in VS Code on Windows

```powershell
powershell -ExecutionPolicy Bypass -File .\SETUP_WINDOWS.ps1
```

This creates `.venv`, installs the dependencies, registers a Jupyter kernel named
`Python (geprior)`, writes `.vscode/settings.json`, and runs the verifier. To target a
specific interpreter:

```powershell
powershell -ExecutionPolicy Bypass -File .\SETUP_WINDOWS.ps1 -Python "C:\Program Files\Python312\python.exe"
```

Then in VS Code: **File > Open Folder** on the folder that directly contains
`geprior\`, `Ctrl+Shift+P` > **Python: Select Interpreter** > `.venv\Scripts\python.exe`,
open the notebook and select the **Python (geprior)** kernel. `.vscode/launch.json`
provides run configurations for the verifier, the selection stage and the analysis.

### Windows Application Control blocking SciPy

On a managed Windows machine the import may fail with an Application Control policy
blocking SciPy's compiled extensions. This is a machine policy, not a project fault;
scikit-learn requires SciPy, so SciPy cannot be removed. Diagnose the mechanism with:

```powershell
powershell -ExecutionPolicy Bypass -File .\DIAGNOSE_WINDOWS.ps1
```

Workarounds, in rough order of convenience: run under WSL2 (`wsl --install -d Ubuntu`,
then `bash SETUP_WSL.sh`), which stays entirely local; use `notebooks/Run_On_Colab.ipynb`;
install a system-wide Miniforge/Anaconda distribution, which managed policies often
permit where a per-user install is not; or request an IT allow-list exemption for the
Python installation directory.

## Statistical protocol

Median-based throughout. Per-dataset Friedman tests over the seed-paired resamples
carry the inference; the cross-dataset mean rank is descriptive only, since four
datasets cannot power a Demsar critical-difference diagram. `critical_difference`
raises rather than falling back when `k` is outside the tabulated range, since a
fallback to a smaller `k` yields a critical difference that is too small. The three
confirmatory contrasts in `config.PREREGISTERED_CONTRASTS` are fixed before any run;
any comparison computed after the fact is exploratory.

## Reproducibility notes

GRAPE requires two behaviour-preserving compatibility patches to run under NumPy 2.x
and Python 3.12, applied in `vendor.py`: a float bound in a `random.randint` call, and
the removed `np.NaN` alias.

The test partition is never passed to `engine.search`, which is the structural
guarantee against leakage; model selection and threshold calibration see only the
inner validation fold carved from the training partition.
